import express from "express";
import http from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, Modality, ThinkingLevel, GenerateVideosOperation } from "@google/genai";
import Groq from "groq-sdk";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;
const app = express();
app.use(express.json({ limit: "50mb" }));

// Lazy GoogleGenAI client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not configured.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Lazy Groq client
let groqClient: Groq | null = null;
function getGroq(): Groq {
  if (!groqClient) {
    const key = process.env.GROQ_API_KEY;
    if (!key || !key.trim()) {
      throw new Error(
        "GROQ_API_KEY no está configurada. Puedes agregar tu clave en las variables de entorno del proyecto para activar Groq LPU."
      );
    }
    groqClient = new Groq({ apiKey: key.trim() });
  }
  return groqClient;
}

let groqDisabledDueToPermission = false;
function hasGroq(): boolean {
  return (
    !groqDisabledDueToPermission &&
    Boolean(process.env.GROQ_API_KEY && process.env.GROQ_API_KEY.trim().length > 0)
  );
}

// 1. Health check & Available Providers
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    hasGroqKey: hasGroq(),
    time: new Date().toISOString(),
  });
});

app.get("/api/providers", (_req, res) => {
  res.json({
    gemini: {
      id: "gemini",
      name: "Google Gemini",
      isConfigured: Boolean(process.env.GEMINI_API_KEY),
      models: [
        { id: "gemini-3.8-flash", name: "Gemini 3.8 Flash", desc: "Recomendado, multimodal y alta estabilidad", recommended: true },
        { id: "gemini-3.1-flash-lite", name: "Gemini 3.1 Flash Lite", desc: "Máxima velocidad y mayor cuota" },
        { id: "gemini-flash-latest", name: "Gemini Flash Latest", desc: "Equilibrado y rápido" },
      ],
    },
    groq: {
      id: "groq",
      name: "Groq (LPU Ultra-Rápido)",
      isConfigured: hasGroq(),
      models: [
        { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B", desc: "Razonamiento profundo e inteligencia (128K)", recommended: true },
        { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B Instant", desc: "Velocidad extrema (<400ms)" },
        { id: "llama-3.2-11b-vision-preview", name: "Llama 3.2 11B Vision", desc: "Visión multimodal para documentos e imágenes" },
      ],
    },
  });
});

// Helper to extract clean error messaging and detect 429 quota exhaustion or 503 high demand
function formatApiError(error: any) {
  let rawMsg = String(error?.message || "");
  let parsedCode = error?.code || error?.status;

  // Try to parse JSON from error.message if Gemini SDK formatted it as JSON string
  try {
    const parsed = JSON.parse(rawMsg);
    if (parsed?.error) {
      if (parsed.error.message) rawMsg = parsed.error.message;
      if (parsed.error.code) parsedCode = parsed.error.code;
    }
  } catch (_) {
    // Not a JSON string
  }

  const status = parsedCode;
  const is429 =
    status === 429 ||
    status === "RESOURCE_EXHAUSTED" ||
    rawMsg.includes("429") ||
    rawMsg.includes("RESOURCE_EXHAUSTED") ||
    rawMsg.includes("quota") ||
    rawMsg.includes("Quota exceeded");

  const is503 =
    status === 503 ||
    status === "UNAVAILABLE" ||
    rawMsg.includes("503") ||
    rawMsg.includes("UNAVAILABLE") ||
    rawMsg.includes("high demand") ||
    rawMsg.includes("overloaded");

  let retrySeconds = 0;
  const retryMatch = rawMsg.match(/retry in ([0-9.]+)s/i);
  if (retryMatch) {
    retrySeconds = Math.ceil(parseFloat(retryMatch[1]));
  }

  let userMessage = rawMsg || "Ocurrió un error al procesar la solicitud.";
  if (is429) {
    userMessage = `Límite de cuota alcanzado en Gemini (429). ${
      hasGroq()
        ? "Puedes conmutar al proveedor Groq (LPU) o usar Gemini 3.1 Flash Lite para continuar sin esperas."
        : retrySeconds > 0
        ? `Espera ${retrySeconds}s, cambia a Gemini 3.1 Flash Lite, o activa GROQ_API_KEY para redundancia multi-proveedor.`
        : "Cambia al modelo Gemini 3.1 Flash Lite o activa GROQ_API_KEY en ajustes para redundancia multi-proveedor."
    }`;
  } else if (is503) {
    userMessage = `Servicio con alta demanda temporal (503). ${
      hasGroq()
        ? "Puedes utilizar Groq (LPU) o cambiar a Gemini 3.1 Flash Lite."
        : "Cambia a Gemini 3.1 Flash Lite o reintenta en unos instantes."
    }`;
  }

  return {
    error: userMessage,
    isQuotaExceeded: is429,
    isHighDemand: is503,
    retrySeconds,
    hasGroqConfigured: hasGroq(),
    rawDetails: rawMsg,
  };
}

// Helper to normalize file inputs (whether single file, multiple files, plain text, or data URLs)
function normalizeFileInputs(rawBody: any): Array<{
  fileData: string;
  mimeType: string;
  fileName: string;
  isText: boolean;
  textContent?: string;
  cleanBase64: string;
}> {
  const files: Array<{
    fileData: string;
    mimeType: string;
    fileName: string;
    isText: boolean;
    textContent?: string;
    cleanBase64: string;
  }> = [];

  const rawList =
    Array.isArray(rawBody?.files) && rawBody.files.length > 0
      ? rawBody.files
      : rawBody?.fileData || rawBody?.data || rawBody?.base64
      ? [rawBody]
      : [];

  // If text or notes are passed directly without fileData wrapper, treat as text document
  if (rawList.length === 0 && (rawBody?.text || rawBody?.rawText || rawBody?.textContent || rawBody?.content)) {
    const directText = String(rawBody.text || rawBody.rawText || rawBody.textContent || rawBody.content).trim();
    if (directText) {
      const b64 = Buffer.from(directText, "utf-8").toString("base64");
      files.push({
        fileData: directText,
        mimeType: "text/plain",
        fileName: rawBody.fileName || "Nota_Documento.txt",
        isText: true,
        textContent: directText,
        cleanBase64: b64,
      });
      return files;
    }
  }

  for (let i = 0; i < rawList.length; i++) {
    const f = rawList[i];
    let raw = String(f.fileData || f.data || f.base64 || "").trim();
    if (!raw) continue;

    let mime = String(f.mimeType || f.type || "application/octet-stream").trim().toLowerCase();
    const name = f.fileName || f.name || `Documento_${i + 1}`;

    if (raw.startsWith("data:")) {
      const commaIdx = raw.indexOf(",");
      if (commaIdx !== -1) {
        const header = raw.slice(0, commaIdx);
        raw = raw.slice(commaIdx + 1).replace(/\s/g, "");
        const mimeMatch = header.match(/data:([^;]+)/);
        if (mimeMatch) {
          mime = mimeMatch[1].toLowerCase();
        }
      }
    }

    const isTextMime =
      mime.startsWith("text/") ||
      mime === "application/json" ||
      mime === "application/csv" ||
      mime === "application/xml" ||
      mime === "image/svg+xml";

    if (isTextMime) {
      let decodedText = "";
      const cleanNoSpace = raw.replace(/\s/g, "");
      const isBase64Pattern =
        /^[A-Za-z0-9+/=]+$/.test(cleanNoSpace) && cleanNoSpace.length % 4 === 0;
      if (isBase64Pattern) {
        try {
          const buf = Buffer.from(cleanNoSpace, "base64");
          const utf = buf.toString("utf-8");
          if (/^[\x20-\x7E\s\u00A0-\uFFFF]*$/.test(utf)) {
            decodedText = utf;
          } else {
            decodedText = raw;
          }
        } catch {
          decodedText = raw;
        }
      } else {
        decodedText = raw;
      }
      const b64 = Buffer.from(decodedText, "utf-8").toString("base64");
      files.push({
        fileData: raw,
        mimeType: mime,
        fileName: name,
        isText: true,
        textContent: decodedText,
        cleanBase64: b64,
      });
    } else {
      const cleanB64 = raw.replace(/\s/g, "");
      files.push({
        fileData: raw,
        mimeType: mime,
        fileName: name,
        isText: false,
        cleanBase64: cleanB64,
      });
    }
  }

  return files;
}

// Multi-tier Fallback Generator for Gemini API Quota resiliency and high-demand failover
async function generateWithQuotaFallback(
  ai: GoogleGenAI,
  preferredModel: string,
  contents: any,
  config: any
): Promise<{ response: any; modelUsed: string }> {
  // Ordered sequence of fallback models to survive free tier daily quotas (e.g. gemini-3.8-flash has 20 requests/day limit)
  // and temporary high demand spikes (503 UNAVAILABLE)
  const candidateModels = [
    preferredModel,
    "gemini-3.8-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest",
    "gemini-2.5-flash",
  ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      console.log(`[Gemini Request] Invoking model: ${model}`);
      // Remove thinkingConfig if falling back to a model that does not support it
      const reqConfig = { ...config };
      if (model !== preferredModel && reqConfig.thinkingConfig) {
        delete reqConfig.thinkingConfig;
      }

      let response;
      try {
        response = await ai.models.generateContent({
          model,
          contents,
          config: reqConfig,
        });
      } catch (innerErr: any) {
        // If it failed and tools (e.g. Google Search) was attached, retry without tools
        if (reqConfig.tools) {
          console.info(`[Model Retry] Retrying model ${model} without tools...`);
          const configNoTools = { ...reqConfig };
          delete configNoTools.tools;
          response = await ai.models.generateContent({
            model,
            contents,
            config: configNoTools,
          });
        } else {
          throw innerErr;
        }
      }

      return { response, modelUsed: model };
    } catch (err: any) {
      lastError = err;
      let rawMsg = String(err?.message || "");
      let status = err?.status || err?.code;

      try {
        const parsed = JSON.parse(rawMsg);
        if (parsed?.error) {
          if (parsed.error.message) rawMsg = parsed.error.message;
          if (parsed.error.code) status = parsed.error.code;
        }
      } catch (_) {}
      
      const isQuotaOrRateLimit =
        status === 429 ||
        status === "RESOURCE_EXHAUSTED" ||
        rawMsg.includes("429") ||
        rawMsg.includes("RESOURCE_EXHAUSTED") ||
        rawMsg.includes("quota") ||
        rawMsg.includes("Rate limit");

      const isUnavailableOrBusy =
        status === 503 ||
        status === "UNAVAILABLE" ||
        status === 504 ||
        status === "DEADLINE_EXCEEDED" ||
        rawMsg.includes("503") ||
        rawMsg.includes("UNAVAILABLE") ||
        rawMsg.includes("high demand") ||
        rawMsg.includes("overloaded");

      const isNotFoundOrUnsupported =
        status === 404 ||
        status === "NOT_FOUND" ||
        rawMsg.includes("404") ||
        rawMsg.includes("not found") ||
        rawMsg.includes("is not supported") ||
        rawMsg.includes("PERMISSION_DENIED");

      if (isQuotaOrRateLimit || isUnavailableOrBusy || isNotFoundOrUnsupported) {
        console.info(`[Model Retry] Switching candidate: ${model} -> next available...`);
        continue;
      }
      
      // If it's another non-transient error, rethrow immediately
      throw err;
    }
  }

  throw lastError;
}

// Groq chat handler
async function callGroqChat(
  messages: Array<{ role: string; content: string; attachment?: { data: string; type: string; name?: string } }>,
  model: string = "llama-3.3-70b-versatile",
  systemInstruction?: string
): Promise<{ reply: string; modelUsed: string }> {
  const groq = getGroq();

  const hasImage = messages.some((m) => m.attachment?.type?.startsWith("image/"));
  let targetModel = (model && model.startsWith("llama-")) ? model : "llama-3.3-70b-versatile";
  if (hasImage && !targetModel.includes("vision")) {
    targetModel = "llama-3.2-11b-vision-preview";
  }

  const groqMessages: any[] = [];
  if (systemInstruction) {
    groqMessages.push({ role: "system", content: systemInstruction });
  }

  for (const m of messages) {
    const role = m.role === "assistant" ? "assistant" : "user";
    if (m.attachment?.data && m.attachment?.type?.startsWith("image/")) {
      const dataUrl = m.attachment.data.startsWith("data:")
        ? m.attachment.data
        : `data:${m.attachment.type};base64,${m.attachment.data}`;

      groqMessages.push({
        role,
        content: [
          { type: "text", text: m.content || "Analiza esta imagen adjunta." },
          { type: "image_url", image_url: { url: dataUrl } },
        ],
      });
    } else if (m.attachment?.data) {
      let textContent = m.attachment.data;
      if (m.attachment.data.includes(",")) {
        try {
          textContent = Buffer.from(m.attachment.data.split(",")[1], "base64").toString("utf-8");
        } catch {
          textContent = m.attachment.data;
        }
      }
      groqMessages.push({
        role,
        content: `${m.content || ""}\n\n[Documento Adjunto: ${m.attachment.name || "archivo"}]\n${textContent}`,
      });
    } else {
      groqMessages.push({
        role,
        content: m.content || "",
      });
    }
  }

  console.log(`[Groq Request] Invoking model: ${targetModel}`);
  let completion: any;
  try {
    completion = await groq.chat.completions.create({
      model: targetModel,
      messages: groqMessages,
      temperature: 0.3,
      max_tokens: 4096,
    });
  } catch (err: any) {
    const msg = String(err?.message || "");
    if (msg.includes("blocked_org") || msg.includes("model_not_found") || err?.status === 403 || err?.status === 404) {
      groqDisabledDueToPermission = true;
      console.warn("[Groq Warning] Groq API key is restricted or lacks model permissions. Disabling Groq failover.");
    }
    throw err;
  }

  const reply = completion.choices[0]?.message?.content || "No se generó respuesta desde Groq.";
  return { reply, modelUsed: targetModel };
}

// Groq structured document intelligence extraction
async function callGroqDocumentExtraction(
  files: Array<{ fileData: string; mimeType: string; fileName?: string }>,
  extractionMode: string,
  customPrompt?: string,
  preferredModel?: string
): Promise<{ data: any; modelUsed: string }> {
  const groq = getGroq();

  const hasImage = files.some((f) => f.mimeType.startsWith("image/"));
  const targetModel = (preferredModel && preferredModel.startsWith("llama-"))
    ? preferredModel
    : (hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile");
  const isMulti = files.length > 1;

  const fileTitles = files.map((f, i) => `[Archivo ${i + 1}: ${f.fileName || 'Documento'}]`).join(", ");

  const prompt = `
Act as an expert multimodal document intelligence and business analyst.
You are analyzing ${isMulti ? `${files.length} related documents: ${fileTitles}` : `a document titled: "${files[0]?.fileName || 'Documento'}"`}.
${isMulti ? `CRITICAL MULTI-DOCUMENT INSTRUCTION: You MUST cross-reference all ${files.length} documents. Complement information from one document with data from the others (for instance, linking orders to invoices, receipts to statements, comparing terms, aggregating line items, or combining parts into a coherent whole). Highlight connections and cross-document insights.` : ''}

Goal: Read and extract all text, numbers, entities, dates, itemized rows, tables, and narrative summaries, and structure them so they can be seamlessly inserted into Google Docs and Google Sheets.

Extraction Mode: "${extractionMode}".
${customPrompt ? `User Specific Instructions: "${customPrompt}"` : ""}

You MUST return a clean, valid JSON object with EXACTLY this structure:
{
  "documentType": "string (Classification in Spanish, e.g. ${isMulti ? 'Análisis Consolidado Multidocumento: Facturas y Comprobantes' : 'Factura Comercial, Recibo de Gastos, Contrato Legal'})",
  "documentSummary": "string (Detailed executive summary in Spanish explaining purpose, dates, amounts, parties${isMulti ? ', and how the documents complement each other' : ''})",
  "keyDataPoints": [
    { "label": "string", "value": "string" }
  ],
  ${isMulti ? `"crossDocumentInsights": [
    "string (Insight explaining complementary details found by combining documents, e.g. El comprobante #2 confirma el pago pendiente indicado en la factura #1)"
  ],
  "sourceFilesCount": ${files.length},
  "sourceFileNames": ${JSON.stringify(files.map(f => f.fileName || 'Documento'))},` : ''}
  "docsContent": {
    "title": "string (Professional document title for a new Google Doc${isMulti ? ' - Consolidado' : ''})",
    "formattedText": "string (Clear structured plain text with uppercase section headers and bullet points ready to insert into Google Docs)",
    "markdown": "string (Rich Markdown version with headings, bullet points, and tables)"
  },
  "sheetsData": {
    "title": "string (Suggested title for a Google Sheet)",
    "headers": ${isMulti ? '["Documento de Origen", "Fecha", "Concepto / Descripción", "Categoría", "Cantidad", "Precio Unitario", "Total"]' : '["Fecha", "Concepto / Descripción", "Categoría", "Cantidad", "Precio Unitario", "Total"]'},
    "rows": [["val1", "val2", "val3", "val4", "val5", "val6"${isMulti ? ', "val7"' : ''}]],
    "sheetName": "string (e.g. Datos Consolidados)"
  },
  "suggestedActions": ["string"]
}
`;

  const contentParts: any[] = [{ type: "text", text: prompt }];

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const isImg = f.mimeType.startsWith("image/");
    if (isImg) {
      const dataUrl = f.fileData.startsWith("data:") ? f.fileData : `data:${f.mimeType};base64,${f.fileData}`;
      contentParts.push({ type: "image_url", image_url: { url: dataUrl } });
    } else {
      let textContent = f.fileData;
      if (f.fileData.includes(",")) {
        try {
          textContent = Buffer.from(f.fileData.split(",")[1], "base64").toString("utf-8");
        } catch {
          textContent = f.fileData;
        }
      }
      contentParts.push({
        type: "text",
        text: `\n\n[Documento ${i + 1}/${files.length}: ${f.fileName || 'archivo'}]:\n${textContent}`,
      });
    }
  }

  const messages = [{ role: "user", content: contentParts }];

  console.log(`[Groq Extraction] Invoking model: ${targetModel} for ${files.length} document(s)`);
  let completion: any;
  try {
    completion = await groq.chat.completions.create({
      model: targetModel,
      messages: messages as any,
      response_format: { type: "json_object" },
      temperature: 0.1,
      max_tokens: 4096,
    });
  } catch (err: any) {
    const msg = String(err?.message || "");
    if (msg.includes("blocked_org") || msg.includes("model_not_found") || err?.status === 403 || err?.status === 404) {
      groqDisabledDueToPermission = true;
      console.warn("[Groq Warning] Groq API key is restricted or lacks model permissions. Disabling Groq failover.");
    }
    throw err;
  }

  const rawJson = completion.choices[0]?.message?.content;
  if (!rawJson) {
    throw new Error("Groq no devolvió ningún contenido JSON.");
  }

  let parsed: any;
  try {
    parsed = JSON.parse(rawJson);
  } catch {
    const match = rawJson.match(/\{[\s\S]*\}/);
    if (match) {
      parsed = JSON.parse(match[0]);
    } else {
      throw new Error("No se pudo analizar la respuesta JSON de Groq.");
    }
  }

  return { data: parsed, modelUsed: targetModel };
}

// 2. Multi-turn Chat & Automation endpoint (Gemini & Groq Multi-Provider)
app.post("/api/chat", async (req, res) => {
  try {
    const {
      messages,
      systemInstruction,
      model = "gemini-3.8-flash",
      provider = "gemini",
      enableThinking = false,
      useGoogleSearch = false,
      workflowContext,
    } = req.body;

    const isGroq = provider === "groq" || String(model).startsWith("llama-");

    let sysInstruction = systemInstruction || 
      "You are an intelligent executive voice & workflow AI assistant connected directly to Google Workspace (Google Docs and Google Sheets) and Obsidian.\n" +
      "You speak clearly and concisely in conversational Spanish, helping users plan, execute, and automate tasks.\n\n" +
      "GOOGLE WORKSPACE AUTOMATIC ACTION INSTRUCTION:\n" +
      "The application creates and edits Google Docs and Google Sheets AUTOMATICALLY in real time without requiring the user to click any button or confirmation.\n" +
      "When the user requests or indicates creating or modifying a document or spreadsheet (for example: 'crea un documento...', 'crea una hoja de cálculo...', 'haz una tabla en sheets...', 'haz un doc...'):\n" +
      "1. Confirm warmly in conversational Spanish what you are creating.\n" +
      "2. ALWAYS provide the complete structured payload using a designated workspace action block at the end of your response:\n" +
      "```workspace_action\n" +
      "{\n" +
      "  \"action\": \"create_doc\" | \"create_sheet\" | \"append_sheet\",\n" +
      "  \"title\": \"Título claro y descriptivo\",\n" +
      "  \"content\": \"Texto completo formateado con títulos, secciones y puntos para Google Docs\",\n" +
      "  \"headers\": [\"Columna 1\", \"Columna 2\", \"Columna 3\"],\n" +
      "  \"rows\": [[\"val 1\", \"val 2\", \"val 3\"]],\n" +
      "  \"sheetName\": \"Hoja 1\",\n" +
      "  \"summary\": \"Breve descripción de la acción que se va a ejecutar\"\n" +
      "}\n" +
      "```\n" +
      "Make sure the content or rows are comprehensive, formatted, and high quality.";
    
    if (workflowContext) {
      sysInstruction += `\nCurrent Workspace Status: ${JSON.stringify(workflowContext)}`;
    }

    if (isGroq) {
      const groqResult = await callGroqChat(messages, model || "llama-3.3-70b-versatile", sysInstruction);
      return res.json({
        reply: groqResult.reply,
        model: groqResult.modelUsed,
        provider: "groq",
        usedThinking: false,
      });
    }

    // Default: Gemini with automatic failover to Groq if Gemini hits quota/availability errors
    let ai: GoogleGenAI;
    try {
      ai = getAI();
    } catch (keyErr: any) {
      if (hasGroq()) {
        console.warn("[Failover] Gemini key not configured, falling back to Groq LPU...");
        const groqResult = await callGroqChat(messages, "llama-3.3-70b-versatile", sysInstruction);
        return res.json({
          reply: groqResult.reply,
          model: groqResult.modelUsed,
          provider: "groq",
          failoverOccurred: true,
          failoverNotice: "Gemini no está configurado. La respuesta se generó a través de Groq LPU.",
          usedThinking: false,
        });
      }
      throw keyErr;
    }

    // Map model based on requested or specific tier
    let chosenModel = "gemini-3.8-flash";
    if (useGoogleSearch) {
      chosenModel = "gemini-3.8-flash";
    } else if (model === "gemini-3.1-pro-preview" || enableThinking) {
      chosenModel = "gemini-3.1-pro-preview";
    } else if (model === "gemini-3.1-flash-lite") {
      chosenModel = "gemini-3.1-flash-lite";
    } else if (model === "gemini-3.8-flash" || model === "gemini-flash-latest") {
      chosenModel = model;
    }

    const config: any = {};
    config.systemInstruction = sysInstruction;

    // Enable Google Search Grounding
    if (useGoogleSearch || model?.includes("search")) {
      config.tools = [{ googleSearch: {} }];
    }

    if (enableThinking || chosenModel === "gemini-3.1-pro-preview") {
      config.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH,
      };
    }

    const contents = (messages || []).map((m: { role: string; content: string; attachment?: { data: string; type: string; name?: string } }) => {
      const parts: any[] = [];
      if (m.attachment?.data && m.attachment?.type) {
        const cleanData = m.attachment.data.includes(",") ? m.attachment.data.split(",")[1] : m.attachment.data;
        parts.push({
          inlineData: {
            mimeType: m.attachment.type,
            data: cleanData,
          },
        });
      }
      parts.push({ text: m.content || "Analyze the attached file." });
      return {
        role: m.role === "assistant" ? "model" : m.role,
        parts,
      };
    });

    if (contents.length === 0) {
      return res.status(400).json({ error: "No messages provided." });
    }

    try {
      const { response, modelUsed } = await generateWithQuotaFallback(
        ai,
        chosenModel,
        contents,
        config
      );

      const replyText = response.text || "No response generated.";

      // Extract Google Search grounding sources if present
      const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      let groundingSources: { title: string; uri: string }[] = [];
      if (Array.isArray(rawChunks)) {
        groundingSources = rawChunks
          .map((c: any) => ({
            title: c.web?.title || "Fuente Web",
            uri: c.web?.uri || "",
          }))
          .filter((s) => Boolean(s.uri));
      }

      return res.json({
        reply: replyText,
        model: modelUsed,
        provider: "gemini",
        usedThinking: Boolean(enableThinking || modelUsed === "gemini-3.1-pro-preview"),
        groundingSources,
      });
    } catch (geminiError: any) {
      // If Gemini quota/demand is exhausted and Groq is configured, seamlessly failover!
      if (hasGroq()) {
        try {
          console.warn("[Multi-Provider Failover] Gemini failed, seamlessly routing request to Groq LPU...");
          const groqResult = await callGroqChat(messages, "llama-3.3-70b-versatile", sysInstruction);
          return res.json({
            reply: groqResult.reply,
            model: groqResult.modelUsed,
            provider: "groq",
            failoverOccurred: true,
            failoverNotice: "Gemini experimentó límites de disponibilidad. La respuesta se generó a través de Groq LPU.",
            usedThinking: false,
          });
        } catch (groqErr) {
          console.warn("[Multi-Provider Failover] Groq failover also failed:", groqErr);
        }
      }
      throw geminiError;
    }
  } catch (error: any) {
    console.error("Chat API Error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 2b. Multimodal Document & Image Extraction Endpoint (Gemini & Groq Multi-Provider with Multi-Document Support)
app.post("/api/analyze-document", async (req, res) => {
  try {
    const {
      extractionMode = "hybrid",
      customPrompt,
      enableThinking = false,
      model = "gemini-3.8-flash",
      provider = "gemini",
    } = req.body;

    // Normalize input into an array of files with robust encoding support
    const files = normalizeFileInputs(req.body);

    if (files.length === 0) {
      return res.status(400).json({ error: "At least one document or image file is required." });
    }

    const isGroq = provider === "groq" || String(model).startsWith("llama-");
    const isMulti = files.length > 1;

    if (isGroq) {
      const groqResult = await callGroqDocumentExtraction(
        files,
        extractionMode,
        customPrompt,
        model
      );
      return res.json({
        success: true,
        data: groqResult.data,
        model: groqResult.modelUsed,
        provider: "groq",
      });
    }

    // Default: Gemini extraction with automatic Groq failover
    let ai: GoogleGenAI;
    try {
      ai = getAI();
    } catch (keyErr: any) {
      if (hasGroq()) {
        try {
          console.warn("[Failover] Gemini key not configured, routing document extraction to Groq LPU...");
          const groqResult = await callGroqDocumentExtraction(
            files,
            extractionMode,
            customPrompt
          );
          return res.json({
            success: true,
            data: groqResult.data,
            model: groqResult.modelUsed,
            provider: "groq",
            failoverOccurred: true,
            failoverNotice: "Gemini no configurado. Extracción completada a través de Groq LPU.",
          });
        } catch (groqErr) {
          console.warn("[Failover] Groq failover failed:", groqErr);
        }
      }
      throw keyErr;
    }
    
    let chosenModel = "gemini-3.8-flash";
    if (enableThinking) {
      chosenModel = "gemini-3.1-pro-preview";
    } else if (model === "gemini-3.1-flash-lite" || model === "gemini-3.8-flash" || model === "gemini-flash-latest") {
      chosenModel = model;
    }

    const fileTitles = files.map((f, i) => `[Archivo ${i + 1}: ${f.fileName || 'Documento'}]`).join(", ");

    const prompt = `
Act as an expert multimodal document intelligence and business analyst.
You are analyzing ${isMulti ? `${files.length} related documents: ${fileTitles}` : `an image or complex document (invoice, receipt, contract, legal agreement, financial statement, spreadsheet screenshot, chart, handwritten memo, technical report, or data table) titled: "${files[0]?.fileName || 'Documento'}"`}.

${isMulti ? `CRITICAL MULTI-DOCUMENT INSTRUCTION: You MUST cross-reference all ${files.length} documents. Complement information from one document with data from the others (for instance, linking orders to invoices, receipts to statements, comparing terms, aggregating line items, or combining parts into a coherent whole). Highlight connections and cross-document insights.` : ''}

Goal: Read and extract all text, numbers, entities, dates, itemized rows, tables, and narrative summaries, and structure them so they can be seamlessly inserted into Google Docs and Google Sheets.

Extraction Mode: "${extractionMode}".
${customPrompt ? `User Specific Instructions: "${customPrompt}"` : ""}

Generate a clean JSON object with this exact schema:
{
  "documentType": string, // Specific document classification in Spanish, e.g. "${isMulti ? 'Análisis Consolidado Multidocumento: Facturas y Comprobantes' : 'Factura Comercial, Recibo de Gastos, Contrato Legal'}"
  "documentSummary": string, // Detailed executive summary in Spanish explaining the purpose, key entities, totals, dates, and conclusions${isMulti ? ', and how the documents complement each other' : ''}.
  "keyDataPoints": [ // 4 to 10 critical key-value facts extracted across the document(s)
    { "label": string, "value": string }
  ],
  ${isMulti ? `"crossDocumentInsights": [
    string // 2 to 4 insights explaining how the documents complement each other, e.g. "El documento B detalla los impuestos que no estaban desglosados en el documento A."
  ],
  "sourceFilesCount": ${files.length},
  "sourceFileNames": ${JSON.stringify(files.map(f => f.fileName || 'Documento'))},` : ''}
  "docsContent": {
    "title": string, // Professional document title for a new Google Doc${isMulti ? ' - Consolidado' : ''}
    "formattedText": string, // Clear structured plain text with uppercase section headers and bullet points ready to insert into Google Docs
    "markdown": string // Rich Markdown version with # Headings, bullet points, and tables
  },
  "sheetsData": {
    "title": string, // Suggested title for a Google Sheet
    "headers": string[], // Column names for tabular data (e.g. ${isMulti ? '["Documento de Origen", "Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]' : '["Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]'})
    "rows": (string | number)[][], // 2D array of rows. For each line item or data row, provide a complete row matching the headers. Keep numbers clean.
    "sheetName": string // Clean name for the sheet tab, e.g. "${isMulti ? 'Datos Consolidados' : 'Datos Extraídos'}"
  },
  "suggestedActions": string[] // 3-4 recommended action steps
}

Ensure the extracted table in "sheetsData" is as thorough as possible, capturing every single itemized line or row visible across all documents.
Return ONLY valid JSON.
`;

    const config: any = {
      responseMimeType: "application/json",
      systemInstruction: "You are an elite multimodal document intelligence system with vision capabilities. You extract data with 100% precision from images, PDFs, charts, receipts, and complex documents, synthesizing and cross-referencing multiple files seamlessly.",
    };

    if (enableThinking) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    }

    const parts: any[] = [];

    // Add each file as text or inlineData part with description
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.isText && f.textContent) {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]\n--- CONTENIDO DEL DOCUMENTO ---\n${f.textContent}\n--- FIN DEL DOCUMENTO ---`,
        });
      } else {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]`,
        });
        parts.push({
          inlineData: {
            mimeType: f.mimeType,
            data: f.cleanBase64,
          },
        });
      }
    }

    parts.push({ text: prompt });

    const contents = [
      {
        role: "user",
        parts,
      },
    ];

    try {
      const { response, modelUsed } = await generateWithQuotaFallback(
        ai,
        chosenModel,
        contents,
        config
      );

      const text = response.text || "{}";
      let parsedData: any;
      try {
        parsedData = JSON.parse(text);
      } catch {
        const match = text.match(/\{[\s\S]*\}/);
        if (match) {
          parsedData = JSON.parse(match[0]);
        } else {
          throw new Error("Unable to parse structured JSON from model response.");
        }
      }

      return res.json({
        success: true,
        data: parsedData,
        model: modelUsed,
        provider: "gemini",
      });
    } catch (geminiError: any) {
      // Automatic failover to Groq if Gemini is exhausted/unavailable
      if (hasGroq()) {
        try {
          console.warn("[Multi-Provider Failover] Gemini failed, seamlessly routing document extraction to Groq LPU...");
          const groqResult = await callGroqDocumentExtraction(
            files,
            extractionMode,
            customPrompt
          );
          return res.json({
            success: true,
            data: groqResult.data,
            model: groqResult.modelUsed,
            provider: "groq",
            failoverOccurred: true,
            failoverNotice: "Extracción completada mediante Groq LPU debido a alta demanda o cuota en Gemini.",
          });
        } catch (groqErr) {
          console.warn("[Multi-Provider Failover] Groq document extraction also failed:", groqErr);
        }
      }
      throw geminiError;
    }
  } catch (error: any) {
    console.error("Document analysis endpoint error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 2c. Multimodal Document Extraction with Server-Sent Events (SSE) & generateContentStream
async function handleDocumentStreamingAnalysis(req: express.Request, res: express.Response) {
  // Set SSE Headers
  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
  });

  const sendSSE = (event: string, data: any) => {
    if (res.writableEnded) return;
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    if (typeof (res as any).flush === "function") {
      (res as any).flush();
    }
  };

  let isAborted = false;
  res.on("close", () => {
    if (!res.writableEnded) {
      isAborted = true;
    }
  });

  try {
    const {
      extractionMode = "hybrid",
      customPrompt,
      enableThinking = false,
      model = "gemini-3.8-flash",
      provider = "gemini",
    } = req.body;

    const files = normalizeFileInputs(req.body);

    if (files.length === 0) {
      sendSSE("error", { error: "At least one document or image file is required." });
      return res.end();
    }

    const isGroq = provider === "groq" || String(model).startsWith("llama-");
    const isMulti = files.length > 1;

    sendSSE("status", {
      phase: "preparing",
      message: `Procesando ${files.length} documento(s) en modo ${extractionMode}...`,
      fileCount: files.length,
      mode: extractionMode,
    });

    const fileTitles = files.map((f, i) => `[Archivo ${i + 1}: ${f.fileName || 'Documento'}]`).join(", ");

    const prompt = `
Act as an expert multimodal document intelligence and business analyst.
You are analyzing ${isMulti ? `${files.length} related documents: ${fileTitles}` : `an image or complex document (invoice, receipt, contract, legal agreement, financial statement, spreadsheet screenshot, chart, handwritten memo, technical report, or data table) titled: "${files[0]?.fileName || 'Documento'}"`}.

${isMulti ? `CRITICAL MULTI-DOCUMENT INSTRUCTION: You MUST cross-reference all ${files.length} documents. Complement information from one document with data from the others (for instance, linking orders to invoices, receipts to statements, comparing terms, aggregating line items, or combining parts into a coherent whole). Highlight connections and cross-document insights.` : ''}

Goal: Read and extract all text, numbers, entities, dates, itemized rows, tables, and narrative summaries, and structure them so they can be seamlessly inserted into Google Docs and Google Sheets.

Extraction Mode: "${extractionMode}".
${customPrompt ? `User Specific Instructions: "${customPrompt}"` : ""}

Generate a clean JSON object with this exact schema:
{
  "documentType": string, // Specific document classification in Spanish, e.g. "${isMulti ? 'Análisis Consolidado Multidocumento: Facturas y Comprobantes' : 'Factura Comercial, Recibo de Gastos, Contrato Legal'}"
  "documentSummary": string, // Detailed executive summary in Spanish explaining the purpose, key entities, totals, dates, and conclusions${isMulti ? ', and how the documents complement each other' : ''}.
  "keyDataPoints": [ // 4 to 10 critical key-value facts extracted across the document(s)
    { "label": string, "value": string }
  ],
  ${isMulti ? `"crossDocumentInsights": [
    string // 2 to 4 insights explaining how the documents complement each other
  ],
  "sourceFilesCount": ${files.length},
  "sourceFileNames": ${JSON.stringify(files.map(f => f.fileName || 'Documento'))},` : ''}
  "docsContent": {
    "title": string, // Professional document title for a new Google Doc${isMulti ? ' - Consolidado' : ''}
    "formattedText": string, // Clear structured plain text with uppercase section headers and bullet points ready to insert into Google Docs
    "markdown": string // Rich Markdown version with # Headings, bullet points, and tables
  },
  "sheetsData": {
    "title": string, // Suggested title for a Google Sheet
    "headers": string[], // Column names for tabular data (e.g. ${isMulti ? '["Documento de Origen", "Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]' : '["Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]'})
    "rows": (string | number)[][], // 2D array of rows. For each line item or data row, provide a complete row matching the headers. Keep numbers clean.
    "sheetName": string // Clean name for the sheet tab, e.g. "${isMulti ? 'Datos Consolidados' : 'Datos Extraídos'}"
  },
  "suggestedActions": string[] // 3-4 recommended action steps
}

Ensure the extracted table in "sheetsData" is as thorough as possible, capturing every single itemized line or row visible across all documents.
Return ONLY valid JSON.
`;

    // 1. If Groq was specifically selected:
    if (isGroq) {
      const groq = getGroq();
      const hasImage = files.some((f) => f.mimeType.startsWith("image/"));
      const targetModel = (model && model.startsWith("llama-"))
        ? model
        : (hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile");

      sendSSE("status", {
        phase: "streaming",
        message: `Extrayendo datos con Groq LPU (${targetModel}) en tiempo real...`,
        model: targetModel,
        provider: "groq",
      });

      const contentParts: any[] = [{ type: "text", text: prompt }];
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (f.mimeType.startsWith("image/")) {
          const dataUrl = f.fileData.startsWith("data:") ? f.fileData : `data:${f.mimeType};base64,${f.fileData}`;
          contentParts.push({ type: "image_url", image_url: { url: dataUrl } });
        } else {
          let textContent = f.fileData;
          if (f.fileData.includes(",")) {
            try {
              textContent = Buffer.from(f.fileData.split(",")[1], "base64").toString("utf-8");
            } catch {
              textContent = f.fileData;
            }
          }
          contentParts.push({
            type: "text",
            text: `\n\n[Documento ${i + 1}/${files.length}: ${f.fileName || 'archivo'}]:\n${textContent}`,
          });
        }
      }

      const stream = await groq.chat.completions.create({
        model: targetModel,
        messages: [{ role: "user", content: contentParts }] as any,
        response_format: { type: "json_object" },
        temperature: 0.1,
        max_tokens: 4096,
        stream: true,
      });

      let accumulatedText = "";
      let chunkCount = 0;
      for await (const chunk of stream) {
        if (isAborted) break;
        const delta = chunk.choices[0]?.delta?.content || "";
        if (delta) {
          accumulatedText += delta;
          chunkCount++;
          sendSSE("chunk", {
            delta,
            chunkCount,
            accumulatedLength: accumulatedText.length,
          });
        }
      }

      sendSSE("status", {
        phase: "parsing",
        message: "Estructurando datos para Google Sheets y Google Docs...",
      });

      let parsedData: any;
      try {
        parsedData = JSON.parse(accumulatedText);
      } catch {
        const match = accumulatedText.match(/\{[\s\S]*\}/);
        if (match) parsedData = JSON.parse(match[0]);
        else throw new Error("No se pudo interpretar el JSON devuelto por Groq.");
      }

      sendSSE("complete", {
        success: true,
        data: parsedData,
        model: targetModel,
        provider: "groq",
      });
      return res.end();
    }

    // 2. Default: Gemini generateContentStream with Multi-tier Quota Fallback and Groq Failover
    let ai: GoogleGenAI;
    try {
      ai = getAI();
    } catch (err: any) {
      if (hasGroq()) {
        sendSSE("status", {
          phase: "failover",
          message: "Gemini API key no detectada. Redirigiendo a Groq LPU (Streaming)...",
        });
      }
      throw err;
    }

    let chosenModel = "gemini-3.8-flash";
    if (enableThinking) {
      chosenModel = "gemini-3.1-pro-preview";
    } else if (
      model === "gemini-3.1-flash-lite" ||
      model === "gemini-3.5-flash" ||
      model === "gemini-3.8-flash" ||
      model === "gemini-flash-latest"
    ) {
      chosenModel = model;
    }

    const config: any = {
      responseMimeType: "application/json",
      systemInstruction:
        "You are an elite multimodal document intelligence system with vision capabilities. You extract data with 100% precision from images, PDFs, charts, receipts, and complex documents, synthesizing and cross-referencing multiple files seamlessly.",
    };

    if (enableThinking) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    }

    const parts: any[] = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.isText && f.textContent) {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]\n--- CONTENIDO DEL DOCUMENTO ---\n${f.textContent}\n--- FIN DEL DOCUMENTO ---`,
        });
      } else {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]`,
        });
        parts.push({
          inlineData: {
            mimeType: f.mimeType,
            data: f.cleanBase64,
          },
        });
      }
    }
    parts.push({ text: prompt });

    const contents = [{ role: "user", parts }];

    const candidateModels = [
      chosenModel,
      "gemini-3.8-flash",
      "gemini-3.1-flash-lite",
      "gemini-flash-latest",
    ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

    let streamSucceeded = false;
    let lastError: any = null;
    let modelUsed = chosenModel;
    let accumulatedText = "";
    let totalChunks = 0;

    for (const currentModel of candidateModels) {
      if (isAborted) break;
      try {
        sendSSE("status", {
          phase: "connecting",
          message: `Iniciando streaming con ${currentModel}...`,
          model: currentModel,
          provider: "gemini",
        });

        const reqConfig = { ...config };
        if (currentModel !== chosenModel && reqConfig.thinkingConfig) {
          delete reqConfig.thinkingConfig;
        }

        const responseStream = await ai.models.generateContentStream({
          model: currentModel,
          contents,
          config: reqConfig,
        });

        sendSSE("status", {
          phase: "streaming",
          message: `Extrayendo datos progresivamente en tiempo real con ${currentModel}...`,
          model: currentModel,
          provider: "gemini",
        });

        accumulatedText = "";
        let chunkIndex = 0;

        for await (const chunk of responseStream) {
          if (isAborted) break;
          const textPart = chunk.text || "";
          if (textPart) {
            accumulatedText += textPart;
            chunkIndex++;
            totalChunks++;
            sendSSE("chunk", {
              delta: textPart,
              chunkIndex,
              accumulatedLength: accumulatedText.length,
            });
          }
        }

        if (accumulatedText.trim().length > 0) {
          modelUsed = currentModel;
          streamSucceeded = true;
          break;
        } else {
          lastError = new Error(`El modelo ${currentModel} finalizó la respuesta vacía.`);
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[Stream Model Retry] ${currentModel} stream failed (${err?.message?.slice(0, 100)}). Trying fallback...`);
        sendSSE("status", {
          phase: "fallback",
          message: `Modelo ${currentModel} con alta demanda o límite. Conmutando al siguiente modelo...`,
          failedModel: currentModel,
        });
      }
    }

    if (!streamSucceeded) {
      // If Gemini quota/demand is exhausted and Groq is configured, seamlessly stream through Groq!
      if (hasGroq()) {
        try {
          console.warn("[Multi-Provider Failover] Gemini streaming failed, seamlessly failover to Groq LPU stream...");
          sendSSE("status", {
            phase: "failover",
            message: "Gemini con cuota excedida. Conmutando a Groq LPU (Streaming)...",
            provider: "groq",
          });

          const groq = getGroq();
          const hasImage = files.some((f) => f.mimeType.startsWith("image/"));
          const groqTargetModel = hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile";

          const contentParts: any[] = [{ type: "text", text: prompt }];
          for (let i = 0; i < files.length; i++) {
            const f = files[i];
            if (f.mimeType.startsWith("image/")) {
              const dataUrl = f.fileData.startsWith("data:") ? f.fileData : `data:${f.mimeType};base64,${f.fileData}`;
              contentParts.push({ type: "image_url", image_url: { url: dataUrl } });
            } else {
              contentParts.push({
                type: "text",
                text: `\n\n[Documento ${i + 1}/${files.length}: ${f.fileName}]:\n${f.textContent || f.fileData}`,
              });
            }
          }

          const groqStream = await groq.chat.completions.create({
            model: groqTargetModel,
            messages: [{ role: "user", content: contentParts }] as any,
            response_format: { type: "json_object" },
            temperature: 0.1,
            max_tokens: 4096,
            stream: true,
          });

          accumulatedText = "";
          let groqChunkCount = 0;
          for await (const chunk of groqStream) {
            if (isAborted) break;
            const delta = chunk.choices[0]?.delta?.content || "";
            if (delta) {
              accumulatedText += delta;
              groqChunkCount++;
              totalChunks++;
              sendSSE("chunk", {
                delta,
                chunkIndex: groqChunkCount,
                accumulatedLength: accumulatedText.length,
              });
            }
          }

          modelUsed = groqTargetModel;
          streamSucceeded = true;
        } catch (groqErr: any) {
          console.warn("[Groq Stream Failover Error] Groq streaming failed:", groqErr?.message || groqErr);
          const msg = String(groqErr?.message || "");
          if (msg.includes("blocked_org") || msg.includes("model_not_found") || groqErr?.status === 403 || groqErr?.status === 404) {
            groqDisabledDueToPermission = true;
          }
        }
      }

      if (!streamSucceeded) {
        throw lastError || new Error("No se pudo completar el streaming con ningún modelo de Gemini.");
      }
    }

    sendSSE("status", {
      phase: "parsing",
      message: "Procesando estructura y vinculando columnas para Google Sheets y Docs...",
      model: modelUsed,
    });

    let parsedData: any;
    try {
      parsedData = JSON.parse(accumulatedText);
    } catch {
      const match = accumulatedText.match(/\{[\s\S]*\}/);
      if (match) {
        parsedData = JSON.parse(match[0]);
      } else {
        throw new Error("No se pudo analizar la estructura JSON del documento extraído.");
      }
    }

    sendSSE("complete", {
      success: true,
      data: parsedData,
      model: modelUsed,
      provider: modelUsed.startsWith("llama") ? "groq" : "gemini",
      chunksCount: totalChunks,
      accumulatedLength: accumulatedText.length,
    });
    res.end();
  } catch (error: any) {
    console.error("Document analysis stream endpoint error:", error);
    const formatted = formatApiError(error);
    sendSSE("error", formatted);
    res.end();
  }
}

app.post("/api/analyze-document/stream", handleDocumentStreamingAnalysis);
app.post("/api/analyze-document-stream", handleDocumentStreamingAnalysis);

// 3. Fast Low-Latency Quick Command Endpoint (gemini-3.1-flash-lite with fallback)
app.post("/api/quick-command", async (req, res) => {
  try {
    const rawPrompt =
      (typeof req.body?.prompt === "string" && req.body.prompt.trim()) ||
      (typeof req.body?.text === "string" && req.body.text.trim()) ||
      (typeof req.body?.command === "string" && req.body.command.trim()) ||
      (typeof req.body?.query === "string" && req.body.query.trim()) ||
      "";

    if (!rawPrompt) {
      return res.status(400).json({ error: "El comando o prompt es requerido." });
    }

    const { systemInstruction } = req.body;
    const ai = getAI();

    const candidateModels = ["gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-latest"];
    let lastError: any = null;
    let responseText = "";
    let modelUsed = "gemini-3.1-flash-lite";

    for (const model of candidateModels) {
      try {
        const config: any = {
          systemInstruction: systemInstruction || "You are an ultra-fast assistant that provides instant, concise responses and structured commands.",
        };
        if (model.includes("3.1") || model.includes("3.8")) {
          config.thinkingConfig = {
            thinkingLevel: ThinkingLevel.MINIMAL,
          };
        }
        const response = await ai.models.generateContent({
          model,
          contents: rawPrompt,
          config,
        });
        responseText = response.text || "";
        modelUsed = model;
        break;
      } catch (err: any) {
        lastError = err;
        console.info(`[Quick Command] Notice: model ${model} unavailable, trying fallback...`);
      }
    }

    if (!responseText && hasGroq()) {
      try {
        const groq = getGroq();
        const groqRes = await groq.chat.completions.create({
          model: "llama-3.1-8b-instant",
          messages: [
            { role: "system", content: systemInstruction || "You are an ultra-fast assistant that provides instant, concise responses and structured commands." },
            { role: "user", content: rawPrompt }
          ],
          temperature: 0.3,
          max_tokens: 1024,
        });
        responseText = groqRes.choices[0]?.message?.content || "";
        modelUsed = "llama-3.1-8b-instant";
      } catch (groqErr) {
        console.warn("[Quick Command] Groq failover error:", groqErr);
      }
    }

    if (!responseText && lastError) {
      throw lastError;
    }

    res.json({
      text: responseText,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error("Quick command error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 3c. AI Prompt Enhancer for High-Conversion Image & Video Generation
app.post("/api/enhance-prompt", async (req, res) => {
  try {
    const { prompt, type = "image", stylePreset, cameraMotion } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const ai = getAI();
    const systemInstruction = `You are an elite creative visual director and AI prompt engineer specializing in Google Gemini (gemini-3.1-flash-image, gemini-3-pro-image) and Veo 3 video generation.
Your task is to take the user's initial idea and rewrite it into a highly detailed, descriptive, visually stunning prompt in English that maximizes photorealism, artistic coherence, lighting, textures, camera lenses, and spatial depth.
${type === "video" ? "For video: Focus on smooth camera motion, lighting transitions, physics, temporal coherence, and atmospheric presence. Mention frame rate, motion dynamics, and depth." : "For image: Focus on lighting (e.g., golden hour, rim light, volumetric fog), camera lens (e.g. 35mm f/1.4, Hasselblad medium format), textures, composition (rule of thirds, leading lines), and materials."}
${stylePreset ? `Incorporate the chosen artistic/visual style: "${stylePreset}".` : ""}
${cameraMotion ? `Incorporate the specific camera movement: "${cameraMotion}".` : ""}
Rules:
- Return ONLY the enhanced prompt string. No conversational filler, no markdown codeblocks, no explanations.
- Maximum 150-200 words. Keep it vivid, impactful, and coherent.`;

    let enhancedText = "";
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: [{ parts: [{ text: `Expand and enhance this prompt: "${prompt}"` }] }],
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });
      enhancedText = response.text?.trim() || "";
    } catch (geminiErr) {
      console.warn("Gemini prompt enhance (flash) failed, attempting lite...", geminiErr);
      try {
        const responseLite = await ai.models.generateContent({
          model: "gemini-3.1-flash-lite",
          contents: [{ parts: [{ text: `Expand and enhance this prompt: "${prompt}"` }] }],
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });
        enhancedText = responseLite.text?.trim() || "";
      } catch (liteErr) {
        if (hasGroq()) {
          try {
            const groq = getGroq();
            const completion = await groq.chat.completions.create({
              messages: [
                { role: "system", content: systemInstruction },
                { role: "user", content: `Expand and enhance this prompt: "${prompt}"` },
              ],
              model: "llama-3.3-70b-versatile",
              temperature: 0.7,
              max_tokens: 300,
            });
            enhancedText = completion.choices[0]?.message?.content?.trim() || "";
          } catch (groqErr) {
            console.warn("Groq prompt enhance also failed:", groqErr);
          }
        }
      }
    }

    if (!enhancedText) {
      enhancedText = prompt;
    }

    res.json({ enhancedPrompt: enhancedText });
  } catch (error: any) {
    console.error("Enhance prompt error:", error);
    res.status(500).json({ error: error?.message || "Failed to enhance prompt" });
  }
});

// 4. Generate High-Quality Images with Multi-Tier Model Fallback & Search Grounding
app.post("/api/generate-image", async (req, res) => {
  try {
    const {
      prompt,
      imageSize = "1K",
      aspectRatio = "1:1",
      enableSearchGrounding = false,
    } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Image prompt is required." });
    }

    const ai = getAI();
    const validSizes = ["512px", "1K", "2K", "4K"];
    const chosenSize = validSizes.includes(imageSize) ? imageSize : "1K";

    const candidateModels = [
      "gemini-3.1-flash-image",
      "gemini-3.1-flash-lite-image",
      "gemini-3-pro-image",
      "gemini-3.1-flash-image-preview",
      "gemini-3-pro-image-preview",
    ];

    let imageUrl: string | null = null;
    let descriptionText = "";
    let modelUsed = "";
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        console.log(`[Image Generation] Attempting model: ${model}`);
        const config: any = {
          imageConfig: {
            aspectRatio: aspectRatio || "1:1",
          },
        };

        // imageSize supported on gemini-3.1-flash-image and gemini-3-pro-image
        if (!model.includes("lite")) {
          config.imageConfig.imageSize = chosenSize;
        }

        // Enable Google Search grounding if requested and model supports it
        if (enableSearchGrounding && (model.includes("flash-image") || model.includes("pro-image"))) {
          config.tools = [
            {
              googleSearch: {
                searchTypes: {
                  webSearch: {},
                  imageSearch: {},
                },
              },
            },
          ];
        }

        const response = await ai.models.generateContent({
          model,
          contents: {
            parts: [{ text: prompt }],
          },
          config,
        });

        if (response.candidates && response.candidates[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
            } else if (part.text) {
              descriptionText += part.text;
            }
          }
        }

        if (imageUrl) {
          modelUsed = model;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[Image Generation] Model ${model} failed (${err?.message?.slice(0, 100) || err}). Trying fallback...`);
      }
    }

    if (!imageUrl) {
      throw lastError || new Error("No se pudo generar la imagen con ninguno de los modelos disponibles. " + descriptionText);
    }

    res.json({
      imageUrl,
      description: descriptionText,
      imageSize: chosenSize,
      aspectRatio,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error("Generate image error:", error);
    const formatted = formatApiError(error);
    if (formatted.isQuotaExceeded) {
      formatted.error = "Límite de cuota alcanzado para generación de imágenes (429). En el plan gratuito los modelos de imagen pueden tener cuota restringida o requerir facturación en Google AI Studio.";
    }
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 5. Create & Edit Images with Multi-Tier Model Fallback
app.post("/api/edit-image", async (req, res) => {
  try {
    const { prompt, imageBase64, mimeType = "image/png", aspectRatio } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required." });
    }

    const ai = getAI();
    const parts: any[] = [];

    // If an existing image is provided to edit:
    if (imageBase64) {
      const cleanBase64 = imageBase64.includes(",")
        ? imageBase64.split(",")[1]
        : imageBase64;

      parts.push({
        inlineData: {
          data: cleanBase64,
          mimeType: mimeType || "image/png",
        },
      });
    }

    parts.push({ text: prompt });

    const candidateModels = [
      "gemini-3.1-flash-image",
      "gemini-3.1-flash-lite-image",
      "gemini-3-pro-image",
      "gemini-3.1-flash-image-preview",
    ];

    let imageUrl: string | null = null;
    let textOut = "";
    let modelUsed = "";
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        console.log(`[Edit Image] Attempting model: ${model}`);
        const config: any = {};
        if (aspectRatio) {
          config.imageConfig = { aspectRatio };
        }

        const response = await ai.models.generateContent({
          model,
          contents: {
            parts,
          },
          ...(Object.keys(config).length > 0 ? { config } : {}),
        });

        if (response.candidates && response.candidates[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
            } else if (part.text) {
              textOut += part.text;
            }
          }
        }

        if (imageUrl) {
          modelUsed = model;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[Edit Image] Model ${model} failed (${err?.message?.slice(0, 100) || err}). Trying fallback...`);
      }
    }

    if (!imageUrl) {
      throw lastError || new Error("No se pudo procesar la imagen con los modelos disponibles. " + textOut);
    }

    res.json({
      imageUrl,
      notes: textOut,
      model: modelUsed,
      mode: imageBase64 ? "edited" : "created",
    });
  } catch (error: any) {
    console.error("Edit image error:", error);
    const formatted = formatApiError(error);
    if (formatted.isQuotaExceeded) {
      formatted.error = "Límite de cuota alcanzado para edición de imágenes (429). En el plan gratuito los modelos de imagen pueden tener cuota restringida.";
    }
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// TTS Quota Circuit Breaker (Free tier allows 10 requests/day per project)
let ttsQuotaCooldownUntil: number = 0;

// 6. Text-to-Speech endpoint (gemini-3.1-flash-tts-preview) with resilient fallback
app.post("/api/tts", async (req, res) => {
  try {
    const { text, voice = "Zephyr" } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required." });
    }

    // Circuit Breaker: If quota was exceeded (10 free requests/day), immediately delegate to client SpeechSynthesis
    if (Date.now() < ttsQuotaCooldownUntil) {
      return res.json({
        fallbackToBrowser: true,
        reason: "TTS en enfriamiento por cuota (10 peticiones gratuitas/día). Delegando a síntesis nativa del navegador.",
      });
    }

    const ai = getAI();
    const validVoices = ["Puck", "Charon", "Kore", "Fenrir", "Zephyr"];
    const voiceName = validVoices.includes(voice) ? voice : "Zephyr";

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const audioBase64 =
        response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

      if (!audioBase64) {
        return res.json({
          fallbackToBrowser: true,
          reason: "No se obtuvo stream de audio de Gemini TTS.",
        });
      }

      return res.json({
        audio: audioBase64,
        mimeType: "audio/pcm;rate=24000",
        sampleRate: 24000,
      });
    } catch (ttsGenError: any) {
      const formatted = formatApiError(ttsGenError);
      if (formatted.isQuotaExceeded || formatted.isHighDemand) {
        // Set circuit breaker for 30 minutes to protect rate limits and prevent repeated 429 logs
        ttsQuotaCooldownUntil = Date.now() + 30 * 60 * 1000;
        console.info(
          `[TTS Circuit Breaker] Gemini TTS cuota alcanzada (10 req/día). Delegando a síntesis nativa del navegador de manera silenciosa.`
        );
        return res.json({
          fallbackToBrowser: true,
          reason: "Cuota de Gemini TTS alcanzada (10 peticiones gratuitas/día). Utilizando síntesis de voz nativa del navegador.",
        });
      }
      return res.json({
        fallbackToBrowser: true,
        reason: "Servicio TTS no disponible, delegando a síntesis nativa.",
      });
    }
  } catch (error: any) {
    console.info("TTS request exception, falling back to browser:", error?.message || error);
    return res.json({ fallbackToBrowser: true });
  }
});

// 6b. Veo 3 Video Generation: Text to Video, Image to Video & Interpolation (Start + End Frame)
app.post("/api/generate-video", async (req, res) => {
  try {
    const {
      prompt,
      imageBase64,
      mimeType = "image/png",
      lastFrameBase64,
      lastFrameMimeType = "image/png",
      aspectRatio = "16:9",
      resolution = "720p",
      cameraMotion,
    } = req.body;

    if (!prompt && !imageBase64) {
      return res.status(400).json({ error: "Se requiere un prompt de texto o una imagen para generar el video con Veo 3." });
    }

    const ai = getAI();
    const candidateModels = [
      "veo-3.1-generate-preview",
      "veo-3.1-lite-generate-preview",
    ];

    let operation: any = null;
    let lastError: any = null;
    let modelUsed = "";

    const selectedRatio = aspectRatio === "9:16" ? "9:16" : "16:9";
    const selectedResolution = resolution === "1080p" ? "1080p" : "720p";

    // Combine prompt with camera motion directive if provided
    let finalPrompt = prompt || "";
    if (cameraMotion && cameraMotion.trim()) {
      finalPrompt = finalPrompt
        ? `${finalPrompt}. Camera motion: ${cameraMotion.trim()}`
        : `Camera motion: ${cameraMotion.trim()}`;
    }

    for (const model of candidateModels) {
      try {
        console.log(`[Veo Video] Attempting generation with model ${model}...`);
        const payload: any = {
          model,
          config: {
            numberOfVideos: 1,
            aspectRatio: selectedRatio,
            resolution: selectedResolution,
          },
        };

        if (finalPrompt) {
          payload.prompt = finalPrompt;
        }

        if (imageBase64) {
          const cleanBase64 = imageBase64.includes(",")
            ? imageBase64.split(",")[1]
            : imageBase64;
          payload.image = {
            imageBytes: cleanBase64,
            mimeType: mimeType || "image/png",
          };
        }

        if (lastFrameBase64) {
          const cleanLastBase64 = lastFrameBase64.includes(",")
            ? lastFrameBase64.split(",")[1]
            : lastFrameBase64;
          payload.config.lastFrame = {
            imageBytes: cleanLastBase64,
            mimeType: lastFrameMimeType || "image/png",
          };
        }

        operation = await ai.models.generateVideos(payload);
        if (operation?.name) {
          modelUsed = model;
          console.log(`[Veo Video] Operation started successfully: ${operation.name} (${model})`);
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[Veo Video] Model ${model} failed (${err?.message?.slice(0, 100) || err}). Retrying next...`);
      }
    }

    if (!operation?.name) {
      throw lastError || new Error("No se pudo iniciar la operación de video con Veo 3.");
    }

    return res.json({
      operationName: operation.name,
      modelUsed,
      aspectRatio: selectedRatio,
      resolution: selectedResolution,
      prompt: finalPrompt || "",
      hasStartingImage: Boolean(imageBase64),
      hasLastFrame: Boolean(lastFrameBase64),
    });
  } catch (error: any) {
    console.error("Veo Video Generation Error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 6c. Veo 3 Video Status Poll
app.post("/api/video-status", async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    const ai = getAI();
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    return res.json({
      done: Boolean(updated.done),
      error: updated.error || null,
      operationName,
    });
  } catch (error: any) {
    console.error("Veo Video Status Error:", error);
    const formatted = formatApiError(error);
    res.status(500).json(formatted);
  }
});

// 6d. Veo 3 Video Download Stream
app.post("/api/video-download", async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    const ai = getAI();
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
    if (!uri) {
      return res.status(404).json({ error: "Video URI not found or generation not finished." });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const videoRes = await fetch(uri, {
      headers: { "x-goog-api-key": apiKey || "" },
    });

    if (!videoRes.ok) {
      return res.status(videoRes.status).json({ error: "Failed to download video stream." });
    }

    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Content-Disposition", `inline; filename="veo3-${Date.now()}.mp4"`);

    if (videoRes.body) {
      const reader = videoRes.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(Buffer.from(value));
      }
      res.end();
    } else {
      res.status(500).json({ error: "No video body stream available." });
    }
  } catch (error: any) {
    console.error("Veo Video Download Error:", error);
    const formatted = formatApiError(error);
    res.status(500).json(formatted);
  }
});

// Create HTTP server for both Express and WebSocket
const server = http.createServer(app);

// 7. WebSocket for Real-time Voice Conversations via Gemini Live API (gemini-3.8-live)
const wss = new WebSocketServer({ server, path: "/live" });

wss.on("connection", async (clientWs: WebSocket) => {
  console.log("Client connected to /live WebSocket");
  let liveSession: any = null;

  try {
    const ai = getAI();
    liveSession = await ai.live.connect({
      model: "gemini-3.8-live",
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
        },
        systemInstruction: `Eres un asistente de voz integrado directamente con Google Workspace. 
Cuando el usuario te pida crear o modificar un documento en Google Docs o añadir filas en Google Sheets por voz, genera la estructura formateada inmediatamente iniciando con "DOC_PROPOSAL:" o "SHEET_PROPOSAL:" para que el sistema cree los archivos en tiempo real sin requerir confirmación manual del usuario.`,
      },
      callbacks: {
        onmessage: (message: any) => {
          try {
            const parts = message.serverContent?.modelTurn?.parts;
            if (parts && parts.length > 0) {
              for (const part of parts) {
                if (part.inlineData?.data) {
                  clientWs.send(
                    JSON.stringify({
                      type: "audio",
                      audio: part.inlineData.data,
                    })
                  );
                }
                if (part.text) {
                  clientWs.send(
                    JSON.stringify({
                      type: "transcript",
                      text: part.text,
                    })
                  );
                }
              }
            }
            if (message.serverContent?.turnComplete) {
              clientWs.send(JSON.stringify({ type: "turnComplete" }));
            }
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: "interrupted" }));
            }
          } catch (err) {
            console.error("Error sending Live message to client:", err);
          }
        },
        onclose: () => {
          console.log("Live session closed");
          try {
            clientWs.send(JSON.stringify({ type: "sessionClosed" }));
          } catch (_) {}
        },
        onerror: (err: any) => {
          console.error("Live session error:", err);
          try {
            clientWs.send(
              JSON.stringify({ type: "error", error: err?.message || String(err) })
            );
          } catch (_) {}
        },
      },
    });

    clientWs.send(JSON.stringify({ type: "connected", model: "gemini-3.8-live" }));
  } catch (err: any) {
    console.error("Failed to connect to Live API:", err);
    clientWs.send(
      JSON.stringify({
        type: "error",
        error: "Live API connection failed: " + (err?.message || String(err)),
      })
    );
  }

  clientWs.on("message", (raw: Buffer) => {
    try {
      const data = JSON.parse(raw.toString());
      if (data.type === "audio" && data.audio && liveSession) {
        liveSession.sendRealtimeInput({
          audio: {
            data: data.audio,
            mimeType: "audio/pcm;rate=16000",
          },
        });
      } else if (data.type === "text" && data.text && liveSession) {
        if (typeof liveSession.sendClientContent === "function") {
          liveSession.sendClientContent({
            turns: [{ role: "user", parts: [{ text: data.text }] }],
            turnComplete: true,
          });
        }
      }
    } catch (err) {
      console.error("Error processing client message:", err);
    }
  });

  clientWs.on("close", () => {
    console.log("Client disconnected from /live");
    if (liveSession && typeof liveSession.close === "function") {
      try {
        liveSession.close();
      } catch (_) {}
    }
  });
});

// Setup Vite middleware in dev or static serving in prod
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Server startup error:", err);
});
