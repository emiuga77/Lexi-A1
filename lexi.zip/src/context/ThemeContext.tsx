import React, { createContext, useContext, useState, useEffect } from 'react';

export type AppTheme = 'night' | 'day';

interface ThemeContextValue {
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  toggleTheme: () => void;
  isNight: boolean;
}

const ThemeContext = createContext<ThemeContextValue>({
  theme: 'night',
  setTheme: () => {},
  toggleTheme: () => {},
  isNight: true,
});

const THEME_STORAGE_KEY = 'lexi_app_theme';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Default to 'night' (black) per explicit user request
  const [theme, setThemeState] = useState<AppTheme>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === 'day' || saved === 'night') return saved;
    } catch {
      // ignore
    }
    return 'night';
  });

  const setTheme = (newTheme: AppTheme) => {
    setThemeState(newTheme);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, newTheme);
    } catch {
      // ignore
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'night' ? 'day' : 'night');
  };

  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    if (theme === 'night') {
      root.classList.add('dark', 'theme-night');
      root.classList.remove('theme-day');
      root.style.backgroundColor = '#000000';
      body.style.backgroundColor = '#000000';
      body.style.color = '#f4f4f5';
    } else {
      root.classList.remove('dark', 'theme-night');
      root.classList.add('theme-day');
      root.style.backgroundColor = '#f8fafc';
      body.style.backgroundColor = '#f8fafc';
      body.style.color = '#0f172a';
    }
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, isNight: theme === 'night' }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
