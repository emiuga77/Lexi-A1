import React, { useState, useEffect, useRef } from 'react';
import { User } from 'firebase/auth';
import {
  Bot,
  FileText,
  Table,
  Image,
  Sparkles,
  LogOut,
  CheckCircle2,
  BookOpen,
  Layers,
  Users,
  Database,
  Menu,
  X,
  Moon,
  Sun,
  ChevronDown,
  ShieldCheck,
  Check,
  Radio,
  SlidersHorizontal,
  Building2,
  FileDown,
} from 'lucide-react';
import { getObsidianVaultName } from '../utils/obsidian';
import { ObsidianModal } from './ObsidianModal';
import { ProfileModal } from './ProfileModal';
import { DataPermanencyModal } from './DataPermanencyModal';
import { getActiveProfile } from '../services/profileService';
import { UserProfile } from '../types';
import { useTheme } from '../context/ThemeContext';

interface Props {
  activeTab: 'voice_hub' | 'extractor' | 'docs' | 'sheets' | 'images' | 'real_estate';
  setActiveTab: (tab: 'voice_hub' | 'extractor' | 'docs' | 'sheets' | 'images' | 'real_estate') => void;
  user: User | null;
  onLogin: () => void;
  onLogout: () => void;
  isLoggingIn: boolean;
  isLiveConnected: boolean;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  user,
  onLogin,
  onLogout,
  isLoggingIn,
  isLiveConnected,
}) => {
  const { theme, setTheme, toggleTheme, isNight } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isObsidianModalOpen, setIsObsidianModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isPermanencyModalOpen, setIsPermanencyModalOpen] = useState(false);
  const [vaultName, setVaultName] = useState(getObsidianVaultName());
  const [currentProfile, setCurrentProfile] = useState<UserProfile>(() => getActiveProfile());

  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const updateVault = () => setVaultName(getObsidianVaultName());
    const updateProfile = () => setCurrentProfile(getActiveProfile());

    window.addEventListener('focus', updateVault);
    window.addEventListener('voiceflow:profile_changed', updateProfile);
    return () => {
      window.removeEventListener('focus', updateVault);
      window.removeEventListener('voiceflow:profile_changed', updateProfile);
    };
  }, []);

  // Close dropdown on click outside or Escape key
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node) &&
        triggerRef.current &&
        !triggerRef.current.contains(event.target as Node)
      ) {
        setIsMenuOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isMenuOpen]);

  const selectTab = (
    tab: 'voice_hub' | 'extractor' | 'docs' | 'sheets' | 'images' | 'real_estate'
  ) => {
    setActiveTab(tab);
    setIsMenuOpen(false);
  };

  const getTabLabel = () => {
    switch (activeTab) {
      case 'voice_hub':
        return 'Orbe Dashboard IA';
      case 'extractor':
        return 'Extractor IA';
      case 'docs':
        return 'Google Docs';
      case 'sheets':
        return 'Google Sheets';
      case 'images':
        return 'Image & Video';
      case 'real_estate':
        return 'Ficha Inmobiliaria PDF';
      default:
        return 'Asistente';
    }
  };

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-colors duration-200 border-b ${
        isNight
          ? 'bg-black/95 backdrop-blur-md border-zinc-900 text-zinc-100'
          : 'bg-white/95 backdrop-blur-md border-slate-200 text-slate-900'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-3">
        {/* Minimalist Brand Logo & Identity */}
        <div className="flex items-center gap-3 shrink-0">
          <div
            onClick={() => selectTab('voice_hub')}
            className={`w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer transition-all ${
              isNight
                ? 'bg-zinc-900 text-zinc-100 border border-zinc-800 hover:border-zinc-700 shadow-xs'
                : 'bg-slate-900 text-white shadow-xs'
            }`}
          >
            <Bot className="w-4 h-4" />
          </div>

          <div className="flex items-center gap-2">
            <span
              onClick={() => selectTab('voice_hub')}
              className={`font-bold text-sm tracking-tight cursor-pointer ${
                isNight ? 'text-white' : 'text-slate-900'
              }`}
            >
              Lexi
            </span>
            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-medium tracking-wide flex items-center gap-1.5 ${
                isNight
                  ? 'bg-zinc-900 border border-zinc-800 text-zinc-300'
                  : 'bg-slate-100 border border-slate-200 text-slate-700'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
              {getTabLabel()}
            </span>
          </div>
        </div>

        {/* Action Controls & Minimalist Dropdown Menu Trigger */}
        <div className="flex items-center gap-2">
          {/* Live Voice Indicator when active */}
          {isLiveConnected && (
            <div
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium ${
                isNight
                  ? 'bg-emerald-950/80 border border-emerald-800/80 text-emerald-300'
                  : 'bg-emerald-50 border border-emerald-200 text-emerald-700'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <span>Voz en Vivo</span>
            </div>
          )}

          {/* Quick Real Estate Technical Sheet Button */}
          <button
            id="btn-quick-real-estate-toggle"
            type="button"
            onClick={() => selectTab('real_estate')}
            title="Ir a Ficha Técnica Inmobiliaria y PDF"
            className={`hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
              activeTab === 'real_estate'
                ? isNight
                  ? 'bg-zinc-800 border-zinc-700 text-amber-400'
                  : 'bg-slate-200 border-slate-300 text-slate-900'
                : isNight
                ? 'bg-zinc-950 hover:bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-amber-500" />
            <span>Ficha PDF</span>
          </button>

          {/* Quick Theme Switcher Button */}
          <button
            id="btn-quick-theme-toggle"
            type="button"
            onClick={toggleTheme}
            title={isNight ? 'Cambiar a versión diurna (clara)' : 'Cambiar a versión nocturna (fondo negro)'}
            className={`p-2 rounded-lg text-xs font-medium transition-colors cursor-pointer border ${
              isNight
                ? 'bg-zinc-950 hover:bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
                : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
            }`}
          >
            {isNight ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>

          {/* Main All-Access Dropdown Trigger */}
          <div className="relative">
            <button
              ref={triggerRef}
              id="btn-main-dropdown-menu"
              type="button"
              onClick={() => setIsMenuOpen((prev) => !prev)}
              aria-expanded={isMenuOpen}
              className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                isMenuOpen
                  ? isNight
                    ? 'bg-zinc-800 border-zinc-700 text-white'
                    : 'bg-slate-200 border-slate-300 text-slate-900'
                  : isNight
                  ? 'bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-200 hover:border-zinc-700'
                  : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-800'
              }`}
            >
              <Menu className="w-4 h-4" />
              <span className="font-medium">Menú</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  isMenuOpen ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Dropdown Panel: Access Everything */}
            {isMenuOpen && (
              <div
                ref={menuRef}
                id="main-app-dropdown"
                className={`absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl shadow-2xl border p-2 z-50 transition-all duration-150 animate-in fade-in zoom-in-95 ${
                  isNight
                    ? 'bg-black/98 border-zinc-800 text-zinc-100 divide-zinc-900 shadow-black/80'
                    : 'bg-white border-slate-200 text-slate-900 divide-slate-100 shadow-xl'
                }`}
              >
                {/* Header in dropdown */}
                <div
                  className={`px-3 py-2 border-b flex items-center justify-between ${
                    isNight ? 'border-zinc-900 text-zinc-400' : 'border-slate-100 text-slate-500'
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase">
                    <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                    <span>Navegación & Acceso Total</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsMenuOpen(false)}
                    className="p-1 rounded-md hover:opacity-80 transition-opacity cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Section 1: Main Views */}
                <div className="py-2 space-y-0.5">
                  <div
                    className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${
                      isNight ? 'text-zinc-500' : 'text-slate-400'
                    }`}
                  >
                    Módulos y Vistas
                  </div>

                  <button
                    id="menu-opt-voice-hub"
                    type="button"
                    onClick={() => selectTab('voice_hub')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      activeTab === 'voice_hub'
                        ? isNight
                          ? 'bg-zinc-900 text-white font-semibold'
                          : 'bg-slate-100 text-slate-900 font-semibold'
                        : isNight
                        ? 'hover:bg-zinc-900/60 text-zinc-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-medium">Orbe Dashboard IA</div>
                        <div className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                          Dashboard con Orbe interactivo y control por voz
                        </div>
                      </div>
                    </div>
                    {activeTab === 'voice_hub' && <Check className="w-4 h-4 text-blue-500" />}
                  </button>

                  <button
                    id="menu-opt-extractor"
                    type="button"
                    onClick={() => selectTab('extractor')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      activeTab === 'extractor'
                        ? isNight
                          ? 'bg-zinc-900 text-white font-semibold'
                          : 'bg-slate-100 text-slate-900 font-semibold'
                        : isNight
                        ? 'hover:bg-zinc-900/60 text-zinc-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
                        <Layers className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-medium">Extractor IA (Docs & Sheets)</div>
                        <div className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                          Streaming SSE de documentos e imágenes
                        </div>
                      </div>
                    </div>
                    {activeTab === 'extractor' && <Check className="w-4 h-4 text-indigo-500" />}
                  </button>

                  <button
                    id="menu-opt-docs"
                    type="button"
                    onClick={() => selectTab('docs')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      activeTab === 'docs'
                        ? isNight
                          ? 'bg-zinc-900 text-white font-semibold'
                          : 'bg-slate-100 text-slate-900 font-semibold'
                        : isNight
                        ? 'hover:bg-zinc-900/60 text-zinc-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-blue-600/10 text-blue-500">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-medium">Google Docs</div>
                        <div className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                          Gestor y redactor de documentos
                        </div>
                      </div>
                    </div>
                    {activeTab === 'docs' && <Check className="w-4 h-4 text-blue-500" />}
                  </button>

                  <button
                    id="menu-opt-sheets"
                    type="button"
                    onClick={() => selectTab('sheets')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      activeTab === 'sheets'
                        ? isNight
                          ? 'bg-zinc-900 text-white font-semibold'
                          : 'bg-slate-100 text-slate-900 font-semibold'
                        : isNight
                        ? 'hover:bg-zinc-900/60 text-zinc-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                        <Table className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-medium">Google Sheets</div>
                        <div className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                          Hojas de cálculo y celdas por voz
                        </div>
                      </div>
                    </div>
                    {activeTab === 'sheets' && <Check className="w-4 h-4 text-emerald-500" />}
                  </button>

                  <button
                    id="menu-opt-images"
                    type="button"
                    onClick={() => selectTab('images')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      activeTab === 'images'
                        ? isNight
                          ? 'bg-zinc-900 text-white font-semibold'
                          : 'bg-slate-100 text-slate-900 font-semibold'
                        : isNight
                        ? 'hover:bg-zinc-900/60 text-zinc-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400">
                        <Image className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-medium">Image & Video Studio</div>
                        <div className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                          Creación visual con Gemini y Veo 3
                        </div>
                      </div>
                    </div>
                    {activeTab === 'images' && <Check className="w-4 h-4 text-purple-500" />}
                  </button>

                  <button
                    id="menu-opt-real-estate"
                    type="button"
                    onClick={() => selectTab('real_estate')}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      activeTab === 'real_estate'
                        ? isNight
                          ? 'bg-zinc-900 text-white font-semibold'
                          : 'bg-slate-100 text-slate-900 font-semibold'
                        : isNight
                        ? 'hover:bg-zinc-900/60 text-zinc-300'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-500">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-medium">Ficha Inmobiliaria PDF</span>
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                            PDF 300 DPI
                          </span>
                        </div>
                        <div className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                          Dossier profesional para clientes e inversores
                        </div>
                      </div>
                    </div>
                    {activeTab === 'real_estate' && <Check className="w-4 h-4 text-amber-500" />}
                  </button>
                </div>

                {/* Section 2: Tools & Integrations */}
                <div className={`py-2 border-t space-y-0.5 ${isNight ? 'border-zinc-900' : 'border-slate-100'}`}>
                  <div
                    className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${
                      isNight ? 'text-zinc-500' : 'text-slate-400'
                    }`}
                  >
                    Herramientas e Integraciones
                  </div>

                  {/* Profile & Noise Gate Modal Trigger */}
                  <button
                    id="menu-opt-profile"
                    type="button"
                    onClick={() => {
                      setIsProfileModalOpen(true);
                      setIsMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      isNight ? 'hover:bg-zinc-900/60 text-zinc-300' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Users className="w-4 h-4 text-blue-400" />
                      <div>
                        <span className="font-medium">Perfil & Filtro Anti-Ruido</span>
                        <span
                          className={`ml-2 text-[10px] px-1.5 py-0.5 rounded font-mono ${
                            isNight ? 'bg-zinc-800 text-zinc-300' : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {currentProfile.noiseGateThreshold}%
                        </span>
                      </div>
                    </div>
                    <span className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>
                      {currentProfile.name.split(' ')[0]}
                    </span>
                  </button>

                  {/* Obsidian Modal Trigger */}
                  <button
                    id="menu-opt-obsidian"
                    type="button"
                    onClick={() => {
                      setIsObsidianModalOpen(true);
                      setIsMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      isNight ? 'hover:bg-zinc-900/60 text-zinc-300' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <BookOpen className="w-4 h-4 text-purple-400" />
                      <div>
                        <span className="font-medium">Bóveda de Obsidian</span>
                        <span
                          className={`ml-2 text-[10px] px-1.5 py-0.5 rounded font-mono ${
                            isNight ? 'bg-zinc-800 text-purple-300' : 'bg-purple-50 text-purple-700'
                          }`}
                        >
                          {vaultName}
                        </span>
                      </div>
                    </div>
                    <span className={`text-[10px] ${isNight ? 'text-zinc-500' : 'text-slate-400'}`}>Configurar</span>
                  </button>

                  {/* Permanency Modal Trigger */}
                  <button
                    id="menu-opt-permanency"
                    type="button"
                    onClick={() => {
                      setIsPermanencyModalOpen(true);
                      setIsMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                      isNight ? 'hover:bg-zinc-900/60 text-zinc-300' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Database className="w-4 h-4 text-emerald-400" />
                      <span className="font-medium">Permanencia DB (Firestore / Supabase)</span>
                    </div>
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  </button>
                </div>

                {/* Section 3: Theme Configuration (Modo Nocturno / Diurno) */}
                <div className={`py-2 border-t ${isNight ? 'border-zinc-900' : 'border-slate-100'}`}>
                  <div
                    className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider flex items-center justify-between ${
                      isNight ? 'text-zinc-500' : 'text-slate-400'
                    }`}
                  >
                    <span>Configuración de Apariencia</span>
                    <span className="text-[9px] font-mono lowercase">fondo {isNight ? 'negro' : 'claro'}</span>
                  </div>

                  <div className="px-3 pt-1.5 grid grid-cols-2 gap-2">
                    <button
                      id="theme-opt-night"
                      type="button"
                      onClick={() => setTheme('night')}
                      className={`px-3 py-2 rounded-xl text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                        isNight
                          ? 'bg-zinc-900 border-zinc-700 text-white font-semibold shadow-xs ring-1 ring-zinc-700'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                      }`}
                    >
                      <Moon className="w-3.5 h-3.5 text-zinc-300" />
                      <span>Nocturna (Negro)</span>
                      {isNight && <Check className="w-3 h-3 text-emerald-400 ml-auto" />}
                    </button>

                    <button
                      id="theme-opt-day"
                      type="button"
                      onClick={() => setTheme('day')}
                      className={`px-3 py-2 rounded-xl text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                        !isNight
                          ? 'bg-blue-50 border-blue-200 text-blue-900 font-semibold shadow-xs ring-1 ring-blue-300'
                          : 'bg-zinc-950 hover:bg-zinc-900 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      <Sun className="w-3.5 h-3.5 text-amber-500" />
                      <span>Diurna (Luz)</span>
                      {!isNight && <Check className="w-3 h-3 text-blue-600 ml-auto" />}
                    </button>
                  </div>
                </div>

                {/* Section 4: Account & Google Workspace */}
                <div className={`p-2 border-t mt-1 ${isNight ? 'border-zinc-900' : 'border-slate-100'}`}>
                  {user ? (
                    <div
                      className={`p-2 rounded-xl border flex items-center justify-between ${
                        isNight ? 'bg-zinc-950 border-zinc-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2 overflow-hidden">
                        {user.photoURL ? (
                          <img
                            src={user.photoURL}
                            alt={user.displayName || 'User'}
                            className="w-7 h-7 rounded-full shrink-0"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center shrink-0">
                            {user.displayName?.charAt(0) || user.email?.charAt(0) || 'U'}
                          </div>
                        )}
                        <div className="truncate">
                          <div className="text-xs font-semibold truncate">
                            {user.displayName || user.email || 'Cuenta Conectada'}
                          </div>
                          <div className="text-[10px] text-emerald-500 flex items-center gap-1 font-medium">
                            <CheckCircle2 className="w-2.5 h-2.5" /> Workspace Activo
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          onLogout();
                          setIsMenuOpen(false);
                        }}
                        title="Desconectar cuenta"
                        className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                          isNight
                            ? 'text-zinc-400 hover:text-rose-400 hover:bg-zinc-900'
                            : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                        }`}
                      >
                        <LogOut className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        onLogin();
                        setIsMenuOpen(false);
                      }}
                      disabled={isLoggingIn}
                      className={`w-full py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                        isNight
                          ? 'bg-zinc-900 hover:bg-zinc-800 border-zinc-700 text-white'
                          : 'bg-white hover:bg-slate-50 border-slate-300 text-slate-800 shadow-xs'
                      }`}
                    >
                      <svg className="w-3.5 h-3.5" viewBox="0 0 48 48">
                        <path
                          fill="#EA4335"
                          d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                        />
                        <path
                          fill="#4285F4"
                          d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                        />
                        <path
                          fill="#34A853"
                          d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                        />
                      </svg>
                      <span>{isLoggingIn ? 'Conectando...' : 'Conectar Google Workspace'}</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modals integrated seamlessly */}
      <ObsidianModal
        isOpen={isObsidianModalOpen}
        onClose={() => {
          setIsObsidianModalOpen(false);
          setVaultName(getObsidianVaultName());
        }}
      />

      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => {
          setIsProfileModalOpen(false);
          setCurrentProfile(getActiveProfile());
        }}
        onProfileSwitched={(p) => {
          setCurrentProfile(p);
        }}
      />

      <DataPermanencyModal
        isOpen={isPermanencyModalOpen}
        onClose={() => setIsPermanencyModalOpen(false)}
      />
    </header>
  );
};
