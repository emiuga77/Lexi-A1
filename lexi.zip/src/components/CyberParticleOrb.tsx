import React, { useEffect, useRef, useState } from 'react';
import { Volume2, Brain, Sparkles, Radio } from 'lucide-react';

export type OrbState = 'idle' | 'listening' | 'thinking' | 'speaking';

export interface CyberParticleOrbProps {
  status: OrbState;
  audioLevel?: number; // 0 to 100
  isVoiceDetected?: boolean;
  onClick?: () => void;
  size?: number; // default: 340
  showControls?: boolean;
  interimTranscript?: string;
  className?: string;
  title?: string;
  subtitle?: string;
  fullBackground?: boolean;
}

interface Particle3D {
  baseX: number;
  baseY: number;
  baseZ: number;
  dispX: number;
  dispY: number;
  dispZ: number;
  driftSpeed: number;
  driftPhase: number;
  driftRadius: number;
  x: number;
  y: number;
  z: number;
  lat: number;
  lon: number;
  size: number;
  alpha: number;
  baseAlpha: number;
  color: string;
  isHotspot: boolean;
  hotspotWeight: number;
}

interface AmbientParticle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  alpha: number;
}

export const CyberParticleOrb: React.FC<CyberParticleOrbProps> = ({
  status,
  audioLevel = 0,
  isVoiceDetected = false,
  onClick,
  size = 340,
  showControls = true,
  interimTranscript = '',
  className = '',
  title,
  subtitle,
  fullBackground = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  // Mutable refs for high-frequency props to avoid restarting the 60fps render loop
  const statusRef = useRef<OrbState>(status);
  statusRef.current = status;
  const audioLevelRef = useRef<number>(audioLevel);
  audioLevelRef.current = audioLevel;
  const isVoiceDetectedRef = useRef<boolean>(isVoiceDetected);
  isVoiceDetectedRef.current = isVoiceDetected;

  // 3D Orbital Cursor Interaction Refs
  const isDraggingRef = useRef(false);
  const lastMousePosRef = useRef({ x: 0, y: 0, time: 0 });
  const dragVelocityRef = useRef({ yaw: 0, pitch: 0 });
  const totalDragDistRef = useRef(0);
  const cursorHoverRef = useRef({ yaw: 0, pitch: 0 });
  const hoverTiltRef = useRef({ yaw: 0, pitch: 0 });

  // Animation & simulation refs
  const animFrameIdRef = useRef<number | null>(null);
  const rotationRef = useRef<{ yaw: number; pitch: number; roll: number }>({
    yaw: 0.3,
    pitch: 0.2,
    roll: 0,
  });
  const audioSmoothRef = useRef<number>(0);
  const pulseTimeRef = useRef<number>(0);
  // Smooth state transition refs (dispersion and brightness)
  const dispersionRef = useRef<number>(status === 'idle' ? 1.0 : 0.0);
  const brightnessRef = useRef<number>(status === 'idle' ? 0.28 : 1.0);

  // Particles cache
  const particlesRef = useRef<Particle3D[]>([]);
  const ambientParticlesRef = useRef<AmbientParticle[]>([]);

  // Initialize particle sphere once
  useEffect(() => {
    const NUM_PARTICLES = 2600;
    const NUM_AMBIENT = 120;
    const particles: Particle3D[] = [];

    // The two bright hotspot nodes from the reference image
    // Hotspot 1: upper-right quadrant
    const h1Lat = 0.52;
    const h1Lon = 1.15;
    // Hotspot 2: lower-right quadrant
    const h2Lat = -0.48;
    const h2Lon = 0.95;

    // Golden spiral sphere distribution (Fibonacci sphere)
    const phi = Math.PI * (3 - Math.sqrt(5)); // ~2.39996323

    for (let i = 0; i < NUM_PARTICLES; i++) {
      const y = 1 - (i / (NUM_PARTICLES - 1)) * 2; // -1 to 1
      const radiusAtY = Math.sqrt(Math.max(0, 1 - y * y));
      const theta = phi * i;

      const x = Math.cos(theta) * radiusAtY;
      const z = Math.sin(theta) * radiusAtY;

      const lat = Math.asin(Math.max(-1, Math.min(1, y)));
      const lon = Math.atan2(z, x);

      // Check proximity to the two bright nodes
      const d1 = Math.hypot(lat - h1Lat, lon - h1Lon);
      const d2 = Math.hypot(lat - h2Lat, lon - h2Lon);
      const isHotspot = d1 < 0.32 || d2 < 0.28;
      const hotspotWeight = isHotspot
        ? Math.max(1 - d1 / 0.32, 1 - d2 / 0.28)
        : 0;

      // Particle size & base opacity - enhanced brilliance & sparkling clarity
      const baseSize = isHotspot ? 2.2 + hotspotWeight * 2.5 : 1.1 + Math.random() * 1.2;
      const baseAlpha = isHotspot ? 0.98 : 0.65 + Math.random() * 0.35;

      // Diamond white, electric cyan, and luminous sky-blue palette
      let color = 'rgba(125, 245, 255, '; // cyan-200 / vivid electric cyan
      if (isHotspot) {
        color = hotspotWeight > 0.4 ? 'rgba(255, 255, 255, ' : 'rgba(224, 248, 255, ';
      } else if (Math.random() > 0.65) {
        color = 'rgba(255, 255, 255, '; // pure crystalline white sparkle
      } else if (Math.random() > 0.35) {
        color = 'rgba(56, 189, 248, '; // sky-400 vibrant
      } else {
        color = 'rgba(147, 197, 253, '; // light neon blue
      }

      // Generate dispersed volumetric cloud position for deactivated microphone state
      const scatterPower = Math.pow(Math.random(), 0.65);
      const scatterRadius = 0.5 + scatterPower * 2.3; // 0.5 to 2.8 radius

      // Organic directional dispersion
      const rx = (Math.random() - 0.5) * 2;
      const ry = (Math.random() - 0.5) * 2;
      const rz = (Math.random() - 0.5) * 2;
      const rLen = Math.hypot(rx, ry, rz) || 1;

      const blend = 0.45;
      const dx = x * (1 - blend) + (rx / rLen) * blend;
      const dy = y * (1 - blend) + (ry / rLen) * blend;
      const dz = z * (1 - blend) + (rz / rLen) * blend;
      const dLen = Math.hypot(dx, dy, dz) || 1;

      const dispX = (dx / dLen) * scatterRadius;
      const dispY = (dy / dLen) * scatterRadius;
      const dispZ = (dz / dLen) * scatterRadius;

      const driftSpeed = 0.3 + Math.random() * 0.7;
      const driftPhase = Math.random() * Math.PI * 2;
      const driftRadius = 0.04 + Math.random() * 0.08;

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        dispX,
        dispY,
        dispZ,
        driftSpeed,
        driftPhase,
        driftRadius,
        x,
        y,
        z,
        lat,
        lon,
        size: baseSize,
        alpha: baseAlpha,
        baseAlpha,
        color,
        isHotspot,
        hotspotWeight,
      });
    }

    particlesRef.current = particles;

    // Outer ambient drift particles - cosmic stardust field
    const ambient: AmbientParticle[] = [];
    const NUM_AMBIENT_COUNT = fullBackground ? 260 : 130;
    for (let i = 0; i < NUM_AMBIENT_COUNT; i++) {
      const dist = 0.8 + Math.random() * 2.6;
      const theta = Math.random() * Math.PI * 2;
      const phiAngle = Math.acos(Math.random() * 2 - 1);
      ambient.push({
        x: dist * Math.sin(phiAngle) * Math.cos(theta),
        y: dist * Math.sin(phiAngle) * Math.sin(theta),
        z: dist * Math.cos(phiAngle),
        vx: (Math.random() - 0.5) * 0.0018,
        vy: (Math.random() - 0.5) * 0.0018,
        vz: (Math.random() - 0.5) * 0.0018,
        size: 0.6 + Math.random() * 1.4,
        alpha: 0.18 + Math.random() * 0.4,
      });
    }
    ambientParticlesRef.current = ambient;
  }, [fullBackground]);

  // Main Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let lastTime = performance.now();

    const render = (currentTime: number) => {
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;
      pulseTimeRef.current += dt;

      // Smooth audio reactivity using mutable ref to prevent effect tear-down
      const currentStatus = statusRef.current;
      const currentAudio = audioLevelRef.current;
      const targetAudio = Math.min(100, Math.max(0, currentAudio));
      audioSmoothRef.current += (targetAudio - audioSmoothRef.current) * (dt * 12);
      const audioNorm = audioSmoothRef.current / 100; // 0 to 1

      // Handle canvas resizing for DPR sharpness & fluid background adaptation
      const dpr = window.devicePixelRatio || 1;
      let displayWidth = size;
      let displayHeight = size;

      if (fullBackground) {
        displayWidth = containerRef.current?.clientWidth || window.innerWidth;
        displayHeight = containerRef.current?.clientHeight || window.innerHeight;
      }

      if (canvas.width !== Math.floor(displayWidth * dpr) || canvas.height !== Math.floor(displayHeight * dpr)) {
        canvas.width = Math.floor(displayWidth * dpr);
        canvas.height = Math.floor(displayHeight * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, displayWidth, displayHeight);

      const centerX = displayWidth / 2;
      const centerY = displayHeight / 2;
      const baseRadius = fullBackground
        ? Math.min(displayWidth, displayHeight) * 0.21
        : displayWidth * 0.36;

      // 1. Calculate Active State, Smooth Dispersion & Brightness Transitions
      const isMicActive = currentStatus === 'listening' || currentStatus === 'thinking' || currentStatus === 'speaking';
      const targetDispersion = isMicActive ? 0.0 : 1.0;
      const targetBrightness = isMicActive ? 1.45 + audioNorm * 1.2 : 0.45;

      dispersionRef.current += (targetDispersion - dispersionRef.current) * Math.min(1, dt * 3.4);
      brightnessRef.current += (targetBrightness - brightnessRef.current) * Math.min(1, dt * 4.0);

      const disp = dispersionRef.current;
      // Smoothstep easing for point cloud dispersion: 3*d^2 - 2*d^3
      const easeDisp = disp * disp * (3 - 2 * disp);
      const brightness = brightnessRef.current;

      // 3D Rotation Physics: Interactive Cursor Control + Inertia + Ambient Auto-Rotation
      let baseYawSpeed = 0.35;
      let basePitchSpeed = 0.18;
      if (currentStatus === 'listening') {
        baseYawSpeed = 0.75 + audioNorm * 1.5;
        basePitchSpeed = 0.35 + audioNorm * 0.8;
      } else if (currentStatus === 'thinking') {
        baseYawSpeed = 2.4;
        basePitchSpeed = 1.1;
      } else if (currentStatus === 'speaking') {
        baseYawSpeed = 0.55;
        basePitchSpeed = 0.25;
      } else {
        // Dispersed cloud gentle cosmic rotation
        baseYawSpeed = 0.22;
        basePitchSpeed = 0.12;
      }

      if (!isDraggingRef.current) {
        const inertiaSpeed = Math.hypot(dragVelocityRef.current.yaw, dragVelocityRef.current.pitch);
        if (inertiaSpeed > 0.015) {
          rotationRef.current.yaw += dragVelocityRef.current.yaw * dt;
          rotationRef.current.pitch += dragVelocityRef.current.pitch * dt;
          const decay = Math.pow(0.92, dt * 60);
          dragVelocityRef.current.yaw *= decay;
          dragVelocityRef.current.pitch *= decay;
        } else {
          rotationRef.current.yaw += baseYawSpeed * dt;
          rotationRef.current.pitch += basePitchSpeed * dt;
        }
      }

      // Clamp pitch so the orb doesn't flip upside-down
      const maxPitch = Math.PI * 0.44;
      rotationRef.current.pitch = Math.max(-maxPitch, Math.min(maxPitch, rotationRef.current.pitch));

      // Magnetic hover tilt towards cursor position
      const targetHoverYaw = cursorHoverRef.current.yaw;
      const targetHoverPitch = cursorHoverRef.current.pitch;
      hoverTiltRef.current.yaw += (targetHoverYaw - hoverTiltRef.current.yaw) * Math.min(1, dt * 6);
      hoverTiltRef.current.pitch += (targetHoverPitch - hoverTiltRef.current.pitch) * Math.min(1, dt * 6);

      const totalYaw = rotationRef.current.yaw + hoverTiltRef.current.yaw;
      const totalPitch = rotationRef.current.pitch + hoverTiltRef.current.pitch;

      const cosYaw = Math.cos(totalYaw);
      const sinYaw = Math.sin(totalYaw);
      const cosPitch = Math.cos(totalPitch);
      const sinPitch = Math.sin(totalPitch);

      // 2. Render Deep Background Glow & Ambient Aura
      // Scales seamlessly across the background with soft zero-boundary radial falloff
      const haloRadius = fullBackground
        ? Math.max(displayWidth, displayHeight) * 0.65
        : baseRadius * (1.15 + (1 - easeDisp) * 0.35 + (isMicActive ? audioNorm * 0.25 : 0));
      const haloGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        baseRadius * 0.15,
        centerX,
        centerY,
        haloRadius
      );

      if (isMicActive) {
        if (status === 'thinking') {
          haloGrad.addColorStop(0, `rgba(168, 85, 247, ${(0.35 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(0.4, `rgba(99, 102, 241, ${(0.18 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(0.75, `rgba(79, 70, 229, ${(0.05 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        } else if (status === 'speaking') {
          haloGrad.addColorStop(0, `rgba(59, 130, 246, ${(0.38 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(0.45, `rgba(14, 165, 233, ${(0.18 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(0.75, `rgba(2, 132, 199, ${(0.05 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        } else {
          // Listening (Microphone Active) -> radiant electric cyan brilliance!
          haloGrad.addColorStop(0, `rgba(14, 165, 233, ${(0.45 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(0.35, `rgba(56, 189, 248, ${(0.24 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(0.7, `rgba(2, 132, 199, ${(0.08 * brightness).toFixed(3)})`);
          haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        }
      } else {
        // Deactivated microphone: subtle, quiet, dim starlight aura unified with background
        const breathe = Math.sin(pulseTimeRef.current * 1.2) * 0.02;
        haloGrad.addColorStop(0, `rgba(14, 165, 233, ${Math.max(0, 0.10 + breathe)})`);
        haloGrad.addColorStop(0.45, `rgba(56, 189, 248, ${Math.max(0, 0.035 + breathe)})`);
        haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      }

      ctx.fillStyle = haloGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, haloRadius, 0, Math.PI * 2);
      ctx.fill();

      // 3. Ambient Drifting Particles
      ctx.globalCompositeOperation = 'lighter';
      const ambients = ambientParticlesRef.current;
      for (let i = 0; i < ambients.length; i++) {
        const p = ambients[i];
        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;

        // Keep inside bounds
        const d = Math.hypot(p.x, p.y, p.z);
        if (d > 3.2 || d < 0.7) {
          p.vx *= -1;
          p.vy *= -1;
          p.vz *= -1;
        }

        // Project onto canvas
        const fov = 320;
        const scale = fov / (fov + p.z * baseRadius);
        const spreadMultiplier = fullBackground ? 2.4 : 1.0;
        const px = centerX + p.x * baseRadius * scale * spreadMultiplier;
        const py = centerY + p.y * baseRadius * scale * spreadMultiplier;

        ctx.fillStyle = `rgba(224, 242, 254, ${(p.alpha * (p.z > 0 ? 1 : 0.4) * (0.4 + 0.6 * (1 - easeDisp)) * brightness).toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(px, py, Math.max(0.6, p.size * scale), 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. Render Main 3D Particle Mesh (Quantum Sphere when active, Dispersed Point Cloud when deactivated)
      // Fluid, harmonic wave movement across the orb's particle surface
      const particles = particlesRef.current;
      const fov = 360;
      const t = pulseTimeRef.current;

      const waveFreq = status === 'thinking' ? 4.8 : status === 'listening' ? 3.4 : 2.8;
      const waveAmp =
        (0.065 +
        (status === 'listening' ? audioNorm * 0.06 : 0) +
        (status === 'speaking' ? Math.sin(t * 6) * 0.03 : 0)) *
        (1 - easeDisp);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Multi-harmonic sinusoidal wave ripple across the orb
        const ripple =
          (Math.sin(p.lat * 6.5 + t * waveFreq) *
           Math.cos(p.lon * 5.2 + t * (waveFreq * 0.88)) +
           Math.sin(p.lat * 3.5 - p.lon * 3.8 + t * (waveFreq * 0.65)) * 0.35) *
          waveAmp;
        const sphereR = 1 + ripple;

        // Subtle floating drift in the dispersed point cloud state
        const driftX = Math.sin(p.driftPhase + t * p.driftSpeed) * p.driftRadius * easeDisp;
        const driftY = Math.cos(p.driftPhase + t * (p.driftSpeed * 0.85)) * p.driftRadius * easeDisp;
        const driftZ = Math.sin(p.driftPhase * 1.5 + t * (p.driftSpeed * 0.7)) * p.driftRadius * easeDisp;

        // Blend 3D position between spherical quantum orb and dispersed point cloud
        const dispMultiplier = fullBackground ? 1.4 : 1.0;
        const curX = (p.baseX * sphereR) * (1 - easeDisp) + (p.dispX + driftX) * easeDisp * dispMultiplier;
        const curY = (p.baseY * sphereR) * (1 - easeDisp) + (p.dispY + driftY) * easeDisp * dispMultiplier;
        const curZ = (p.baseZ * sphereR) * (1 - easeDisp) + (p.dispZ + driftZ) * easeDisp * dispMultiplier;

        // 3D Rotation (Yaw around Y, then Pitch around X)
        // 1. Rotate around Y axis
        const x1 = curX * cosYaw - curZ * sinYaw;
        const z1 = curZ * cosYaw + curX * sinYaw;
        const y1 = curY;

        // 2. Rotate around X axis
        const y2 = y1 * cosPitch - z1 * sinPitch;
        const z2 = z1 * cosPitch + y1 * sinPitch;
        const x2 = x1;

        // 3. Perspective Projection
        const scale = fov / (fov + z2 * baseRadius);
        const px = centerX + x2 * baseRadius * scale;
        const py = centerY + y2 * baseRadius * scale;

        // Depth-based shading: front particles are brighter, rear are dim
        const depthFactor = (z2 + 1) * 0.5; // 0 to 1
        const pointSize = Math.max(
          0.85,
          p.size * scale * (0.8 + depthFactor * 0.6) * (p.isHotspot && easeDisp < 0.2 ? 1.5 : 1.0)
        );

        // Alpha & brightness modulation: brilliant and crisp
        const baseAlphaMod = (0.55 + (1 - easeDisp) * 0.65) * brightness;
        let finalAlpha = p.baseAlpha * (0.35 + depthFactor * 0.75) * baseAlphaMod;

        // Boost hotspot brightness when mic is active
        if (p.isHotspot && easeDisp < 0.2 && z2 > -0.2) {
          finalAlpha = Math.min(1.0, finalAlpha * 1.6 + 0.35 * brightness);
        }

        if (currentStatus === 'listening') {
          finalAlpha = Math.min(1.0, finalAlpha * (1.3 + audioNorm * 0.8));
        }

        // Draw particle dot with vibrant color
        ctx.fillStyle = `${p.color}${Math.max(0.04, Math.min(1, finalAlpha)).toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(px, py, pointSize, 0, Math.PI * 2);
        ctx.fill();

        // Extra diamond shine / specular core on front and hotspot particles for vivid brilliance
        if (finalAlpha > 0.55 && z2 > -0.2) {
          ctx.fillStyle = `rgba(255, 255, 255, ${(finalAlpha * 0.75 * Math.min(1.3, brightness)).toFixed(3)})`;
          ctx.beginPath();
          ctx.arc(px, py, pointSize * 0.45, 0, Math.PI * 2);
          ctx.fill();
        }

        // Extra flare on the two intense energy nodes when active and facing viewer
        if (easeDisp < 0.2 && p.isHotspot && p.hotspotWeight > 0.75 && z2 > 0.2 && isMicActive) {
          const flareRadius = pointSize * (3.0 + audioNorm * 1.5);
          const flareGrad = ctx.createRadialGradient(px, py, 0, px, py, flareRadius);
          flareGrad.addColorStop(0, `rgba(255, 255, 255, ${(0.95 * Math.min(1.3, brightness)).toFixed(2)})`);
          flareGrad.addColorStop(0.5, `rgba(56, 189, 248, ${(0.55 * Math.min(1.3, brightness)).toFixed(2)})`);
          flareGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = flareGrad;
          ctx.beginPath();
          ctx.arc(px, py, flareRadius, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 6. Electric Central Glow Core (only luminous when mic is active)
      if (isMicActive || easeDisp < 0.8) {
        const coreIntensity = (1 - easeDisp) * brightness;
        if (coreIntensity > 0.05) {
          const coreRadius = baseRadius * (0.2 + coreIntensity * 0.25);
          const coreGrad = ctx.createRadialGradient(
            centerX,
            centerY,
            0,
            centerX,
            centerY,
            coreRadius
          );
          coreGrad.addColorStop(0, `rgba(56, 189, 248, ${(0.22 * coreIntensity).toFixed(3)})`);
          coreGrad.addColorStop(0.6, `rgba(14, 165, 233, ${(0.06 * coreIntensity).toFixed(3)})`);
          coreGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = coreGrad;
          ctx.beginPath();
          ctx.arc(centerX, centerY, coreRadius, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      ctx.restore();

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    animFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [size, fullBackground]);

  // 3D Orbital Cursor Interaction Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement | null;
    if (target?.closest('button, a, input, textarea, select')) {
      return;
    }
    isDraggingRef.current = true;
    setIsDragging(true);
    lastMousePosRef.current = { x: e.clientX, y: e.clientY, time: performance.now() };
    dragVelocityRef.current = { yaw: 0, pitch: 0 };
    totalDragDistRef.current = 0;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const now = performance.now();
    const dtMouse = Math.max(0.001, (now - lastMousePosRef.current.time) / 1000);

    if (isDraggingRef.current) {
      const dx = e.clientX - lastMousePosRef.current.x;
      const dy = e.clientY - lastMousePosRef.current.y;
      totalDragDistRef.current += Math.hypot(dx, dy);

      // Sensitivity: smooth 1:1 rotation with cursor
      const sensitivity = 0.007;
      const dYaw = dx * sensitivity;
      const dPitch = dy * sensitivity;

      rotationRef.current.yaw += dYaw;
      rotationRef.current.pitch += dPitch;

      const maxPitch = Math.PI * 0.44;
      rotationRef.current.pitch = Math.max(-maxPitch, Math.min(maxPitch, rotationRef.current.pitch));

      dragVelocityRef.current = {
        yaw: dYaw / dtMouse,
        pitch: dPitch / dtMouse,
      };

      lastMousePosRef.current = { x: e.clientX, y: e.clientY, time: now };
    } else {
      // Magnetic hover tilt towards cursor position
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const nx = (e.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
        const ny = (e.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
        cursorHoverRef.current = {
          yaw: Math.max(-0.32, Math.min(0.32, nx * 0.25)),
          pitch: Math.max(-0.32, Math.min(0.32, ny * 0.25)),
        };
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    setIsDragging(false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }

    // Only click if it was not a rotation drag
    if (totalDragDistRef.current < 7) {
      onClick?.();
    }
  };

  const getStatusBadge = () => {
    switch (status) {
      case 'listening':
        return {
          icon: <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-300" />,
          label: 'Escuchando tu voz...',
          badgeClass: 'bg-cyan-950/80 border-cyan-500/60 text-cyan-200 shadow-cyan-500/30',
          pulseColor: 'bg-cyan-400',
        };
      case 'thinking':
        return {
          icon: <Brain className="w-3.5 h-3.5 animate-spin text-purple-300" />,
          label: 'Analizando instrucción...',
          badgeClass: 'bg-purple-950/80 border-purple-500/60 text-purple-200 shadow-purple-500/30',
          pulseColor: 'bg-purple-400',
        };
      case 'speaking':
        return {
          icon: <Volume2 className="w-3.5 h-3.5 animate-bounce text-blue-300" />,
          label: 'Lexi respondiendo...',
          badgeClass: 'bg-blue-950/80 border-blue-500/60 text-blue-200 shadow-blue-500/30',
          pulseColor: 'bg-blue-400',
        };
      default:
        return {
          icon: <Sparkles className="w-3.5 h-3.5 text-sky-400" />,
          label: isHovered ? '¡Haz clic para hablar!' : 'Toca el orbe para hablar',
          badgeClass: 'bg-slate-900/80 border-slate-700/80 text-slate-300 hover:border-cyan-500/50',
          pulseColor: 'bg-sky-400',
        };
    }
  };

  const badge = getStatusBadge();

  return (
    <div
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        cursorHoverRef.current = { yaw: 0, pitch: 0 };
      }}
      className={`relative select-none touch-none ${
        fullBackground
          ? 'w-full h-full absolute inset-0 overflow-hidden flex items-center justify-center'
          : 'flex flex-col items-center justify-center'
      } ${isDragging ? 'cursor-grabbing' : 'cursor-grab'} ${className}`}
      style={fullBackground ? undefined : { minWidth: size, minHeight: size }}
      title={
        status === 'listening'
          ? 'Arrastra para rotar • Haz clic para pausar escucha'
          : 'Arrastra para rotar • Haz clic para activar micrófono'
      }
    >
      {/* Outer ambient deep glow backdrop - unified with background */}
      <div
        className={`absolute rounded-full transition-all duration-700 pointer-events-none ${
          fullBackground ? 'w-[520px] h-[520px]' : 'w-80 h-80'
        } ${
          status === 'listening'
            ? 'bg-cyan-400/30 blur-3xl animate-pulse'
            : status === 'thinking'
            ? 'bg-purple-400/25 blur-3xl animate-pulse'
            : status === 'speaking'
            ? 'bg-blue-400/25 blur-3xl animate-pulse'
            : 'bg-cyan-600/5 blur-3xl opacity-30'
        }`}
      />

      {/* HTML5 Canvas Simulation: Quantum Particle Orb unified with Stardust Universe */}
      <canvas
        ref={canvasRef}
        className={`${fullBackground ? 'absolute inset-0 w-full h-full' : 'relative'} z-10 touch-none`}
        style={fullBackground ? { width: '100%', height: '100%' } : { width: size, height: size }}
      />

      {/* Interactive HUD & Status Bar below the Orb (when showControls is active) */}
      {showControls && (
        <div
          className={`${
            fullBackground ? 'absolute bottom-8 z-20 pointer-events-auto' : 'flex flex-col items-center gap-2 mt-1 z-20'
          } flex flex-col items-center gap-2`}
        >
          <button
            id="btn-cyber-orb-activate"
            type="button"
            onClick={onClick}
            className={`px-4 py-2 rounded-full border text-xs font-semibold backdrop-blur-md flex items-center gap-2 shadow-sm transition-all duration-300 cursor-pointer ${badge.badgeClass}`}
          >
            <span className={`w-2 h-2 rounded-full ${badge.pulseColor} animate-ping`} />
            {badge.icon}
            <span className="tracking-wide">{badge.label}</span>
          </button>

          {/* Interim speech transcript display */}
          {interimTranscript && (
            <div className="max-w-md px-3.5 py-1.5 rounded-xl bg-slate-900/90 border border-cyan-500/40 text-cyan-200 text-xs font-mono text-center shadow-lg animate-fade-in backdrop-blur-md">
              <span className="text-cyan-400 mr-1.5">“</span>
              <span>{interimTranscript}</span>
              <span className="text-cyan-400 ml-1.5">”</span>
            </div>
          )}

          {/* Optional custom titles */}
          {title && (
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
              {title}
            </h2>
          )}
          {subtitle && (
            <p className="text-xs text-slate-500 dark:text-zinc-400 max-w-sm text-center">
              {subtitle}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
