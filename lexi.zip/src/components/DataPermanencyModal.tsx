import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertCircle, Copy, Check, ShieldCheck, RefreshCw, X, ExternalLink } from 'lucide-react';
import { getSupabaseStatus, testSupabaseConnection, SUPABASE_SETUP_SQL } from '../services/supabaseClient';
import firebaseConfig from '../../firebase-applet-config.json';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const DataPermanencyModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [supabaseStatus, setSupabaseStatus] = useState(() => getSupabaseStatus());
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSupabaseStatus(getSupabaseStatus());
      setTestResult(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testSupabaseConnection();
      setTestResult(res);
    } catch (e: any) {
      setTestResult({ success: false, message: e?.message || 'Error al conectar' });
    } finally {
      setIsTesting(false);
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SETUP_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div
        id="data-permanency-modal"
        className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-500/20">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                Permanencia de Datos (Cloud & Supabase)
              </h2>
              <p className="text-xs text-slate-500">
                Almacenamiento persistente para comandos, extracciones, auditoría y metadatos de Lexi
              </p>
            </div>
          </div>
          <button
            id="close-permanency-modal"
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Active Cloud Database (Firebase Firestore) */}
          <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/60">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <span className="text-xs font-bold text-emerald-900">
                  Firebase Firestore Cloud DB (Activo & Sincronizado)
                </span>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                <CheckCircle2 className="w-3 h-3" /> Conectado
              </span>
            </div>
            <div className="mt-2 text-xs text-slate-600 space-y-1">
              <div>
                <span className="font-semibold text-slate-700">Database ID: </span>
                <code className="font-mono text-emerald-800 bg-emerald-100/60 px-1.5 py-0.5 rounded text-[11px]">
                  {firebaseConfig.firestoreDatabaseId}
                </code>
              </div>
              <div>
                <span className="font-semibold text-slate-700">Colecciones sincronizadas: </span>
                <span className="text-slate-600 font-mono text-[11px]">
                  command_history, extractions, audit_logs, document_metadata, profiles
                </span>
              </div>
            </div>
          </div>

          {/* Supabase Integration Card */}
          <div className="p-4 rounded-xl border border-teal-200 bg-teal-50/40">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-teal-700" />
                <div>
                  <span className="text-xs font-bold text-teal-950">
                    Supabase PostgreSQL (Capa Dual de Respaldo)
                  </span>
                  <p className="text-[11px] text-teal-700">
                    Cliente oficial <code>@supabase/supabase-js</code> instalado y enlazado
                  </p>
                </div>
              </div>
              {supabaseStatus.configured ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-700 bg-teal-100 px-2 py-0.5 rounded-full">
                  <CheckCircle2 className="w-3 h-3" /> Configurado
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  <AlertCircle className="w-3 h-3" /> Variables Listas
                </span>
              )}
            </div>

            <div className="mt-3 text-xs text-slate-600 space-y-2">
              <div className="p-2.5 rounded-lg bg-white border border-teal-100">
                <div className="flex items-center justify-between text-slate-700 text-[11px] mb-1">
                  <span className="font-semibold">Estado de Variables:</span>
                  <span className={supabaseStatus.configured ? 'text-teal-700 font-medium' : 'text-slate-500'}>
                    {supabaseStatus.configured ? 'URL y Clave Anon detectadas' : 'VITE_SUPABASE_URL en .env.example'}
                  </span>
                </div>
                {supabaseStatus.url && (
                  <div className="text-[11px] font-mono text-slate-600 truncate">
                    URL: {supabaseStatus.url}
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  id="btn-test-supabase"
                  type="button"
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>Probar Conexión Supabase</span>
                </button>

                <button
                  id="btn-copy-supabase-sql"
                  type="button"
                  onClick={handleCopySql}
                  className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-teal-800 border border-teal-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSql ? '¡SQL Copiado!' : 'Copiar Script SQL de Tablas'}</span>
                </button>
              </div>

              {testResult && (
                <div
                  className={`mt-2 p-2.5 rounded-lg text-xs flex items-start gap-2 border ${
                    testResult.success
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-amber-50 border-amber-200 text-amber-800'
                  }`}
                >
                  {testResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  )}
                  <div>{testResult.message}</div>
                </div>
              )}
            </div>
          </div>

          {/* Setup Guide instructions */}
          <div className="rounded-xl border border-slate-200 p-4 bg-slate-50/50">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Tablas de Supabase Generadas para Lexi:
            </h3>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc list-inside">
              <li>
                <code className="font-mono text-slate-800 font-bold">extraction_records</code>: Almacena extracciones realizadas por IA con conteo de tablas y campos.
              </li>
              <li>
                <code className="font-mono text-slate-800 font-bold">voice_commands</code>: Historial de comandos orales ejecutados en Docs, Sheets y Obsidian.
              </li>
              <li>
                <code className="font-mono text-slate-800 font-bold">audit_logs</code>: Trazabilidad inmutable de todas las acciones del asistente.
              </li>
              <li>
                <code className="font-mono text-slate-800 font-bold">document_metadata</code>: Metadatos y características técnicas de documentos procesados.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Permanencia dual: Firestore Cloud + Supabase Client Sync
          </span>
          <button
            id="close-permanency-footer-btn"
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold cursor-pointer transition-all"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
