import React, { useState, useEffect } from 'react';
import { WorkspaceFile, PendingActionConfirmation } from '../types';
import {
  listGoogleSheets,
  createGoogleSheet,
  appendSpreadsheetRow,
  readSpreadsheetValues,
  updateSpreadsheetCell,
  updateSpreadsheetRange,
} from '../services/workspaceApi';
import {
  Table,
  Plus,
  RefreshCw,
  ExternalLink,
  Send,
  AlertCircle,
  Clock,
  LayoutGrid,
  Sparkles,
  Zap,
  ArrowDown,
  ArrowRight,
  Radio,
  CheckCircle2,
  Edit2,
} from 'lucide-react';
import { VoiceToCellBar } from './VoiceToCellBar';
import {
  colIndexToLetter,
  colLetterToIndex,
  ParsedVoiceCellCommand,
} from '../utils/voiceToCellParser';
import { saveCommandRecord } from '../services/firestoreDb';

interface Props {
  isAuthenticated: boolean;
  onPromptLogin: () => void;
  onRequestAction: (action: PendingActionConfirmation) => void;
}

export const GoogleSheetsManager: React.FC<Props> = ({
  isAuthenticated,
  onPromptLogin,
  onRequestAction,
}) => {
  const [sheets, setSheets] = useState<WorkspaceFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // New Sheet Form
  const [newTitle, setNewTitle] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // Selected Sheet for Inspection & Appending
  const [selectedSheetId, setSelectedSheetId] = useState<string | null>(null);
  const [sheetData, setSheetData] = useState<{ range: string; values: string[][] } | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(false);

  // Append row state
  const [newRowInput, setNewRowInput] = useState('');
  const [isAppending, setIsAppending] = useState(false);

  // Voice-to-Cell Real-Time States
  const [isVoiceToCellActive, setIsVoiceToCellActive] = useState(false);
  const [activeCell, setActiveCell] = useState('B2');
  const [highlightedCell, setHighlightedCell] = useState<{ cell: string; timestamp: number } | null>(null);
  const [lastAction, setLastAction] = useState<{ cell: string; value: string | number; timestamp: number } | null>(null);
  const [isProcessingVoiceCell, setIsProcessingVoiceCell] = useState(false);
  const [autoAdvance, setAutoAdvance] = useState(true);
  const [advanceDirection, setAdvanceDirection] = useState<'down' | 'right'>('down');
  const [editingCellCoord, setEditingCellCoord] = useState<string | null>(null);
  const [editingCellValue, setEditingCellValue] = useState('');

  // Clear highlight after 2.5 seconds
  useEffect(() => {
    if (highlightedCell) {
      const timer = setTimeout(() => {
        setHighlightedCell(null);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [highlightedCell]);

  const fetchSheets = async () => {
    if (!isAuthenticated) return;
    setIsLoading(true);
    setError(null);
    try {
      const items = await listGoogleSheets();
      setSheets(items);
      // Auto-select first sheet if none selected yet
      if (items.length > 0 && !selectedSheetId) {
        handleSelectSheet(items[0].id);
      }
    } catch (err: any) {
      console.warn('Error listing sheets:', err?.message || err);
      setError(err?.message || 'Failed to fetch Google Sheets.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchSheets();
    }
  }, [isAuthenticated]);

  // Load single spreadsheet values
  const handleSelectSheet = async (id: string) => {
    setSelectedSheetId(id);
    setIsLoadingData(true);
    try {
      const data = await readSpreadsheetValues(id, 'Sheet1!A1:Z50');
      setSheetData(data);
    } catch (err: any) {
      console.warn('Error reading spreadsheet values:', err?.message || err);
      setError(err?.message || 'Failed to read spreadsheet rows.');
    } finally {
      setIsLoadingData(false);
    }
  };

  // Extract header columns for voice matching
  const headers: string[] =
    sheetData?.values && sheetData.values.length > 0
      ? sheetData.values[0].map((h, i) => h || `Col ${i + 1}`)
      : [];

  const selectedSheet = sheets.find((s) => s.id === selectedSheetId);

  // Apply real-time Voice-to-Cell command
  const handleApplyVoiceCommand = async (parsed: ParsedVoiceCellCommand) => {
    if (!selectedSheetId) {
      setError('Por favor selecciona una hoja de cálculo primero.');
      return;
    }

    setIsProcessingVoiceCell(true);
    setError(null);

    try {
      if (parsed.type === 'select_cell' && parsed.cell) {
        setActiveCell(parsed.cell.toUpperCase());
      } else if (parsed.direction || parsed.type === 'navigate') {
        const curCol = activeCell.replace(/\d+/g, '').toUpperCase() || 'A';
        const curRow = parseInt(activeCell.replace(/\D+/g, ''), 10) || 1;
        const curColIdx = colLetterToIndex(curCol);
        let nextCol = curCol;
        let nextRow = curRow;

        if (parsed.direction === 'next' || advanceDirection === 'right') {
          nextCol = colIndexToLetter(curColIdx + 1);
        } else if (parsed.direction === 'down' || advanceDirection === 'down') {
          nextRow = curRow + 1;
        } else if (parsed.direction === 'prev') {
          nextCol = colIndexToLetter(Math.max(0, curColIdx - 1));
        } else if (parsed.direction === 'up') {
          nextRow = Math.max(1, curRow - 1);
        }
        setActiveCell(`${nextCol}${nextRow}`);
      } else if (parsed.type === 'clear_cell' || parsed.type === 'set_cell') {
        const targetCell = (parsed.cell || activeCell).toUpperCase();
        const targetVal = parsed.type === 'clear_cell' ? '' : (parsed.value !== undefined ? parsed.value : '');
        const colLetter = targetCell.replace(/\d+/g, '').toUpperCase() || 'A';
        const colIdx = colLetterToIndex(colLetter);
        const rowNum = parseInt(targetCell.replace(/\D+/g, ''), 10) || 1;
        const rowIdx = rowNum - 1; // 0-based

        // Optimistic update to UI table
        setSheetData((prev) => {
          const values = prev ? prev.values.map((r) => [...r]) : [];
          while (values.length <= rowIdx) {
            values.push([]);
          }
          while (values[rowIdx].length <= colIdx) {
            values[rowIdx].push('');
          }
          values[rowIdx][colIdx] = String(targetVal);
          return {
            range: prev?.range || 'Sheet1!A1:Z50',
            values,
          };
        });

        setHighlightedCell({ cell: targetCell, timestamp: Date.now() });
        setLastAction({ cell: targetCell, value: targetVal, timestamp: Date.now() });

        // Auto-advance cursor to next row or column if enabled
        if (autoAdvance && parsed.type === 'set_cell') {
          if (advanceDirection === 'down') {
            setActiveCell(`${colLetter}${rowNum + 1}`);
          } else {
            setActiveCell(`${colIndexToLetter(colIdx + 1)}${rowNum}`);
          }
        }

        // Persist directly to Google Sheets via API
        await updateSpreadsheetCell(selectedSheetId, targetCell, targetVal);

        // Record in Lexi's persistent Command History
        saveCommandRecord({
          commandText: parsed.rawText || `Dictado en celda ${targetCell}: ${targetVal}`,
          actionType: 'sheets_update_cell',
          targetDocumentTitle: selectedSheet?.name || 'Google Sheet',
          modelUsed: 'voice-to-cell-realtime',
          status: 'executed',
          resultSummary: `Celda ${targetCell} actualizada con "${targetVal}" vía Voice-to-Cell.`,
          metadata: {
            spreadsheetId: selectedSheetId,
          },
        }).catch((e) => console.warn('Record save notice:', e));
      } else if (parsed.type === 'set_row' && parsed.rowIndex && parsed.rowValues) {
        const rowNum = parsed.rowIndex;
        const rowIdx = rowNum - 1;
        const rowValues = parsed.rowValues;

        setSheetData((prev) => {
          const values = prev ? prev.values.map((r) => [...r]) : [];
          while (values.length <= rowIdx) {
            values.push([]);
          }
          for (let i = 0; i < rowValues.length; i++) {
            while (values[rowIdx].length <= i) {
              values[rowIdx].push('');
            }
            values[rowIdx][i] = String(rowValues[i]);
          }
          return {
            range: prev?.range || 'Sheet1!A1:Z50',
            values,
          };
        });

        const endCol = colIndexToLetter(rowValues.length - 1);
        const range = `A${rowNum}:${endCol}${rowNum}`;
        setHighlightedCell({ cell: range, timestamp: Date.now() });
        setLastAction({ cell: range, value: rowValues.join(', '), timestamp: Date.now() });

        await updateSpreadsheetRange(selectedSheetId, range, [rowValues]);

        saveCommandRecord({
          commandText: parsed.rawText || `Fila ${rowNum} actualizada con ${rowValues.length} valores`,
          actionType: 'sheets_update_cell',
          targetDocumentTitle: selectedSheet?.name || 'Google Sheet',
          modelUsed: 'voice-to-cell-realtime',
          status: 'executed',
          resultSummary: `Fila ${rowNum} actualizada en Google Sheets vía Voice-to-Cell.`,
          metadata: {
            spreadsheetId: selectedSheetId,
          },
        }).catch((e) => console.warn('Record save notice:', e));
      }
    } catch (err: any) {
      console.error('Error applying voice cell command:', err);
      setError(err?.message || 'Error al actualizar la celda en Google Sheets.');
      throw err;
    } finally {
      setIsProcessingVoiceCell(false);
    }
  };

  // Add new empty row to spreadsheet
  const handleAddNewRow = async () => {
    if (!selectedSheetId) return;
    const colCount = headers.length || 4;
    const emptyRow = new Array(colCount).fill('');
    try {
      await appendSpreadsheetRow(selectedSheetId, ['']);
      await handleSelectSheet(selectedSheetId);
    } catch (e: any) {
      setError(e?.message || 'Failed to add row');
    }
  };

  // Commit direct inline cell edit
  const handleCommitCellEdit = async (coord: string, val: string) => {
    setEditingCellCoord(null);
    await handleApplyVoiceCommand({
      type: 'set_cell',
      cell: coord,
      value: val,
      confidence: 1,
      rawText: `Edición manual de ${coord}: ${val}`,
    });
  };

  // Create Spreadsheet (Requires User Confirmation as per Workspace Skill)
  const handleInitiateCreate = (e: React.FormEvent, templateHeaders?: (string | number)[][]) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const initialRows = templateHeaders || [
      ['Fecha', 'Concepto / Elemento', 'Categoría', 'Monto (USD)', 'Estado'],
      [new Date().toLocaleDateString(), 'Automatización por Voz Lexi', 'Operaciones', '$450.00', 'Completado'],
      [new Date().toLocaleDateString(), 'Infraestructura Cloud', 'Tecnología', '$89.00', 'Aprobado'],
    ];

    onRequestAction({
      id: 'create-sheet-' + Date.now(),
      type: 'sheets_create',
      title: 'Crear Nueva Hoja de Cálculo en Google Sheets',
      targetName: newTitle,
      details: [
        { label: 'Título de la Hoja', value: newTitle },
        { label: 'Columnas Iniciales', value: (initialRows[0] as string[]) || [] },
      ],
      onConfirm: async () => {
        setIsCreating(true);
        try {
          const res = await createGoogleSheet(newTitle, initialRows);
          setNewTitle('');
          await fetchSheets();
          handleSelectSheet(res.id);
        } catch (err: any) {
          setError(err?.message || 'Failed to create spreadsheet');
        } finally {
          setIsCreating(false);
        }
      },
      onCancel: () => {},
    });
  };

  // Append Row (Requires User Confirmation as per Workspace Skill)
  const handleInitiateAppend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSheetId || !newRowInput.trim()) return;

    const rowValues = newRowInput.split(/,|\t/).map((s) => s.trim());
    const targetSheet = sheets.find((s) => s.id === selectedSheetId);

    onRequestAction({
      id: 'append-sheet-' + Date.now(),
      type: 'sheets_append',
      title: 'Append Row to Google Sheet',
      targetName: targetSheet?.name || 'Google Sheet',
      targetId: selectedSheetId,
      details: [
        { label: 'Target Spreadsheet', value: targetSheet?.name || 'Selected Sheet' },
        { label: 'Values to Append (Columns)', value: rowValues },
      ],
      onConfirm: async () => {
        setIsAppending(true);
        try {
          await appendSpreadsheetRow(selectedSheetId, rowValues);
          setNewRowInput('');
          await handleSelectSheet(selectedSheetId);
        } catch (err: any) {
          setError(err?.message || 'Failed to append row');
        } finally {
          setIsAppending(false);
        }
      },
      onCancel: () => {},
    });
  };

  // Quick Templates
  const applyTemplate = (type: 'expenses' | 'sprint' | 'workflow') => {
    const today = new Date().toLocaleDateString();
    if (type === 'expenses') {
      setNewTitle(`Presupuesto y Gastos - ${today}`);
    } else if (type === 'sprint') {
      setNewTitle(`Velocidad de Sprint & Tareas - ${today}`);
    } else {
      setNewTitle(`Registro de Automatización con Lexi - ${today}`);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
          <Table className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Conectar Google Sheets</h2>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          Inicia sesión con tu cuenta de Google para habilitar el asistente de voz Lexi y el modo Voice-to-Cell en tiempo real en tus hojas de cálculo.
        </p>
        <button
          type="button"
          onClick={onPromptLogin}
          className="px-6 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-sm hover:bg-emerald-700 shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
        >
          Iniciar sesión con Google
        </button>
      </div>
    );
  }

  // Get active cell coordinates details
  const activeCol = activeCell.replace(/\d+/g, '').toUpperCase() || 'A';
  const activeColIdx = colLetterToIndex(activeCol);
  const activeRowNum = parseInt(activeCell.replace(/\D+/g, ''), 10) || 1;
  const activeHeaderName = headers[activeColIdx] || `Columna ${activeCol}`;

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Table className="w-6 h-6 text-emerald-600" />
            Google Sheets & Voice-to-Cell en Tiempo Real
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Dicta valores a celdas individuales por voz, identifica columnas por nombre y automatiza hojas de cálculo en vivo.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchSheets}
            disabled={isLoading}
            className="px-3.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refrescar Hojas</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </span>
          <button type="button" onClick={() => setError(null)} className="text-rose-500 hover:text-rose-700">
            ✕
          </button>
        </div>
      )}

      {/* Voice-to-Cell Mode Bar */}
      <VoiceToCellBar
        isEnabled={isVoiceToCellActive}
        onToggle={(enabled) => setIsVoiceToCellActive(enabled)}
        activeCell={activeCell}
        headers={headers}
        onApplyVoiceCommand={handleApplyVoiceCommand}
        isProcessing={isProcessingVoiceCell}
        lastAction={lastAction}
        spreadsheetTitle={selectedSheet?.name}
        hasSheetSelected={!!selectedSheetId}
      />

      {/* Main Grid: Create Sheet & Inspect */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Create Sheet & Row Form */}
        <div className="lg:col-span-4 space-y-4">
          {/* Spreadsheets selector list */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Tus Hojas de Google ({sheets.length})
              </h2>
              <span className="text-[10px] text-slate-400">Google Drive</span>
            </div>

            {isLoading ? (
              <div className="py-6 text-center text-xs text-slate-500 space-y-2">
                <div className="w-5 h-5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
                <span>Cargando hojas de cálculo...</span>
              </div>
            ) : sheets.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400 space-y-1">
                <Table className="w-6 h-6 text-slate-300 mx-auto" />
                <p>No se encontraron hojas en Google Drive.</p>
              </div>
            ) : (
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {sheets.map((sh) => (
                  <button
                    key={sh.id}
                    type="button"
                    onClick={() => handleSelectSheet(sh.id)}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between gap-2 ${
                      selectedSheetId === sh.id
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold shadow-xs'
                        : 'bg-slate-50/70 border-slate-200 hover:bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs truncate">{sh.name}</div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5 font-normal">
                        <Clock className="w-2.5 h-2.5" />
                        {sh.modifiedTime ? new Date(sh.modifiedTime).toLocaleDateString() : 'Reciente'}
                      </div>
                    </div>
                    {selectedSheetId === sh.id && (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full shrink-0">
                        Activa
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quick Create Sheet */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-emerald-600" />
              Nueva Hoja de Cálculo
            </h2>

            {/* Quick Templates */}
            <div>
              <div className="flex flex-wrap gap-1">
                <button
                  type="button"
                  onClick={() => applyTemplate('expenses')}
                  className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-[10px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  Gastos
                </button>
                <button
                  type="button"
                  onClick={() => applyTemplate('sprint')}
                  className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-[10px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  Sprint
                </button>
                <button
                  type="button"
                  onClick={() => applyTemplate('workflow')}
                  className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-[10px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  Automatización
                </button>
              </div>
            </div>

            <form onSubmit={(e) => handleInitiateCreate(e)} className="space-y-2">
              <input
                type="text"
                required
                placeholder="Título de la hoja..."
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-hidden"
              />

              <button
                type="submit"
                disabled={!newTitle.trim() || isCreating}
                className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Crear Hoja en Google</span>
              </button>
            </form>
          </div>

          {/* Append Row form */}
          {selectedSheetId && (
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Table className="w-3.5 h-3.5 text-emerald-600" />
                  Añadir Fila Completa
                </span>
              </div>

              <form onSubmit={handleInitiateAppend} className="space-y-2">
                <input
                  type="text"
                  placeholder="Valores separados por coma (ej: 2026-09-18, Nómina, 450, Pagado)..."
                  value={newRowInput}
                  onChange={(e) => setNewRowInput(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-hidden font-mono"
                />
                <button
                  type="submit"
                  disabled={!newRowInput.trim() || isAppending}
                  className="w-full py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3 h-3" />
                  <span>Insertar Fila en Sheets</span>
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Right: Live Interactive Spreadsheet Grid */}
        <div className="lg:col-span-8 space-y-3">
          {selectedSheetId ? (
            <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
              {/* Table Toolbar & Coordinate Badge */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <LayoutGrid className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 truncate max-w-xs">
                      {selectedSheet?.name || 'Hoja Activa'}
                    </h3>
                    <span className="text-[10px] text-slate-400">
                      Rango: {sheetData?.range || 'Sheet1!A1:Z50'}
                    </span>
                  </div>
                </div>

                {/* Coordinate & Auto-Advance Control */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Current Active Cell Badge */}
                  <div className="px-2.5 py-1 rounded-lg bg-blue-50 border border-blue-200 text-blue-900 text-xs font-mono font-bold flex items-center gap-1.5">
                    <span className="text-[10px] text-blue-500 font-sans font-normal uppercase">Celda:</span>
                    <span>{activeCell}</span>
                    <span className="text-[10px] text-blue-600 font-sans font-medium">
                      ({activeHeaderName})
                    </span>
                  </div>

                  {/* Auto-Advance Toggle */}
                  <button
                    type="button"
                    onClick={() => setAutoAdvance(!autoAdvance)}
                    title="Avanzar celda automáticamente al dictar por voz"
                    className={`px-2 py-1 rounded-lg border text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                      autoAdvance
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-slate-100 border-slate-200 text-slate-500'
                    }`}
                  >
                    <ArrowDown className="w-3 h-3" />
                    <span>Auto-avanzar: {autoAdvance ? 'Sí' : 'No'}</span>
                  </button>

                  {/* Direction Switch */}
                  {autoAdvance && (
                    <button
                      type="button"
                      onClick={() =>
                        setAdvanceDirection(advanceDirection === 'down' ? 'right' : 'down')
                      }
                      title="Dirección de avance al dictar"
                      className="px-2 py-1 rounded-lg border border-slate-200 bg-slate-50 text-slate-700 text-[11px] font-semibold flex items-center gap-1 hover:bg-slate-100 cursor-pointer"
                    >
                      {advanceDirection === 'down' ? (
                        <>
                          <ArrowDown className="w-3 h-3 text-emerald-600" />
                          <span>Hacia Abajo</span>
                        </>
                      ) : (
                        <>
                          <ArrowRight className="w-3 h-3 text-emerald-600" />
                          <span>A la Derecha</span>
                        </>
                      )}
                    </button>
                  )}

                  {/* Add Row Button */}
                  <button
                    type="button"
                    onClick={handleAddNewRow}
                    className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-semibold flex items-center gap-1 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-3 h-3 text-emerald-600" />
                    <span>+ Fila</span>
                  </button>

                  {/* External Google Sheets Link */}
                  <a
                    href={`https://docs.google.com/spreadsheets/d/${selectedSheetId}/edit`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-emerald-700 hover:bg-slate-50 transition-colors"
                    title="Abrir en Google Sheets"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Status bar */}
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  Haz clic en cualquier celda para seleccionarla o dicta: «En B3 pon 450»
                </span>
                {isLoadingData && (
                  <span className="text-emerald-600 font-semibold animate-pulse flex items-center gap-1">
                    <RefreshCw className="w-3 h-3 animate-spin" /> Actualizando celdas...
                  </span>
                )}
              </div>

              {/* Interactive Spreadsheet Grid */}
              <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-96 shadow-inner bg-slate-50/50">
                {sheetData?.values && sheetData.values.length > 0 ? (
                  <table className="min-w-full text-xs text-left border-collapse">
                    {/* Header Columns with Letters (A, B, C...) & Titles */}
                    <thead className="bg-slate-100 border-b border-slate-200 font-semibold text-slate-700 sticky top-0 z-10">
                      <tr>
                        {/* Corner Top-Left Cell */}
                        <th className="w-10 px-2 py-2 border-r border-slate-200 text-center bg-slate-200/70 text-slate-500 text-[10px] font-mono select-none">
                          #
                        </th>

                        {sheetData.values[0].map((header, cIdx) => {
                          const colLetter = colIndexToLetter(cIdx);
                          const isColActive = activeCol === colLetter;
                          return (
                            <th
                              key={cIdx}
                              className={`px-3 py-2 border-r border-slate-200 whitespace-nowrap transition-colors ${
                                isColActive
                                  ? 'bg-blue-100/70 text-blue-900 border-b-2 border-b-blue-600'
                                  : 'bg-slate-100/90 text-slate-700'
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <span className="px-1.5 py-0.5 rounded bg-slate-200/80 text-slate-600 text-[10px] font-mono font-bold">
                                  {colLetter}
                                </span>
                                <span className="font-bold text-xs">
                                  {header || `Columna ${colLetter}`}
                                </span>
                              </div>
                            </th>
                          );
                        })}
                      </tr>
                    </thead>

                    {/* Data Rows */}
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {sheetData.values.slice(1).map((row, rIdx) => {
                        const rowNumber = rIdx + 2; // Row 1 is headers
                        const isRowActive = activeRowNum === rowNumber;

                        return (
                          <tr
                            key={rIdx}
                            className={`transition-colors ${
                              isRowActive ? 'bg-blue-50/30' : 'hover:bg-slate-50/60'
                            }`}
                          >
                            {/* Row Number Header */}
                            <td
                              onClick={() => setActiveCell(`A${rowNumber}`)}
                              className={`px-2 py-1.5 border-r border-slate-200 text-center font-mono text-[11px] select-none cursor-pointer transition-colors ${
                                isRowActive
                                  ? 'bg-blue-100/80 text-blue-900 font-bold'
                                  : 'bg-slate-100/70 text-slate-500 hover:bg-slate-200'
                              }`}
                              title={`Seleccionar fila ${rowNumber}`}
                            >
                              {rowNumber}
                            </td>

                            {/* Row Cells */}
                            {sheetData.values[0].map((_, cIdx) => {
                              const colLetter = colIndexToLetter(cIdx);
                              const cellCoord = `${colLetter}${rowNumber}`;
                              const cellValue = row[cIdx] ?? '';
                              const isActive = activeCell === cellCoord;
                              const isHighlighted =
                                highlightedCell?.cell === cellCoord ||
                                (highlightedCell?.cell.includes(':') &&
                                  highlightedCell.cell.includes(String(rowNumber)));
                              const isEditing = editingCellCoord === cellCoord;

                              return (
                                <td
                                  key={cIdx}
                                  onClick={() => {
                                    setActiveCell(cellCoord);
                                  }}
                                  onDoubleClick={() => {
                                    setEditingCellCoord(cellCoord);
                                    setEditingCellValue(cellValue);
                                  }}
                                  className={`px-3 py-1.5 border-r border-slate-100 text-slate-800 whitespace-nowrap font-mono text-[11px] transition-all duration-200 relative cursor-pointer select-none ${
                                    isHighlighted
                                      ? 'bg-emerald-100 text-emerald-950 font-bold ring-2 ring-emerald-500 ring-inset shadow-xs'
                                      : isActive
                                      ? 'bg-blue-50/80 text-blue-900 font-bold ring-2 ring-blue-500 ring-inset shadow-xs'
                                      : 'hover:bg-slate-100/50'
                                  }`}
                                  title={`Celda ${cellCoord} (${headers[cIdx] || colLetter})`}
                                >
                                  {isEditing ? (
                                    <input
                                      autoFocus
                                      type="text"
                                      value={editingCellValue}
                                      onChange={(e) => setEditingCellValue(e.target.value)}
                                      onBlur={() => handleCommitCellEdit(cellCoord, editingCellValue)}
                                      onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                          handleCommitCellEdit(cellCoord, editingCellValue);
                                        } else if (e.key === 'Escape') {
                                          setEditingCellCoord(null);
                                        }
                                      }}
                                      className="w-full bg-white border border-blue-500 rounded px-1.5 py-0.5 text-xs text-slate-900 outline-hidden font-mono"
                                    />
                                  ) : (
                                    <div className="flex items-center justify-between gap-1">
                                      <span className="truncate">
                                        {cellValue !== '' ? cellValue : <span className="text-slate-300 italic">—</span>}
                                      </span>
                                      {isHighlighted && (
                                        <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0 animate-bounce" />
                                      )}
                                    </div>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                ) : (
                  <div className="p-8 text-center text-xs text-slate-400 space-y-2">
                    <Table className="w-8 h-8 text-slate-300 mx-auto" />
                    <p>No hay datos en la hoja o el rango está vacío.</p>
                    <button
                      type="button"
                      onClick={handleAddNewRow}
                      className="px-3 py-1 rounded-xl bg-emerald-600 text-white font-semibold text-xs hover:bg-emerald-700 cursor-pointer"
                    >
                      + Insertar Primera Fila
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500 space-y-3">
              <Table className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-sm font-bold text-slate-800">
                Selecciona una hoja de cálculo
              </h3>
              <p className="max-w-sm mx-auto text-slate-400">
                Elige una hoja de cálculo en la columna izquierda o crea una nueva para activar el modo Voice-to-Cell.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

