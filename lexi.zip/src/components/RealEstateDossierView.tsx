import React from 'react';
import {
  Building2,
  Bed,
  Bath,
  Car,
  Maximize2,
  MapPin,
  Calendar,
  Compass,
  ShieldCheck,
  Zap,
  CheckCircle2,
  Phone,
  Mail,
  Globe,
  Award,
  TrendingUp,
  Landmark,
  QrCode,
  Layers,
} from 'lucide-react';
import { PropertyCRMRecord, PropertyImage, TechnicalSheetPdfOptions } from '../types';

interface Props {
  property: PropertyCRMRecord;
  options: TechnicalSheetPdfOptions;
  containerRef?: React.RefObject<HTMLDivElement | null>;
}

export const RealEstateDossierView: React.FC<Props> = ({
  property,
  options,
  containerRef,
}) => {
  const isEn = options.language === 'en';

  const formattedPrice = new Intl.NumberFormat(isEn ? 'en-US' : 'es-ES', {
    style: 'currency',
    currency: property.currency,
    maximumFractionDigits: 0,
  }).format(property.price);

  const pricePerM2 = Math.round(property.price / (property.specs.builtAreaM2 || 1));
  const formattedPricePerM2 = new Intl.NumberFormat(isEn ? 'en-US' : 'es-ES', {
    style: 'currency',
    currency: property.currency,
    maximumFractionDigits: 0,
  }).format(pricePerM2);

  const heroImage: PropertyImage =
    property.images.find((img) => img.isHero) ||
    property.images[0] || {
      id: 'default_hero_image',
      url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=85',
      caption: 'Vista Principal',
      category: 'exterior',
      isHero: true,
    };

  const galleryImages = property.images.filter((img) => img.id !== heroImage.id).slice(0, 4);

  // Status badge label
  const getStatusLabel = () => {
    switch (property.status) {
      case 'exclusive':
        return isEn ? 'EXCLUSIVE LISTING' : 'EN EXCLUSIVA';
      case 'reserved':
        return isEn ? 'RESERVED' : 'RESERVADO';
      case 'sold':
        return isEn ? 'SOLD' : 'VENDIDO';
      default:
        return isEn ? 'AVAILABLE' : 'DISPONIBLE';
    }
  };

  const getPropertyTypeLabel = () => {
    const types: Record<string, { es: string; en: string }> = {
      penthouse: { es: 'Ático Dúplex de Lujo', en: 'Luxury Penthouse' },
      villa: { es: 'Villa Contemporánea', en: 'Contemporary Villa' },
      apartment: { es: 'Residencia Exclusiva', en: 'Exclusive Apartment' },
      townhouse: { es: 'Chalet Adosado de Autor', en: 'Designer Townhouse' },
      loft: { es: 'Loft Arquitectónico', en: 'Architectural Loft' },
      commercial: { es: 'Activo Comercial Prime', en: 'Prime Commercial Asset' },
      estate: { es: 'Finca Señorial', en: 'Country Estate' },
    };
    return types[property.propertyType]?.[options.language] || property.propertyType.toUpperCase();
  };

  return (
    <div
      ref={containerRef}
      id="printable-technical-sheet"
      className="bg-white text-slate-900 mx-auto print:mx-0 shadow-2xl print:shadow-none border border-slate-200 print:border-none overflow-hidden transition-all text-left"
      style={{
        width: '100%',
        maxWidth: '210mm',
        minHeight: '297mm',
        boxSizing: 'border-box',
        backgroundColor: '#ffffff',
        color: '#0f172a',
      }}
    >
      {/* =========================================================
          PAGE 1: COVER & EXECUTIVE DOSSIER
          ========================================================= */}
      <div className="p-8 sm:p-10 flex flex-col justify-between">
        {/* Top Header: Agency Identity & Reference Code */}
        <div className="border-b border-slate-200 pb-5 mb-6 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-600 inline-block"></span>
              <span className="text-[11px] font-bold tracking-[0.25em] uppercase text-slate-500">
                {property.agentContact.agencyName || 'LEXI PRIVATE REAL ESTATE'}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-serif font-bold tracking-tight text-slate-900 leading-tight">
              {property.title}
            </h1>
            {property.tagline && (
              <p className="text-xs sm:text-sm font-medium text-slate-500 mt-1 italic">
                "{property.tagline}"
              </p>
            )}
          </div>

          <div className="text-right shrink-0">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-white text-[10px] font-bold tracking-wider uppercase mb-1.5">
              <Award className="w-3 h-3 text-amber-400" />
              <span>{getStatusLabel()}</span>
            </div>
            <div className="text-[11px] font-mono font-semibold text-slate-600">
              REF: <span className="text-slate-900 font-bold">{property.referenceCode}</span>
            </div>
            <div className="text-[10px] text-slate-400">
              {new Date().toLocaleDateString(isEn ? 'en-US' : 'es-ES', {
                month: 'long',
                year: 'numeric',
              })}
            </div>
          </div>
        </div>

        {/* Hero Architectural Visual */}
        <div className="relative rounded-2xl overflow-hidden mb-6 border border-slate-200 group bg-slate-100">
          <img
            src={heroImage.url}
            alt={heroImage.caption}
            crossOrigin="anonymous"
            className="w-full h-72 sm:h-96 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/20 pointer-events-none" />

          {/* Top Overlays */}
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <span className="px-3 py-1 rounded-lg bg-black/60 backdrop-blur-md text-white font-medium text-xs border border-white/20">
              {getPropertyTypeLabel()}
            </span>
            <span className="px-3 py-1 rounded-lg bg-emerald-600/90 backdrop-blur-md text-white font-bold text-xs border border-emerald-400/30 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-300" />
              {isEn ? 'Energy Rating' : 'Calificación'} {property.specs.energyRating}
            </span>
          </div>

          {/* Bottom Hero Overlay: Location & Price */}
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between text-white">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-slate-200 font-medium mb-1 drop-shadow-sm">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>
                  {options.showExactAddress
                    ? property.location.address + ', '
                    : ''}
                  {property.location.neighborhood}, {property.location.city}
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-serif font-bold tracking-tight text-white drop-shadow-md">
                {formattedPrice}
              </div>
            </div>

            <div className="text-right">
              <div className="text-[11px] text-slate-300 uppercase tracking-wider font-semibold">
                {isEn ? 'Built Area' : 'Superficie'}
              </div>
              <div className="text-base font-bold text-amber-300 font-mono">
                {property.specs.builtAreaM2} m²
              </div>
              <div className="text-[10px] text-slate-300">
                ({formattedPricePerM2}/m²)
              </div>
            </div>
          </div>
        </div>

        {/* Key Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-2xs">
              <Maximize2 className="w-4 h-4 text-amber-600" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isEn ? 'Usable Area' : 'Sup. Útil'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-800 font-mono">
                {property.specs.usableAreaM2} m²
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-2xs">
              <Bed className="w-4 h-4 text-blue-600" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isEn ? 'Bedrooms' : 'Dormitorios'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-800 font-mono">
                {property.specs.bedrooms} {isEn ? 'Suites' : 'Habitaciones'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-2xs">
              <Bath className="w-4 h-4 text-cyan-600" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isEn ? 'Bathrooms' : 'Baños'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-800 font-mono">
                {property.specs.bathrooms} {property.specs.halfBaths ? `+ ${property.specs.halfBaths}` : ''}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-2xs">
              <Car className="w-4 h-4 text-emerald-600" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isEn ? 'Parking' : 'Garaje'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-800 font-mono">
                {property.specs.parkingSpots} {isEn ? 'Spaces' : 'Plazas'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 col-span-2 sm:col-span-1">
            <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-2xs">
              <Compass className="w-4 h-4 text-indigo-600" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {isEn ? 'Orientation' : 'Orientación'}
              </div>
              <div className="text-xs sm:text-sm font-bold text-slate-800">
                {property.specs.orientation}
              </div>
            </div>
          </div>
        </div>

        {/* Gallery Strip: 4 High-Res Thumbnail Features */}
        {galleryImages.length > 0 && (
          <div className="mb-6">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-slate-400" />
              <span>{isEn ? 'Photographic Dossier Highlights' : 'Galería Arquitectónica Destacada'}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {galleryImages.map((img, i) => (
                <div
                  key={img.id || i}
                  className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 relative group"
                >
                  <img
                    src={img.url}
                    alt={img.caption}
                    crossOrigin="anonymous"
                    className="w-full h-24 object-cover"
                  />
                  <div className="p-1.5 bg-white border-t border-slate-100">
                    <p className="text-[10px] font-medium text-slate-700 truncate">
                      {img.caption}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Two-Column Core Specifications & Premium Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Left Column: Architectural Specifications */}
          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-100 pb-2 mb-3 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-slate-600" />
              <span>{isEn ? 'Technical Specifications' : 'Especificaciones Técnicas'}</span>
            </h3>

            <dl className="grid grid-cols-2 gap-y-2.5 gap-x-2 text-xs">
              <div>
                <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                  {isEn ? 'Built Area' : 'Superficie Construida'}
                </dt>
                <dd className="font-semibold text-slate-800 font-mono">
                  {property.specs.builtAreaM2} m²
                </dd>
              </div>

              <div>
                <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                  {isEn ? 'Usable Area' : 'Superficie Útil'}
                </dt>
                <dd className="font-semibold text-slate-800 font-mono">
                  {property.specs.usableAreaM2} m²
                </dd>
              </div>

              {property.specs.terraceAreaM2 && (
                <div>
                  <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                    {isEn ? 'Terrace / Solarium' : 'Terraza / Solárium'}
                  </dt>
                  <dd className="font-semibold text-slate-800 font-mono">
                    {property.specs.terraceAreaM2} m²
                  </dd>
                </div>
              )}

              {property.specs.plotAreaM2 && (
                <div>
                  <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                    {isEn ? 'Plot / Land' : 'Parcela Privada'}
                  </dt>
                  <dd className="font-semibold text-slate-800 font-mono">
                    {property.specs.plotAreaM2} m²
                  </dd>
                </div>
              )}

              <div>
                <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                  {isEn ? 'Floor / Level' : 'Planta / Nivel'}
                </dt>
                <dd className="font-medium text-slate-700">
                  {property.specs.floor}
                </dd>
              </div>

              <div>
                <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                  {isEn ? 'Year Built' : 'Año Construcción'}
                </dt>
                <dd className="font-semibold text-slate-800 font-mono">
                  {property.specs.yearBuilt}
                </dd>
              </div>

              <div>
                <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                  {isEn ? 'Condition' : 'Estado del Inmueble'}
                </dt>
                <dd className="font-medium text-slate-700">
                  {property.specs.condition}
                </dd>
              </div>

              <div>
                <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                  {isEn ? 'Energy Class' : 'Consumo Energético'}
                </dt>
                <dd className="font-semibold text-emerald-700 font-mono">
                  {property.specs.energyConsumption || `Clase ${property.specs.energyRating}`}
                </dd>
              </div>

              {options.showCadastral && property.cadastralReference && (
                <div className="col-span-2 pt-1 border-t border-slate-100">
                  <dt className="text-[10px] text-slate-400 uppercase font-semibold">
                    {isEn ? 'Cadastral Reference' : 'Referencia Catastral'}
                  </dt>
                  <dd className="font-mono text-[11px] text-slate-600 select-all">
                    {property.cadastralReference}
                  </dd>
                </div>
              )}
            </dl>
          </div>

          {/* Right Column: Premium Amenities Checklist */}
          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-100 pb-2 mb-3 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
              <span>{isEn ? 'Premium Amenities & Equipment' : 'Equipamiento y Calidades'}</span>
            </h3>

            <ul className="space-y-2 text-xs">
              {property.features.slice(0, 7).map((feature, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Executive Architectural Description */}
        <div className="border border-slate-200 rounded-xl p-5 bg-slate-50/50 mb-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-slate-600" />
            <span>{isEn ? 'Executive Architectural Summary' : 'Memoria y Descripción de la Propiedad'}</span>
          </h3>
          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line font-serif">
            {property.description}
          </p>

          {property.highlights.length > 0 && (
            <div className="mt-4 pt-3 border-t border-slate-200">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                {isEn ? 'Key Selling Points' : 'Puntos Fuertes para el Inversor'}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {property.highlights.map((item, idx) => (
                  <div
                    key={idx}
                    className="text-xs text-slate-700 flex items-start gap-1.5"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-900 shrink-0 mt-1.5"></span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Optional Financial & Investment Data */}
        {options.showFinancials && (
          <div className="border border-slate-200 rounded-xl p-4 bg-white mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isEn ? 'Financial & Tax Summary' : 'Cuadro Económico y Fiscal'}</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="text-[10px] text-slate-400 font-semibold uppercase">
                  {isEn ? 'Community Fees' : 'Comunidad'}
                </div>
                <div className="text-sm font-bold text-slate-800 font-mono mt-0.5">
                  {property.financials.communityFeesMonthly
                    ? `${property.financials.communityFeesMonthly} €/mes`
                    : 'Consultar'}
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="text-[10px] text-slate-400 font-semibold uppercase">
                  {isEn ? 'Annual Property Tax (IBI)' : 'IBI Anual'}
                </div>
                <div className="text-sm font-bold text-slate-800 font-mono mt-0.5">
                  {property.financials.propertyTaxAnnual
                    ? `${property.financials.propertyTaxAnnual} €/año`
                    : 'Consultar'}
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="text-[10px] text-slate-400 font-semibold uppercase">
                  {isEn ? 'Gross Rental Yield' : 'Rentabilidad Bruta'}
                </div>
                <div className="text-sm font-bold text-emerald-600 font-mono mt-0.5">
                  {property.financials.estimatedRentalYieldPct
                    ? `${property.financials.estimatedRentalYieldPct}% anual`
                    : 'Consultar'}
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="text-[10px] text-slate-400 font-semibold uppercase">
                  {isEn ? 'Est. Monthly Rent' : 'Alquiler Estimado'}
                </div>
                <div className="text-sm font-bold text-slate-800 font-mono mt-0.5">
                  {property.financials.estimatedMonthlyRent
                    ? `${property.financials.estimatedMonthlyRent.toLocaleString()} €/mes`
                    : 'Consultar'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Location & Urban Environment */}
        <div className="border border-slate-200 rounded-xl p-4 bg-white mb-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2.5 flex items-center gap-1.5">
            <Landmark className="w-3.5 h-3.5 text-slate-600" />
            <span>{isEn ? 'Location & Connectivity' : 'Entorno Urbano y Conectividad'}</span>
          </h3>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="text-slate-600">
              <span className="font-semibold text-slate-900">{property.location.neighborhood}</span>
              {' · '}
              <span>{property.location.city}, {property.location.stateOrProvince}</span>
            </div>

            {property.location.nearbyLandmarks && property.location.nearbyLandmarks.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                {property.location.nearbyLandmarks.map((point, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                  >
                    {point.name} <strong className="text-slate-900">({point.distance})</strong>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer: Professional Agent Card & Legal Disclaimer */}
        <div className="pt-5 border-t border-slate-200 mt-2">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            {/* Agent Signature */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center font-serif text-lg font-bold shadow-xs">
                {property.agentContact.name
                  .split(' ')
                  .map((n) => n[0])
                  .join('')
                  .slice(0, 2)}
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900">
                  {property.agentContact.name}
                </div>
                <div className="text-[11px] text-slate-500 font-medium">
                  {property.agentContact.title}
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {property.agentContact.licenseNumber}
                </div>
              </div>
            </div>

            {/* Direct Contact Metrics */}
            <div className="flex flex-wrap items-center gap-4 text-xs">
              <div className="flex items-center gap-1 text-slate-700 font-medium">
                <Phone className="w-3.5 h-3.5 text-amber-600" />
                <span>{property.agentContact.phone}</span>
              </div>
              <div className="flex items-center gap-1 text-slate-700 font-medium">
                <Mail className="w-3.5 h-3.5 text-blue-600" />
                <span>{property.agentContact.email}</span>
              </div>
              <div className="flex items-center gap-1 text-slate-700 font-medium">
                <Globe className="w-3.5 h-3.5 text-slate-500" />
                <span>{property.agentContact.agencyWebsite}</span>
              </div>
            </div>

            {/* QR Verification Badge */}
            {options.showQrVerification && (
              <div className="flex items-center gap-2 p-1.5 rounded-lg border border-slate-200 bg-slate-50">
                <QrCode className="w-7 h-7 text-slate-800" />
                <div className="text-[9px] text-slate-500 leading-tight">
                  <div className="font-bold text-slate-800">Verificación Oficial</div>
                  <div>Escanea para validar</div>
                </div>
              </div>
            )}
          </div>

          {/* Legal Disclaimer */}
          <p className="text-[9px] text-slate-400 leading-normal mt-4 pt-3 border-t border-slate-100">
            {isEn
              ? 'CONFIDENTIAL PROPERTY DOSSIER: The information contained in this technical sheet has been provided by the vendor and verified in good faith. Measurements, floor areas, and tax estimates are indicative and subject to contractual verification. Lexi Real Estate CRM Private Client Services.'
              : 'DOSSIER INMOBILIARIO CONFIDENCIAL: La información contenida en esta ficha técnica ha sido facilitada por la propiedad y verificada de buena fe. Las superficies, planos y datos económicos son orientativos y carecen de valor contractual vinculante. Generado vía Lexi Real Estate CRM Studio.'}
          </p>
        </div>
      </div>
    </div>
  );
};
