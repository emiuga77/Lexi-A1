import React, { useState, useEffect } from 'react';
import { X, ExternalLink, Copy, Check, Sparkles, BookOpen, AlertCircle } from 'lucide-react';
import {
  getObsidianVaultName,
  setObsidianVaultName,
  openInObsidian,
  buildObsidianNewUri,
  DEFAULT_VAULT,
} from '../utils/obsidian';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ObsidianModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [vaultName, setVaultNameState] = useState(DEFAULT_VAULT);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copied, setCopied] = useState(false);
  const [testOpened, setTestOpened] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setVaultNameState(getObsidianVaultName());
      setSavedSuccess(false);
      setCopied(false);
      setTestOpened(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setObsidianVaultName(vaultName);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleTestOpen = () => {
    const today = new Date().toISOString().split('T')[0];
    const testContent = `# Conexión exitosa con Obsidian 🚀\n\n- **Bóveda**: ${vaultName}\n- **Fecha**: ${today}\n- **Origen**: VoiceFlow AI Assistant\n\nTu asistente de voz y flujos de trabajo ahora puede enviar notas directamente a tu bóveda de Obsidian utilizando el protocolo oficial \`obsidian://new\`.\n\n## Próximos pasos\n- Pídele al asistente por voz: *"Crea una nota para mi reunión de hoy"*\n- Pulsa el botón **Abrir en Obsidian** en cualquier respuesta o documento para transferirlo al instante.`;

    openInObsidian({
      vault: vaultName,
      name: `VoiceFlow Test - ${today}`,
      content: testContent,
    });
    setTestOpened(true);
    setTimeout(() => setTestOpened(false), 4000);
  };

  const sampleUri = buildObsidianNewUri({
    vault: vaultName,
    name: 'Ejemplo Nota',
    content: '# Hola Obsidian',
  });

  const handleCopyUri = async () => {
    try {
      await navigator.clipboard.writeText(sampleUri);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-purple-700 to-indigo-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center border border-white/20">
              <BookOpen className="w-4 h-4 text-purple-200" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight flex items-center gap-1.5">
                Conexión con Obsidian
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/40 text-purple-100 border border-purple-400/30">
                  Protocolo URI
                </span>
              </h3>
              <p className="text-[11px] text-purple-200">Bóveda activa configurada: <strong>{vaultName}</strong></p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-purple-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          {/* Vault Name Form */}
          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label htmlFor="obsidian-vault-input" className="block font-bold text-slate-800 mb-1">
                Nombre de tu Bóveda (Vault):
              </label>
              <div className="flex gap-2">
                <input
                  id="obsidian-vault-input"
                  type="text"
                  value={vaultName}
                  onChange={(e) => setVaultNameState(e.target.value)}
                  placeholder="tron"
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600 font-mono text-xs text-slate-900 outline-hidden"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
                >
                  Guardar
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Por defecto configurado en <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-purple-700">tron</code>.
              </p>
            </div>

            {savedSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>¡Nombre de bóveda guardado correctamente!</span>
              </div>
            )}
          </form>

          {/* Test Action Card */}
          <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-purple-950 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                Probar conexión con Obsidian
              </span>
              <span className="text-[10px] text-purple-700 font-mono">bóveda: {vaultName}</span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Al hacer clic en el botón, el navegador enviará una orden mediante el protocolo oficial <code className="font-mono bg-white px-1 rounded border border-purple-200 text-purple-700">obsidian://new</code> para abrir tu aplicación Obsidian y crear una nota de prueba.
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleTestOpen}
                className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Abrir nota de prueba en Obsidian
              </button>

              <button
                type="button"
                onClick={handleCopyUri}
                className="px-3 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-semibold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                {copied ? '¡Copiado!' : 'Copiar URI de ejemplo'}
              </button>
            </div>

            {testOpened && (
              <div className="text-[11px] text-purple-800 bg-white/80 p-2 rounded-lg border border-purple-200 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Enviando orden a Obsidian... Si tu navegador pide permiso para abrir la aplicación, pulsa <strong>"Permitir"</strong>.</span>
              </div>
            )}
          </div>

          {/* Tips / How it works */}
          <div className="text-[11px] text-slate-500 space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-200/70">
            <div className="font-semibold text-slate-700 flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-slate-400" />
              ¿Cómo usarlo en el día a día?
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-600">
              <li>En cualquier respuesta del <strong>Asistente de Voz</strong>, verás el botón <strong>"Abrir en Obsidian"</strong>.</li>
              <li>En la pestaña <strong>Google Docs</strong>, puedes exportar cualquier documento o plantilla a tu bóveda con un solo clic.</li>
              <li>No requiere instalar ningún plugin en Obsidian; funciona nativamente con tu instalación local.</li>
            </ul>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
