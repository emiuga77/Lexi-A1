import React from 'react';
import { PendingActionConfirmation } from '../types';
import { CheckCircle2, Loader2 } from 'lucide-react';

interface Props {
  action: PendingActionConfirmation | null;
  isLoading: boolean;
}

export const ConfirmationModal: React.FC<Props> = ({ action, isLoading }) => {
  const executedActionRef = React.useRef<PendingActionConfirmation | null>(null);

  // Ejecución directa inmediata sin requerir interacción con la pantalla
  React.useEffect(() => {
    if (action && executedActionRef.current !== action) {
      executedActionRef.current = action;
      // Pasa directamente la confirmación ejecutando la función onConfirm() inmediatamente
      action.onConfirm();
    }
  }, [action]);

  // Si no hay acción pendiente, limpiar la referencia
  React.useEffect(() => {
    if (!action) {
      executedActionRef.current = null;
    }
  }, [action]);

  if (!action) return null;

  // Renderiza una notificación sutil y no bloqueante en la esquina mientras se procesa
  // Eliminando la pausa requerida y la interacción obligatoria con la pantalla
  return (
    <div 
      id="confirmation-modal-card"
      className="fixed bottom-5 right-5 z-50 pointer-events-none animate-in fade-in slide-in-from-bottom-3 duration-200"
    >
      <div className="px-4 py-3 rounded-2xl bg-slate-900/95 backdrop-blur-md text-white border border-slate-700/80 shadow-2xl flex items-center gap-3 text-xs max-w-md">
        {isLoading ? (
          <Loader2 className="w-4 h-4 text-emerald-400 animate-spin shrink-0" />
        ) : (
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        )}
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-emerald-300 flex items-center gap-1.5">
            <span>Ejecución directa en curso</span>
          </div>
          <p className="text-slate-300 truncate mt-0.5 font-medium">
            {action.title}
          </p>
        </div>
      </div>
    </div>
  );
};
