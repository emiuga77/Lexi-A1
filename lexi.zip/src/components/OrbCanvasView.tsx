import React, { useState, useEffect } from 'react';
import {
  Command,
  MessageSquare,
  SlidersHorizontal,
  User as UserIcon,
  LogOut,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { CyberParticleOrb } from './CyberParticleOrb';
import { OverlayView } from '../utils/commandParser';
import { getActiveProfile } from '../services/profileService';
import { UserProfile } from '../types';

interface Props {
  onNavigate: (view: OverlayView) => void;
  user: User | null;
  isWorkspaceConnected?: boolean;
  onLogin: () => void;
  onLogout: () => void;
  onExecutePrompt: (prompt: string) => void;
  voiceStatus: 'idle' | 'listening' | 'thinking' | 'speaking';
  liveMicLevel: number;
  isVoiceDetected: boolean;
  interimTranscript: string;
  onToggleListen: () => void;
  onInterruptSpeaking: () => void;
  feedbackToast?: string | null;
}

export const OrbCanvasView: React.FC<Props> = ({
  onNavigate,
  user,
  isWorkspaceConnected = false,
  onLogin,
  onLogout,
  voiceStatus,
  liveMicLevel,
  isVoiceDetected,
  interimTranscript,
  onToggleListen,
  onInterruptSpeaking,
  feedbackToast,
}) => {
  const [activeProfile, setActiveProfile] = useState<UserProfile>(() => getActiveProfile());

  useEffect(() => {
    const handleProfileUpdate = () => setActiveProfile(getActiveProfile());
    window.addEventListener('voiceflow:profile_changed', handleProfileUpdate);
    return () => window.removeEventListener('voiceflow:profile_changed', handleProfileUpdate);
  }, []);

  const handleOrbClick = () => {
    if (voiceStatus === 'speaking') {
      onInterruptSpeaking();
      return;
    }
    onToggleListen();
  };

  return (
    <div
      id="orb-canvas-fullscreen"
      className="relative w-full h-full min-h-screen bg-black overflow-hidden flex flex-col justify-between text-white select-none"
    >
      {/* Top Header: Pure, sleek HUD with brand, command suggestion, and quick controls */}
      <header className="relative z-20 w-full max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        {/* Brand & Command Suggestion ("Abre sidebar con chat") */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] animate-pulse" />
            <span className="font-mono text-xs tracking-widest text-slate-200 font-bold uppercase">
              Lexi • Orb Canvas
            </span>
          </div>

          {/* Example Command Pill */}
          <button
            type="button"
            onClick={() => onNavigate('CHAT_SIDEBAR')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono bg-slate-900 border border-cyan-500/30 text-cyan-300 hover:border-cyan-400 hover:bg-slate-800 transition-all cursor-pointer"
            title="Haz clic o di por voz: 'Abre sidebar con chat'"
          >
            <span className="text-slate-400">Ejemplo:</span>
            <span className="font-semibold text-cyan-200">&ldquo;Abre sidebar con chat&rdquo;</span>
          </button>

          {/* Feedback Toast in Top Header */}
          {feedbackToast && (
            <div className="hidden lg:inline-flex items-center px-3 py-1 rounded-full text-[11px] font-mono bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 animate-in fade-in">
              {feedbackToast}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Button to open Sidebar Chat */}
          <button
            id="btn-orb-open-sidebar-chat"
            type="button"
            onClick={() => onNavigate('CHAT_SIDEBAR')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400 text-slate-300 hover:text-white transition-all text-xs font-mono cursor-pointer"
            title="Abrir Sidebar con Chat (comando: 'abre sidebar con chat')"
          >
            <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Abre sidebar con chat</span>
            <span className="md:hidden">Sidebar</span>
          </button>

          {/* Command Palette Button (⌘K) */}
          <button
            id="btn-open-command-palette-pill"
            type="button"
            onClick={() => onNavigate('COMMAND_PALETTE')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400 text-slate-300 hover:text-white transition-all text-xs font-mono cursor-pointer group"
            title="Abrir panel de comandos (Ctrl + K / Cmd + K)"
          >
            <Command className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-12 transition-transform" />
            <span className="hidden sm:inline">Comandos</span>
            <kbd className="hidden lg:inline-block px-1 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400">
              ⌘K
            </kbd>
          </button>

          {/* Profile & Noise Gate Settings */}
          <button
            id="btn-orb-profile"
            type="button"
            onClick={() => onNavigate('PROFILE')}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition-all cursor-pointer"
            title={`Perfil: ${activeProfile.name}`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>

          {/* User Auth & Workspace Connection Status */}
          {user && isWorkspaceConnected ? (
            <button
              id="btn-orb-auth"
              type="button"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/40 hover:border-rose-500/60 text-slate-300 hover:text-rose-300 transition-all text-xs font-mono cursor-pointer"
              title={`Workspace Conectado como ${user.email || 'Usuario'}. Clic para cerrar sesión.`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <LogOut className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline truncate max-w-[100px]">{user.displayName || 'Cuenta'}</span>
            </button>
          ) : user && !isWorkspaceConnected ? (
            <div className="flex items-center gap-1">
              <button
                id="btn-orb-connect-workspace"
                type="button"
                onClick={onLogin}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/80 border border-amber-500/50 hover:bg-amber-900 text-amber-300 transition-all text-xs font-mono cursor-pointer"
                title="Autorizar Google Workspace para sincronización automática de Docs y Sheets"
              >
                <UserIcon className="w-3.5 h-3.5" />
                <span>Conectar Workspace</span>
              </button>
              <button
                type="button"
                onClick={onLogout}
                className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-300 transition-all cursor-pointer"
                title="Cerrar sesión"
              >
                <LogOut className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <button
              id="btn-orb-login"
              type="button"
              onClick={onLogin}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/90 border border-cyan-500/50 hover:bg-cyan-900 text-cyan-300 transition-all text-xs font-mono cursor-pointer"
              title="Iniciar sesión con Google Workspace"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Conectar</span>
            </button>
          )}
        </div>
      </header>

      {/* Unified Cosmic Particle Animation & 3D Interactive Orb Background */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <CyberParticleOrb
          status={voiceStatus}
          audioLevel={liveMicLevel}
          isVoiceDetected={isVoiceDetected}
          interimTranscript={interimTranscript}
          onClick={handleOrbClick}
          showControls={false}
          fullBackground={true}
          title=""
          subtitle=""
        />
      </div>

      {/* Center Stage Floating Transcript (when user speaks) */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-end pb-12 px-4 w-full pointer-events-none">
        {interimTranscript && (
          <div className="max-w-md px-4 py-2 rounded-2xl bg-slate-900/80 border border-cyan-500/40 text-cyan-200 text-xs font-mono text-center shadow-[0_0_25px_rgba(6,182,212,0.25)] backdrop-blur-md animate-fade-in pointer-events-auto">
            <span className="text-cyan-400 mr-1.5 font-bold">“</span>
            <span>{interimTranscript}</span>
            <span className="text-cyan-400 ml-1.5 font-bold">”</span>
          </div>
        )}
      </main>

      {/* No bottom text or footer: perfectly clean pure black space */}
      <div className="h-4 w-full" />
    </div>
  );
};
