import React, { useState } from 'react';
import {
  X,
  Building2,
  MapPin,
  Maximize2,
  DollarSign,
  FileText,
  User,
  Image as ImageIcon,
  Check,
  Plus,
  Trash2,
} from 'lucide-react';
import { PropertyCRMRecord, PropertyType, PropertyStatus } from '../types';

interface Props {
  isOpen: boolean;
  property: PropertyCRMRecord | null;
  onClose: () => void;
  onSave: (updated: PropertyCRMRecord) => Promise<void>;
}

export const PropertyEditorModal: React.FC<Props> = ({
  isOpen,
  property,
  onClose,
  onSave,
}) => {
  if (!isOpen || !property) return null;

  const [formData, setFormData] = useState<PropertyCRMRecord>({ ...property });
  const [activeTab, setActiveTab] = useState<'general' | 'specs' | 'location' | 'financials' | 'features' | 'agent' | 'images'>('general');
  const [isSaving, setIsSaving] = useState(false);
  const [newFeatureText, setNewFeatureText] = useState('');
  const [newHighlightText, setNewHighlightText] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newImageCaption, setNewImageCaption] = useState('');

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSave(formData);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const addFeature = () => {
    if (!newFeatureText.trim()) return;
    setFormData((prev) => ({
      ...prev,
      features: [...prev.features, newFeatureText.trim()],
    }));
    setNewFeatureText('');
  };

  const removeFeature = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index),
    }));
  };

  const addHighlight = () => {
    if (!newHighlightText.trim()) return;
    setFormData((prev) => ({
      ...prev,
      highlights: [...prev.highlights, newHighlightText.trim()],
    }));
    setNewHighlightText('');
  };

  const removeHighlight = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      highlights: prev.highlights.filter((_, i) => i !== index),
    }));
  };

  const addImage = () => {
    if (!newImageUrl.trim()) return;
    setFormData((prev) => ({
      ...prev,
      images: [
        ...prev.images,
        {
          id: `img_${Date.now()}`,
          url: newImageUrl.trim(),
          caption: newImageCaption.trim() || 'Fotografía de propiedad',
          category: 'exterior',
        },
      ],
    }));
    setNewImageUrl('');
    setNewImageCaption('');
  };

  const removeImage = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((img) => img.id !== id),
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-4xl max-h-[92vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden text-slate-900"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Editor de Ficha Técnica CRM
              </h2>
              <p className="text-xs text-slate-400">
                Ref: {formData.referenceCode} · Actualización directa para el dossier PDF
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 py-2 bg-slate-50 border-b border-slate-200 flex items-center gap-1 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'general', label: 'General & Precio', icon: DollarSign },
            { id: 'specs', label: 'Dimensiones & Specs', icon: Maximize2 },
            { id: 'location', label: 'Ubicación', icon: MapPin },
            { id: 'financials', label: 'Economía & Fiscal', icon: FileText },
            { id: 'features', label: 'Equipamiento & Puntos', icon: Building2 },
            { id: 'images', label: 'Galería Fotográfica', icon: ImageIcon },
            { id: 'agent', label: 'Contacto Agente', icon: User },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-2 rounded-lg flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-5 text-xs">
          {/* TAB: GENERAL */}
          {activeTab === 'general' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Título de la Propiedad
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Código de Referencia
                  </label>
                  <input
                    type="text"
                    value={formData.referenceCode}
                    onChange={(e) => setFormData({ ...formData, referenceCode: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Subtítulo / Tagline Comercial
                </label>
                <input
                  type="text"
                  value={formData.tagline || ''}
                  onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                  placeholder="Ej: Vistas panorámicas 360° al Mediterráneo"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Precio
                  </label>
                  <input
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    required
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Moneda
                  </label>
                  <select
                    value={formData.currency}
                    onChange={(e) => setFormData({ ...formData, currency: e.target.value as any })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  >
                    <option value="EUR">EUR (€)</option>
                    <option value="USD">USD ($)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="MXN">MXN ($)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Tipo de Inmueble
                  </label>
                  <select
                    value={formData.propertyType}
                    onChange={(e) => setFormData({ ...formData, propertyType: e.target.value as PropertyType })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  >
                    <option value="penthouse">Ático / Penthouse</option>
                    <option value="villa">Villa / Chalet</option>
                    <option value="apartment">Apartamento / Piso</option>
                    <option value="townhouse">Adosado / Pareado</option>
                    <option value="loft">Loft</option>
                    <option value="commercial">Comercial</option>
                    <option value="estate">Finca Rústica</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Estado en CRM
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as PropertyStatus })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 font-semibold"
                  >
                    <option value="available">Disponible</option>
                    <option value="exclusive">En Exclusiva</option>
                    <option value="reserved">Reservado</option>
                    <option value="sold">Vendido</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Descripción Arquitectónica y Comercial
                </label>
                <textarea
                  rows={6}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 leading-relaxed font-sans"
                />
              </div>
            </div>
          )}

          {/* TAB: SPECS */}
          {activeTab === 'specs' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Sup. Construida (m²)
                  </label>
                  <input
                    type="number"
                    value={formData.specs.builtAreaM2}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, builtAreaM2: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Sup. Útil (m²)
                  </label>
                  <input
                    type="number"
                    value={formData.specs.usableAreaM2}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, usableAreaM2: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Terraza / Solárium (m²)
                  </label>
                  <input
                    type="number"
                    value={formData.specs.terraceAreaM2 || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, terraceAreaM2: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Parcela / Terreno (m²)
                  </label>
                  <input
                    type="number"
                    value={formData.specs.plotAreaM2 || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, plotAreaM2: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Dormitorios
                  </label>
                  <input
                    type="number"
                    value={formData.specs.bedrooms}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, bedrooms: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Baños Completos
                  </label>
                  <input
                    type="number"
                    value={formData.specs.bathrooms}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, bathrooms: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Plazas de Garaje
                  </label>
                  <input
                    type="number"
                    value={formData.specs.parkingSpots}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, parkingSpots: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Año Construcción
                  </label>
                  <input
                    type="number"
                    value={formData.specs.yearBuilt}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, yearBuilt: Number(e.target.value) },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Planta / Distribución
                  </label>
                  <input
                    type="text"
                    value={formData.specs.floor}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, floor: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Orientación
                  </label>
                  <input
                    type="text"
                    value={formData.specs.orientation}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, orientation: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Calificación Energética
                  </label>
                  <select
                    value={formData.specs.energyRating}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        specs: { ...formData.specs, energyRating: e.target.value as any },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 font-bold"
                  >
                    <option value="A">Clase A (Máxima Eficiencia)</option>
                    <option value="B">Clase B</option>
                    <option value="C">Clase C</option>
                    <option value="D">Clase D</option>
                    <option value="E">Clase E</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB: LOCATION */}
          {activeTab === 'location' && (
            <div className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Dirección Exacta
                </label>
                <input
                  type="text"
                  value={formData.location.address}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      location: { ...formData.location, address: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Barrio / Zona
                  </label>
                  <input
                    type="text"
                    value={formData.location.neighborhood}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        location: { ...formData.location, neighborhood: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Ciudad
                  </label>
                  <input
                    type="text"
                    value={formData.location.city}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        location: { ...formData.location, city: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Código Postal
                  </label>
                  <input
                    type="text"
                    value={formData.location.postalCode}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        location: { ...formData.location, postalCode: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Referencia Catastral (Opcional)
                </label>
                <input
                  type="text"
                  value={formData.cadastralReference || ''}
                  onChange={(e) => setFormData({ ...formData, cadastralReference: e.target.value })}
                  placeholder="Ej: 9843210UF7494S0001LM"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>
            </div>
          )}

          {/* TAB: FINANCIALS */}
          {activeTab === 'financials' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Comunidad (€/mes)
                  </label>
                  <input
                    type="number"
                    value={formData.financials.communityFeesMonthly || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        financials: {
                          ...formData.financials,
                          communityFeesMonthly: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    IBI Anual (€/año)
                  </label>
                  <input
                    type="number"
                    value={formData.financials.propertyTaxAnnual || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        financials: {
                          ...formData.financials,
                          propertyTaxAnnual: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Rentabilidad Bruta Estimada (%)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.financials.estimatedRentalYieldPct || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        financials: {
                          ...formData.financials,
                          estimatedRentalYieldPct: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB: FEATURES & HIGHLIGHTS */}
          {activeTab === 'features' && (
            <div className="space-y-6">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Equipamiento y Calidades Destacadas
                </label>
                <div className="flex gap-2 mb-3">
                  <input
                    type="text"
                    value={newFeatureText}
                    onChange={(e) => setNewFeatureText(e.target.value)}
                    placeholder="Ej: Piscina Infinity Climatizada, Domótica KNX..."
                    className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addFeature();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={addFeature}
                    className="px-4 py-2 bg-slate-900 text-white rounded-xl font-medium flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Añadir
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {formData.features.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <span className="text-slate-800">{item}</span>
                      <button
                        type="button"
                        onClick={() => removeFeature(idx)}
                        className="text-slate-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-200 pt-4">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Puntos Fuertes (Key Selling Points)
                </label>
                <div className="flex gap-2 mb-3">
                  <input
                    type="text"
                    value={newHighlightText}
                    onChange={(e) => setNewHighlightText(e.target.value)}
                    placeholder="Ej: Solárium de 165 m² con cocina exterior..."
                    className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addHighlight();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={addHighlight}
                    className="px-4 py-2 bg-slate-900 text-white rounded-xl font-medium flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Añadir
                  </button>
                </div>

                <div className="space-y-2">
                  {formData.highlights.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <span className="text-slate-800">{item}</span>
                      <button
                        type="button"
                        onClick={() => removeHighlight(idx)}
                        className="text-slate-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: IMAGES */}
          {activeTab === 'images' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="text-xs font-bold text-slate-800">Añadir Nueva Fotografía</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="url"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="URL de la imagen (HTTPS)..."
                    className="px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                  <input
                    type="text"
                    value={newImageCaption}
                    onChange={(e) => setNewImageCaption(e.target.value)}
                    placeholder="Pie de foto (ej: Salón principal)..."
                    className="px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
                <button
                  type="button"
                  onClick={addImage}
                  className="px-4 py-2 bg-slate-900 text-white rounded-xl font-semibold flex items-center gap-1.5 text-xs"
                >
                  <Plus className="w-4 h-4" /> Añadir a Galería
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {formData.images.map((img) => (
                  <div
                    key={img.id}
                    className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 relative group"
                  >
                    <img
                      src={img.url}
                      alt={img.caption}
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2 bg-white border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[11px] font-medium text-slate-700 truncate">
                        {img.caption}
                      </span>
                      <button
                        type="button"
                        onClick={() => removeImage(img.id)}
                        className="text-slate-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: AGENT */}
          {activeTab === 'agent' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Nombre del Consultor / Agente
                  </label>
                  <input
                    type="text"
                    value={formData.agentContact.name}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, name: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900 font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Cargo / Especialidad
                  </label>
                  <input
                    type="text"
                    value={formData.agentContact.title}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, title: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Teléfono
                  </label>
                  <input
                    type="text"
                    value={formData.agentContact.phone}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, phone: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    WhatsApp Directo
                  </label>
                  <input
                    type="text"
                    value={formData.agentContact.whatsapp}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, whatsapp: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Email Corporativo
                  </label>
                  <input
                    type="email"
                    value={formData.agentContact.email}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, email: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Nombre de la Agencia / Brokerage
                  </label>
                  <input
                    type="text"
                    value={formData.agentContact.agencyName}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, agencyName: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Sitio Web Oficial
                  </label>
                  <input
                    type="text"
                    value={formData.agentContact.agencyWebsite}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        agentContact: { ...formData.agentContact, agencyWebsite: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Modal Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 font-semibold shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{isSaving ? 'Guardando...' : 'Guardar Cambios en CRM'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
