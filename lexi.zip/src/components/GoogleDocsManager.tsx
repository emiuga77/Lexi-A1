import React, { useState, useEffect } from 'react';
import { WorkspaceFile, PendingActionConfirmation } from '../types';
import {
  listGoogleDocs,
  createGoogleDoc,
  appendToGoogleDoc,
  readGoogleDoc,
} from '../services/workspaceApi';
import {
  FileText,
  Plus,
  RefreshCw,
  ExternalLink,
  BookOpen,
  Send,
  Sparkles,
  AlertCircle,
  Clock,
  Download,
} from 'lucide-react';
import { openInObsidian, downloadMarkdownFile, getObsidianVaultName } from '../utils/obsidian';

interface Props {
  isAuthenticated: boolean;
  onPromptLogin: () => void;
  onRequestAction: (action: PendingActionConfirmation) => void;
}

export const GoogleDocsManager: React.FC<Props> = ({
  isAuthenticated,
  onPromptLogin,
  onRequestAction,
}) => {
  const [docs, setDocs] = useState<WorkspaceFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // New Doc Form
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // Selected Doc for Inspection & Appending
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [selectedDocDetails, setSelectedDocDetails] = useState<{ title: string; text: string } | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [appendText, setAppendText] = useState('');
  const [isAppending, setIsAppending] = useState(false);

  const fetchDocs = async () => {
    if (!isAuthenticated) return;
    setIsLoading(true);
    setError(null);
    try {
      const items = await listGoogleDocs();
      setDocs(items);
    } catch (err: any) {
      console.warn('Error listing docs:', err?.message || err);
      setError(err?.message || 'Failed to fetch Google Docs.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchDocs();
    }
  }, [isAuthenticated]);

  // Load single doc details
  const handleSelectDoc = async (id: string) => {
    setSelectedDocId(id);
    setIsLoadingDetails(true);
    try {
      const details = await readGoogleDoc(id);
      setSelectedDocDetails(details);
    } catch (err: any) {
      console.warn('Error reading doc:', err?.message || err);
      setError(err?.message || 'Failed to read document text.');
    } finally {
      setIsLoadingDetails(false);
    }
  };

  // Trigger Create Document (Requires User Confirmation as per Workspace Skill)
  const handleInitiateCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onRequestAction({
      id: 'create-doc-' + Date.now(),
      type: 'docs_create',
      title: 'Create New Google Doc',
      targetName: newTitle,
      details: [
        { label: 'Document Title', value: newTitle },
        { label: 'Initial Content', value: newContent || '(Blank Document)' },
      ],
      onConfirm: async () => {
        setIsCreating(true);
        try {
          const res = await createGoogleDoc(newTitle, newContent);
          setNewTitle('');
          setNewContent('');
          await fetchDocs();
          handleSelectDoc(res.id);
        } catch (err: any) {
          setError(err?.message || 'Failed to create document');
        } finally {
          setIsCreating(false);
        }
      },
      onCancel: () => {},
    });
  };

  // Trigger Append Text (Requires User Confirmation as per Workspace Skill)
  const handleInitiateAppend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDocId || !appendText.trim() || !selectedDocDetails) return;

    onRequestAction({
      id: 'append-doc-' + Date.now(),
      type: 'docs_append',
      title: 'Append Text to Google Doc',
      targetName: selectedDocDetails.title,
      targetId: selectedDocId,
      details: [
        { label: 'Target Document', value: selectedDocDetails.title },
        { label: 'Text to Append', value: appendText },
      ],
      onConfirm: async () => {
        setIsAppending(true);
        try {
          await appendToGoogleDoc(selectedDocId, appendText);
          setAppendText('');
          await handleSelectDoc(selectedDocId);
        } catch (err: any) {
          setError(err?.message || 'Failed to append text');
        } finally {
          setIsAppending(false);
        }
      },
      onCancel: () => {},
    });
  };

  // Preset Template Fillers
  const applyTemplate = (type: 'meeting' | 'spec' | 'summary') => {
    const today = new Date().toLocaleDateString();
    if (type === 'meeting') {
      setNewTitle(`Sprint Sync & Action Items - ${today}`);
      setNewContent(
        `# Sprint Sync & Action Items\nDate: ${today}\n\n## 1. Attendees & Objectives\n- Align on sprint priorities and API integration deliverables.\n\n## 2. Key Decisions\n- Enable Live API for real-time voice conversations.\n- Enforce explicit confirmation on destructive Google Docs and Sheets actions.\n\n## 3. Next Steps & Owners\n- Deploy frontend updates (Engineering Team)\n- Test multi-modal image generation (Design Team)`
      );
    } else if (type === 'spec') {
      setNewTitle(`AI Automation Architecture Spec - ${today}`);
      setNewContent(
        `# System Architecture Specification\nVersion: 1.0\nAuthor: AI Workflow Assistant\n\n## Overview\nReal-time bidirectional orchestration connecting Google Docs, Google Sheets, and Gemini 3 models.\n\n## Integration Components\n- Docs API v1 (batchUpdate)\n- Sheets API v4 (values.append)\n- Live API (gemini-3.8-live WebSockets)`
      );
    } else {
      setNewTitle(`Executive Weekly Briefing - ${today}`);
      setNewContent(
        `# Executive Weekly Briefing\nWeek of: ${today}\n\n## Highlights\n- All operational metrics trending positive.\n- Automation workflows reduced manual spreadsheet updates by 85%.`
      );
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
          <FileText className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Connect Google Docs</h2>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          Sign in with your Google account to allow the voice assistant to create, inspect, and update Google Docs in real time.
        </p>
        <button
          type="button"
          onClick={onPromptLogin}
          className="px-6 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 shadow-md shadow-blue-500/20 transition-all cursor-pointer"
        >
          Sign in with Google
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            Google Docs Automation
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Create, inspect, and append documentation via real-time Google Docs API calls.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchDocs}
          disabled={isLoading}
          className="px-3.5 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh Documents
        </button>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </span>
          <button type="button" onClick={() => setError(null)} className="text-rose-500 hover:text-rose-700">
            ✕
          </button>
        </div>
      )}

      {/* Main Grid: Create Document Form & Existing Documents */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Create Document Form */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 mb-2 flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-600" />
              Create New Google Doc
            </h2>

            {/* Quick Templates */}
            <div className="mb-4">
              <span className="text-[11px] font-semibold text-slate-500 block mb-1.5 uppercase tracking-wider">
                Quick Start Templates:
              </span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => applyTemplate('meeting')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-[11px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  Meeting Sync
                </button>
                <button
                  type="button"
                  onClick={() => applyTemplate('spec')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-[11px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  Architecture Spec
                </button>
                <button
                  type="button"
                  onClick={() => applyTemplate('summary')}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-[11px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  Weekly Brief
                </button>
              </div>
            </div>

            <form onSubmit={handleInitiateCreate} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Q3 Strategic Operations Memo"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Initial Document Body (Markdown/Text)
                </label>
                <textarea
                  rows={6}
                  placeholder="Enter initial notes or let voice assistant dictate content..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden font-mono leading-relaxed"
                />
              </div>

              <div className="space-y-2">
                <button
                  type="submit"
                  disabled={!newTitle.trim() || isCreating}
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create in Google Docs (With Confirmation)</span>
                </button>

                <button
                  type="button"
                  disabled={!newTitle.trim() && !newContent.trim()}
                  onClick={() => {
                    const vault = getObsidianVaultName();
                    openInObsidian({
                      vault,
                      name: newTitle || 'Borrador Documento',
                      content: newContent || '',
                    });
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <BookOpen className="w-3.5 h-3.5 text-purple-700" />
                  <span>Abrir borrador en Obsidian ({getObsidianVaultName()})</span>
                </button>
              </div>
            </form>
          </div>

          {/* Document Inspector Card */}
          {selectedDocId && selectedDocDetails && (
            <div className="p-5 rounded-2xl bg-white border border-blue-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2 min-w-0">
                  <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="text-xs font-bold text-slate-900 truncate">
                    {selectedDocDetails.title}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      openInObsidian({
                        vault: getObsidianVaultName(),
                        name: selectedDocDetails.title || 'Doc',
                        content: selectedDocDetails.text || '',
                      });
                    }}
                    title={`Exportar y abrir en Obsidian (${getObsidianVaultName()})`}
                    className="px-2 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <BookOpen className="w-3 h-3 text-purple-700" />
                    <span className="hidden sm:inline">Obsidian</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      downloadMarkdownFile(
                        selectedDocDetails.title || 'doc',
                        selectedDocDetails.text || ''
                      );
                    }}
                    title="Descargar como archivo Markdown (.md)"
                    className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Download className="w-3 h-3 text-slate-500" />
                    <span>.md</span>
                  </button>

                  <a
                    href={`https://docs.google.com/document/d/${selectedDocId}/edit`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 shrink-0"
                  >
                    Open <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Document Text Preview */}
              <div className="max-h-48 overflow-y-auto p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700 whitespace-pre-wrap leading-relaxed">
                {isLoadingDetails ? 'Reading document...' : selectedDocDetails.text || '(Empty Document)'}
              </div>

              {/* Append Text Form */}
              <form onSubmit={handleInitiateAppend} className="space-y-2 pt-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Append New Content to this Document
                </label>
                <textarea
                  rows={2}
                  placeholder="Type or dictate additional content..."
                  value={appendText}
                  onChange={(e) => setAppendText(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden"
                />
                <button
                  type="submit"
                  disabled={!appendText.trim() || isAppending}
                  className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  Append Text (With Confirmation)
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Right: Existing Google Docs List */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">
              Your Google Docs ({docs.length})
            </h2>
            <span className="text-xs text-slate-400">Drive Search Scope</span>
          </div>

          {isLoading ? (
            <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500 space-y-2">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <span>Fetching Google Docs from Google Drive...</span>
            </div>
          ) : docs.length === 0 ? (
            <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500 space-y-2">
              <FileText className="w-8 h-8 text-slate-300 mx-auto" />
              <p>No Google Docs found in your authorized files yet.</p>
              <p className="text-[11px] text-slate-400">
                Use the form on the left or say "Create a document for project notes" to the voice assistant!
              </p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
              {docs.map((doc) => (
                <div
                  key={doc.id}
                  className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                    selectedDocId === doc.id
                      ? 'bg-blue-50/70 border-blue-300 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  <div
                    onClick={() => handleSelectDoc(doc.id)}
                    className="min-w-0 flex-1 flex items-start gap-3 cursor-pointer"
                  >
                    <div className="p-2 rounded-lg bg-blue-100/70 text-blue-700 shrink-0 mt-0.5">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 truncate">
                        {doc.name}
                      </h4>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          {doc.modifiedTime
                            ? new Date(doc.modifiedTime).toLocaleDateString([], {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : 'Recently'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleSelectDoc(doc.id)}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 transition-colors cursor-pointer"
                    >
                      Inspect
                    </button>
                    {doc.webViewLink && (
                      <a
                        href={doc.webViewLink}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-100 transition-colors"
                        title="Open in Google Docs"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
