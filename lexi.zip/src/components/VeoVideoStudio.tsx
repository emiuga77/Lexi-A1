import React, { useState, useEffect, useRef } from 'react';
import {
  Film,
  Sparkles,
  Play,
  Download,
  Upload,
  RefreshCw,
  Sliders,
  AlertCircle,
  CheckCircle2,
  Video,
  Eye,
  Clock,
  Ratio,
  Layers,
  Sparkle,
  Share2,
  X,
  Camera,
  Repeat,
  Wand2,
  ArrowRightLeft,
  Maximize2,
} from 'lucide-react';
import { saveMediaCreation, getMediaCreations, logAuditEvent } from '../services/firestoreDb';

interface Props {
  isAuthenticated?: boolean;
  onPromptLogin?: () => void;
  initialImageBase64?: string | null;
  initialPrompt?: string;
  initialMode?: 'text_to_video' | 'image_to_video' | 'interpolation';
  onSendToImageStudio?: (imageBase64: string, prompt?: string) => void;
}

export const VeoVideoStudio: React.FC<Props> = ({
  isAuthenticated = false,
  onPromptLogin,
  initialImageBase64,
  initialPrompt,
  initialMode = 'text_to_video',
  onSendToImageStudio,
}) => {
  const [mode, setMode] = useState<'text_to_video' | 'image_to_video' | 'interpolation'>(initialMode);
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
  
  // Starting and Ending Frame states
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string | null>(initialImageBase64 || null);
  const [uploadedFileName, setUploadedFileName] = useState<string>(initialImageBase64 ? 'Imagen de inicio transferida' : '');
  const [lastFrameBase64, setLastFrameBase64] = useState<string | null>(null);
  const [lastFrameFileName, setLastFrameFileName] = useState<string>('');

  // Camera Motion Presets
  const [cameraMotion, setCameraMotion] = useState<string>('');
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false);

  // Generation & Polling State
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressStep, setProgressStep] = useState<string>('');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Result Video Player State
  const [generatedVideoBlobUrl, setGeneratedVideoBlobUrl] = useState<string | null>(null);
  const [lastOperationName, setLastOperationName] = useState<string | null>(null);
  const [savedCreations, setSavedCreations] = useState<any[]>([]);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [snapshotSuccess, setSnapshotSuccess] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const lastFrameInputRef = useRef<HTMLInputElement | null>(null);
  const videoPlayerRef = useRef<HTMLVideoElement | null>(null);
  const pollTimerRef = useRef<any>(null);
  const elapsedTimerRef = useRef<any>(null);

  // Initialize with initial props if provided
  useEffect(() => {
    if (initialImageBase64) {
      setUploadedImageBase64(initialImageBase64);
      setUploadedFileName('Imagen transferida de Image Studio');
      setMode('image_to_video');
    }
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [initialImageBase64, initialPrompt]);

  // Load saved creations from Firestore
  useEffect(() => {
    loadRecentCreations();
    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
    };
  }, []);

  const loadRecentCreations = async () => {
    try {
      const items = await getMediaCreations();
      setSavedCreations(items.filter((item: any) => item.type === 'video'));
    } catch (e) {
      console.warn('Error loading creations:', e);
    }
  };

  // Starting File Upload Handling
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Por favor selecciona un archivo de imagen válido (PNG, JPG, WEBP).');
      return;
    }

    setUploadedFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImageBase64(reader.result as string);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleClearImage = () => {
    setUploadedImageBase64(null);
    setUploadedFileName('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Last Frame Upload Handling (Interpolation mode)
  const handleLastFrameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Por favor selecciona una imagen válida para el fotograma final.');
      return;
    }

    setLastFrameFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setLastFrameBase64(reader.result as string);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleClearLastFrame = () => {
    setLastFrameBase64(null);
    setLastFrameFileName('');
    if (lastFrameInputRef.current) lastFrameInputRef.current.value = '';
  };

  // AI Prompt Enhancer for Video
  const handleEnhancePrompt = async () => {
    if (!prompt.trim()) {
      setError('Escribe una idea base antes de optimizar el prompt.');
      return;
    }

    setIsEnhancingPrompt(true);
    setError(null);

    try {
      const res = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          type: 'video',
          cameraMotion: cameraMotion || undefined,
        }),
      });

      if (!res.ok) {
        throw new Error('No se pudo optimizar el prompt con IA.');
      }

      const data = await res.json();
      if (data.enhancedPrompt) {
        setPrompt(data.enhancedPrompt);
      }
    } catch (err: any) {
      console.warn('Enhance prompt failed:', err);
      setError(err?.message || 'Error al conectar con el optimizador de prompts.');
    } finally {
      setIsEnhancingPrompt(false);
    }
  };

  // Start Generation
  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'text_to_video' && !prompt.trim()) {
      setError('Por favor ingresa un prompt descriptivo para el video.');
      return;
    }
    if ((mode === 'image_to_video' || mode === 'interpolation') && !uploadedImageBase64) {
      setError('Por favor sube una imagen de partida para animarla en video.');
      return;
    }
    if (mode === 'interpolation' && !lastFrameBase64) {
      setError('Para el modo de interpolación se requiere subir tanto el fotograma inicial como el final.');
      return;
    }

    setIsGenerating(true);
    setError(null);
    setGeneratedVideoBlobUrl(null);
    setProgressStep('Conectando con Google Veo 3 (veo-3.1-generate-preview)...');
    setElapsedSeconds(0);

    // Start elapsed counter
    elapsedTimerRef.current = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);

    try {
      const response = await fetch('/api/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim() || 'Cinematic gentle motion with high detail, physical realism and dynamic lighting',
          imageBase64: (mode === 'image_to_video' || mode === 'interpolation') ? uploadedImageBase64 : undefined,
          lastFrameBase64: mode === 'interpolation' ? lastFrameBase64 : undefined,
          aspectRatio,
          resolution,
          cameraMotion: cameraMotion || undefined,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData?.error || 'Error al iniciar la generación de video con Veo 3.');
      }

      const data = await response.json();
      const operationName = data.operationName;
      setLastOperationName(operationName);

      // Start Polling
      pollVideoOperation(operationName);
    } catch (err: any) {
      console.error('Video generation start error:', err);
      setError(err?.message || 'No se pudo iniciar la generación de video.');
      setIsGenerating(false);
      clearInterval(elapsedTimerRef.current);
    }
  };

  // Poll Veo Operation Status
  const pollVideoOperation = (operationName: string) => {
    let attempts = 0;
    const maxAttempts = 120; // 120 * 3s = 360s (6 min)

    const statusMessages = [
      'Sintetizando vectores de movimiento y física espacial...',
      'Generando coherencia temporal entre fotogramas...',
      'Renderizando iluminación, reflejos y texturas cinemáticas...',
      'Compilando flujo de video con Veo 3...',
      'Codificando contenedor MP4 de alta fidelidad...',
      'Finalizando post-procesamiento de video...',
    ];

    pollTimerRef.current = setInterval(async () => {
      attempts++;
      const messageIdx = Math.min(Math.floor(attempts / 5), statusMessages.length - 1);
      setProgressStep(statusMessages[messageIdx]);

      try {
        const statusRes = await fetch('/api/video-status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ operationName }),
        });

        if (!statusRes.ok) {
          throw new Error('Error al verificar estado de la operación de video.');
        }

        const statusData = await statusRes.json();

        if (statusData.done) {
          clearInterval(pollTimerRef.current);
          clearInterval(elapsedTimerRef.current);

          if (statusData.error) {
            throw new Error(`Error en Veo 3: ${statusData.error.message || JSON.stringify(statusData.error)}`);
          }

          setProgressStep('Descargando y preparando reproducción de video...');
          await downloadAndRenderVideo(operationName);
        } else if (attempts >= maxAttempts) {
          clearInterval(pollTimerRef.current);
          clearInterval(elapsedTimerRef.current);
          throw new Error('El proceso de generación de video excedió el tiempo límite esperado. Por favor reintenta con un prompt más conciso.');
        }
      } catch (pollErr: any) {
        console.error('Polling error:', pollErr);
        clearInterval(pollTimerRef.current);
        clearInterval(elapsedTimerRef.current);
        setError(pollErr?.message || 'Error durante la espera del video.');
        setIsGenerating(false);
      }
    }, 3000);
  };

  // Download Video Binary from Backend
  const downloadAndRenderVideo = async (operationName: string) => {
    try {
      const downloadRes = await fetch('/api/video-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operationName }),
      });

      if (!downloadRes.ok) {
        throw new Error('No se pudo descargar el archivo de video procesado.');
      }

      const blob = await downloadRes.blob();
      const videoUrl = URL.createObjectURL(blob);
      setGeneratedVideoBlobUrl(videoUrl);
      setIsGenerating(false);
      setProgressStep('');

      // Persist to Firebase Firestore
      const saved = await saveMediaCreation({
        type: 'video',
        prompt: prompt || (mode === 'image_to_video' ? 'Animación de foto con Veo 3' : 'Video Veo 3'),
        model: 'veo-3.1-generate-preview',
        aspectRatio,
        mediaUrl: videoUrl,
        status: 'completed',
        hasStartingImage: mode !== 'text_to_video',
      });

      logAuditEvent({
        actionType: 'voice_command_executed',
        entityType: 'document',
        details: `Video generado con éxito mediante Veo 3 (${aspectRatio}, ${resolution}): "${prompt || 'Animación'}"`,
        status: 'success',
      }).catch(() => {});

      setSavedCreations((prev) => [saved, ...prev]);
    } catch (err: any) {
      console.error('Video download error:', err);
      setError(err?.message || 'Error al descargar el video terminado.');
      setIsGenerating(false);
    }
  };

  // Capture current video frame to snapshot
  const handleCaptureFrame = () => {
    if (!videoPlayerRef.current) return;
    const video = videoPlayerRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const frameDataUrl = canvas.toDataURL('image/png');

    setSnapshotSuccess('Fotograma capturado con éxito');
    setTimeout(() => setSnapshotSuccess(null), 3500);

    if (onSendToImageStudio) {
      onSendToImageStudio(frameDataUrl, `Edición del fotograma capturado de Veo 3: ${prompt.slice(0, 80)}`);
    } else {
      // Direct download fallback
      const a = document.createElement('a');
      a.href = frameDataUrl;
      a.download = `veo-snapshot-${Date.now()}.png`;
      a.click();
    }
  };

  // Change playback rate
  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoPlayerRef.current) {
      videoPlayerRef.current.playbackRate = speed;
    }
  };

  // Camera Motion Presets
  const cameraMotionPresets = [
    { label: 'Natural / Automático', value: '' },
    { label: 'Dron Panorámico', value: 'Cinematic aerial drone flythrough, sweeping view, smooth descent' },
    { label: 'Órbita 360° Suave', value: 'Smooth 360 degree orbital rotation around central subject' },
    { label: 'Dolly Zoom (Vértigo)', value: 'Hitchcock vertigo dolly zoom, background warping while subject stays fixed' },
    { label: 'Cámara Lenta (120fps)', value: 'Super slow motion 120fps, floating particles, hyper fluid movement' },
    { label: 'FPV Dinámica', value: 'Fast energetic first-person view, dynamic banking turns and cinematic speed' },
  ];

  // Prompt Presets
  const promptPresets = [
    'Vista cinematográfica con dron sobre una metrópolis futurista con rascacielos iluminados y vehículos flotantes bajo la lluvia.',
    'Olas bioluminiscentes de color aguamarina rompiendo suavemente en una playa de arena negra al atardecer.',
    'Primer plano en cámara lenta de una gota de agua cristalina cayendo sobre una hoja de loto verde esmeralda.',
    'Cámara orbitando una nave de exploración espacial pasando junto a los anillos dorados de Saturno con estrellas de fondo.',
  ];

  return (
    <div className="space-y-6">
      {/* Studio Header Card */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white border border-indigo-900/50 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-rose-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Film className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold tracking-tight">Estudio de Video Veo 3</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  Google Veo 3 Preview
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 max-w-xl">
                Crea videos cinemáticos a partir de texto, anima fotos estáticas o genera transiciones entre fotogramas de inicio y fin con física realista.
              </p>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700">
            <button
              type="button"
              onClick={() => setMode('text_to_video')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                mode === 'text_to_video'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Texto a Video</span>
            </button>
            <button
              type="button"
              onClick={() => setMode('image_to_video')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                mode === 'image_to_video'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Animar Foto</span>
            </button>
            <button
              type="button"
              onClick={() => setMode('interpolation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                mode === 'interpolation'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Animación con fotograma de inicio y fotograma de fin"
            >
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>Inicio + Fin</span>
            </button>
          </div>
        </div>
      </div>

      {/* Error Notice */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-3 shadow-xs">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-1">
            <p className="font-semibold text-rose-900">{error}</p>
            {error.includes('429') && (
              <p className="text-[11px] text-rose-600">
                La cuota para Veo 3 está sujeta a los límites de tu cuenta de Google AI Studio. Puedes reintentar en unos momentos.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-rose-500 hover:text-rose-800 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form Column */}
        <div className="lg:col-span-6 space-y-5">
          <form onSubmit={handleGenerate} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            {/* Image Upload for Image-to-Video and Interpolation Mode */}
            {(mode === 'image_to_video' || mode === 'interpolation') && (
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {mode === 'interpolation' ? '1. Fotograma de Inicio (Frame 1)' : 'Foto de Origen para Animar'}
                </label>
                {uploadedImageBase64 ? (
                  <div className="relative rounded-xl border border-indigo-200 bg-indigo-50/50 p-2 flex items-center gap-3">
                    <img
                      src={uploadedImageBase64}
                      alt="Source preview"
                      className="w-16 h-16 object-cover rounded-lg border border-indigo-200"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 truncate">
                        {uploadedFileName || 'Imagen de inicio'}
                      </div>
                      <div className="text-[11px] text-indigo-700">
                        Fotograma inicial listo para Veo 3
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleClearImage}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-white cursor-pointer"
                      title="Quitar imagen"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 hover:border-indigo-500 rounded-xl p-5 text-center cursor-pointer transition-colors bg-slate-50/50 hover:bg-indigo-50/30"
                  >
                    <Upload className="w-7 h-7 text-slate-400 mx-auto mb-1.5" />
                    <p className="text-xs font-semibold text-slate-700">
                      Haz clic para subir o arrastra la imagen de partida
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      PNG, JPG o WEBP (máx. 20MB)
                    </p>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            )}

            {/* Ending Frame for Interpolation Mode */}
            {mode === 'interpolation' && (
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  2. Fotograma Final (Last Frame)
                </label>
                {lastFrameBase64 ? (
                  <div className="relative rounded-xl border border-rose-200 bg-rose-50/50 p-2 flex items-center gap-3">
                    <img
                      src={lastFrameBase64}
                      alt="Last frame preview"
                      className="w-16 h-16 object-cover rounded-lg border border-rose-200"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 truncate">
                        {lastFrameFileName || 'Fotograma final'}
                      </div>
                      <div className="text-[11px] text-rose-700">
                        Veo 3 creará la transición continua hacia este cuadro
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleClearLastFrame}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-white cursor-pointer"
                      title="Quitar fotograma final"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => lastFrameInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 hover:border-rose-400 rounded-xl p-5 text-center cursor-pointer transition-colors bg-slate-50/50 hover:bg-rose-50/30"
                  >
                    <Upload className="w-7 h-7 text-rose-400 mx-auto mb-1.5" />
                    <p className="text-xs font-semibold text-slate-700">
                      Sube la imagen de llegada (fotograma final)
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Veo 3 generará el video que conecta ambos estados
                    </p>
                  </div>
                )}
                <input
                  ref={lastFrameInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleLastFrameChange}
                  className="hidden"
                />
              </div>
            )}

            {/* Prompt Input with AI Enhancer */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {mode === 'text_to_video'
                    ? 'Prompt de Video'
                    : mode === 'interpolation'
                    ? 'Dirección de Transición (Opcional)'
                    : 'Instrucciones de Movimiento (Opcional)'}
                </label>
                <button
                  type="button"
                  onClick={handleEnhancePrompt}
                  disabled={isEnhancingPrompt || !prompt.trim()}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                  title="Optimizar prompt con Gemini 3.8 Flash para cinematografía y coherencia temporal"
                >
                  <Wand2 className={`w-3.5 h-3.5 ${isEnhancingPrompt ? 'animate-spin' : ''}`} />
                  <span>{isEnhancingPrompt ? 'Mejorando...' : 'Optimizar con IA'}</span>
                </button>
              </div>

              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={3}
                placeholder={
                  mode === 'text_to_video'
                    ? 'Describe la escena: acción, cinematografía, iluminación, cámara (ej: "Dron sobrevolando montañas nevadas al amanecer...")'
                    : mode === 'interpolation'
                    ? 'Describe cómo evoluciona la escena entre el inicio y el final (ej: "El día se convierte gradualmente en noche estrellada...")'
                    : 'Describe cómo se debe mover la foto (ej: "El agua fluye suavemente y las nubes avanzan con viento ligero...")'
                }
                className="w-full text-xs rounded-xl border border-slate-300 p-3 text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none leading-relaxed"
              />
            </div>

            {/* Camera Motion Director Controls */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-indigo-600" />
                <span>Movimiento de Cámara Cinemático</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                {cameraMotionPresets.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setCameraMotion(preset.value)}
                    className={`py-1.5 px-2.5 rounded-lg text-xs font-medium border text-left truncate transition-all cursor-pointer ${
                      cameraMotion === preset.value
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-400 font-semibold'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio & Resolution Selectors */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Relación de Aspecto
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAspectRatio('16:9')}
                    className={`p-2 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all cursor-pointer ${
                      aspectRatio === '16:9'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-mono text-xs">16:9</span>
                    <span className="text-[10px] text-slate-500 font-normal">Horizontal</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setAspectRatio('9:16')}
                    className={`p-2 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all cursor-pointer ${
                      aspectRatio === '9:16'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-mono text-xs">9:16</span>
                    <span className="text-[10px] text-slate-500 font-normal">Vertical (Reels)</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Resolución
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setResolution('720p')}
                    className={`p-2 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all cursor-pointer ${
                      resolution === '720p'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-mono text-xs">720p</span>
                    <span className="text-[10px] text-slate-500 font-normal">Rápido HD</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setResolution('1080p')}
                    className={`p-2 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all cursor-pointer ${
                      resolution === '1080p'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-mono text-xs">1080p</span>
                    <span className="text-[10px] text-slate-500 font-normal">Ultra HD</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Prompts */}
            {mode === 'text_to_video' && (
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold text-slate-500">Ejemplos inspiradores:</span>
                <div className="flex flex-wrap gap-1.5">
                  {promptPresets.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setPrompt(preset)}
                      className="px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 rounded-lg border border-slate-200 transition-colors text-left cursor-pointer truncate max-w-full"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={
                isGenerating ||
                (mode === 'image_to_video' && !uploadedImageBase64) ||
                (mode === 'interpolation' && (!uploadedImageBase64 || !lastFrameBase64))
              }
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-rose-600 hover:from-indigo-700 hover:to-rose-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Renderizando con Veo 3 ({elapsedSeconds}s)...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {mode === 'text_to_video'
                      ? 'Generar Video con Veo 3'
                      : mode === 'interpolation'
                      ? 'Generar Transición Inicio-Fin'
                      : 'Animar Foto con Veo 3'}
                  </span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Output Column */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col h-full min-h-[380px]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Video className="w-4 h-4 text-indigo-600" />
                Reproductor & Generación
              </span>
              {generatedVideoBlobUrl && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCaptureFrame}
                    className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="Capturar fotograma actual y enviarlo a Image Studio"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Capturar Fotograma</span>
                  </button>
                  <a
                    href={generatedVideoBlobUrl}
                    download={`veo3-${Date.now()}.mp4`}
                    className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Descargar MP4</span>
                  </a>
                </div>
              )}
            </div>

            {snapshotSuccess && (
              <div className="mb-3 p-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  {snapshotSuccess}
                </span>
                {onSendToImageStudio && (
                  <span className="font-semibold text-emerald-900">Enviado a Image Studio</span>
                )}
              </div>
            )}

            {/* Content Area */}
            <div className="flex-1 flex flex-col items-center justify-center">
              {isGenerating ? (
                <div className="text-center space-y-4 max-w-sm p-6">
                  <div className="relative w-20 h-20 mx-auto">
                    <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-ping opacity-25" />
                    <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-indigo-600 to-rose-500 flex items-center justify-center text-white shadow-xl">
                      <Film className="w-8 h-8 animate-pulse" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Veo 3 está renderizando tu video
                    </h3>
                    <p className="text-xs text-indigo-600 font-medium mt-1">
                      {progressStep || 'Iniciando generación...'}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-2">
                      Tiempo transcurrido: {elapsedSeconds} segundos (los videos suelen completarse en 60-120 segundos)
                    </p>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-rose-500 rounded-full transition-all duration-300 animate-pulse"
                      style={{ width: `${Math.min(10 + elapsedSeconds * 0.8, 95)}%` }}
                    />
                  </div>
                </div>
              ) : generatedVideoBlobUrl ? (
                <div className="w-full space-y-3 flex-1 flex flex-col justify-center">
                  <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center shadow-md">
                    <video
                      ref={videoPlayerRef}
                      src={generatedVideoBlobUrl}
                      controls
                      autoPlay
                      loop={isLooping}
                      className="w-full h-full object-contain"
                    />
                  </div>

                  {/* Playback Controls Toolbar */}
                  <div className="flex items-center justify-between text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-slate-500">Velocidad:</span>
                      {[0.5, 1, 1.5, 2].map((spd) => (
                        <button
                          key={spd}
                          type="button"
                          onClick={() => handleSpeedChange(spd)}
                          className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                            playbackSpeed === spd
                              ? 'bg-indigo-600 text-white font-bold'
                              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setIsLooping(!isLooping)}
                        className={`flex items-center gap-1 text-[11px] font-semibold cursor-pointer ${
                          isLooping ? 'text-indigo-600' : 'text-slate-400'
                        }`}
                        title="Alternar bucle continuo"
                      >
                        <Repeat className="w-3.5 h-3.5" />
                        <span>Bucle {isLooping ? 'On' : 'Off'}</span>
                      </button>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {aspectRatio} • {resolution}
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 space-y-3">
                  <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                    <Play className="w-8 h-8 ml-0.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-700">Listo para Generar Video</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5 max-w-xs mx-auto">
                      Ingresa un prompt o sube una imagen y haz clic en "Generar Video" para ver el resultado en este reproductor.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Cloud Saved Creations */}
      {savedCreations.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-600" />
              Videos Guardados en Firebase Firestore ({savedCreations.length})
            </span>
            <button
              type="button"
              onClick={loadRecentCreations}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Actualizar</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {savedCreations.map((item, idx) => (
              <div
                key={item.id || idx}
                className="rounded-xl border border-slate-200 overflow-hidden bg-slate-50/50 hover:shadow-md transition-shadow flex flex-col"
              >
                <div className="bg-black aspect-video relative flex items-center justify-center">
                  <video
                    src={item.mediaUrl}
                    controls
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                  <p className="text-xs text-slate-800 line-clamp-2 font-medium">
                    {item.prompt || 'Video Veo 3'}
                  </p>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                    <span className="font-mono">{item.aspectRatio || '16:9'}</span>
                    <a
                      href={item.mediaUrl}
                      download={`veo3-saved-${idx}.mp4`}
                      className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>Descargar</span>
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
