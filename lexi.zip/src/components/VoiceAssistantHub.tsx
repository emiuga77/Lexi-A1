import React, { useState, useEffect, useRef } from 'react';
import {
  ChatMessage,
  AssistantRole,
  GeminiModelTier,
  GroqModelTier,
  AIProvider,
  PendingActionConfirmation,
  FileAttachment,
} from '../types';
import {
  Mic,
  MicOff,
  Send,
  Sparkles,
  Volume2,
  VolumeX,
  Brain,
  Zap,
  Bot,
  User as UserIcon,
  FileText,
  Table,
  Image as ImageIcon,
  CheckCircle2,
  ExternalLink,
  Square,
  RefreshCw,
  Sliders,
  BookOpen,
  Download,
  Copy,
  Check,
  Paperclip,
  X,
  FileSpreadsheet,
  Database,
  Users,
  SlidersHorizontal,
  Volume1,
  ShieldCheck,
  Radio,
  Globe,
  History,
  Lock,
} from 'lucide-react';
import {
  floatTo16BitPCMBase64,
  LiveAudioPlayer,
  VoiceNoiseFilter,
  calculateAudioRMS,
  rmsToNormalizedLevel,
} from '../utils/audio';
import {
  openInObsidian,
  downloadMarkdownFile,
  getObsidianVaultName,
  saveConversationToObsidian,
  isAutoSaveObsidianEnabled,
  setAutoSaveObsidianEnabled,
} from '../utils/obsidian';
import { logAuditEvent, saveChatSession, getChatSessions, saveCommandRecord } from '../services/firestoreDb';
import { getActiveProfile } from '../services/profileService';
import { ProfileModal } from './ProfileModal';
import { CommandHistoryModal } from './CommandHistoryModal';
import { CyberParticleOrb } from './CyberParticleOrb';
import { UserProfile, VoiceCommandActionType } from '../types';
import { parseVoiceNavigationCommand, OverlayView } from '../utils/commandParser';

interface Props {
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  onRequestAction: (action: PendingActionConfirmation) => void;
  isAuthenticated: boolean;
  onPromptLogin: () => void;
  isLiveConnected: boolean;
  setIsLiveConnected: React.Dispatch<React.SetStateAction<boolean>>;
  onNavigateOverlay?: (view: OverlayView) => void;
}

export const VoiceAssistantHub: React.FC<Props> = ({
  messages,
  setMessages,
  onRequestAction,
  isAuthenticated,
  onPromptLogin,
  isLiveConnected,
  setIsLiveConnected,
  onNavigateOverlay,
}) => {
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [selectedRole, setSelectedRole] = useState<AssistantRole>('executive');
  const [selectedProvider, setSelectedProvider] = useState<AIProvider>('gemini');
  const [selectedModel, setSelectedModel] = useState<GeminiModelTier>('gemini-3.8-flash');
  const [selectedGroqModel, setSelectedGroqModel] = useState<GroqModelTier>('llama-3.3-70b-versatile');
  const [directWorkspaceCreation, setDirectWorkspaceCreation] = useState(true);
  const [isExecutingWorkspaceAction, setIsExecutingWorkspaceAction] = useState(false);
  const [enableHighThinking, setEnableHighThinking] = useState(false);
  const [useGoogleSearch, setUseGoogleSearch] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [openedObsidianMsgId, setOpenedObsidianMsgId] = useState<string | null>(null);
  const [currentAttachment, setCurrentAttachment] = useState<FileAttachment | null>(null);
  const [autoSaveObsidian, setAutoSaveObsidian] = useState<boolean>(() => isAutoSaveObsidianEnabled());
  const chatFileInputRef = useRef<HTMLInputElement | null>(null);

  // User Profile & Noise Gate State
  const [activeProfile, setActiveProfileState] = useState<UserProfile>(() => getActiveProfile());
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [liveMicLevel, setLiveMicLevel] = useState<number>(0);
  const [isVoiceDetected, setIsVoiceDetected] = useState<boolean>(false);
  const [liveNoiseGated, setLiveNoiseGated] = useState<boolean>(false);
  const [isContinuousListening, setIsContinuousListening] = useState<boolean>(false);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [isCommandHistoryOpen, setIsCommandHistoryOpen] = useState(false);
  const [dashboardViewMode, setDashboardViewMode] = useState<'orb' | 'chat'>('orb');

  // Handle clicking the glowing cyber particle orb
  const handleOrbClick = () => {
    setAudioError(null);

    // 1. If AI is currently speaking, interrupt it
    if (isAiSpeaking || voiceStatus === 'speaking') {
      interruptSpeaking();
      return;
    }

    // 2. If currently listening, stop and process speech
    if (isContinuousListening || isRecording || voiceStatus === 'listening') {
      if (isContinuousListening) {
        stopContinuousSpeech();
      } else {
        stopRecording();
      }
      // If there is accumulated text, send it
      if (inputText.trim()) {
        const query = inputText.trim();
        setInputText('');
        handleSendMessage(query);
      }
      return;
    }

    // 3. If Live Voice websocket is connected, it handles audio streaming
    if (isLiveConnected) {
      return;
    }

    // 4. Start listening: activate speech recognition and audio level visualizer
    toggleContinuousSpeech();
  };

  const handleReExecuteCommand = (commandText: string, actionType?: VoiceCommandActionType) => {
    setInputText(commandText);
    handleSendMessage(commandText);
  };

  const continuousRecognitionRef = useRef<any>(null);
  const micMonitorStreamRef = useRef<MediaStream | null>(null);
  const micMonitorCtxRef = useRef<AudioContext | null>(null);
  const micMonitorAnimFrameRef = useRef<number | null>(null);
  const noiseFilterRef = useRef<VoiceNoiseFilter | null>(null);

  // Listen for profile changes from modal or navbar
  useEffect(() => {
    const handleProfileChanged = () => {
      const updated = getActiveProfile();
      setActiveProfileState(updated);
      if (noiseFilterRef.current) {
        noiseFilterRef.current.updateThreshold(updated.noiseGateThreshold);
      }
    };
    window.addEventListener('voiceflow:profile_changed', handleProfileChanged);
    return () => window.removeEventListener('voiceflow:profile_changed', handleProfileChanged);
  }, []);

  const handleSaveConversationToObsidian = () => {
    if (messages.length === 0) return;
    const result = saveConversationToObsidian(messages);
    if (result) {
      logAuditEvent({
        actionType: 'obsidian_conversation_saved',
        entityType: 'session',
        details: `Conversación archivada en base de datos Obsidian: "${result.record.title}" (${messages.length} mensajes)`,
        status: 'success',
      }).catch(() => {});

      setMessages((prev) => [
        ...prev,
        {
          id: 'sys-obs-' + Date.now(),
          role: 'system',
          content: `🟣 **Conversación Archivada en Obsidian:** Registro sincronizado con éxito en tu base de datos de Obsidian (Bóveda \`${result.record.vault}\`).`,
          timestamp: Date.now(),
        },
      ]);
    }
  };

  // Audio refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const playerRef = useRef<LiveAudioPlayer | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const executedProposalsRef = useRef<Set<string>>(new Set());
  const accumulatedLiveTranscriptRef = useRef<string>('');

  // Role system instructions
  const roleInstructions: Record<AssistantRole, { name: string; desc: string; instruction: string }> = {
    executive: {
      name: 'Executive Workflow Architect',
      desc: 'Orchestrates high-level tasks, daily summaries, and cross-tool workflows',
      instruction:
        'You are an Executive AI Assistant. You help leaders organize workflows across Google Docs, Sheets, and Obsidian (vault "tron"), generate action items, and synthesize decisions into structured documents and markdown notes.',
    },
    docs_specialist: {
      name: 'Docs & Report Specialist',
      desc: 'Excels in formatting comprehensive memos, meeting minutes, and briefs',
      instruction:
        'You are a Google Docs and Obsidian Markdown specialist. You write structured, polished reports, memos, and agendas with clear headings, executive summaries, and Obsidian-compatible formatting ready for the "tron" vault or Google Docs.',
    },
    sheets_analyst: {
      name: 'Sheets & Data Analyst',
      desc: 'Analyzes metrics, designs spreadsheet schemas, and logs tabular records',
      instruction:
        'You are a Google Sheets and data analyst. You structure tabular data cleanly, generate rows for tracking budgets, tasks, and KPIs, and provide formulas.',
    },
    creative_designer: {
      name: 'Creative Content Director',
      desc: 'Guides media creation, visual prompts, and presentation graphics',
      instruction:
        'You are a creative director. You assist with generating visual ideas, craft detailed prompts for Gemini image generation models (1K/2K/4K), and compose compelling presentations.',
    },
  };

  // Scroll to bottom when messages update
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, voiceStatus]);

  // Initialize LiveAudioPlayer
  useEffect(() => {
    playerRef.current = new LiveAudioPlayer((speaking) => {
      setIsAiSpeaking(speaking);
      if (speaking) {
        setVoiceStatus('speaking');
        window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'speaking' } }));
      } else if (!isRecording) {
        setVoiceStatus('idle');
        window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
      }
    });

    return () => {
      playerRef.current?.close();
      stopRecording();
      closeLiveWebSocket();
    };
  }, []);

  // Handle Model Tier toggle
  const handleModelChange = (model: GeminiModelTier) => {
    setSelectedModel(model);
    if (model === 'gemini-3.1-pro-preview') {
      setEnableHighThinking(true);
    } else {
      setEnableHighThinking(false);
    }
  };

  // Connect / Disconnect Live WebSocket for Live API (gemini-3.8-live)
  const toggleLiveConnection = async () => {
    if (isLiveConnected) {
      closeLiveWebSocket();
      stopRecording();
      setIsLiveConnected(false);
      setVoiceStatus('idle');
    } else {
      setAudioError(null);
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/live`;
        const ws = new WebSocket(wsUrl);

        ws.onopen = () => {
          console.log('Connected to Gemini Live WebSocket');
          setIsLiveConnected(true);
          startRecording(ws);
        };

        ws.onmessage = async (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'connected') {
              console.log('Gemini 3.8 Live session active');
            } else if (data.type === 'audio' && data.audio) {
              playerRef.current?.playChunk(data.audio);
            } else if (data.type === 'transcript' && data.text) {
              accumulatedLiveTranscriptRef.current += ' ' + data.text;
              const fullTurnText = accumulatedLiveTranscriptRef.current;

              setMessages((prev) => {
                const last = prev[prev.length - 1];
                if (last && last.role === 'assistant' && last.modelUsed === 'gemini-3.8-live') {
                  return [
                    ...prev.slice(0, -1),
                    { ...last, content: last.content + ' ' + data.text },
                  ];
                } else {
                  return [
                    ...prev,
                    {
                      id: 'live-' + Date.now(),
                      role: 'assistant',
                      content: data.text,
                      timestamp: Date.now(),
                      modelUsed: 'gemini-3.8-live',
                    },
                  ];
                }
              });
            } else if (data.type === 'turnComplete') {
              const fullTurnText = accumulatedLiveTranscriptRef.current;
              if (fullTurnText) {
                const proposal = parseActionProposal(fullTurnText);
                if (proposal) {
                  const proposalKey = `${proposal.type}_${proposal.payload?.title || proposal.title}`;
                  if (!executedProposalsRef.current.has(proposalKey)) {
                    executedProposalsRef.current.add(proposalKey);
                    await executeProposalDirectly(proposal);
                  }
                }
              }
              accumulatedLiveTranscriptRef.current = '';
            } else if (data.type === 'interrupted') {
              accumulatedLiveTranscriptRef.current = '';
              playerRef.current?.stopAndClear();
            } else if (data.type === 'error') {
              setAudioError(data.error);
            }
          } catch (e) {
            console.error('Error parsing live WS message:', e);
          }
        };

        ws.onerror = (err) => {
          console.error('Live WS error:', err);
          setAudioError('Live API connection error. Check server logs.');
          setIsLiveConnected(false);
        };

        ws.onclose = () => {
          console.log('Live WS closed');
          setIsLiveConnected(false);
          setIsRecording(false);
          setVoiceStatus('idle');
        };

        wsRef.current = ws;
      } catch (err: any) {
        setAudioError(err?.message || 'Could not start Live API session');
      }
    }
  };

  const closeLiveWebSocket = () => {
    executedProposalsRef.current.clear();
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (_) {}
      wsRef.current = null;
    }
  };

  // Mic Noise Monitoring for visual VU Meter & noise gate feedback during Speech Recognition
  const startMicNoiseMonitoring = async () => {
    try {
      if (micMonitorStreamRef.current) return;
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: activeProfile.noiseSuppressionEnabled,
          autoGainControl: true,
        },
      });
      micMonitorStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      micMonitorCtxRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);

      const buffer = new Float32Array(analyser.fftSize);
      const updateMeter = () => {
        if (!micMonitorStreamRef.current) return;
        analyser.getFloatTimeDomainData(buffer);
        const rms = calculateAudioRMS(buffer);
        const normalized = rmsToNormalizedLevel(rms);
        setLiveMicLevel(normalized);

        const threshold = activeProfile.noiseGateThreshold;
        const speaking = normalized >= threshold;
        setIsVoiceDetected(speaking);
        setLiveNoiseGated(!speaking && normalized > 2);

        micMonitorAnimFrameRef.current = requestAnimationFrame(updateMeter);
      };
      updateMeter();
    } catch (e) {
      console.warn('Microphone monitoring unavailable:', e);
    }
  };

  const stopMicNoiseMonitoring = () => {
    if (micMonitorAnimFrameRef.current) {
      cancelAnimationFrame(micMonitorAnimFrameRef.current);
      micMonitorAnimFrameRef.current = null;
    }
    if (micMonitorStreamRef.current) {
      micMonitorStreamRef.current.getTracks().forEach((t) => t.stop());
      micMonitorStreamRef.current = null;
    }
    if (micMonitorCtxRef.current && micMonitorCtxRef.current.state !== 'closed') {
      try {
        micMonitorCtxRef.current.close();
      } catch (_) {}
      micMonitorCtxRef.current = null;
    }
    setLiveMicLevel(0);
    setIsVoiceDetected(false);
    setLiveNoiseGated(false);
  };

  // Start Mic Audio capture and stream Float32 -> 16-bit PCM base64 with active profile noise gate
  const startRecording = async (activeWs?: WebSocket) => {
    try {
      setAudioError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: activeProfile.noiseSuppressionEnabled,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass({ sampleRate: 16000 });
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);

      // Create profile-tailored noise filter
      const noiseFilter = new VoiceNoiseFilter({
        noiseGateThreshold: activeProfile.noiseGateThreshold,
        highpassFilterEnabled: activeProfile.highpassFilterEnabled,
        onVoiceActivityChange: (isSpeaking, currentLevel) => {
          setLiveMicLevel(currentLevel);
          setIsVoiceDetected(isSpeaking);
          setLiveNoiseGated(!isSpeaking && currentLevel > 2);
        },
      });
      noiseFilterRef.current = noiseFilter;

      // 4096 buffer size processor
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      scriptProcessorRef.current = processor;

      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);

        // Pass audio buffer through our Noise Gate
        const { isVoice, processedBuffer } = noiseFilter.processBuffer(inputData);

        // Anti-Noise Guard: If audio is below noise gate threshold (fan, keyboard, coughing, chatter),
        // we DO NOT send it to the AI WebSocket. This prevents the AI from getting confused or hallucinating!
        if (!isVoice) {
          return;
        }

        const pcmBase64 = floatTo16BitPCMBase64(processedBuffer);
        const targetWs = activeWs || wsRef.current;
        if (targetWs && targetWs.readyState === WebSocket.OPEN) {
          targetWs.send(
            JSON.stringify({
              type: 'audio',
              audio: pcmBase64,
            })
          );
        }
      };

      // Apply Highpass 85Hz filter to cut off sub-bass rumble if enabled in profile
      if (activeProfile.highpassFilterEnabled) {
        const biquad = audioCtx.createBiquadFilter();
        biquad.type = 'highpass';
        biquad.frequency.setValueAtTime(85, audioCtx.currentTime);
        source.connect(biquad);
        biquad.connect(processor);
      } else {
        source.connect(processor);
      }

      processor.connect(audioCtx.destination);

      setIsRecording(true);
      setVoiceStatus('listening');
    } catch (err: any) {
      console.error('Failed to open microphone:', err);
      setAudioError('Microphone permission denied or unavailable.');
    }
  };

  const stopRecording = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (scriptProcessorRef.current) {
      try {
        scriptProcessorRef.current.disconnect();
      } catch (_) {}
      scriptProcessorRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (_) {}
      audioContextRef.current = null;
    }
    noiseFilterRef.current = null;
    stopMicNoiseMonitoring();
    setIsRecording(false);
    setLiveMicLevel(0);
    setIsVoiceDetected(false);
    setLiveNoiseGated(false);
    if (voiceStatus === 'listening') {
      setVoiceStatus('idle');
    }
  };

  const interruptSpeaking = () => {
    playerRef.current?.stopAndClear();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (_) {}
    }
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text: 'Stop' }));
    }
    setIsAiSpeaking(false);
    setVoiceStatus('idle');
  };

  // Toggle Continuous Speech Recognition with Background Noise Filtering
  const toggleContinuousSpeech = () => {
    if (isContinuousListening) {
      stopContinuousSpeech();
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setAudioError('El reconocimiento de voz nativo no está soportado en este navegador. Puedes escribir directamente.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = activeProfile.language || 'es-ES';
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsContinuousListening(true);
        setIsRecording(true);
        setVoiceStatus('listening');
        setInterimTranscript('Escuchando voz continua...');
        startMicNoiseMonitoring();
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (final.trim()) {
          const spoken = final.trim();
          const navCmd = parseVoiceNavigationCommand(spoken);
          if (navCmd.isNavCommand && onNavigateOverlay && navCmd.targetView) {
            onNavigateOverlay(navCmd.targetView);
            setInterimTranscript('');
            return;
          }
          setInputText((prev) => (prev ? prev + ' ' + spoken : spoken));
          setInterimTranscript('');
        } else if (interim.trim()) {
          setInterimTranscript(interim);
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
          console.warn('Speech recognition notice:', event.error);
        }
      };

      recognition.onend = () => {
        if (continuousRecognitionRef.current) {
          try {
            recognition.start();
          } catch (_) {}
        } else {
          stopContinuousSpeech();
        }
      };

      continuousRecognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Error starting continuous recognition:', err);
      setAudioError('No se pudo iniciar el reconocimiento de voz.');
      stopContinuousSpeech();
    }
  };

  const stopContinuousSpeech = () => {
    if (continuousRecognitionRef.current) {
      const ref = continuousRecognitionRef.current;
      continuousRecognitionRef.current = null;
      try {
        ref.stop();
      } catch (_) {}
    }
    stopMicNoiseMonitoring();
    setIsContinuousListening(false);
    setIsRecording(false);
    setInterimTranscript('');
    if (voiceStatus === 'listening') setVoiceStatus('idle');
  };

  // Quick speech-to-text dictation with active profile language
  const handleDictatePrompt = () => {
    if (isContinuousListening) {
      stopContinuousSpeech();
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setAudioError('Reconocimiento de voz no soportado en este navegador.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = activeProfile.language || 'es-ES';
    recognition.interimResults = true;

    recognition.onstart = () => {
      setIsRecording(true);
      setVoiceStatus('listening');
      setInterimTranscript('Habla ahora...');
      startMicNoiseMonitoring();
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';
      for (let i = 0; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          final += event.results[i][0].transcript;
        } else {
          interim += event.results[i][0].transcript;
        }
      }
      if (final.trim()) {
        const spoken = final.trim();
        const navCmd = parseVoiceNavigationCommand(spoken);
        if (navCmd.isNavCommand && onNavigateOverlay && navCmd.targetView) {
          onNavigateOverlay(navCmd.targetView);
          setInterimTranscript('');
          stopMicNoiseMonitoring();
          setIsRecording(false);
          setVoiceStatus('idle');
          return;
        }
        setInputText((prev) => (prev ? prev + ' ' + spoken : spoken));
        setInterimTranscript('');
      } else if (interim.trim()) {
        setInterimTranscript(interim);
      }
    };

    recognition.onerror = (event: any) => {
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        console.warn('Speech recognition notice:', event.error);
      }
      stopMicNoiseMonitoring();
      setIsRecording(false);
      setVoiceStatus('idle');
      setInterimTranscript('');
    };

    recognition.onend = () => {
      stopMicNoiseMonitoring();
      setIsRecording(false);
      setInterimTranscript('');
      if (voiceStatus === 'listening') setVoiceStatus('idle');
    };

    recognition.start();
  };

  const handleChatFileSelect = (file: File) => {
    if (file.size > 20 * 1024 * 1024) {
      setAudioError('El archivo supera los 20MB permitidos.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const isImg = file.type.startsWith('image/');
      setCurrentAttachment({
        name: file.name,
        type: file.type || 'application/octet-stream',
        size: file.size,
        data: result,
        previewUrl: isImg ? result : undefined,
      });
    };
    reader.readAsDataURL(file);
  };

  // Send message via /api/chat with full multi-turn context
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend !== undefined ? textToSend : inputText;
    if ((!text.trim() && !currentAttachment) || isLoading) return;

    if (text.trim()) {
      const navCmd = parseVoiceNavigationCommand(text.trim());
      if (navCmd.isNavCommand && onNavigateOverlay && navCmd.targetView) {
        onNavigateOverlay(navCmd.targetView);
        setInputText('');
        return;
      }
    }

    const attached = currentAttachment;
    const userMessage: ChatMessage = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: text || (attached ? `Por favor analiza este archivo adjunto (${attached.name}) y extrae los datos necesarios.` : ''),
      timestamp: Date.now(),
      attachment: attached || undefined,
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputText('');
    setCurrentAttachment(null);
    setIsLoading(true);
    setVoiceStatus('thinking');
    window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'thinking' } }));

    try {
      const activeModel = selectedProvider === 'groq' ? selectedGroqModel : selectedModel;
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
            attachment: m.attachment
              ? {
                  name: m.attachment.name,
                  type: m.attachment.type,
                  data: m.attachment.data,
                }
              : undefined,
          })),
          model: activeModel,
          provider: selectedProvider,
          enableThinking: selectedProvider === 'gemini' && enableHighThinking,
          useGoogleSearch: selectedProvider === 'gemini' && useGoogleSearch,
          systemInstruction: `${roleInstructions[selectedRole].instruction}\n[Perfil de Usuario Activo: "${activeProfile.name}", Rol: "${activeProfile.role}", Tono Preferido: "${activeProfile.tone}"]${activeProfile.customInstructions ? `\nInstrucciones Específicas del Usuario: "${activeProfile.customInstructions}"` : ''}`,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with ${response.status}`);
      }

      const data = await response.json();

      // Check if response contains a structured workflow action proposal
      const proposal = parseActionProposal(data.reply, text);

      const assistantMessage: ChatMessage = {
        id: 'msg-' + Date.now() + 1,
        role: 'assistant',
        content: data.reply,
        timestamp: Date.now(),
        modelUsed: data.model,
        usedThinking: data.usedThinking,
        groundingSources: data.groundingSources,
        actionProposal: proposal || undefined,
      };

      setMessages((prev) => {
        const next = [...prev, assistantMessage];
        if (autoSaveObsidian && next.length >= 2) {
          try {
            saveConversationToObsidian(next);
          } catch (obsErr) {
            console.warn('Auto-save conversation to Obsidian error:', obsErr);
          }
        }
        // Save multi-turn session to Firestore
        try {
          saveChatSession({
            title: next[0]?.content.slice(0, 50) || 'Sesión de Chat Gemini',
            model: data.model || activeModel,
            role: selectedRole,
            messages: next,
          });
        } catch (dbErr) {
          console.warn('Auto-save chat to Firestore notice:', dbErr);
        }
        return next;
      });

      // Automatic Workspace Execution without requiring clicks
      if (proposal) {
        if (isAuthenticated) {
          executeProposalDirectly(proposal);
        } else {
          setMessages((prev) => [
            ...prev,
            {
              id: 'sys-notice-' + Date.now(),
              role: 'system',
              content: `💡 **Conexión a Google Workspace:** Se detectó la creación de **${proposal.title}**. Inicia sesión con Google arriba una sola vez para que la asistente guarde automáticamente las hojas de cálculo y documentos en tu Google Drive sin requerir clics.`,
              timestamp: Date.now(),
            },
          ]);
          onPromptLogin();
        }
      }

      // Speak response aloud via TTS if desired
      speakResponse(data.reply);
    } catch (err: any) {
      console.error('Chat error:', err);
      const raw = String(err?.message || '');
      let friendlyError = raw;
      if (raw.includes('503') || raw.includes('high demand') || raw.includes('UNAVAILABLE')) {
        friendlyError = 'El modelo seleccionado está experimentando alta demanda temporal (503). Por favor selecciona Gemini 3.1 Flash Lite en la barra superior o reintenta en unos instantes.';
      } else if (raw.includes('429') || raw.includes('quota') || raw.includes('RESOURCE_EXHAUSTED')) {
        friendlyError = 'Límite de cuota alcanzado (429). Por favor selecciona Gemini 3.1 Flash Lite para continuar sin restricciones.';
      }

      setMessages((prev) => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          role: 'assistant',
          content: `⚠️ ${friendlyError}`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsLoading(false);
      setVoiceStatus('idle');
      window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
    }
  };

  // Listen for voice-initiated prompt executions from useVoiceCommander or global events
  const handleSendMessageRef = useRef(handleSendMessage);
  useEffect(() => {
    handleSendMessageRef.current = handleSendMessage;
  });

  useEffect(() => {
    const handleVoicePrompt = (e: Event) => {
      const customEvent = e as CustomEvent<{ prompt: string }>;
      const prompt = customEvent.detail?.prompt;
      if (prompt && prompt.trim()) {
        handleSendMessageRef.current(prompt.trim());
      }
    };
    window.addEventListener('voiceflow:execute_prompt', handleVoicePrompt);
    return () => {
      window.removeEventListener('voiceflow:execute_prompt', handleVoicePrompt);
    };
  }, []);

  // Convert text response to speech via /api/tts with seamless native browser synthesis fallback
  const speakResponse = async (text: string) => {
    // Keep utterance concise for audio clarity
    const cleanSnippet = text.replace(/```[\s\S]*?```/g, '').replace(/[*_#`[\]()]/g, '').trim().slice(0, 350);
    if (!cleanSnippet) return;

    const speakViaBrowser = () => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setIsAiSpeaking(false);
        return;
      }
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(cleanSnippet);
        utterance.lang = activeProfile.language || 'es-ES';
        const voices = window.speechSynthesis.getVoices();
        const langPrefix = (activeProfile.language || 'es').slice(0, 2);
        const match = voices.find((v) => v.lang.startsWith(langPrefix));
        if (match) utterance.voice = match;
        utterance.rate = 1.05;
        utterance.onstart = () => {
          setIsAiSpeaking(true);
          setVoiceStatus('speaking');
          window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'speaking' } }));
        };
        utterance.onend = () => {
          setIsAiSpeaking(false);
          setVoiceStatus('idle');
          window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
        };
        utterance.onerror = () => {
          setIsAiSpeaking(false);
          setVoiceStatus('idle');
          window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
        };
        window.speechSynthesis.speak(utterance);
      } catch (_) {
        setIsAiSpeaking(false);
      }
    };

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanSnippet, voice: 'Zephyr' }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          playerRef.current?.playChunk(data.audio);
          return;
        }
        if (data.fallbackToBrowser) {
          speakViaBrowser();
          return;
        }
      }
      speakViaBrowser();
    } catch (_) {
      speakViaBrowser();
    }
  };

  // Extract markdown table into structured headers & rows
  const extractMarkdownTable = (text: string): { headers: string[]; rows: (string | number)[][] } | null => {
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
    const tableLines = lines.filter((l) => l.startsWith('|') && l.endsWith('|'));
    if (tableLines.length >= 2) {
      const parseRow = (line: string) =>
        line
          .slice(1, -1)
          .split('|')
          .map((c) => c.trim());
      const rawHeaders = parseRow(tableLines[0]);
      // Skip markdown divider line like |---|---|
      const dataLines = tableLines.slice(1).filter((l) => !/^\|(\s*:?-+:?\s*\|)+$/.test(l));
      const rawRows = dataLines.map(parseRow);
      if (rawHeaders.length > 0 && rawRows.length > 0) {
        return { headers: rawHeaders, rows: rawRows };
      }
    }
    return null;
  };

  // Parse workflow actions proposed by Gemini or Groq, with support for automatic sheets & docs creation
  const parseActionProposal = (text: string, userPrompt?: string) => {
    if (!text || text.trim().length === 0) return null;

    // 1. Check for structured workspace_action JSON block
    const wsActionMatch = text.match(/```workspace_action\s*([\s\S]*?)\s*```/);
    if (wsActionMatch) {
      try {
        const parsed = JSON.parse(wsActionMatch[1]);
        if (parsed.action === 'create_doc' || parsed.type === 'docs_create') {
          return {
            type: 'docs_create' as const,
            title: parsed.title || 'Documento en Google Docs',
            description: parsed.summary || 'Generación y guardado automático en Google Docs',
            payload: {
              title: parsed.title || 'Documento Asistente IA - ' + new Date().toLocaleDateString(),
              content: parsed.content || text.replace(/```workspace_action[\s\S]*?```/, '').trim(),
            },
            status: 'pending_confirmation' as const,
          };
        } else if (parsed.action === 'create_sheet' || parsed.type === 'sheets_create') {
          return {
            type: 'sheets_create' as const,
            title: parsed.title || 'Hoja de Cálculo en Google Sheets',
            description: parsed.summary || 'Generación y guardado automático en Google Sheets',
            payload: {
              title: parsed.title || 'Hoja de Cálculo Asistente IA',
              headers: parsed.headers || ['Columna 1', 'Columna 2'],
              rows: parsed.rows || [],
              sheetName: parsed.sheetName || 'Datos',
            },
            status: 'pending_confirmation' as const,
          };
        } else if (parsed.action === 'append_sheet' || parsed.type === 'sheets_append') {
          return {
            type: 'sheets_append' as const,
            title: parsed.title || 'Añadir Fila a Google Sheet',
            description: parsed.summary || 'Registro automático en Google Sheets',
            payload: {
              row: parsed.row || (parsed.rows && parsed.rows[0]) || [new Date().toLocaleDateString(), 'Registro IA'],
            },
            status: 'pending_confirmation' as const,
          };
        }
      } catch (e) {
        console.warn('Error parsing workspace_action JSON:', e);
      }
    }

    // 2. Check for legacy tags DOC_PROPOSAL / CREATE_DOC
    if (text.includes('DOC_PROPOSAL:') || text.includes('CREATE_DOC:')) {
      const cleaned = text.replace(/DOC_PROPOSAL:\s*|CREATE_DOC:\s*/g, '').trim();
      const firstLine = cleaned.split('\n')[0]?.replace(/^#+\s*/, '').trim() || 'Documento Google Docs';
      return {
        type: 'docs_create' as const,
        title: firstLine,
        description: 'Guardar documento en Google Docs',
        payload: { title: firstLine, content: cleaned },
        status: 'pending_confirmation' as const,
      };
    }

    // 3. Check for legacy tags SHEET_PROPOSAL / CREATE_SHEET / APPEND_SHEET
    if (text.includes('SHEET_PROPOSAL:') || text.includes('CREATE_SHEET:') || text.includes('APPEND_SHEET:')) {
      const table = extractMarkdownTable(text);
      if (table) {
        return {
          type: 'sheets_create' as const,
          title: 'Hoja de Cálculo - ' + new Date().toLocaleDateString(),
          description: 'Hoja de cálculo generada automáticamente en Google Sheets',
          payload: {
            title: 'Hoja de Cálculo - ' + new Date().toLocaleDateString(),
            headers: table.headers,
            rows: table.rows,
          },
          status: 'pending_confirmation' as const,
        };
      }
      return {
        type: 'sheets_append' as const,
        title: 'Registrar en Google Sheet',
        description: 'Añadir fila a Google Sheets',
        payload: { row: [new Date().toLocaleDateString(), 'Acción IA', 'Completado', text.slice(0, 60)] },
        status: 'pending_confirmation' as const,
      };
    }

    // 4. Automatic Spreadsheet Detection (Markdown table present + context of sheets/data/tables)
    const combinedContext = `${userPrompt || ''} ${text}`.toLowerCase();
    const tableData = extractMarkdownTable(text);
    const mentionsSheet =
      combinedContext.includes('hoja') ||
      combinedContext.includes('sheet') ||
      combinedContext.includes('tabla') ||
      combinedContext.includes('cálculo') ||
      combinedContext.includes('calculo') ||
      combinedContext.includes('excel') ||
      combinedContext.includes('presupuesto') ||
      combinedContext.includes('inventario') ||
      combinedContext.includes('balance') ||
      combinedContext.includes('datos');

    if (tableData && (mentionsSheet || tableData.rows.length >= 1)) {
      // Derive a meaningful title from headings, first line, or prompt
      let extractedTitle = 'Hoja de Cálculo IA - ' + new Date().toLocaleDateString();
      const headingMatch = text.match(/^#+\s*(.*)$/m);
      if (headingMatch && headingMatch[1]) {
        extractedTitle = headingMatch[1].trim();
      } else if (userPrompt && userPrompt.trim().length > 3) {
        extractedTitle = userPrompt
          .replace(/^(crea|hazme|haz|genera|redacta)\s+(una?\s+)?(hoja(\s+de\s+c[aá]lculo)?|sheet|tabla|excel)\s*(de|con|para|sobre)?\s*/i, '')
          .slice(0, 45)
          .trim();
        if (!extractedTitle) extractedTitle = 'Hoja de Cálculo IA';
      }

      return {
        type: 'sheets_create' as const,
        title: extractedTitle,
        description: `Crear hoja de cálculo con ${tableData.rows.length} filas y ${tableData.headers.length} columnas`,
        payload: {
          title: extractedTitle,
          headers: tableData.headers,
          rows: tableData.rows,
        },
        status: 'pending_confirmation' as const,
      };
    }

    // 5. Automatic Document Detection (Prompt requests doc or text contains formatted report)
    const mentionsDocRequest =
      /(crea|crear|haz|hazme|redacta|escribe|genera|guardar?)\s+(un\s+)?(doc|documento|informe|reporte|minuta|resumen|art[ií]culo|gu[ií]a|memo)/i.test(
        userPrompt || ''
      ) ||
      combinedContext.includes('google doc') ||
      combinedContext.includes('documento para docs') ||
      combinedContext.includes('en google docs');

    if (mentionsDocRequest && text.trim().length > 50) {
      let docTitle = 'Documento Asistente IA - ' + new Date().toLocaleDateString();
      const headingMatch = text.match(/^#+\s*(.*)$/m);
      if (headingMatch && headingMatch[1]) {
        docTitle = headingMatch[1].trim();
      } else if (userPrompt && userPrompt.trim().length > 3) {
        docTitle = userPrompt
          .replace(/^(crea|hazme|haz|genera|redacta|escribe)\s+(un\s+)?(documento|doc|reporte|informe|minuta|resumen)\s*(de|con|para|sobre)?\s*/i, '')
          .slice(0, 50)
          .trim();
        if (!docTitle) docTitle = 'Documento Asistente IA';
      }

      return {
        type: 'docs_create' as const,
        title: docTitle,
        description: 'Documento redactado y formateado para Google Docs',
        payload: {
          title: docTitle,
          content: text.replace(/```workspace_action[\s\S]*?```/, '').trim(),
        },
        status: 'pending_confirmation' as const,
      };
    }

    // 6. Natural Spanish Detection for Google Sheets row addition
    if (
      /(a[ñn]ad(e|ir)|agrega(r)?|inserta(r)?|registra(r)?)\s+(una?\s+)?fila/i.test(combinedContext) ||
      combinedContext.includes('añadir a la hoja') ||
      combinedContext.includes('agregar fila')
    ) {
      return {
        type: 'sheets_append' as const,
        title: 'Añadir Fila a Google Sheet',
        description: 'Insertar nuevo registro tabular en Google Sheets',
        payload: {
          row: [new Date().toLocaleDateString(), 'Registro Automático IA', text.slice(0, 60)],
        },
        status: 'pending_confirmation' as const,
      };
    }

    return null;
  };

  // Reference to hold pending proposal if Google Workspace auth is needed
  const pendingProposalRef = useRef<any>(null);

  // Resume pending proposal as soon as workspace auth succeeds
  useEffect(() => {
    const handleWorkspaceAuth = async (e: Event) => {
      const customEvent = e as CustomEvent<{ hasToken: boolean }>;
      if (customEvent.detail?.hasToken && pendingProposalRef.current) {
        const pending = pendingProposalRef.current;
        pendingProposalRef.current = null;
        await executeProposalDirectly(pending);
      }
    };
    window.addEventListener('workspace:auth_changed', handleWorkspaceAuth);
    return () => {
      window.removeEventListener('workspace:auth_changed', handleWorkspaceAuth);
    };
  }, []);

  // Reemplaza el manejo de transcripción y propuestas por ejecución directa automática
  const executeProposalDirectly = async (proposal: any) => {
    if (!proposal) return;

    // Verificar si el token OAuth de Workspace está presente antes de invocar la API
    const { getAccessToken } = await import('../services/firebaseAuth');
    const token = await getAccessToken();

    if (!token) {
      pendingProposalRef.current = proposal;
      speakResponse(
        `Para crear ${proposal.payload?.title || proposal.title} en Google Workspace, por favor autoriza el acceso con tu cuenta de Google.`
      );

      setMessages((prev) => {
        const title = proposal.payload?.title || proposal.title;
        const exists = prev.some(
          (m) => m.id.startsWith('sys-auth-req-') && (m as any).proposalTitle === title
        );
        if (exists) return prev;

        return [
          ...prev,
          {
            id: 'sys-auth-req-' + Date.now(),
            role: 'system',
            proposalTitle: title,
            actionProposal: proposal,
            content: `🔑 **Autenticación con Google Workspace requerida:**\nPara que Lexi cree y guarde automáticamente **"${title}"** en tu Google Drive, inicia sesión con Google a continuación.`,
            timestamp: Date.now(),
          },
        ];
      });

      onPromptLogin();
      return;
    }

    try {
      if (proposal.type === 'docs_create') {
        const { createGoogleDoc } = await import('../services/workspaceApi');
        const title = proposal.payload?.title || 'Nuevo Documento Google Docs';
        const content = proposal.payload?.content || '';
        const doc = await createGoogleDoc(title, content);

        proposal.status = 'executed';
        proposal.url = doc.url;
        
        // Notificar por voz
        speakResponse(`He creado el documento ${doc.title} en tu Google Docs de forma automática.`);

        // Guardar comando en el historial persistente de Lexi
        saveCommandRecord({
          commandText: proposal.title || `Crear Google Doc "${doc.title}"`,
          actionType: 'docs_create',
          targetDocumentTitle: doc.title,
          modelUsed: selectedModel,
          status: 'executed',
          resultUrl: doc.url,
          resultSummary: `Documento "${doc.title}" creado y sincronizado en Google Drive.`,
        }).catch((err) => console.warn('Command history save notice:', err));

        // Log audit event to Firebase Firestore
        logAuditEvent({
          actionType: 'google_doc_created',
          entityType: 'document',
          details: `Documento Google Docs "${doc.title}" creado automáticamente vía comando de voz/chat. URL: ${doc.url}`,
          status: 'success',
        }).catch((err) => console.warn('Audit log error:', err));

        setMessages((prev) => [
          ...prev,
          {
            id: 'sys-' + Date.now(),
            role: 'system',
            content: `⚡ **Google Doc Creado Automáticamente:** [${doc.title}](${doc.url})\nEl documento ya está disponible y abierto en tu Google Drive sin necesidad de hacer clics.`,
            timestamp: Date.now(),
          },
        ]);
      } else if (proposal.type === 'sheets_append') {
        const { appendSpreadsheetRows, listGoogleSheets, createGoogleSheet } = await import('../services/workspaceApi');
        let spreadsheetId = proposal.payload?.spreadsheetId;
        if (!spreadsheetId) {
          const sheets = await listGoogleSheets().catch(() => []);
          if (sheets.length > 0) {
            spreadsheetId = sheets[0].id;
          } else {
            const newSheet = await createGoogleSheet('Registro Automático de Asistente IA', [
              ['Fecha', 'Acción', 'Estado', 'Detalle'],
            ]);
            spreadsheetId = newSheet.id;
          }
        }
        const row = proposal.payload?.row || [new Date().toLocaleDateString(), 'Registro Automático'];
        await appendSpreadsheetRows(spreadsheetId, [row]);
        proposal.status = 'executed';
        
        speakResponse(`He añadido la fila a tu hoja de cálculo automáticamente.`);

        // Guardar comando en el historial persistente de Lexi
        saveCommandRecord({
          commandText: proposal.title || 'Añadir registro a Google Sheets',
          actionType: 'sheets_append',
          targetDocumentTitle: 'Hoja de Cálculo en Google Drive',
          modelUsed: selectedModel,
          status: 'executed',
          resultSummary: 'Registro insertado exitosamente en Google Sheets.',
        }).catch((err) => console.warn('Command history save notice:', err));

        // Log audit event to Firebase Firestore
        logAuditEvent({
          actionType: 'google_sheet_appended',
          entityType: 'spreadsheet',
          details: `Fila añadida a hoja de cálculo ID: ${spreadsheetId}`,
          status: 'success',
        }).catch((err) => console.warn('Audit log error:', err));

        setMessages((prev) => [
          ...prev,
          {
            id: 'sys-' + Date.now(),
            role: 'system',
            content: `⚡ **Fila Registrada Automáticamente:** Se ha añadido la fila en tu hoja de cálculo en Google Sheets.`,
            timestamp: Date.now(),
          },
        ]);
      } else if (proposal.type === 'sheets_create') {
        const { createGoogleSheet } = await import('../services/workspaceApi');
        const allRows: (string | number)[][] = [];
        if (proposal.payload?.headers && proposal.payload.headers.length > 0) {
          allRows.push(proposal.payload.headers);
        }
        if (proposal.payload?.rows && proposal.payload.rows.length > 0) {
          allRows.push(...proposal.payload.rows);
        }
        const title = proposal.payload?.title || 'Nueva Hoja de Cálculo';
        const sheet = await createGoogleSheet(title, allRows);

        proposal.status = 'executed';
        proposal.url = sheet.url;

        speakResponse(`He creado la hoja de cálculo ${sheet.title} en tu Google Sheets automáticamente.`);

        // Guardar comando en el historial persistente de Lexi
        saveCommandRecord({
          commandText: proposal.title || `Crear hoja de cálculo "${sheet.title}"`,
          actionType: 'sheets_create',
          targetDocumentTitle: sheet.title,
          modelUsed: selectedModel,
          status: 'executed',
          resultUrl: sheet.url,
          resultSummary: `Hoja de cálculo "${sheet.title}" creada con ${allRows.length} filas en Google Sheets.`,
        }).catch((err) => console.warn('Command history save notice:', err));

        // Log audit event to Firebase Firestore
        logAuditEvent({
          actionType: 'google_sheet_created',
          entityType: 'spreadsheet',
          details: `Hoja de cálculo "${sheet.title}" creada automáticamente con ${allRows.length} filas. URL: ${sheet.url}`,
          status: 'success',
        }).catch((err) => console.warn('Audit log error:', err));

        setMessages((prev) => [
          ...prev,
          {
            id: 'sys-' + Date.now(),
            role: 'system',
            content: `⚡ **Google Sheet Creada Automáticamente:** [${sheet.title}](${sheet.url})\nLa hoja de cálculo con encabezados y filas fue creada en tu Google Drive sin requerir clics.`,
            timestamp: Date.now(),
          },
        ]);
      }
    } catch (error: any) {
      const errorMsg = error?.message || '';
      const isAuthError =
        errorMsg.includes('Google Workspace authentication required') ||
        errorMsg.includes('Please sign in') ||
        errorMsg.includes('401') ||
        error?.status === 401;

      if (isAuthError) {
        pendingProposalRef.current = proposal;
        setMessages((prev) => [
          ...prev,
          {
            id: 'sys-auth-req-' + Date.now(),
            role: 'system',
            actionProposal: proposal,
            content: `🔑 **Sesión de Google Workspace requerida:**\nTu sesión requiere autorización para guardar **"${proposal.payload?.title || proposal.title}"**. Haz clic en "Conectar Google" a continuación.`,
            timestamp: Date.now(),
          },
        ]);
        onPromptLogin();
      } else {
        console.error('Error al ejecutar la acción en Google Workspace:', error);
        setMessages((prev) => [
          ...prev,
          {
            id: 'sys-err-' + Date.now(),
            role: 'system',
            content: `❌ No se pudo crear en Google Workspace: ${errorMsg || 'Error de permisos'}.`,
            timestamp: Date.now(),
          },
        ]);
      }
    }
  };

  // Handle Action Proposal execution: ejecuta directamente sin interrupciones
  const executeProposal = (proposal: any) => {
    executeProposalDirectly(proposal);
  };

  // Quick prompt commands
  const quickActions = [
    {
      icon: FileText,
      label: '⚡ Crear Documento Google Docs',
      prompt: 'Crea un documento de Google Docs titulado "Plan de Estrategia y Objetivos" con resumen ejecutivo, 3 metas clave y próximos pasos.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
    },
    {
      icon: FileSpreadsheet,
      label: '⚡ Crear Hoja en Google Sheets',
      prompt: 'Crea una hoja de cálculo en Google Sheets titulada "Presupuesto Operativo 2026" con columnas [Concepto, Categoría, Monto USD, Estado] y 4 filas de registros detallados.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
    },
    {
      icon: FileSpreadsheet,
      label: 'Extraer Multidocumento a Sheets & Docs',
      prompt: 'Extrae y consolida datos tabulares para Google Sheets y el informe ejecutivo para Google Docs a partir de los documentos analizados.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
    },
    {
      icon: BookOpen,
      label: 'Nota para Obsidian (tron)',
      prompt: 'Redacta una nota ejecutiva en formato Markdown para mi bóveda "tron" de Obsidian con resumen de prioridades, tareas pendientes y etiquetas.',
    },
    {
      icon: FileText,
      label: 'Create Meeting Summary Doc',
      prompt: 'Draft an executive meeting summary document with goals, key decisions, and next steps for our sprint.',
    },
    {
      icon: Table,
      label: 'Log Expense in Spreadsheet',
      prompt: 'Format a row entry for an engineering software subscription expense: $149.00 on today\'s date with category Cloud Tooling.',
    },
    {
      icon: Brain,
      label: 'High Thinking Deep Analysis',
      prompt: 'Deeply reason and compare the tradeoffs between synchronous webhooks and asynchronous event bus architectures for multi-cloud enterprise apps.',
      model: 'gemini-3.1-pro-preview' as GeminiModelTier,
      thinking: true,
    },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-50/50">
      {/* Top Banner / Live Status & Control Bar */}
      <div className="p-4 bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Live Cyber Particle Orb Visualizer in Header */}
          <div className="flex items-center gap-3">
            <button
              id="btn-header-orb-listen"
              type="button"
              onClick={handleOrbClick}
              className="relative flex items-center justify-center w-14 h-14 rounded-2xl bg-slate-950 border border-cyan-500/40 hover:border-cyan-400 shadow-md shadow-cyan-500/20 hover:scale-105 transition-all cursor-pointer group"
              title={
                voiceStatus === 'listening'
                  ? 'Escuchando... Haz clic para detener y procesar'
                  : 'Haz clic en el orbe para activar la escucha por voz de la IA'
              }
            >
              <CyberParticleOrb
                size={52}
                status={voiceStatus}
                audioLevel={liveMicLevel}
                isVoiceDetected={isVoiceDetected}
                showControls={false}
              />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-900">
                  {voiceStatus === 'listening'
                    ? 'Lexi está escuchando tu voz...'
                    : voiceStatus === 'speaking'
                    ? 'Lexi hablando...'
                    : voiceStatus === 'thinking'
                    ? 'Lexi analizando con Gemini...'
                    : isLiveConnected
                    ? 'Lexi Live Voice Conectado'
                    : 'Asistente de Voz Lexi lista'}
                </span>
                <span
                  className={`w-2 h-2 rounded-full ${
                    voiceStatus === 'listening'
                      ? 'bg-cyan-400 animate-ping'
                      : isLiveConnected
                      ? 'bg-emerald-500'
                      : 'bg-slate-300'
                  }`}
                />
              </div>
              <p className="text-xs text-slate-500">
                {isLiveConnected
                  ? 'Audio bidireccional en tiempo real activo. Habla con Lexi para automatizar documentos.'
                  : 'Haz clic en el orbe para hablar o escribe tus instrucciones.'}
              </p>
            </div>
          </div>

          {/* Voice Buttons & Controls */}
          <div className="flex items-center gap-2">
            {/* View Mode Toggle: Orb Dashboard vs Chat Stream */}
            <div className="inline-flex rounded-xl border border-slate-200 bg-slate-100 p-0.5 shadow-2xs">
              <button
                id="btn-view-mode-orb"
                type="button"
                onClick={() => setDashboardViewMode('orb')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  dashboardViewMode === 'orb'
                    ? 'bg-slate-950 text-cyan-300 shadow-sm border border-cyan-500/40'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Ver el Orbe Cuántico y el Dashboard principal"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Orbe Dashboard</span>
              </button>
              <button
                id="btn-view-mode-chat"
                type="button"
                onClick={() => setDashboardViewMode('chat')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  dashboardViewMode === 'chat'
                    ? 'bg-white text-blue-700 shadow-sm font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Ver hilo de mensajes y respuestas detalladas"
              >
                <Bot className="w-3.5 h-3.5" />
                <span>Conversación {messages.length > 0 ? `(${messages.length})` : ''}</span>
              </button>
            </div>

            {/* Command History View Trigger */}
            <button
              id="btn-open-command-history"
              type="button"
              onClick={() => setIsCommandHistoryOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 hover:border-indigo-300 text-indigo-800 transition-all text-xs font-semibold cursor-pointer shadow-2xs group"
              title="Ver, buscar y re-ejecutar comandos de voz anteriores de Lexi en documentos"
            >
              <History className="w-3.5 h-3.5 text-indigo-600 group-hover:rotate-[-20deg] transition-transform" />
              <span>Historial</span>
            </button>

            {/* Active User Profile & Anti-Noise Gate Badge with direct modal trigger */}
            <button
              id="btn-hub-active-profile"
              type="button"
              onClick={() => setIsProfileModalOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 hover:bg-blue-50/70 hover:border-blue-300 transition-all text-xs cursor-pointer shadow-2xs group"
              title="Administrar perfiles de voz y calibración de ruido"
            >
              <div
                className="w-3 h-3 rounded-full shrink-0 ring-1 ring-white"
                style={{ backgroundColor: activeProfile.avatarColor || '#2563eb' }}
              />
              <div className="text-left hidden sm:block">
                <div className="font-bold text-slate-800 flex items-center gap-1 group-hover:text-blue-700">
                  <Users className="w-3 h-3 text-blue-600" />
                  <span>{activeProfile.name}</span>
                </div>
                <div className="text-[10px] text-slate-500 flex items-center gap-1">
                  <ShieldCheck className="w-2.5 h-2.5 text-emerald-600" />
                  <span>Filtro Anti-Ruido: {activeProfile.noiseGateThreshold}%</span>
                </div>
              </div>
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 sm:ml-1" />
            </button>

            {isAiSpeaking && (
              <button
                id="btn-interrupt-speech"
                type="button"
                onClick={interruptSpeaking}
                className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold flex items-center gap-1.5 hover:bg-amber-100 transition-colors cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-amber-800" />
                <span>Interrupt AI</span>
              </button>
            )}

            <button
              id="btn-toggle-live-api"
              type="button"
              onClick={toggleLiveConnection}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-all cursor-pointer ${
                isLiveConnected
                  ? 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                  : 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/20'
              }`}
            >
              {isLiveConnected ? (
                <>
                  <MicOff className="w-3.5 h-3.5" />
                  <span>Disconnect Live Voice</span>
                </>
              ) : (
                <>
                  <Mic className="w-3.5 h-3.5" />
                  <span>Start Live Voice (gemini-3.8-live)</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Real-time Voice Recognition & Anti-Noise HUD */}
        {(isRecording || isContinuousListening) && (
          <div className="max-w-5xl mx-auto mt-3 p-3 rounded-xl bg-slate-900 text-white shadow-lg border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="relative">
                <div
                  className={`w-3.5 h-3.5 rounded-full ${
                    isVoiceDetected
                      ? 'bg-emerald-500 animate-ping'
                      : liveNoiseGated
                      ? 'bg-amber-400'
                      : 'bg-slate-500'
                  }`}
                />
                <div
                  className={`absolute inset-0 w-3.5 h-3.5 rounded-full ${
                    isVoiceDetected
                      ? 'bg-emerald-400'
                      : liveNoiseGated
                      ? 'bg-amber-400'
                      : 'bg-slate-600'
                  }`}
                />
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold tracking-wide uppercase">
                    {isVoiceDetected ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Radio className="w-3 h-3 animate-pulse" /> Voz Detectada ({activeProfile.name})
                      </span>
                    ) : liveNoiseGated ? (
                      <span className="text-amber-300 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Ruido de Fondo Filtrado
                      </span>
                    ) : (
                      <span className="text-slate-400">Silencio / Monitoreando audio...</span>
                    )}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    (Puerta: {activeProfile.noiseGateThreshold}%)
                  </span>
                </div>
                {interimTranscript && (
                  <p className="text-xs text-blue-200 italic font-mono mt-0.5 truncate max-w-md">
                    "{interimTranscript}"
                  </p>
                )}
              </div>
            </div>

            {/* Live Audio Level VU Meter */}
            <div className="w-full sm:w-64 flex flex-col gap-1">
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>Nivel Mic</span>
                <span className={liveMicLevel >= activeProfile.noiseGateThreshold ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                  {Math.round(liveMicLevel)}%
                </span>
              </div>
              <div className="relative h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-75 rounded-full ${
                    liveMicLevel >= activeProfile.noiseGateThreshold
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                      : 'bg-amber-500/70'
                  }`}
                  style={{ width: `${Math.min(100, liveMicLevel)}%` }}
                />
                {/* Threshold Marker Indicator */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-rose-500 shadow-sm"
                  style={{ left: `${activeProfile.noiseGateThreshold}%` }}
                  title={`Umbral anti-ruido: ${activeProfile.noiseGateThreshold}%`}
                />
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsProfileModalOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
              >
                <SlidersHorizontal className="w-3 h-3 text-blue-400" />
                <span>Calibrar</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (isContinuousListening) stopContinuousSpeech();
                  if (isRecording) stopRecording();
                }}
                className="px-2.5 py-1 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-200 text-xs font-semibold transition-colors cursor-pointer"
              >
                Detener
              </button>
            </div>
          </div>
        )}

        {audioError && (
          <div className="max-w-5xl mx-auto mt-2 p-2 px-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center justify-between">
            <span>{audioError}</span>
            <button
              type="button"
              onClick={() => setAudioError(null)}
              className="text-rose-500 hover:text-rose-800 font-bold"
            >
              ✕
            </button>
          </div>
        )}
      </div>

      {/* Model & Role Configuration Toolbar */}
      <div className="bg-slate-100/80 border-b border-slate-200/80 px-4 py-2">
        <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Role selector */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-600 flex items-center gap-1">
              <Bot className="w-3.5 h-3.5 text-blue-600" /> Role:
            </span>
            <select
              id="select-assistant-role"
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value as AssistantRole)}
              className="bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 font-medium shadow-xs focus:ring-1 focus:ring-blue-500 outline-hidden"
            >
              <option value="executive">Executive Workflow Architect</option>
              <option value="docs_specialist">Google Docs Specialist</option>
              <option value="sheets_analyst">Google Sheets Analyst</option>
              <option value="creative_designer">Creative Content Director</option>
            </select>
          </div>

          {/* AI Provider Selector */}
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-600">Motor:</span>
            <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 shadow-xs">
              <button
                type="button"
                onClick={() => setSelectedProvider('gemini')}
                className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                  selectedProvider === 'gemini'
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Google Gemini (Multimodal Pro & Flash)"
              >
                <Sparkles className="w-3 h-3" /> Gemini
              </button>
              <button
                type="button"
                onClick={() => setSelectedProvider('groq')}
                className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                  selectedProvider === 'groq'
                    ? 'bg-amber-600 text-white font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Groq LPU (Ultra Rápido Llama 3.3 70B / 8B / Vision)"
              >
                <Zap className="w-3 h-3" /> Groq (LPU)
              </button>
            </div>
          </div>

          {/* Model Selector based on provider */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-600">Modelo:</span>
            {selectedProvider === 'gemini' ? (
              <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 shadow-xs">
                <button
                  type="button"
                  onClick={() => handleModelChange('gemini-3.1-flash-lite')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedModel === 'gemini-3.1-flash-lite'
                      ? 'bg-amber-100 text-amber-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Baja latencia y respuestas instantáneas"
                >
                  <Zap className="w-3 h-3 text-amber-600" /> Flash Lite
                </button>

                <button
                  type="button"
                  onClick={() => handleModelChange('gemini-3.5-flash')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedModel === 'gemini-3.5-flash'
                      ? 'bg-blue-100 text-blue-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Multimodal y flujos de trabajo inteligentes"
                >
                  <Sparkles className="w-3 h-3 text-blue-600" /> 3.5 Flash
                </button>

                <button
                  type="button"
                  onClick={() => handleModelChange('gemini-3.8-flash')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedModel === 'gemini-3.8-flash'
                      ? 'bg-emerald-100 text-emerald-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Multimodal avanzado y razonamiento rápido"
                >
                  <Sparkles className="w-3 h-3 text-emerald-600" /> 3.8 Flash
                </button>

                <button
                  type="button"
                  onClick={() => handleModelChange('gemini-3.1-pro-preview')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedModel === 'gemini-3.1-pro-preview'
                      ? 'bg-purple-100 text-purple-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Tareas complejas con High Thinking"
                >
                  <Brain className="w-3 h-3 text-purple-600" /> 3.1 Pro
                </button>
              </div>
            ) : (
              <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 shadow-xs">
                <button
                  type="button"
                  onClick={() => setSelectedGroqModel('llama-3.3-70b-versatile')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedGroqModel === 'llama-3.3-70b-versatile'
                      ? 'bg-amber-100 text-amber-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Llama 3.3 70B Versatile"
                >
                  <Zap className="w-3 h-3 text-amber-600" /> Llama 3.3 70B
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedGroqModel('llama-3.1-8b-instant')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedGroqModel === 'llama-3.1-8b-instant'
                      ? 'bg-amber-100 text-amber-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Llama 3.1 8B Instant"
                >
                  <Zap className="w-3 h-3 text-amber-600" /> 8B Instant
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedGroqModel('llama-3.2-11b-vision-preview')}
                  className={`px-2 py-0.5 rounded-md text-[11px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                    selectedGroqModel === 'llama-3.2-11b-vision-preview'
                      ? 'bg-amber-100 text-amber-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Llama 3.2 11B Vision"
                >
                  <ImageIcon className="w-3 h-3 text-amber-600" /> Vision 11B
                </button>
              </div>
            )}

            {/* High Thinking Toggle (for Gemini) */}
            {selectedProvider === 'gemini' && (
              <>
                <label
                  className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
                    enableHighThinking
                      ? 'bg-purple-50 border-purple-300 text-purple-800'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={enableHighThinking}
                    onChange={(e) => {
                      setEnableHighThinking(e.target.checked);
                      if (e.target.checked) setSelectedModel('gemini-3.1-pro-preview');
                    }}
                    className="rounded border-slate-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span>High Thinking</span>
                </label>

                {/* Google Search Grounding with gemini-3.5-flash */}
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !useGoogleSearch;
                    setUseGoogleSearch(nextState);
                    if (nextState) {
                      setSelectedModel('gemini-3.5-flash');
                    }
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1.5 border ${
                    useGoogleSearch
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs ring-2 ring-blue-400/30'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-blue-400 hover:text-blue-700'
                  }`}
                  title="Búsqueda web en vivo con Google Search Grounding (gemini-3.5-flash)"
                >
                  <Globe className={`w-3.5 h-3.5 ${useGoogleSearch ? 'text-white' : 'text-blue-600'}`} />
                  <span>Google Search</span>
                  {useGoogleSearch && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
                  )}
                </button>
              </>
            )}
          </div>

          {/* Workspace Direct Connection & Obsidian Database Toggles */}
          <div className="flex flex-wrap items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={() => {
                const next = !autoSaveObsidian;
                setAutoSaveObsidian(next);
                setAutoSaveObsidianEnabled(next);
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-colors cursor-pointer ${
                autoSaveObsidian
                  ? 'bg-purple-50 border-purple-300 text-purple-800 shadow-xs'
                  : 'bg-white border-slate-200 text-slate-500 hover:text-slate-700'
              }`}
              title="Guarda automáticamente cada conversación e investigación en la base de datos de Obsidian"
            >
              <BookOpen className={`w-3.5 h-3.5 ${autoSaveObsidian ? 'text-purple-600' : 'text-slate-400'}`} />
              <span>Obsidian DB: {autoSaveObsidian ? 'Auto 🟣' : 'Manual'}</span>
            </button>

            <button
              type="button"
              onClick={handleSaveConversationToObsidian}
              disabled={messages.length === 0}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-purple-200 bg-purple-50 hover:bg-purple-100 disabled:opacity-40 disabled:cursor-not-allowed text-purple-900 font-bold text-[11px] transition-colors cursor-pointer"
              title="Guardar sesión y diálogo completo en tu bóveda de Obsidian como base de datos"
            >
              <Database className="w-3.5 h-3.5 text-purple-700" />
              <span>Guardar en Obsidian</span>
            </button>

            <button
              type="button"
              onClick={() => setDirectWorkspaceCreation(!directWorkspaceCreation)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-colors cursor-pointer ${
                directWorkspaceCreation
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800 shadow-xs'
                  : 'bg-white border-slate-200 text-slate-500 hover:text-slate-700'
              }`}
              title="Crea automáticamente el documento en Google Docs o la hoja en Google Sheets cuando se lo indiques"
            >
              <FileSpreadsheet className={`w-3.5 h-3.5 ${directWorkspaceCreation ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>Conexión Directa Docs & Sheets: {directWorkspaceCreation ? 'Activa ⚡' : 'Manual'}</span>
            </button>
            {isExecutingWorkspaceAction && (
              <span className="text-[10px] text-blue-600 font-bold flex items-center gap-1 animate-pulse">
                <RefreshCw className="w-3 h-3 animate-spin" /> Creando en Workspace...
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Conversation Thread */}
      <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
        <div className="max-w-3xl mx-auto space-y-4">
          {/* Main Cyber Particle Orb Dashboard View */}
          {(dashboardViewMode === 'orb' || messages.length === 0) && (
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-b from-slate-950 via-[#060c1c] to-slate-950 border border-cyan-500/30 shadow-2xl p-6 sm:p-8 text-white">
              {/* Futuristic Cyber Grid & Atmospheric Glow */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#0284c70d_1px,transparent_1px),linear-gradient(to_bottom,#0284c70d_1px,transparent_1px)] bg-[size:28px_28px] pointer-events-none" />
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-48 bg-cyan-500/10 blur-3xl pointer-events-none" />

              {/* Dashboard Header Badge */}
              <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  <div className="px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-[11px] font-mono tracking-wider flex items-center gap-2 shadow-sm shadow-cyan-950">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span className="font-bold">DASHBOARD IA • ORBE CUÁNTICO</span>
                  </div>
                  <span className="text-[10px] text-slate-400 hidden sm:inline font-mono">
                    gemini-3.8-flash + groq llama-3.3
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {messages.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setDashboardViewMode('chat')}
                      className="px-3 py-1 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-400 text-xs font-semibold text-cyan-300 transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <Bot className="w-3.5 h-3.5" />
                      <span>Ver Respuestas ({messages.length})</span>
                    </button>
                  )}
                </div>
              </div>

              {/* The Glowing Blue Particle Cyber Orb (Centerpiece) */}
              <div className="relative z-10 flex flex-col items-center justify-center my-3">
                <CyberParticleOrb
                  size={330}
                  status={voiceStatus}
                  audioLevel={liveMicLevel}
                  isVoiceDetected={isVoiceDetected}
                  interimTranscript={interimTranscript}
                  onClick={handleOrbClick}
                  title={
                    voiceStatus === 'listening'
                      ? 'Lexi escuchando tu voz...'
                      : voiceStatus === 'speaking'
                      ? 'Lexi respondiendo...'
                      : voiceStatus === 'thinking'
                      ? 'Analizando con Inteligencia Artificial...'
                      : 'Asistente de Voz Inteligente'
                  }
                  subtitle={
                    voiceStatus === 'listening'
                      ? 'Habla ahora con tu instrucción. Haz clic de nuevo en el orbe para detener y procesar.'
                      : 'Haz clic en el orbe para que el asistente de IA comience a escuchar y ejecutar tus órdenes.'
                  }
                />
              </div>

              {/* Real-time Voice Wave HUD when recording / listening */}
              {(isRecording || isContinuousListening || voiceStatus === 'listening') && (
                <div className="relative z-10 max-w-md mx-auto mt-4 p-3.5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 backdrop-blur-md shadow-lg shadow-cyan-950/60">
                  <div className="flex items-center justify-between text-[11px] font-mono mb-1.5 text-cyan-300">
                    <span className="flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
                      <span>Entrada de Micrófono en Vivo</span>
                    </span>
                    <span className="font-bold text-cyan-200">
                      {Math.round(liveMicLevel)}%
                      {liveMicLevel >= activeProfile.noiseGateThreshold && (
                        <span className="text-emerald-400 ml-1.5">● VOZ DETECTADA</span>
                      )}
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden relative">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-500 rounded-full transition-all duration-75 shadow-sm shadow-cyan-500/50"
                      style={{ width: `${Math.min(100, liveMicLevel)}%` }}
                    />
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-rose-500"
                      style={{ left: `${activeProfile.noiseGateThreshold}%` }}
                      title={`Umbral anti-ruido: ${activeProfile.noiseGateThreshold}%`}
                    />
                  </div>
                </div>
              )}

              {/* Quick Action Commands / Suggested Voice Prompts */}
              <div className="relative z-10 mt-6 pt-5 border-t border-slate-800/80">
                <div className="text-center mb-3">
                  <span className="text-[11px] uppercase tracking-widest text-slate-400 font-semibold font-mono">
                    Comandos de voz rápidos para el Asistente
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
                  {quickActions.slice(0, 4).map((qa, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        if (qa.model) setSelectedModel(qa.model);
                        if (qa.thinking) setEnableHighThinking(true);
                        handleSendMessage(qa.prompt);
                      }}
                      className="p-3 rounded-2xl border border-slate-800 bg-slate-900/60 hover:bg-slate-900 hover:border-cyan-500/50 hover:shadow-md hover:shadow-cyan-500/10 transition-all text-left group cursor-pointer"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <qa.icon className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                          {qa.label}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                        {qa.prompt}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Compact Orb Bar when in Chat mode */}
          {dashboardViewMode === 'chat' && (
            <div className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-slate-950 via-[#070e20] to-slate-950 text-cyan-300 border border-cyan-500/30 shadow-md">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleOrbClick}
                  className="w-11 h-11 rounded-xl bg-slate-950 border border-cyan-500/40 flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
                  title="Haz clic para que Lexi te escuche"
                >
                  <CyberParticleOrb
                    size={40}
                    status={voiceStatus}
                    audioLevel={liveMicLevel}
                    isVoiceDetected={isVoiceDetected}
                    showControls={false}
                  />
                </button>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>Orbe Asistente IA</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  </div>
                  <div className="text-[11px] text-cyan-300/80">
                    {voiceStatus === 'listening'
                      ? 'Escuchando tu voz... Di tu instrucción'
                      : voiceStatus === 'speaking'
                      ? 'Hablando... Clic para interrumpir'
                      : 'Clic en el orbe para hablar'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDashboardViewMode('orb')}
                className="px-3 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 hover:bg-cyan-900 text-xs font-semibold text-cyan-200 transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-3 h-3 text-cyan-400" />
                <span>Dashboard del Orbe</span>
              </button>
            </div>
          )}

          {/* Message List */}
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${
                msg.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.role !== 'user' && (
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : msg.role === 'system'
                    ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                    : 'bg-white text-slate-900 border border-slate-200 shadow-xs'
                }`}
              >
                {/* Meta info tag */}
                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-2 mb-2 pb-1.5 border-b border-slate-100 text-[11px] text-slate-400">
                    <span className="font-semibold text-slate-700">
                      {roleInstructions[selectedRole]?.name || 'Voice Assistant'}
                    </span>
                    {msg.modelUsed && (
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono text-[10px]">
                        {msg.modelUsed}
                      </span>
                    )}
                    {msg.usedThinking && (
                      <span className="px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 font-semibold text-[10px] flex items-center gap-0.5">
                        <Brain className="w-2.5 h-2.5" /> High Thinking
                      </span>
                    )}
                  </div>
                )}

                {/* Attachment Preview in Message Bubble */}
                {msg.attachment && (
                  <div className={`mb-2.5 p-2 rounded-xl flex items-center gap-2.5 ${
                    msg.role === 'user' ? 'bg-blue-700/60 border border-blue-400/30' : 'bg-slate-100 border border-slate-200'
                  }`}>
                    {msg.attachment.previewUrl ? (
                      <img
                        src={msg.attachment.previewUrl}
                        alt="Adjunto"
                        className="w-12 h-12 object-cover rounded-lg border border-white/20 bg-black/10 shrink-0"
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                    )}
                    <div className="overflow-hidden text-xs">
                      <span className="font-semibold block truncate max-w-[200px] sm:max-w-[280px]">
                        {msg.attachment.name}
                      </span>
                      <span className={`text-[10px] ${msg.role === 'user' ? 'text-blue-200' : 'text-slate-500'}`}>
                        {(msg.attachment.size / 1024).toFixed(1)} KB • {msg.attachment.type || 'Archivo'}
                      </span>
                    </div>
                  </div>
                )}

                {/* Body Content */}
                <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm">
                  {msg.content}
                </div>

                {/* Grounding Sources (Google Search) */}
                {msg.groundingSources && msg.groundingSources.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200/90 space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-blue-700">
                      <Globe className="w-3.5 h-3.5 text-blue-600" />
                      <span>Fuentes de Google Search ({msg.groundingSources.length}):</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.groundingSources.map((source, sIdx) => (
                        <a
                          key={sIdx}
                          href={source.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-blue-50 hover:bg-blue-100 text-blue-900 text-[10px] font-medium border border-blue-200 transition-colors shadow-2xs group"
                          title={source.title}
                        >
                          <ExternalLink className="w-2.5 h-2.5 text-blue-500 group-hover:text-blue-700" />
                          <span className="truncate max-w-[220px]">{source.title || source.uri}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Action Proposal Card */}
                {msg.actionProposal && (
                  <div className="mt-3 p-3 rounded-xl bg-blue-50 border border-blue-200 text-slate-800">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                        {msg.actionProposal.type.startsWith('docs') ? (
                          <FileText className="w-4 h-4 text-blue-600" />
                        ) : (
                          <Table className="w-4 h-4 text-emerald-600" />
                        )}
                        {msg.actionProposal.title}
                      </span>
                      <span className="text-[10px] uppercase font-bold text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full">
                        Proposal
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mb-2.5">
                      {msg.actionProposal.description}
                    </p>
                    {msg.actionProposal.status === 'executed' || msg.actionProposal.url ? (
                      <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-100/90 border border-emerald-300 text-emerald-950 text-xs">
                        <div className="flex items-center gap-1.5 font-semibold">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>⚡ Creado automáticamente en Google Workspace</span>
                        </div>
                        {msg.actionProposal.url && (
                          <a
                            href={msg.actionProposal.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] shadow-xs transition-colors shrink-0"
                          >
                            Abrir archivo ↗
                          </a>
                        )}
                      </div>
                    ) : !isAuthenticated ? (
                      <div className="flex items-center justify-between p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-950 text-xs">
                        <div className="flex items-center gap-1.5 font-medium">
                          <Lock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>Requiere autorización de Google Workspace</span>
                        </div>
                        <button
                          type="button"
                          onClick={onPromptLogin}
                          className="px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 text-white font-semibold text-[11px] transition-colors cursor-pointer shrink-0 shadow-xs flex items-center gap-1.5"
                        >
                          <UserIcon className="w-3 h-3" />
                          <span>Conectar Google</span>
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between p-2 rounded-lg bg-blue-100/80 border border-blue-200 text-blue-950 text-xs">
                        <div className="flex items-center gap-1.5 font-medium">
                          <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse shrink-0" />
                          <span>⚡ Guardando automáticamente en Google Drive...</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => executeProposal(msg.actionProposal)}
                          className="px-2.5 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white font-semibold text-[11px] transition-colors cursor-pointer shrink-0"
                        >
                          Crear ahora
                        </button>
                      </div>
                    )}

                    {/* Quick Send Proposal to Obsidian */}
                    {msg.actionProposal.type.startsWith('docs') && (
                      <button
                        type="button"
                        onClick={() => {
                          openInObsidian({
                            vault: getObsidianVaultName(),
                            name: msg.actionProposal.payload.title || 'Propuesta Documento',
                            content: msg.actionProposal.payload.content || msg.actionProposal.description,
                          });
                        }}
                        className="w-full mt-1.5 py-1.5 px-3 rounded-lg bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <BookOpen className="w-3.5 h-3.5 text-purple-700" />
                        Abrir propuesta en Obsidian ({getObsidianVaultName()})
                      </button>
                    )}
                  </div>
                )}

                {/* Assistant Message Obsidian & Markdown Action Bar */}
                {msg.role === 'assistant' && (
                  <div className="mt-3 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          const vault = getObsidianVaultName();
                          const firstLine = msg.content
                            .split('\n')[0]
                            .replace(/^[#*\s-]+/, '')
                            .slice(0, 40)
                            .trim();
                          const title = firstLine || `Nota - ${new Date(msg.timestamp).toLocaleDateString()}`;
                          openInObsidian({
                            vault,
                            name: title,
                            content: msg.content,
                          });
                          setOpenedObsidianMsgId(msg.id);
                          setTimeout(() => setOpenedObsidianMsgId(null), 3000);
                        }}
                        title={`Abrir nota en Obsidian (bóveda: ${getObsidianVaultName()})`}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 font-semibold cursor-pointer transition-colors shadow-2xs"
                      >
                        <BookOpen className="w-3 h-3 text-purple-700" />
                        <span>
                          {openedObsidianMsgId === msg.id
                            ? '¡Abriendo en Obsidian!'
                            : `Abrir en Obsidian (${getObsidianVaultName()})`}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const firstLine = msg.content
                            .split('\n')[0]
                            .replace(/^[#*\s-]+/, '')
                            .slice(0, 40)
                            .trim();
                          const title = firstLine || `nota-${Date.now()}`;
                          downloadMarkdownFile(title, msg.content);
                        }}
                        title="Descargar archivo Markdown (.md)"
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 cursor-pointer transition-colors"
                      >
                        <Download className="w-3 h-3 text-slate-500" />
                        <span>.md</span>
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await navigator.clipboard.writeText(msg.content);
                          setCopiedMsgId(msg.id);
                          setTimeout(() => setCopiedMsgId(null), 2000);
                        } catch {
                          // ignore
                        }
                      }}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer transition-colors"
                    >
                      {copiedMsgId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-700 font-medium">Copiado</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copiar</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                <div
                  className={`text-[10px] mt-1 text-right ${
                    msg.role === 'user' ? 'text-blue-100' : 'text-slate-400'
                  }`}
                >
                  {new Date(msg.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>

              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                  <UserIcon className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {/* Loading indicator */}
          {isLoading && (
            <div className="flex gap-3 items-center">
              <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 text-xs text-slate-500 flex items-center gap-2 shadow-xs">
                <div className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                <span>
                  {enableHighThinking
                    ? 'Reasoning in High Thinking mode (gemini-3.1-pro-preview)...'
                    : selectedModel === 'gemini-3.1-flash-lite'
                    ? 'Executing low-latency command...'
                    : 'Generating response with Gemini 3.5 Flash...'}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Message Input Box */}
      <div className="p-4 bg-white border-t border-slate-200">
        {/* Attachment preview banner above input */}
        {currentAttachment && (
          <div className="max-w-3xl mx-auto mb-2 px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-between gap-2 text-xs text-blue-900 shadow-2xs">
            <div className="flex items-center gap-2 truncate">
              {currentAttachment.previewUrl ? (
                <img
                  src={currentAttachment.previewUrl}
                  alt="Adjunto"
                  className="w-7 h-7 object-cover rounded border border-blue-200 shrink-0"
                />
              ) : (
                <FileText className="w-4 h-4 text-blue-600 shrink-0" />
              )}
              <span className="font-semibold truncate">{currentAttachment.name}</span>
              <span className="text-slate-400 text-[10px]">
                ({(currentAttachment.size / 1024).toFixed(1)} KB)
              </span>
            </div>
            <button
              type="button"
              onClick={() => setCurrentAttachment(null)}
              className="text-blue-700 hover:text-red-600 p-1 rounded-md transition-colors cursor-pointer"
              title="Quitar archivo"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="max-w-3xl mx-auto flex items-center gap-2"
        >
          {/* File attachment hidden input & button */}
          <input
            ref={chatFileInputRef}
            type="file"
            accept="image/*,application/pdf,text/plain,text/csv,text/markdown,application/json"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleChatFileSelect(e.target.files[0]);
              }
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => chatFileInputRef.current?.click()}
            title="Adjuntar imagen o documento complejo (PDF, factura, recibo...)"
            className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-all cursor-pointer"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Voice Dictate & Continuous Recognition Button */}
          <div className="flex items-center gap-1">
            <button
              id="btn-voice-dictate"
              type="button"
              onClick={handleDictatePrompt}
              title={
                isRecording
                  ? 'Detener dictado por voz'
                  : `Dictar por voz (${activeProfile.language}, Anti-ruido: ${activeProfile.noiseGateThreshold}%)`
              }
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                isRecording
                  ? 'bg-red-50 border-red-300 text-red-600 animate-pulse'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Mic className="w-5 h-5" />
            </button>

            <button
              id="btn-continuous-voice"
              type="button"
              onClick={toggleContinuousSpeech}
              title={
                isContinuousListening
                  ? 'Detener escucha continua'
                  : 'Modo Escucha Continua con Filtro Anti-Ruido'
              }
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                isContinuousListening
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-600 animate-pulse'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Radio className="w-5 h-5" />
            </button>

            <button
              id="btn-quick-calibrate-noise"
              type="button"
              onClick={() => setIsProfileModalOpen(true)}
              title="Calibrar Ruido de Fondo y Perfiles de Voz"
              className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 hover:bg-blue-50 hover:text-blue-700 transition-all cursor-pointer"
            >
              <SlidersHorizontal className="w-5 h-5" />
            </button>
          </div>

          {/* Text input */}
          <div className="relative flex-1">
            <input
              id="input-chat-prompt"
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                currentAttachment
                  ? `Instrucciones para ${currentAttachment.name}... (o pulsa Enviar para extraer)`
                  : isContinuousListening
                  ? `Escuchando a ${activeProfile.name}... (filtrando ruido por debajo de ${activeProfile.noiseGateThreshold}%)`
                  : `Pregunta, dicta por voz (${activeProfile.name}), o automatiza Docs y Sheets...`
              }
              disabled={isLoading}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all"
            />
          </div>

          {/* Send button */}
          <button
            id="btn-send-message"
            type="submit"
            disabled={(!inputText.trim() && !currentAttachment) || isLoading}
            className="p-2.5 rounded-xl bg-blue-600 text-white font-medium hover:bg-blue-700 disabled:opacity-40 disabled:hover:bg-blue-600 shadow-xs transition-colors cursor-pointer"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>

      {/* User Profiles & Noise Gate Calibration Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => {
          setIsProfileModalOpen(false);
          const updated = getActiveProfile();
          setActiveProfileState(updated);
        }}
        onProfileSwitched={(p) => {
          setActiveProfileState(p);
          if (noiseFilterRef.current) {
            noiseFilterRef.current.updateThreshold(p.noiseGateThreshold);
          }
        }}
      />

      {/* Voice Command History on Documents Modal - Lexi */}
      <CommandHistoryModal
        isOpen={isCommandHistoryOpen}
        onClose={() => setIsCommandHistoryOpen(false)}
        onReExecute={handleReExecuteCommand}
      />
    </div>
  );
};
