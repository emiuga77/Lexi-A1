import React, { useState, useEffect, useCallback } from 'react';
import { User } from 'firebase/auth';
import { AlertCircle, X } from 'lucide-react';
import { initAuth, googleSignIn, logout as firebaseLogout, isWorkspaceConnected } from './services/firebaseAuth';
import { ChatMessage, PendingActionConfirmation } from './types';
import { OrbCanvasView } from './components/OrbCanvasView';
import { CinematicOverlayDrawer } from './components/CinematicOverlayDrawer';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { VoiceAssistantHub } from './components/VoiceAssistantHub';
import { DocumentExtractorStudio } from './components/DocumentExtractorStudio';
import { GoogleDocsManager } from './components/GoogleDocsManager';
import { GoogleSheetsManager } from './components/GoogleSheetsManager';
import { ImageStudio } from './components/ImageStudio';
import { RealEstateStudio } from './components/RealEstateStudio';
import { CommandHistoryModal } from './components/CommandHistoryModal';
import { DataPermanencyModal } from './components/DataPermanencyModal';
import { ProfileModal } from './components/ProfileModal';
import { ObsidianModal } from './components/ObsidianModal';
import { ConfirmationModal } from './components/ConfirmationModal';
import { ThemeProvider } from './context/ThemeContext';
import { OverlayView } from './utils/commandParser';
import { useVoiceCommander } from './hooks/useVoiceCommander';

function AppContent() {
  // Starts strictly in 'ORB_ONLY' on a pure black background
  const [activeOverlay, setActiveOverlay] = useState<OverlayView>('ORB_ONLY');
  const [user, setUser] = useState<User | null>(null);
  const [hasWorkspaceAuth, setHasWorkspaceAuth] = useState<boolean>(() => isWorkspaceConnected());
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isLiveConnected, setIsLiveConnected] = useState(false);
  const [authNotice, setAuthNotice] = useState<{ message: string; type: 'info' | 'warning' | 'error' } | null>(null);

  // Global Multi-turn Chat messages
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  // Mandatory user confirmation modal for mutating operations
  const [pendingAction, setPendingAction] = useState<PendingActionConfirmation | null>(null);
  const [isExecutingAction, setIsExecutingAction] = useState(false);

  // Initialize Auth state listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, token) => {
        setUser(currentUser);
        setHasWorkspaceAuth(Boolean(token || isWorkspaceConnected()));
      },
      () => {
        setUser(null);
        setHasWorkspaceAuth(false);
      }
    );

    const handleWorkspaceAuthEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ hasToken: boolean; user: User | null }>;
      setHasWorkspaceAuth(Boolean(customEvent.detail?.hasToken));
      if (customEvent.detail?.user !== undefined) {
        setUser(customEvent.detail.user);
      }
    };
    window.addEventListener('workspace:auth_changed', handleWorkspaceAuthEvent);

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      window.removeEventListener('workspace:auth_changed', handleWorkspaceAuthEvent);
    };
  }, []);

  const isWorkspaceAuthenticated = Boolean(user && hasWorkspaceAuth);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setAuthNotice(null);
    try {
      const res = await googleSignIn();
      if (res?.user) {
        setUser(res.user);
        setHasWorkspaceAuth(Boolean(res.accessToken));
        setAuthNotice(null);
      }
    } catch (err: any) {
      const message = err?.message || 'Unable to sign in. Please try again.';
      setAuthNotice({ message, type: 'warning' });
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await firebaseLogout();
      setUser(null);
      setHasWorkspaceAuth(false);
      setAuthNotice(null);
    } catch (err: any) {
      console.warn('Logout issue:', err?.message || err);
    }
  };

  // Trigger explicit user confirmation before any mutating action
  const handleRequestAction = (action: PendingActionConfirmation) => {
    setPendingAction({
      ...action,
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          await action.onConfirm();
          setPendingAction(null);
        } catch (e: any) {
          console.warn('Error executing confirmed action:', e?.message || e);
        } finally {
          setIsExecutingAction(false);
        }
      },
      onCancel: () => {
        action.onCancel();
        setPendingAction(null);
      },
    });
  };

  const handleNavigate = useCallback((view: OverlayView) => {
    setActiveOverlay(view);
  }, []);

  const handlePromptExecution = useCallback((prompt: string) => {
    // When executing a prompt, slide out the Chat Sidebar and dispatch execution
    setActiveOverlay('CHAT_SIDEBAR');
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('voiceflow:execute_prompt', { detail: { prompt } }));
    }, 60);
  }, []);

  // Central Voice Commander Hook
  const {
    voiceStatus,
    liveMicLevel,
    isVoiceDetected,
    interimTranscript,
    feedbackToast,
    toggleListening,
    interruptSpeaking,
  } = useVoiceCommander({
    onNavigate: handleNavigate,
    onExecutePrompt: handlePromptExecution,
  });

  // Global Keyboard Shortcuts: Ctrl+K / Cmd+K and Esc to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setActiveOverlay((prev) => (prev === 'COMMAND_PALETTE' ? 'ORB_ONLY' : 'COMMAND_PALETTE'));
      }
      if (e.key === 'Escape' && activeOverlay !== 'ORB_ONLY') {
        setActiveOverlay('ORB_ONLY');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeOverlay]);

  return (
    <div className="relative w-screen h-screen min-h-screen overflow-hidden bg-black text-white font-sans select-none">
      {/* 1. Cinematic Orb Canvas: Always rendered as pure black full-screen foundation */}
      <OrbCanvasView
        onNavigate={handleNavigate}
        user={user}
        isWorkspaceConnected={isWorkspaceAuthenticated}
        onLogin={handleLogin}
        onLogout={handleLogout}
        onExecutePrompt={handlePromptExecution}
        voiceStatus={voiceStatus}
        liveMicLevel={liveMicLevel}
        isVoiceDetected={isVoiceDetected}
        interimTranscript={interimTranscript}
        onToggleListen={toggleListening}
        onInterruptSpeaking={interruptSpeaking}
        feedbackToast={feedbackToast}
      />

      {/* Dismissible Notice Banner (if any auth notification occurs) */}
      {authNotice && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 text-xs flex items-center gap-2.5 rounded-2xl bg-amber-950/90 border border-amber-500/40 text-amber-200 shadow-xl backdrop-blur-md animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{authNotice.message}</span>
          <button
            type="button"
            onClick={() => setAuthNotice(null)}
            className="p-1 hover:text-white rounded cursor-pointer ml-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 2. Slide-out Chat Sidebar ("Abre sidebar con chat") */}
      <aside
        id="lexi-chat-sidebar"
        className={`fixed top-0 right-0 bottom-0 z-40 w-full sm:w-[460px] md:w-[500px] lg:w-[540px] bg-black/95 border-l border-cyan-500/30 backdrop-blur-2xl shadow-2xl shadow-black flex flex-col transition-transform duration-300 ease-in-out ${
          activeOverlay === 'CHAT_SIDEBAR' || activeOverlay === 'CHAT'
            ? 'translate-x-0 pointer-events-auto'
            : 'translate-x-full pointer-events-none'
        }`}
      >
        {/* Sidebar Header */}
        <div className="px-5 py-4 border-b border-cyan-500/20 bg-black flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] animate-pulse" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-white">Chat con Lexi</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  Sidebar
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">Comando activo • Esc para cerrar</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveOverlay('ORB_ONLY')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 hover:text-white hover:border-cyan-400 transition-colors cursor-pointer flex items-center gap-1.5"
              title="Cerrar sidebar (Esc)"
            >
              <span>Ocultar</span>
              <kbd className="text-[9px] bg-slate-800 px-1 py-0.5 rounded text-slate-400">Esc</kbd>
            </button>
            <button
              type="button"
              onClick={() => setActiveOverlay('ORB_ONLY')}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors cursor-pointer"
              title="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sidebar Content */}
        <div className="flex-1 overflow-hidden flex flex-col">
          <VoiceAssistantHub
            messages={messages}
            setMessages={setMessages}
            onRequestAction={handleRequestAction}
            isAuthenticated={isWorkspaceAuthenticated}
            onPromptLogin={handleLogin}
            isLiveConnected={isLiveConnected}
            setIsLiveConnected={setIsLiveConnected}
            onNavigateOverlay={(view) => handleNavigate(view)}
          />
        </div>
      </aside>

      {/* 3. Secondary Command Palette (Ctrl+K / Cmd+K or 'Comandos' Button) */}
      <CommandPaletteModal
        isOpen={activeOverlay === 'COMMAND_PALETTE'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
        onSelectView={(v) => handleNavigate(v)}
        onVoiceCommandPrompt={toggleListening}
      />

      {/* 4. Cinematic Overlay Drawer for Other Fullscreen Modules */}
      <CinematicOverlayDrawer
        activeView={activeOverlay}
        onClose={() => setActiveOverlay('ORB_ONLY')}
        voiceStatus={voiceStatus}
        liveMicLevel={liveMicLevel}
        isVoiceDetected={isVoiceDetected}
        onToggleListen={toggleListening}
      >
        {activeOverlay === 'SHEETS' && (
          <div className="h-full overflow-y-auto">
            <GoogleSheetsManager
              isAuthenticated={isWorkspaceAuthenticated}
              onPromptLogin={handleLogin}
              onRequestAction={handleRequestAction}
            />
          </div>
        )}

        {activeOverlay === 'DOCS' && (
          <div className="h-full overflow-y-auto">
            <GoogleDocsManager
              isAuthenticated={isWorkspaceAuthenticated}
              onPromptLogin={handleLogin}
              onRequestAction={handleRequestAction}
            />
          </div>
        )}

        {activeOverlay === 'EXTRACTOR' && (
          <div className="h-full overflow-y-auto">
            <DocumentExtractorStudio
              isAuthenticated={isWorkspaceAuthenticated}
              onPromptLogin={handleLogin}
              onRequestAction={handleRequestAction}
            />
          </div>
        )}

        {activeOverlay === 'IMAGES' && (
          <div className="h-full overflow-y-auto">
            <ImageStudio />
          </div>
        )}

        {activeOverlay === 'REAL_ESTATE' && (
          <div className="h-full flex flex-col overflow-hidden">
            <RealEstateStudio />
          </div>
        )}
      </CinematicOverlayDrawer>

      {/* 5. Specialized Modals (History, Database, Profile, Obsidian) */}
      <CommandHistoryModal
        isOpen={activeOverlay === 'HISTORY'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
        onReExecute={(cmd) => handlePromptExecution(cmd)}
      />

      <DataPermanencyModal
        isOpen={activeOverlay === 'DATABASE'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
      />

      <ProfileModal
        isOpen={activeOverlay === 'PROFILE'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
      />

      <ObsidianModal
        isOpen={activeOverlay === 'OBSIDIAN'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
      />

      {/* Mandatory User Confirmation Modal for Destructive/Mutating Workspace API Calls */}
      <ConfirmationModal action={pendingAction} isLoading={isExecutingAction} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
