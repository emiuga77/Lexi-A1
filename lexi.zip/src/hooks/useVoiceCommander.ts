import { useState, useRef, useEffect, useCallback } from 'react';
import { OverlayView, parseVoiceNavigationCommand } from '../utils/commandParser';
import { getActiveProfile } from '../services/profileService';
import { calculateAudioRMS, rmsToNormalizedLevel } from '../utils/audio';
import { UserProfile } from '../types';

interface VoiceCommanderOptions {
  onNavigate: (view: OverlayView, feedback?: string) => void;
  onExecutePrompt: (prompt: string) => void;
}

export function useVoiceCommander({ onNavigate, onExecutePrompt }: VoiceCommanderOptions) {
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [liveMicLevel, setLiveMicLevel] = useState<number>(0);
  const [isVoiceDetected, setIsVoiceDetected] = useState<boolean>(false);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isContinuousRef = useRef<boolean>(false);
  const silenceTimerRef = useRef<any>(null);
  const accumulatedTranscriptRef = useRef<string>('');
  const isSpeakingAssistantRef = useRef<boolean>(false);

  const showFeedback = useCallback((msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => {
      setFeedbackToast((prev) => (prev === msg ? null : prev));
    }, 3500);
  }, []);

  const stopMicMonitoring = useCallback(() => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => track.stop());
      micStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (_) {}
      audioContextRef.current = null;
    }
    analyserRef.current = null;
    setLiveMicLevel(0);
    setIsVoiceDetected(false);
  }, []);

  const startMicMonitoring = useCallback(async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      micStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);
      analyserRef.current = analyser;

      const buffer = new Float32Array(analyser.fftSize);

      const monitorLoop = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getFloatTimeDomainData(buffer);
        const rms = calculateAudioRMS(buffer);
        const level = rmsToNormalizedLevel(rms);
        setLiveMicLevel(level);

        const profile = getActiveProfile();
        const detected = level >= (profile?.noiseGateThreshold ?? 15);
        setIsVoiceDetected(detected);

        animFrameRef.current = requestAnimationFrame(monitorLoop);
      };

      monitorLoop();
    } catch (err) {
      console.warn('Microphone access warning:', err);
    }
  }, []);

  const stopListening = useCallback(() => {
    isContinuousRef.current = false;
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    accumulatedTranscriptRef.current = '';
    if (recognitionRef.current) {
      const rec = recognitionRef.current;
      recognitionRef.current = null;
      try {
        rec.stop();
      } catch (_) {}
    }
    stopMicMonitoring();
    setInterimTranscript('');
    setVoiceStatus('idle');
  }, [stopMicMonitoring]);

  const startListening = useCallback(async () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      showFeedback('Reconocimiento de voz no soportado en este navegador.');
      return;
    }

    // Do not start recording if assistant is actively speaking to prevent audio feedback loop
    if (isSpeakingAssistantRef.current) {
      return;
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (_) {}
        recognitionRef.current = null;
      }

      const profile: UserProfile = getActiveProfile();
      const recognition = new SpeechRecognition();
      recognition.lang = profile.language || 'es-ES';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognitionRef.current = recognition;
      isContinuousRef.current = true;

      recognition.onstart = () => {
        setVoiceStatus('listening');
        startMicMonitoring();
      };

      recognition.onresult = (event: any) => {
        // If assistant started speaking, ignore recognition input
        if (isSpeakingAssistantRef.current) {
          return;
        }

        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const candidate = (final || interim).trim();

        // 1. Check for immediate Voice Navigation (Instant execution with zero lag)
        if (candidate) {
          const navResult = parseVoiceNavigationCommand(candidate);
          if (navResult.isNavCommand) {
            if (silenceTimerRef.current) {
              clearTimeout(silenceTimerRef.current);
              silenceTimerRef.current = null;
            }
            setInterimTranscript('');
            accumulatedTranscriptRef.current = '';

            if (navResult.isCloseCommand || navResult.targetView === 'ORB_ONLY') {
              onNavigate('ORB_ONLY', 'Volviendo al orbe central...');
              showFeedback('Volviendo al orbe central...');
            } else if (navResult.targetView) {
              onNavigate(navResult.targetView, navResult.feedbackMessage);
              showFeedback(navResult.feedbackMessage || 'Desplegando vista...');
            }
            return;
          }
        }

        if (final.trim()) {
          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
            silenceTimerRef.current = null;
          }
          const spoken = final.trim();
          setInterimTranscript('');
          accumulatedTranscriptRef.current = '';

          // Execute prompt with AI assistant
          setVoiceStatus('thinking');
          showFeedback(`Procesando: "${spoken.slice(0, 35)}..."`);
          onExecutePrompt(spoken);
        } else if (interim.trim()) {
          setInterimTranscript(interim);
          accumulatedTranscriptRef.current = interim.trim();

          // Silence debounce: If user paused speaking for 1.6s, execute pending speech automatically
          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
          }
          silenceTimerRef.current = setTimeout(() => {
            const pending = accumulatedTranscriptRef.current;
            if (pending && pending.length > 2) {
              accumulatedTranscriptRef.current = '';
              setInterimTranscript('');

              const navResult = parseVoiceNavigationCommand(pending);
              if (navResult.isNavCommand && navResult.targetView) {
                onNavigate(navResult.targetView, navResult.feedbackMessage);
                showFeedback(navResult.feedbackMessage || 'Desplegando vista...');
              } else {
                setVoiceStatus('thinking');
                showFeedback(`Procesando: "${pending.slice(0, 35)}..."`);
                onExecutePrompt(pending);
              }
            }
          }, 1600);
        }
      };

      recognition.onerror = (event: any) => {
        const error = event.error;
        if (error === 'not-allowed' || error === 'service-not-allowed') {
          isContinuousRef.current = false;
          showFeedback('Permiso de micrófono no concedido. Habilita el acceso en el navegador.');
          stopListening();
          return;
        }
        if (error === 'network') {
          console.warn('Speech recognition network notice:', error);
          return;
        }
        if (error !== 'no-speech' && error !== 'aborted') {
          console.warn('Speech recognition notice:', error);
        }
      };

      recognition.onend = () => {
        if (isContinuousRef.current && !isSpeakingAssistantRef.current) {
          // Restart with a safe debounce to cycle engine cleanly
          setTimeout(() => {
            if (isContinuousRef.current && !isSpeakingAssistantRef.current) {
              try {
                startListening();
              } catch (_) {}
            }
          }, 180);
        } else if (!isContinuousRef.current) {
          stopListening();
        }
      };

      recognition.start();
    } catch (err: any) {
      console.warn('Error starting speech listener:', err);
      stopListening();
    }
  }, [onNavigate, onExecutePrompt, showFeedback, startMicMonitoring, stopListening]);

  const toggleListening = useCallback(() => {
    if (voiceStatus === 'listening') {
      stopListening();
    } else {
      startListening();
    }
  }, [voiceStatus, startListening, stopListening]);

  const interruptSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (_) {}
    }
    isSpeakingAssistantRef.current = false;
    setVoiceStatus('idle');
  }, []);

  // Listen for global assistant state changes ('thinking', 'speaking', 'idle')
  useEffect(() => {
    const handleStatusSync = (e: Event) => {
      const custom = e as CustomEvent<{ status: 'idle' | 'listening' | 'thinking' | 'speaking' }>;
      const newStatus = custom.detail?.status;
      if (newStatus) {
        setVoiceStatus(newStatus);
        if (newStatus === 'speaking') {
          isSpeakingAssistantRef.current = true;
        } else if (newStatus === 'idle') {
          isSpeakingAssistantRef.current = false;
        }
      }
    };
    window.addEventListener('voiceflow:status_changed', handleStatusSync);
    return () => {
      window.removeEventListener('voiceflow:status_changed', handleStatusSync);
    };
  }, []);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopListening();
    };
  }, [stopListening]);

  return {
    voiceStatus,
    setVoiceStatus,
    liveMicLevel,
    isVoiceDetected,
    interimTranscript,
    feedbackToast,
    showFeedback,
    startListening,
    stopListening,
    toggleListening,
    interruptSpeaking,
  };
}
