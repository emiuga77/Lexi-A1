/**
 * Voice-to-Cell Command Parser for Google Sheets Manager
 * Parses spoken voice instructions in Spanish & English to locate cells, rows, and columns
 * and extract the target values.
 */

export interface ParsedVoiceCellCommand {
  type: 'set_cell' | 'set_row' | 'select_cell' | 'clear_cell' | 'navigate';
  cell?: string; // e.g. "B3"
  colLetter?: string; // e.g. "B"
  colIndex?: number; // 0-based index
  rowIndex?: number; // 1-based row (e.g. 1, 2, 3...)
  value?: string | number;
  rowValues?: (string | number)[];
  direction?: 'next' | 'prev' | 'down' | 'up';
  matchedHeader?: string;
  confidence: number;
  rawText: string;
}

// Convert 0-based column index to letter (0 -> A, 1 -> B, 25 -> Z, 26 -> AA)
export function colIndexToLetter(index: number): string {
  let temp = index;
  let letter = '';
  while (temp >= 0) {
    letter = String.fromCharCode((temp % 26) + 65) + letter;
    temp = Math.floor(temp / 26) - 1;
  }
  return letter;
}

// Convert column letter to 0-based index ('A' -> 0, 'B' -> 1, 'Z' -> 25)
export function colLetterToIndex(col: string): number {
  const upper = col.toUpperCase();
  let index = 0;
  for (let i = 0; i < upper.length; i++) {
    index = index * 26 + (upper.charCodeAt(i) - 64);
  }
  return index - 1;
}

// Map phonetic letter spoken in Spanish/English to column letter
const PHONETIC_LETTERS: Record<string, string> = {
  a: 'A',
  be: 'B',
  ve: 'B',
  b: 'B',
  ce: 'C',
  se: 'C',
  c: 'C',
  de: 'D',
  d: 'D',
  e: 'E',
  efe: 'F',
  f: 'F',
  ge: 'G',
  g: 'G',
  hache: 'H',
  h: 'H',
  i: 'I',
  jota: 'J',
  j: 'J',
  ka: 'K',
  k: 'K',
  ele: 'L',
  l: 'L',
  eme: 'M',
  m: 'M',
  ene: 'N',
  n: 'N',
  o: 'O',
  pe: 'P',
  p: 'P',
  cu: 'Q',
  q: 'Q',
  erre: 'R',
  r: 'R',
  ese: 'S',
  s: 'S',
  te: 'T',
  t: 'T',
  u: 'U',
  uve: 'V',
  v: 'V',
  w: 'W',
  equis: 'X',
  x: 'X',
  ye: 'Y',
  y: 'Y',
  zeta: 'Z',
  z: 'Z',
};

// Map number words in Spanish
const NUMBER_WORDS: Record<string, number> = {
  cero: 0,
  un: 1,
  uno: 1,
  una: 1,
  dos: 2,
  tres: 3,
  cuatro: 4,
  cinco: 5,
  seis: 6,
  siete: 7,
  ocho: 8,
  nueve: 9,
  diez: 10,
  once: 11,
  doce: 12,
  trece: 13,
  catorce: 14,
  quince: 15,
  dieciséis: 16,
  diecisiete: 17,
  dieciocho: 18,
  diecinueve: 19,
  veinte: 20,
  treinta: 30,
  cuarenta: 40,
  cincuenta: 50,
  sesenta: 60,
  setenta: 70,
  ochenta: 80,
  noventa: 90,
  cien: 100,
  ciento: 100,
  quinientos: 500,
  mil: 1000,
};

/**
 * Normalizes spoken value: converts numeric strings into numbers when appropriate,
 * preserves currency format or strings.
 */
function cleanValue(raw: string): string | number {
  const trimmed = raw.trim().replace(/^[;:,.\-—\s]+|[;:,.\-—\s]+$/g, '');
  
  // Check if it's pure number with optional decimals
  const numericOnly = trimmed.replace(/\$/g, '').replace(/,/g, '').trim();
  if (/^-?\d+(\.\d+)?$/.test(numericOnly)) {
    const num = parseFloat(numericOnly);
    // If original had dollar sign, keep as formatted string or number
    return trimmed.startsWith('$') ? trimmed : num;
  }

  // Check single number word
  const lower = trimmed.toLowerCase();
  if (NUMBER_WORDS[lower] !== undefined) {
    return NUMBER_WORDS[lower];
  }

  return trimmed;
}

/**
 * Main parser function to interpret a voice phrase into a spreadsheet action.
 *
 * @param transcript Spoken voice text
 * @param headers Existing table headers (e.g. ['Fecha', 'Concepto', 'Monto'])
 * @param activeCell Currently highlighted cell (e.g. "B3")
 */
export function parseVoiceToCell(
  transcript: string,
  headers: string[] = [],
  activeCell: string = 'A1'
): ParsedVoiceCellCommand | null {
  const raw = transcript.trim();
  if (!raw) return null;

  const text = raw.toLowerCase();

  // 1. Navigation / Selection commands
  // "ir a B4", "selecciona C2", "go to A1", "select B3"
  const selectMatch = text.match(
    /(?:ir\s+a(?:l)?|selecciona(?:r)?|salta\s+a(?:l)?|go\s+to|select)\s+(?:la\s+celda\s+)?([a-z]{1,2})\s*[-_\s]?\s*(\d+)/i
  );
  if (selectMatch) {
    const col = selectMatch[1].toUpperCase();
    const row = parseInt(selectMatch[2], 10);
    return {
      type: 'select_cell',
      cell: `${col}${row}`,
      colLetter: col,
      colIndex: colLetterToIndex(col),
      rowIndex: row,
      confidence: 0.95,
      rawText: raw,
    };
  }

  // Relative Navigation: "siguiente celda", "next cell", "siguiente fila", "next row"
  if (/(?:siguiente|next)\s+(?:celda|cell)/i.test(text)) {
    return {
      type: 'navigate',
      direction: 'next',
      confidence: 0.9,
      rawText: raw,
    };
  }
  if (/(?:siguiente|next)\s+(?:fila|row)/i.test(text)) {
    return {
      type: 'navigate',
      direction: 'down',
      confidence: 0.9,
      rawText: raw,
    };
  }

  // 2. Clear / Delete cell value
  // "borra B3", "limpia celda C2", "clear cell A1", "vaciar esta celda"
  const clearCoordMatch = text.match(
    /(?:borra(?:r)?|limpia(?:r)?|elimina(?:r)?|vac[ií]a(?:r)?|clear|empty)\s+(?:la\s+celda\s+)?([a-z]{1,2})\s*[-_\s]?\s*(\d+)/i
  );
  if (clearCoordMatch) {
    const col = clearCoordMatch[1].toUpperCase();
    const row = parseInt(clearCoordMatch[2], 10);
    return {
      type: 'clear_cell',
      cell: `${col}${row}`,
      colLetter: col,
      colIndex: colLetterToIndex(col),
      rowIndex: row,
      value: '',
      confidence: 0.95,
      rawText: raw,
    };
  }

  if (/(?:borra(?:r)?|limpia(?:r)?|elimina(?:r)?|vac[ií]a(?:r)?|clear)\s+(?:esta\s+celda|celda\s+actual|current\s+cell)/i.test(text)) {
    const activeCol = activeCell.replace(/\d+/g, '');
    const activeRow = parseInt(activeCell.replace(/\D+/g, ''), 10) || 1;
    return {
      type: 'clear_cell',
      cell: activeCell,
      colLetter: activeCol,
      colIndex: colLetterToIndex(activeCol),
      rowIndex: activeRow,
      value: '',
      confidence: 0.9,
      rawText: raw,
    };
  }

  // 3. Set entire row values:
  // "en la fila 3 pon: 2026-09-18, Nómina, 4500, Pagado"
  // "fila 4 escribe valor1, valor2, valor3"
  const rowMultiMatch = text.match(
    /(?:en\s+la\s+)?fila\s+(\d+)\s*(?:escribe|pon(?:er)?|inserta(?:r)?|valores|set|write)?\s*[:]\s*(.+)/i
  );
  if (rowMultiMatch) {
    const rowNum = parseInt(rowMultiMatch[1], 10);
    const rawList = rowMultiMatch[2].split(/[,;|\t]+/).map((s) => cleanValue(s));
    return {
      type: 'set_row',
      rowIndex: rowNum,
      rowValues: rawList,
      confidence: 0.9,
      rawText: raw,
    };
  }

  // 4. Direct Coordinate Set:
  // "Escribe 450 en B3"
  // "Pon 1250 en la celda C5"
  // "En B3 escribe 450"
  // "Celda A2: Ingresos Operativos"
  // "Set B3 to 450" / "Put 450 in C2"
  
  // Pattern A: "En [Coord] pon/escribe [Value]" or "[Coord] pon/escribe [Value]" or "[Coord]: [Value]"
  const patternA = raw.match(
    /^(?:en\s+(?:la\s+)?(?:celda\s+)?)?([a-zA-Z]{1,2})\s*[-_\s]?\s*(\d+)\s*(?:(?:,|:)?\s*(?:pon(?:er)?|escribe|escribir|set|put|write|to|=)?\s*[:]?\s*)(.+)$/i
  );
  if (patternA && patternA[1] && patternA[2] && patternA[3]) {
    const col = patternA[1].toUpperCase();
    const row = parseInt(patternA[2], 10);
    const val = cleanValue(patternA[3]);
    if (val !== '') {
      return {
        type: 'set_cell',
        cell: `${col}${row}`,
        colLetter: col,
        colIndex: colLetterToIndex(col),
        rowIndex: row,
        value: val,
        confidence: 0.95,
        rawText: raw,
      };
    }
  }

  // Pattern B: "Pon/Escribe [Value] en [Coord]" or "Set [Value] in [Coord]"
  const patternB = raw.match(
    /^(?:pon(?:er)?|escribe|escribir|inserta(?:r)?|set|write|put)\s+(.+?)\s+(?:en\s+(?:la\s+)?(?:celda\s+)?|in\s+(?:cell\s+)?|at\s+)([a-zA-Z]{1,2})\s*[-_\s]?\s*(\d+)$/i
  );
  if (patternB && patternB[1] && patternB[2] && patternB[3]) {
    const val = cleanValue(patternB[1]);
    const col = patternB[2].toUpperCase();
    const row = parseInt(patternB[3], 10);
    return {
      type: 'set_cell',
      cell: `${col}${row}`,
      colLetter: col,
      colIndex: colLetterToIndex(col),
      rowIndex: row,
      value: val,
      confidence: 0.95,
      rawText: raw,
    };
  }

  // 5. Named Column Header + Row Number
  // Examples:
  // "En la columna Monto, fila 3, pon 1250"
  // "Fila 4, columna Categoría: Software Cloud"
  // "Columna Estado, fila 2, aprobado"
  // "Row 3, column Category, set to Hardware"
  if (headers && headers.length > 0) {
    // Try matching any header in the spoken sentence
    for (let cIdx = 0; cIdx < headers.length; cIdx++) {
      const headerTitle = headers[cIdx];
      if (!headerTitle) continue;
      const normalizedHeader = headerTitle.toLowerCase().trim();
      if (!normalizedHeader) continue;

      // Check if header is mentioned
      if (text.includes(normalizedHeader)) {
        // Look for row number near the sentence: "fila 3" or "row 3" or "en la fila 4"
        const rowMatch = text.match(/(?:fila|row|rengl[oó]n|l[ií]nea)\s*(\d+)/i);
        if (rowMatch) {
          const rowNum = parseInt(rowMatch[1], 10);
          const colLetter = colIndexToLetter(cIdx);

          // Extract value: remove header name, "columna", "fila X", "pon", "escribe"
          let extractedValue = raw
            .replace(new RegExp(headerTitle, 'gi'), '')
            .replace(/(?:en\s+(?:la\s+)?)?columna/gi, '')
            .replace(/(?:en\s+(?:la\s+)?)?fila\s*\d+/gi, '')
            .replace(/(?:row|column)\s*\d*/gi, '')
            .replace(/(?:pon(?:er)?|escribe|escribir|inserta(?:r)?|set|write|put|valor|value|es|is)\s*/gi, '')
            .replace(/^[;:,.\-—\s]+|[;:,.\-—\s]+$/g, '');

          const val = cleanValue(extractedValue);
          if (val !== '') {
            return {
              type: 'set_cell',
              cell: `${colLetter}${rowNum}`,
              colLetter,
              colIndex: cIdx,
              rowIndex: rowNum,
              matchedHeader: headerTitle,
              value: val,
              confidence: 0.92,
              rawText: raw,
            };
          }
        }
      }
    }
  }

  // 6. Generic Column Index + Row Number
  // "Columna 2, fila 4: 900"
  // "Fila 3, columna 1, escribe Juan"
  const colIndexRowMatch = text.match(
    /(?:columna\s*(\d+)\s*[,y]?\s*fila\s*(\d+)|fila\s*(\d+)\s*[,y]?\s*columna\s*(\d+))\s*(?:escribe|pon(?:er)?|set|write|:)?\s*(.+)/i
  );
  if (colIndexRowMatch) {
    let colNum = 1;
    let rowNum = 1;
    if (colIndexRowMatch[1] && colIndexRowMatch[2]) {
      colNum = parseInt(colIndexRowMatch[1], 10);
      rowNum = parseInt(colIndexRowMatch[2], 10);
    } else if (colIndexRowMatch[3] && colIndexRowMatch[4]) {
      rowNum = parseInt(colIndexRowMatch[3], 10);
      colNum = parseInt(colIndexRowMatch[4], 10);
    }
    const val = cleanValue(colIndexRowMatch[5]);
    const colLetter = colIndexToLetter(Math.max(0, colNum - 1));
    return {
      type: 'set_cell',
      cell: `${colLetter}${rowNum}`,
      colLetter,
      colIndex: Math.max(0, colNum - 1),
      rowIndex: rowNum,
      value: val,
      confidence: 0.88,
      rawText: raw,
    };
  }

  // 7. Active Cell Direct Dictation
  // When user has an active cell selected (or defaults to A1), and says:
  // "Escribe 750" or "Pon Aprobado" or "Valor 120.50" or "Texto: En proceso"
  const activeSetMatch = raw.match(
    /^(?:escribe|escribir|pon(?:er)?|inserta(?:r)?|set|write|put|valor|texto)\s*[:]?\s*(.+)$/i
  );
  if (activeSetMatch) {
    const val = cleanValue(activeSetMatch[1]);
    const activeCol = activeCell.replace(/\d+/g, '').toUpperCase() || 'A';
    const activeRow = parseInt(activeCell.replace(/\D+/g, ''), 10) || 1;
    return {
      type: 'set_cell',
      cell: activeCell,
      colLetter: activeCol,
      colIndex: colLetterToIndex(activeCol),
      rowIndex: activeRow,
      value: val,
      confidence: 0.8,
      rawText: raw,
    };
  }

  // 8. Single number / standalone phrase if user says e.g. "450" or "$300.00" directly while focused
  if (/^(\$?\s*-?\d+(\.\d+)?|aprobado|pendiente|completado|cancelado|rechazado|activo|inactivo)$/i.test(raw.trim())) {
    const val = cleanValue(raw);
    const activeCol = activeCell.replace(/\d+/g, '').toUpperCase() || 'A';
    const activeRow = parseInt(activeCell.replace(/\D+/g, ''), 10) || 1;
    return {
      type: 'set_cell',
      cell: activeCell,
      colLetter: activeCol,
      colIndex: colLetterToIndex(activeCol),
      rowIndex: activeRow,
      value: val,
      confidence: 0.75,
      rawText: raw,
    };
  }

  return null;
}
