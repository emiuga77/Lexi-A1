import { ChatMessage, ObsidianConversationRecord } from '../types';

const STORAGE_KEY = 'obsidian_vault_name';
const AUTO_SAVE_STORAGE_KEY = 'obsidian_auto_save_conversations';
const SAVED_RECORDS_KEY = 'obsidian_saved_records_db';
export const DEFAULT_VAULT = 'tron';

export function getObsidianVaultName(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && saved.trim()) {
      return saved.trim();
    }
  } catch {
    // ignore
  }
  return DEFAULT_VAULT;
}

export function setObsidianVaultName(vault: string): void {
  try {
    localStorage.setItem(STORAGE_KEY, vault.trim() || DEFAULT_VAULT);
  } catch {
    // ignore
  }
}

export function isAutoSaveObsidianEnabled(): boolean {
  try {
    const val = localStorage.getItem(AUTO_SAVE_STORAGE_KEY);
    return val === null ? true : val === 'true'; // Default true for user request
  } catch {
    return true;
  }
}

export function setAutoSaveObsidianEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(AUTO_SAVE_STORAGE_KEY, String(enabled));
  } catch {}
}

export interface ObsidianNoteOptions {
  vault?: string;
  name: string;
  content: string;
}

/**
 * Builds the official obsidian://new URI
 */
export function buildObsidianNewUri(options: ObsidianNoteOptions): string {
  const vault = (options.vault || getObsidianVaultName()).trim();
  const name = (options.name || 'Nota sin título').trim();
  const content = options.content || '';

  const params = new URLSearchParams();
  params.set('vault', vault);
  params.set('name', name);
  params.set('content', content);

  return `obsidian://new?${params.toString()}`;
}

/**
 * Opens the note directly in the local Obsidian desktop/mobile app
 */
export function openInObsidian(options: ObsidianNoteOptions): { uri: string } {
  const uri = buildObsidianNewUri(options);
  
  // Create an anchor tag to trigger protocol handler safely
  const link = document.createElement('a');
  link.href = uri;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    document.body.removeChild(link);
  }, 100);

  return { uri };
}

/**
 * Saves a record to the internal Obsidian synced index
 */
function recordSavedNote(record: ObsidianConversationRecord): void {
  try {
    const existing: ObsidianConversationRecord[] = JSON.parse(
      localStorage.getItem(SAVED_RECORDS_KEY) || '[]'
    );
    const updated = [record, ...existing.filter((r) => r.id !== record.id)].slice(0, 100);
    localStorage.setItem(SAVED_RECORDS_KEY, JSON.stringify(updated));
  } catch {}
}

export function getSavedObsidianRecords(): ObsidianConversationRecord[] {
  try {
    return JSON.parse(localStorage.getItem(SAVED_RECORDS_KEY) || '[]');
  } catch {
    return [];
  }
}

/**
 * Formats and saves an entire chat/voice dialogue into Obsidian as a database entry
 */
export function saveConversationToObsidian(
  messages: ChatMessage[],
  topic?: string
): { uri: string; record: ObsidianConversationRecord } | null {
  if (!messages || messages.length === 0) return null;

  const vault = getObsidianVaultName();
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
  
  // Find first user query or provided topic
  const firstUserMsg = messages.find((m) => m.role === 'user');
  const cleanTopic = (topic || firstUserMsg?.content.slice(0, 40) || 'Sesion Asistente')
    .replace(/[/\\?%*:|"<>#]/g, '')
    .trim();
  const noteTitle = `Conversaciones/Conversacion - ${cleanTopic} - ${dateStr} ${timeStr}`;

  // Build Obsidian-specific Markdown note with frontmatter & wikilinks
  let markdown = `---
tipo: conversacion_ia
fecha: ${dateStr}
hora: "${now.toLocaleTimeString()}"
boveda: "${vault}"
mensajes_totales: ${messages.length}
tags:
  - asistente-ia
  - conversacion
  - base-de-datos
  - obsidian
---

# 🎙️ Conversación con Asistente IA

- **Fecha:** ${now.toLocaleString()}
- **Bóveda:** \`${vault}\`
- **Tema Central:** *${cleanTopic}*
- **Total de Mensajes:** ${messages.length}

---

## 💬 Transcripción y Diálogo

`;

  messages.forEach((msg, idx) => {
    const speaker = msg.role === 'user' ? '👤 Usuario' : msg.role === 'assistant' ? '🤖 Asistente' : '⚙️ Sistema';
    const timestamp = new Date(msg.timestamp).toLocaleTimeString();
    
    markdown += `### ${idx + 1}. ${speaker} \`[${timestamp}]\`\n`;
    if (msg.modelUsed) {
      markdown += `> *Modelo:* \`${msg.modelUsed}\`${msg.providerUsed ? ` (${msg.providerUsed})` : ''}\n\n`;
    }
    
    markdown += `${msg.content}\n\n`;

    if (msg.actionProposal) {
      markdown += `> ⚡ **Acción de Workspace Asociada:** ${msg.actionProposal.title}\n`;
      if (msg.actionProposal.url) {
        markdown += `> 🔗 [Ver Archivo en Google Workspace](${msg.actionProposal.url})\n`;
      }
      markdown += `\n`;
    }
    markdown += `---\n\n`;
  });

  markdown += `\n## 🔗 Referencias Cruzadas en Obsidian\n- [[Base de Datos - Investigaciones]]\n- [[Índice General de Asistente IA]]\n`;

  const { uri } = openInObsidian({
    vault,
    name: noteTitle,
    content: markdown,
  });

  const record: ObsidianConversationRecord = {
    id: 'obs_conv_' + Date.now(),
    title: noteTitle,
    topic: cleanTopic,
    timestamp: now.toISOString(),
    messageCount: messages.length,
    uri,
    vault,
  };

  recordSavedNote(record);
  return { uri, record };
}

/**
 * Formats and saves a deep research investigation / document extraction into Obsidian as a database note
 */
export function saveInvestigationToObsidian(params: {
  title: string;
  summary: string;
  documentType?: string;
  keyPoints?: { label: string; value: string }[];
  tables?: { headers: string[]; rows: (string | number)[][] };
  insights?: string[];
  rawMarkdown?: string;
  sourceFiles?: string[];
}): { uri: string; record: ObsidianConversationRecord } {
  const vault = getObsidianVaultName();
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
  
  const cleanTitle = (params.title || 'Investigacion Documental')
    .replace(/[/\\?%*:|"<>#]/g, '')
    .trim();
  const noteTitle = `Investigaciones/Investigacion - ${cleanTitle} - ${dateStr} ${timeStr}`;

  let markdown = `---
tipo: investigacion_documental
fecha: ${dateStr}
hora: "${now.toLocaleTimeString()}"
boveda: "${vault}"
categoria: "${params.documentType || 'Análisis Extensivo'}"
tags:
  - investigacion
  - extraccion-documental
  - base-de-datos
  - obsidian
  - gemini-ia
---

# 📑 Investigación y Extracción: ${params.title}

- **Fecha de Proceso:** ${now.toLocaleString()}
- **Bóveda Obsidian:** \`${vault}\`
- **Categoría:** ${params.documentType || 'Documento Técnico'}
${params.sourceFiles && params.sourceFiles.length > 0 ? `- **Archivos Fuente:** ${params.sourceFiles.join(', ')}\n` : ''}

---

## 🎯 Resumen Ejecutivo de la Investigación
${params.summary}

---

`;

  if (params.keyPoints && params.keyPoints.length > 0) {
    markdown += `## 🔑 Hallazgos Clave & Metadatos Extraídos\n\n`;
    markdown += `| Métrica / Campo | Valor Detectado |\n`;
    markdown += `| :--- | :--- |\n`;
    params.keyPoints.forEach((kp) => {
      markdown += `| **${kp.label.replace(/\|/g, '-')}** | ${String(kp.value).replace(/\|/g, '-')} |\n`;
    });
    markdown += `\n---\n\n`;
  }

  if (params.tables && params.tables.headers.length > 0 && params.tables.rows.length > 0) {
    markdown += `## 📊 Datos Tabulares Estructurados\n\n`;
    markdown += `| ${params.tables.headers.join(' | ')} |\n`;
    markdown += `| ${params.tables.headers.map(() => ':---').join(' | ')} |\n`;
    params.tables.rows.forEach((row) => {
      markdown += `| ${row.map((cell) => String(cell).replace(/\|/g, '-')).join(' | ')} |\n`;
    });
    markdown += `\n---\n\n`;
  }

  if (params.insights && params.insights.length > 0) {
    markdown += `## 💡 Conclusiones Cruzadas & Análisis Estratégico\n\n`;
    params.insights.forEach((insight) => {
      markdown += `- ${insight}\n`;
    });
    markdown += `\n---\n\n`;
  }

  if (params.rawMarkdown) {
    markdown += `## 📝 Documento Completo Formateado\n\n${params.rawMarkdown}\n\n`;
  }

  markdown += `\n## 🔗 Conexiones en Bóveda Obsidian\n- [[Base de Datos - Investigaciones]]\n- [[Directorio de Extracciones IA]]\n`;

  const { uri } = openInObsidian({
    vault,
    name: noteTitle,
    content: markdown,
  });

  const record: ObsidianConversationRecord = {
    id: 'obs_inv_' + Date.now(),
    title: noteTitle,
    topic: cleanTitle,
    timestamp: now.toISOString(),
    messageCount: 1,
    uri,
    vault,
  };

  recordSavedNote(record);
  return { uri, record };
}

/**
 * Downloads a Markdown (.md) file to disk as an alternative or backup
 */
export function downloadMarkdownFile(title: string, content: string): void {
  const safeName = (title || 'nota').replace(/[/\\?%*:|"<>]/g, '-').trim();
  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${safeName}.md`;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    document.body.removeChild(link);
  }, 100);
}
