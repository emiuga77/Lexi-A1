// Convert Float32Array from Web Audio API to 16-bit linear PCM base64 string
export function floatTo16BitPCMBase64(float32Array: Float32Array): string {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  let offset = 0;
  for (let i = 0; i < float32Array.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }

  // Convert binary to base64
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Convert 16-bit linear PCM base64 string to AudioBuffer for playback
export function base64PCMToAudioBuffer(
  base64: string,
  audioCtx: AudioContext,
  sampleRate: number = 24000
): AudioBuffer {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  const int16Array = new Int16Array(bytes.buffer);
  const float32Array = new Float32Array(int16Array.length);

  for (let i = 0; i < int16Array.length; i++) {
    float32Array[i] = int16Array[i] / (int16Array[i] < 0 ? 0x8000 : 0x7fff);
  }

  const audioBuffer = audioCtx.createBuffer(1, float32Array.length, sampleRate);
  audioBuffer.getChannelData(0).set(float32Array);
  return audioBuffer;
}

export class LiveAudioPlayer {
  private audioCtx: AudioContext | null = null;
  private nextPlayTime: number = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private isPlaying: boolean = false;
  private onPlaybackStateChange?: (playing: boolean) => void;

  constructor(onPlaybackStateChange?: (playing: boolean) => void) {
    this.onPlaybackStateChange = onPlaybackStateChange;
  }

  private initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioContextClass({ sampleRate: 24000 });
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public playChunk(base64Audio: string) {
    try {
      this.initContext();
      if (!this.audioCtx) return;

      const audioBuffer = base64PCMToAudioBuffer(base64Audio, this.audioCtx, 24000);
      const source = this.audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.audioCtx.destination);

      const currentTime = this.audioCtx.currentTime;
      // If queue fell behind current time, schedule from current time
      const startTime = Math.max(currentTime, this.nextPlayTime);
      source.start(startTime);
      this.nextPlayTime = startTime + audioBuffer.duration;

      this.activeSources.push(source);
      if (!this.isPlaying) {
        this.isPlaying = true;
        this.onPlaybackStateChange?.(true);
      }

      source.onended = () => {
        const idx = this.activeSources.indexOf(source);
        if (idx !== -1) {
          this.activeSources.splice(idx, 1);
        }
        if (this.activeSources.length === 0) {
          this.isPlaying = false;
          this.onPlaybackStateChange?.(false);
        }
      };
    } catch (err) {
      console.error('Error playing audio chunk:', err);
    }
  }

  public stopAndClear() {
    for (const src of this.activeSources) {
      try {
        src.stop();
      } catch (_) {}
    }
    this.activeSources = [];
    if (this.audioCtx) {
      this.nextPlayTime = this.audioCtx.currentTime;
    }
    this.isPlaying = false;
    this.onPlaybackStateChange?.(false);
  }

  public close() {
    this.stopAndClear();
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close();
    }
    this.audioCtx = null;
  }
}

// Calculate Root Mean Square (RMS) volume of Float32 PCM buffer
export function calculateAudioRMS(buffer: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < buffer.length; i++) {
    sum += buffer[i] * buffer[i];
  }
  return Math.sqrt(sum / buffer.length);
}

// Convert RMS into a 0-100 readable scale for VU meters and noise gates
export function rmsToNormalizedLevel(rms: number): number {
  if (rms <= 0.0001) return 0;
  // Scaled non-linearly to match human hearing perception
  const level = Math.min(100, Math.round(rms * 450));
  return level;
}

// Advanced Ambient Noise Calibrator
// Samples background room noise for durationMs and calculates optimal noise gate threshold
export async function calibrateAmbientNoise(
  stream: MediaStream,
  durationMs: number = 2500
): Promise<{ noiseFloor: number; recommendedThreshold: number }> {
  return new Promise((resolve) => {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    const source = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 512;
    source.connect(analyser);

    const buffer = new Float32Array(analyser.fftSize);
    const samples: number[] = [];
    const intervalTime = 50;
    const totalSamples = Math.floor(durationMs / intervalTime);

    const interval = setInterval(() => {
      analyser.getFloatTimeDomainData(buffer);
      const rms = calculateAudioRMS(buffer);
      const level = rmsToNormalizedLevel(rms);
      samples.push(level);

      if (samples.length >= totalSamples) {
        clearInterval(interval);
        try {
          source.disconnect();
          ctx.close();
        } catch (_) {}

        // Calculate 90th percentile to ignore anomalous single clicks
        samples.sort((a, b) => a - b);
        const p90Index = Math.min(samples.length - 1, Math.floor(samples.length * 0.9));
        const noiseFloor = samples[p90Index] || 5;

        // Recommended threshold: noise floor + safety margin (at least 12, max 75)
        const recommendedThreshold = Math.min(80, Math.max(12, Math.round(noiseFloor + 12)));
        resolve({ noiseFloor, recommendedThreshold });
      }
    }, intervalTime);
  });
}

// Noise Gate & Voice Filter Pipeline
export interface NoiseFilterConfig {
  noiseGateThreshold: number; // 0-100 threshold
  highpassFilterEnabled: boolean;
  onVoiceActivityChange?: (isSpeaking: boolean, currentLevel: number) => void;
}

export class VoiceNoiseFilter {
  private threshold: number;
  private isSpeaking: boolean = false;
  private hangoverCounter: number = 0;
  private readonly hangoverFrames: number = 8; // keeps gate open for ~150ms after speech to avoid clipping word ends
  private onVoiceActivityChange?: (isSpeaking: boolean, currentLevel: number) => void;

  constructor(config: NoiseFilterConfig) {
    this.threshold = config.noiseGateThreshold;
    this.onVoiceActivityChange = config.onVoiceActivityChange;
  }

  public setThreshold(val: number) {
    this.threshold = Math.max(0, Math.min(100, val));
  }

  public updateThreshold(val: number) {
    this.setThreshold(val);
  }

  // Processes an incoming audio buffer:
  // If below noise floor, gates audio (attenuates or silences background)
  // Returns { isVoice: boolean, processedBuffer: Float32Array, currentLevel: number }
  public processBuffer(buffer: Float32Array): {
    isVoice: boolean;
    currentLevel: number;
    processedBuffer: Float32Array;
  } {
    const rms = calculateAudioRMS(buffer);
    const level = rmsToNormalizedLevel(rms);

    const rawIsAboveGate = level >= this.threshold;

    if (rawIsAboveGate) {
      this.isSpeaking = true;
      this.hangoverCounter = this.hangoverFrames;
    } else {
      if (this.hangoverCounter > 0) {
        this.hangoverCounter--;
        this.isSpeaking = true;
      } else {
        this.isSpeaking = false;
      }
    }

    this.onVoiceActivityChange?.(this.isSpeaking, level);

    if (!this.isSpeaking) {
      // Noise Gate attenuation: suppress background hum/typing by zeroing or heavily reducing
      const silencedBuffer = new Float32Array(buffer.length);
      return {
        isVoice: false,
        currentLevel: level,
        processedBuffer: silencedBuffer,
      };
    }

    return {
      isVoice: true,
      currentLevel: level,
      processedBuffer: buffer,
    };
  }
}

