import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { PropertyCRMRecord, TechnicalSheetPdfOptions } from '../types';

export interface GeneratePdfProgress {
  status: 'preparing' | 'rendering' | 'compiling' | 'saving' | 'completed' | 'error';
  percent: number;
  message: string;
}

/**
 * Generates a professional, high-resolution A4 multi-page PDF from a target DOM container.
 * Uses 2x retina canvas scaling for sharp vector-like typography and architectural imagery.
 */
export async function generatePropertyPdf(
  element: HTMLElement,
  property: PropertyCRMRecord,
  _options?: TechnicalSheetPdfOptions,
  onProgress?: (progress: GeneratePdfProgress) => void
): Promise<Blob> {
  onProgress?.({
    status: 'preparing',
    percent: 15,
    message: 'Preparando elementos gráficos y tipografía de alta fidelidad...',
  });

  // Ensure all images within the element are loaded
  const images = Array.from(element.querySelectorAll('img'));
  await Promise.all(
    images.map((img) => {
      if (img.complete) return Promise.resolve();
      return new Promise<void>((resolve) => {
        img.onload = () => resolve();
        img.onerror = () => resolve(); // continue even if one image fails
      });
    })
  );

  onProgress?.({
    status: 'rendering',
    percent: 45,
    message: 'Renderizando lienzo de alta resolución (300 DPI equivalente)...',
  });

  // Render container to high-res canvas (2x scale)
  const canvas = await html2canvas(element, {
    scale: 2, // 2x retina scale for crisp text and photographs
    useCORS: true,
    allowTaint: true,
    logging: false,
    backgroundColor: '#ffffff',
    windowWidth: element.scrollWidth,
    windowHeight: element.scrollHeight,
  });

  onProgress?.({
    status: 'compiling',
    percent: 75,
    message: 'Compilando páginas A4 del dossier y calculando saltos de página...',
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.95);

  // A4 dimensions in mm: 210 x 297
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const pdfPageWidth = 210;
  const pdfPageHeight = 297;

  // Calculate scaled height based on aspect ratio
  const imgWidth = pdfPageWidth;
  const imgHeight = (canvas.height * pdfPageWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 0;

  // First page
  pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
  heightLeft -= pdfPageHeight;

  // Additional pages if dossier exceeds 1 A4 page
  while (heightLeft > 5) { // 5mm tolerance
    position -= pdfPageHeight;
    pdf.addPage();
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pdfPageHeight;
  }

  // Add PDF Document Metadata
  pdf.setProperties({
    title: `Ficha Técnica - ${property.title}`,
    subject: `Dossier Inmobiliario Profesional [Ref: ${property.referenceCode}]`,
    author: property.agentContact.agencyName || 'Lexi Private Real Estate',
    keywords: `inmobiliaria, ficha tecnica, dossier, ${property.location.city}, ${property.referenceCode}`,
    creator: 'Lexi AI Voice & Real Estate CRM Studio',
  });

  onProgress?.({
    status: 'saving',
    percent: 90,
    message: 'Empaquetando archivo PDF listo para compartir...',
  });

  const blob = pdf.output('blob');

  // Trigger download with sanitized clean filename
  const cleanTitle = property.title
    .replace(/[^a-zA-Z0-9\sáéíóúÁÉÍÓÚñÑ_-]/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .slice(0, 30);
  const fileName = `Ficha_Tecnica_${property.referenceCode}_${cleanTitle}.pdf`;

  pdf.save(fileName);

  onProgress?.({
    status: 'completed',
    percent: 100,
    message: 'PDF descargado con éxito.',
  });

  return blob;
}

/**
 * Builds a ready-to-share WhatsApp formatted client proposal message.
 */
export function buildWhatsAppShareText(property: PropertyCRMRecord): string {
  const formattedPrice = new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: property.currency,
    maximumFractionDigits: 0,
  }).format(property.price);

  return encodeURIComponent(
    `*${property.title}*\n` +
      `📍 *Ubicación:* ${property.location.neighborhood}, ${property.location.city}\n` +
      `🏷️ *Referencia:* ${property.referenceCode}\n` +
      `💶 *Precio:* ${formattedPrice}\n\n` +
      `📐 *Superficie:* ${property.specs.builtAreaM2} m² construidos (${property.specs.usableAreaM2} m² útiles)\n` +
      `🛏️ *Habitaciones:* ${property.specs.bedrooms} suites\n` +
      `🛁 *Baños:* ${property.specs.bathrooms}\n` +
      `🚗 *Plazas de Garaje:* ${property.specs.parkingSpots}\n` +
      `⚡ *Certificado Energético:* Clase ${property.specs.energyRating}\n\n` +
      `✨ *Puntos Destacados:*\n` +
      property.highlights.slice(0, 4).map((h) => `• ${h}`).join('\n') +
      `\n\n📄 _Te adjunto la Ficha Técnica oficial con especificaciones completas y galería fotográfica._\n\n` +
      `👤 *Contacto:* ${property.agentContact.name}\n` +
      `📞 *Teléfono:* ${property.agentContact.phone}\n` +
      `🏢 *Agencia:* ${property.agentContact.agencyName}`
  );
}

/**
 * Formats a clean email/clipboard summary ready to send to prospective buyers or investors.
 */
export function buildClipboardSummary(property: PropertyCRMRecord): string {
  const formattedPrice = new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: property.currency,
    maximumFractionDigits: 0,
  }).format(property.price);

  return `========================================
FICHA TÉCNICA INMOBILIARIA PROFESIONAL
Ref: ${property.referenceCode} | Estado: ${property.status.toUpperCase()}
========================================

PROPIEDAD: ${property.title}
SUBTÍTULO: ${property.tagline || 'Exclusiva residencia'}
UBICACIÓN: ${property.location.address}, ${property.location.neighborhood}, ${property.location.city} (${property.location.postalCode})
PRECIO: ${formattedPrice}

CARACTERÍSTICAS PRINCIPALES:
- Superficie Construida: ${property.specs.builtAreaM2} m²
- Superficie Útil: ${property.specs.usableAreaM2} m²
${property.specs.terraceAreaM2 ? `- Terraza / Solárium: ${property.specs.terraceAreaM2} m²\n` : ''}${property.specs.plotAreaM2 ? `- Parcela: ${property.specs.plotAreaM2} m²\n` : ''}- Dormitorios: ${property.specs.bedrooms}
- Baños: ${property.specs.bathrooms} + ${property.specs.halfBaths || 0} aseos
- Garaje: ${property.specs.parkingSpots} plazas
- Año de Construcción: ${property.specs.yearBuilt}
- Orientación: ${property.specs.orientation}
- Calificación Energética: Clase ${property.specs.energyRating} (${property.specs.energyConsumption || 'Eficiencia A'})

PUNTOS DESTACADOS:
${property.highlights.map((h) => `* ${h}`).join('\n')}

DESCRIPCIÓN ARQUITECTÓNICA:
${property.description}

DATOS FINANCIEROS Y FISCALES:
- Gastos de Comunidad: ${property.financials.communityFeesMonthly ? `${property.financials.communityFeesMonthly} €/mes` : 'A consultar'}
- Impuesto sobre Bienes Inmuebles (IBI): ${property.financials.propertyTaxAnnual ? `${property.financials.propertyTaxAnnual} €/año` : 'A consultar'}
${property.financials.estimatedRentalYieldPct ? `- Rentabilidad Estimada: ${property.financials.estimatedRentalYieldPct}% anual\n` : ''}
CONSULTOR INMOBILIARIO ASIGNADO:
${property.agentContact.name} - ${property.agentContact.title}
Colegiado / Licencia: ${property.agentContact.licenseNumber}
Teléfono directo: ${property.agentContact.phone}
WhatsApp: ${property.agentContact.whatsapp}
Email: ${property.agentContact.email}
Agencia: ${property.agentContact.agencyName}
Web: ${property.agentContact.agencyWebsite}

Documento generado profesionalmente vía Lexi AI & Real Estate CRM.`;
}
