import {
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import { db, logAuditEvent } from './firestoreDb';
import { auth } from './firebaseAuth';
import { UserProfile } from '../types';
import { setObsidianVaultName } from '../utils/obsidian';
import { safeLocalStorage } from '../utils/storage';

const PROFILES_STORAGE_KEY = 'voiceflow_user_profiles';
const ACTIVE_PROFILE_KEY = 'voiceflow_active_profile_id';

export const DEFAULT_PROFILES: UserProfile[] = [
  {
    id: 'prof_gabriel',
    name: 'Gabriel (Investigador)',
    role: 'Investigador Principal & IA',
    language: 'es-ES',
    noiseGateThreshold: 24,
    noiseSuppressionEnabled: true,
    highpassFilterEnabled: true,
    preferredModel: 'gemini-2.5-pro',
    obsidianVault: 'tron',
    tone: 'analitico',
    customInstructions:
      'Responde en español de forma analítica, profunda y estructurada. Prioriza tablas comparativas y enlaces a Obsidian.',
    avatarColor: '#2563eb', // Blue
    isDefault: true,
    calibratedNoiseFloor: 12,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prof_elena',
    name: 'Elena (Operaciones)',
    role: 'Gestora Google Workspace',
    language: 'es-ES',
    noiseGateThreshold: 22,
    noiseSuppressionEnabled: true,
    highpassFilterEnabled: true,
    preferredModel: 'gemini-2.5-flash',
    obsidianVault: 'tron',
    tone: 'directo',
    customInstructions:
      'Enfócate en la ejecución rápida y limpia de hojas de Google Sheets y documentos de Google Docs sin rodeos.',
    avatarColor: '#059669', // Emerald
    isDefault: false,
    calibratedNoiseFloor: 10,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prof_antinoise',
    name: 'Entorno Ruidoso (Anti-Ruido)',
    role: 'Cancelación Agresiva de Ruido',
    language: 'es-ES',
    noiseGateThreshold: 45, // High threshold for cafes, typing, background conversations
    noiseSuppressionEnabled: true,
    highpassFilterEnabled: true,
    preferredModel: 'gemini-2.5-flash',
    obsidianVault: 'tron',
    tone: 'directo',
    customInstructions:
      'Modo de alta precisión acústica para entornos ruidosos. Descarta ruido de fondo y responde con máxima concisión.',
    avatarColor: '#9333ea', // Purple
    isDefault: false,
    calibratedNoiseFloor: 32,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Read profiles from local storage or fallback to defaults
export function getLocalProfiles(): UserProfile[] {
  try {
    const raw = safeLocalStorage.getItem(PROFILES_STORAGE_KEY);
    if (!raw) {
      safeLocalStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(DEFAULT_PROFILES));
      return DEFAULT_PROFILES;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      safeLocalStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(DEFAULT_PROFILES));
      return DEFAULT_PROFILES;
    }
    return parsed;
  } catch (e) {
    return DEFAULT_PROFILES;
  }
}

// Save profiles to local storage
export function saveLocalProfiles(profiles: UserProfile[]): void {
  try {
    safeLocalStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
  } catch (e) {
    console.warn('Failed to persist profiles locally:', e);
  }
}

// Fetch all profiles (syncs with Firestore if user is authenticated)
export async function fetchProfiles(): Promise<UserProfile[]> {
  const localList = getLocalProfiles();
  const user = auth.currentUser;

  if (!user) {
    return localList;
  }

  try {
    const profilesCol = collection(db, 'users', user.uid, 'profiles');
    const q = query(profilesCol, orderBy('createdAt', 'asc'));
    const snapshot = await getDocs(q);

    if (snapshot.empty) {
      // Seed default profiles into Firestore for this user
      for (const p of localList) {
        const userProfile = { ...p, userId: user.uid };
        await setDoc(doc(db, 'users', user.uid, 'profiles', p.id), userProfile);
      }
      return localList;
    }

    const remoteProfiles: UserProfile[] = [];
    snapshot.forEach((d) => {
      remoteProfiles.push(d.data() as UserProfile);
    });

    if (remoteProfiles.length > 0) {
      saveLocalProfiles(remoteProfiles);
      return remoteProfiles;
    }
  } catch (err) {
    console.warn('Could not read profiles from Firestore, using local cache:', err);
  }

  return localList;
}

// Get the currently active profile
export function getActiveProfile(): UserProfile {
  try {
    const profiles = getLocalProfiles();
    const activeId = safeLocalStorage.getItem(ACTIVE_PROFILE_KEY);

    const matched = profiles.find((p) => p.id === activeId);
    if (matched) return matched;

    const defaultProfile = profiles.find((p) => p.isDefault) || profiles[0] || DEFAULT_PROFILES[0];
    safeLocalStorage.setItem(ACTIVE_PROFILE_KEY, defaultProfile.id);
    return defaultProfile;
  } catch (_) {
    return DEFAULT_PROFILES[0];
  }
}

// Set active profile and trigger synchronization
export function setActiveProfile(profileId: string): UserProfile {
  try {
    const profiles = getLocalProfiles();
    const target = profiles.find((p) => p.id === profileId) || profiles[0];
    safeLocalStorage.setItem(ACTIVE_PROFILE_KEY, target.id);

    // Sync active profile's Obsidian vault
    if (target.obsidianVault) {
      setObsidianVaultName(target.obsidianVault);
    }

    // Dispatch global event for instant UI reactivity
    window.dispatchEvent(
      new CustomEvent('voiceflow:profile_changed', {
        detail: target,
      })
    );

    logAuditEvent({
      actionType: 'profile_switched',
      entityType: 'profile',
      details: `Perfil activo cambiado a: ${target.name} (${target.role}) [Umbral ruido: ${target.noiseGateThreshold}%]`,
      status: 'success',
    }).catch(() => {});

    return target;
  } catch (_) {
    return DEFAULT_PROFILES[0];
  }
}

// Create a new User Profile
export async function createProfile(
  data: Omit<UserProfile, 'id' | 'createdAt' | 'updatedAt'>
): Promise<UserProfile> {
  const user = auth.currentUser;
  const newId = 'prof_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const now = new Date().toISOString();

  const newProfile: UserProfile = {
    ...data,
    id: newId,
    userId: user ? user.uid : undefined,
    createdAt: now,
    updatedAt: now,
  };

  const currentList = getLocalProfiles();
  const updatedList = [...currentList, newProfile];
  saveLocalProfiles(updatedList);

  if (user) {
    try {
      await setDoc(doc(db, 'users', user.uid, 'profiles', newId), newProfile);
    } catch (err) {
      console.warn('Error saving new profile to Firestore:', err);
    }
  }

  logAuditEvent({
    actionType: 'profile_created',
    entityType: 'profile',
    details: `Nuevo perfil de usuario creado: "${newProfile.name}" (${newProfile.role}) con umbral anti-ruido al ${newProfile.noiseGateThreshold}%`,
    status: 'success',
  }).catch(() => {});

  return newProfile;
}

// Update existing User Profile
export async function updateProfile(
  profileId: string,
  data: Partial<Omit<UserProfile, 'id' | 'createdAt'>>
): Promise<UserProfile> {
  const user = auth.currentUser;
  const currentList = getLocalProfiles();
  const idx = currentList.findIndex((p) => p.id === profileId);

  if (idx === -1) {
    throw new Error('Profile not found');
  }

  const updated: UserProfile = {
    ...currentList[idx],
    ...data,
    updatedAt: new Date().toISOString(),
  };

  currentList[idx] = updated;
  saveLocalProfiles(currentList);

  if (user) {
    try {
      await setDoc(doc(db, 'users', user.uid, 'profiles', profileId), updated, { merge: true });
    } catch (err) {
      console.warn('Error updating profile in Firestore:', err);
    }
  }

  const active = getActiveProfile();
  if (active.id === profileId) {
    setActiveProfile(profileId);
  }

  logAuditEvent({
    actionType: 'profile_updated',
    entityType: 'profile',
    details: `Perfil "${updated.name}" actualizado. Umbral anti-ruido: ${updated.noiseGateThreshold}%, Idioma: ${updated.language}`,
    status: 'success',
  }).catch(() => {});

  return updated;
}

// Delete a User Profile (cannot delete last remaining profile)
export async function deleteProfile(profileId: string): Promise<boolean> {
  const user = auth.currentUser;
  const currentList = getLocalProfiles();

  if (currentList.length <= 1) {
    throw new Error('No puedes eliminar el único perfil existente.');
  }

  const filtered = currentList.filter((p) => p.id !== profileId);
  saveLocalProfiles(filtered);

  if (user) {
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'profiles', profileId));
    } catch (err) {
      console.warn('Error deleting profile from Firestore:', err);
    }
  }

  const activeId = safeLocalStorage.getItem(ACTIVE_PROFILE_KEY);
  if (activeId === profileId) {
    setActiveProfile(filtered[0].id);
  }

  logAuditEvent({
    actionType: 'profile_deleted',
    entityType: 'profile',
    details: `Perfil eliminado: ${profileId}`,
    status: 'success',
  }).catch(() => {});

  return true;
}
