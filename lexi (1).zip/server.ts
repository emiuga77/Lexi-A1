import express from "express";
import http from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, Modality, ThinkingLevel, GenerateVideosOperation } from "@google/genai";
import Groq from "groq-sdk";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;
const app = express();

// CORS and Preflight handling for seamless iframe and multi-origin requests
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization, x-groq-api-key"
  );
  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Lazy GoogleGenAI client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not configured.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Lazy Groq client with dynamic API key support and resilient state
let groqClient: Groq | null = null;
let lastUsedGroqKey: string | null = null;

function getGroq(customKey?: string): Groq {
  const key = customKey?.trim() || process.env.GROQ_API_KEY?.trim();
  if (!key) {
    throw new Error(
      "GROQ_API_KEY no está configurada. Puedes agregar tu clave en los secretos del proyecto para activar Groq LPU."
    );
  }
  if (!groqClient || lastUsedGroqKey !== key) {
    groqClient = new Groq({ apiKey: key });
    lastUsedGroqKey = key;
  }
  return groqClient;
}

function hasGroq(customKey?: string): boolean {
  const key = customKey?.trim() || process.env.GROQ_API_KEY?.trim();
  return Boolean(key && key.length > 0);
}

// 1. Health check & Available Providers
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    hasGroqKey: hasGroq(),
    time: new Date().toISOString(),
  });
});

// Live Groq diagnostic endpoint to verify key and permissions in real time
app.get("/api/groq/status", async (req, res) => {
  const customKey = (req.headers["x-groq-api-key"] as string) || (req.query.key as string);
  const key = customKey?.trim() || process.env.GROQ_API_KEY?.trim();

  if (!key) {
    return res.json({
      connected: false,
      hasKey: false,
      message: "GROQ_API_KEY no está configurada en las variables de entorno ni en la petición.",
      limitsUrl: "https://console.groq.com/settings/limits",
      keysUrl: "https://console.groq.com/keys",
    });
  }

  try {
    const groq = getGroq(key);
    const modelsResponse = await groq.models.list();
    const modelIds = (modelsResponse.data || []).map((m: any) => m.id);
    const maskedKey = key.length > 8 ? `${key.substring(0, 6)}...${key.substring(key.length - 4)}` : "***";

    // Test whether any chat model is unblocked
    let testSuccess = false;
    let workingModel: string | null = null;
    let blockedReason: string | null = null;

    const testCandidates = [
      "llama-3.3-70b-versatile",
      "llama-3.1-8b-instant",
      "groq/compound",
      "groq/compound-mini",
      "openai/gpt-oss-120b",
      "openai/gpt-oss-20b",
      "qwen/qwen3.8-27b",
      ...modelIds,
    ];
    const uniqueCandidates = [...new Set(testCandidates)];

    for (const m of uniqueCandidates.slice(0, 7)) {
      if (m.includes("whisper") || m.includes("guard") || m.includes("orpheus")) continue;
      try {
        await groq.chat.completions.create({
          model: m,
          messages: [{ role: "user", content: "ping" }],
          max_tokens: 3,
        });
        testSuccess = true;
        workingModel = m;
        break;
      } catch (err: any) {
        const msg = String(err?.message || "");
        if (msg.includes("blocked_org") || err?.status === 403) {
          blockedReason = "blocked_org";
        }
      }
    }

    return res.json({
      connected: true,
      hasKey: true,
      maskedKey,
      availableModelsCount: modelIds.length,
      availableModels: modelIds,
      canInfer: testSuccess,
      workingModel,
      blockedReason,
      message: testSuccess
        ? `Conexión con Groq LPU 100% activa. Inferencia verificada con modelo ${workingModel}.`
        : blockedReason === "blocked_org"
        ? "Clave de API de Groq conectada y validada correctamente. Sin embargo, tu organización en Groq tiene los modelos desactivados en los límites. Puedes activarlos en: https://console.groq.com/settings/limits"
        : "Clave de API conectada a Groq. Verifica los modelos habilitados en tu consola de Groq.",
      limitsUrl: "https://console.groq.com/settings/limits",
      keysUrl: "https://console.groq.com/keys",
    });
  } catch (err: any) {
    return res.status(err?.status || 500).json({
      connected: false,
      hasKey: true,
      error: String(err?.message || "Error al conectar con Groq"),
      status: err?.status || 500,
      limitsUrl: "https://console.groq.com/settings/limits",
      keysUrl: "https://console.groq.com/keys",
    });
  }
});

app.post("/api/groq/test", async (req, res) => {
  const customKey = (req.headers["x-groq-api-key"] as string) || (req.body?.apiKey as string);
  const key = customKey?.trim() || process.env.GROQ_API_KEY?.trim();

  if (!key) {
    return res.status(400).json({
      success: false,
      error: "No se proporcionó clave GROQ_API_KEY.",
      limitsUrl: "https://console.groq.com/settings/limits",
    });
  }

  try {
    const groq = getGroq(key);
    const modelsResponse = await groq.models.list();
    const modelIds = (modelsResponse.data || []).map((m: any) => m.id);
    const maskedKey = `${key.substring(0, 6)}...${key.substring(key.length - 4)}`;

    return res.json({
      success: true,
      maskedKey,
      totalModels: modelIds.length,
      models: modelIds,
      limitsUrl: "https://console.groq.com/settings/limits",
      note: "Clave válida y comunicando con los servidores de Groq.",
    });
  } catch (err: any) {
    return res.status(err?.status || 500).json({
      success: false,
      error: String(err?.message || "Error conectando con Groq"),
      limitsUrl: "https://console.groq.com/settings/limits",
    });
  }
});

app.get("/api/providers", (req, res) => {
  const customKey = (req.headers["x-groq-api-key"] as string) || (req.query.key as string);
  res.json({
    gemini: {
      id: "gemini",
      name: "Google Gemini",
      isConfigured: Boolean(process.env.GEMINI_API_KEY),
      models: [
        { id: "gemini-3.8-flash", name: "Gemini 3.8 Flash", desc: "Recomendado, multimodal y alta estabilidad", recommended: true },
        { id: "gemini-3.1-flash-lite", name: "Gemini 3.1 Flash Lite", desc: "Máxima velocidad y mayor cuota" },
        { id: "gemini-flash-latest", name: "Gemini Flash Latest", desc: "Equilibrado y rápido" },
      ],
    },
    groq: {
      id: "groq",
      name: "Groq (LPU Ultra-Rápido)",
      isConfigured: hasGroq(customKey),
      models: [
        { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B", desc: "Razonamiento profundo e inteligencia (128K)", recommended: true },
        { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B Instant", desc: "Velocidad extrema (<400ms)" },
        { id: "llama-3.2-11b-vision-preview", name: "Llama 3.2 11B Vision", desc: "Visión multimodal para documentos e imágenes" },
        { id: "openai/gpt-oss-120b", name: "GPT OSS 120B (Groq)", desc: "Gran capacidad de razonamiento abierto" },
        { id: "groq/compound", name: "Groq Compound", desc: "Enrutamiento inteligente en Groq LPU" },
      ],
      limitsUrl: "https://console.groq.com/settings/limits",
    },
  });
});

// Helper to extract clean error messaging and detect 429 quota exhaustion or 503 high demand
function formatApiError(error: any) {
  let rawMsg = String(error?.message || "");
  let parsedCode = error?.code || error?.status;

  // Try to parse JSON from error.message if Gemini or Groq SDK formatted it as JSON string
  try {
    const parsed = JSON.parse(rawMsg);
    if (parsed?.error) {
      if (parsed.error.message) rawMsg = parsed.error.message;
      if (parsed.error.code) parsedCode = parsed.error.code;
    }
  } catch (_) {
    // Not a JSON string
  }

  const status = parsedCode;
  const is429 =
    status === 429 ||
    status === "RESOURCE_EXHAUSTED" ||
    rawMsg.includes("429") ||
    rawMsg.includes("RESOURCE_EXHAUSTED") ||
    rawMsg.includes("quota") ||
    rawMsg.includes("Quota exceeded");

  const is503 =
    status === 503 ||
    status === "UNAVAILABLE" ||
    rawMsg.includes("503") ||
    rawMsg.includes("UNAVAILABLE") ||
    rawMsg.includes("high demand") ||
    rawMsg.includes("overloaded");

  const isGroqBlocked =
    rawMsg.includes("blocked_org") ||
    rawMsg.includes("model_permission_blocked_org");

  const isGroqTerms =
    rawMsg.includes("model_terms_required");

  const isGroqModelNotFound =
    rawMsg.includes("model_not_found");

  let retrySeconds = 0;
  const retryMatch = rawMsg.match(/retry in ([0-9.]+)s/i);
  if (retryMatch) {
    retrySeconds = Math.ceil(parseFloat(retryMatch[1]));
  }

  let userMessage = rawMsg || "Ocurrió un error al procesar la solicitud.";
  if (isGroqBlocked) {
    userMessage =
      "La clave de Groq está conectada y validada correctamente, pero tu organización tiene los modelos bloqueados en límites de Groq. " +
      "Por favor ingresa a https://console.groq.com/settings/limits y activa los modelos requeridos.";
  } else if (isGroqTerms) {
    userMessage =
      "El modelo de Groq requiere aceptar términos en https://console.groq.com/playground antes de usarse.";
  } else if (isGroqModelNotFound) {
    userMessage =
      "El modelo de Groq solicitado no está disponible para tu cuenta. Actívalo en https://console.groq.com/settings/limits o utiliza otro modelo.";
  } else if (is429) {
    userMessage = `Límite de cuota alcanzado en Gemini (429). ${
      hasGroq()
        ? "Puedes conmutar al proveedor Groq (LPU) o usar Gemini 3.1 Flash Lite para continuar sin esperas."
        : retrySeconds > 0
        ? `Espera ${retrySeconds}s, cambia a Gemini 3.1 Flash Lite, o activa GROQ_API_KEY para redundancia multi-proveedor.`
        : "Cambia al modelo Gemini 3.1 Flash Lite o activa GROQ_API_KEY en ajustes para redundancia multi-proveedor."
    }`;
  } else if (is503) {
    userMessage = `Servicio con alta demanda temporal (503). ${
      hasGroq()
        ? "Puedes utilizar Groq (LPU) o cambiar a Gemini 3.1 Flash Lite."
        : "Cambia a Gemini 3.1 Flash Lite o reintenta en unos instantes."
    }`;
  }

  return {
    error: userMessage,
    isQuotaExceeded: is429,
    isHighDemand: is503,
    isGroqBlocked,
    limitsUrl: "https://console.groq.com/settings/limits",
    retrySeconds,
    hasGroqConfigured: hasGroq(),
    rawDetails: rawMsg,
  };
}

// Helper to normalize file inputs (whether single file, multiple files, plain text, or data URLs)
function normalizeFileInputs(rawBody: any): Array<{
  fileData: string;
  mimeType: string;
  fileName: string;
  isText: boolean;
  textContent?: string;
  cleanBase64: string;
}> {
  const files: Array<{
    fileData: string;
    mimeType: string;
    fileName: string;
    isText: boolean;
    textContent?: string;
    cleanBase64: string;
  }> = [];

  const rawList =
    Array.isArray(rawBody?.files) && rawBody.files.length > 0
      ? rawBody.files
      : rawBody?.fileData || rawBody?.data || rawBody?.base64
      ? [rawBody]
      : [];

  // If text or notes are passed directly without fileData wrapper, treat as text document
  if (rawList.length === 0 && (rawBody?.text || rawBody?.rawText || rawBody?.textContent || rawBody?.content)) {
    const directText = String(rawBody.text || rawBody.rawText || rawBody.textContent || rawBody.content).trim();
    if (directText) {
      const b64 = Buffer.from(directText, "utf-8").toString("base64");
      files.push({
        fileData: directText,
        mimeType: "text/plain",
        fileName: rawBody.fileName || "Nota_Documento.txt",
        isText: true,
        textContent: directText,
        cleanBase64: b64,
      });
      return files;
    }
  }

  for (let i = 0; i < rawList.length; i++) {
    const f = rawList[i];
    let raw = String(f.fileData || f.data || f.base64 || "").trim();
    if (!raw) continue;

    let mime = String(f.mimeType || f.type || "application/octet-stream").trim().toLowerCase();
    const name = f.fileName || f.name || `Documento_${i + 1}`;

    if (raw.startsWith("data:")) {
      const commaIdx = raw.indexOf(",");
      if (commaIdx !== -1) {
        const header = raw.slice(0, commaIdx);
        raw = raw.slice(commaIdx + 1).replace(/\s/g, "");
        const mimeMatch = header.match(/data:([^;]+)/);
        if (mimeMatch) {
          mime = mimeMatch[1].toLowerCase();
        }
      }
    }

    const isTextMime =
      mime.startsWith("text/") ||
      mime === "application/json" ||
      mime === "application/csv" ||
      mime === "application/xml" ||
      mime === "image/svg+xml";

    if (isTextMime) {
      let decodedText = "";
      const cleanNoSpace = raw.replace(/\s/g, "");
      const isBase64Pattern =
        /^[A-Za-z0-9+/=]+$/.test(cleanNoSpace) && cleanNoSpace.length % 4 === 0;
      if (isBase64Pattern) {
        try {
          const buf = Buffer.from(cleanNoSpace, "base64");
          const utf = buf.toString("utf-8");
          if (/^[\x20-\x7E\s\u00A0-\uFFFF]*$/.test(utf)) {
            decodedText = utf;
          } else {
            decodedText = raw;
          }
        } catch {
          decodedText = raw;
        }
      } else {
        decodedText = raw;
      }
      const b64 = Buffer.from(decodedText, "utf-8").toString("base64");
      files.push({
        fileData: raw,
        mimeType: mime,
        fileName: name,
        isText: true,
        textContent: decodedText,
        cleanBase64: b64,
      });
    } else {
      const cleanB64 = raw.replace(/\s/g, "");
      files.push({
        fileData: raw,
        mimeType: mime,
        fileName: name,
        isText: false,
        cleanBase64: cleanB64,
      });
    }
  }

  return files;
}

// Multi-tier Fallback Generator for Gemini API Quota resiliency and high-demand failover
async function generateWithQuotaFallback(
  ai: GoogleGenAI,
  preferredModel: string,
  contents: any,
  config: any
): Promise<{ response: any; modelUsed: string }> {
  // Ordered sequence of fallback models to survive free tier daily quotas (e.g. gemini-3.8-flash has 20 requests/day limit)
  // and temporary high demand spikes (503 UNAVAILABLE)
  const normalizedPreferred = preferredModel === "gemini-3.5-flash" ? "gemini-3.8-flash" : preferredModel;
  const candidateModels = [
    normalizedPreferred,
    "gemini-3.8-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest",
    "gemini-2.5-flash",
  ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      console.log(`[Gemini Request] Invoking model: ${model}`);
      // Remove thinkingConfig if falling back to a model that does not support it
      const reqConfig = { ...config };
      if (model !== preferredModel && reqConfig.thinkingConfig) {
        delete reqConfig.thinkingConfig;
      }

      let response;
      try {
        response = await ai.models.generateContent({
          model,
          contents,
          config: reqConfig,
        });
      } catch (innerErr: any) {
        // If it failed and tools (e.g. Google Search) was attached, retry without tools
        if (reqConfig.tools) {
          console.info(`[Model Retry] Retrying model ${model} without tools...`);
          const configNoTools = { ...reqConfig };
          delete configNoTools.tools;
          response = await ai.models.generateContent({
            model,
            contents,
            config: configNoTools,
          });
        } else {
          throw innerErr;
        }
      }

      return { response, modelUsed: model };
    } catch (err: any) {
      lastError = err;
      let rawMsg = String(err?.message || "");
      let status = err?.status || err?.code;

      try {
        const parsed = JSON.parse(rawMsg);
        if (parsed?.error) {
          if (parsed.error.message) rawMsg = parsed.error.message;
          if (parsed.error.code) status = parsed.error.code;
        }
      } catch (_) {}
      
      const isQuotaOrRateLimit =
        status === 429 ||
        status === "RESOURCE_EXHAUSTED" ||
        rawMsg.includes("429") ||
        rawMsg.includes("RESOURCE_EXHAUSTED") ||
        rawMsg.includes("quota") ||
        rawMsg.includes("Rate limit");

      const isUnavailableOrBusy =
        status === 503 ||
        status === "UNAVAILABLE" ||
        status === 504 ||
        status === "DEADLINE_EXCEEDED" ||
        rawMsg.includes("503") ||
        rawMsg.includes("UNAVAILABLE") ||
        rawMsg.includes("high demand") ||
        rawMsg.includes("overloaded");

      const isNotFoundOrUnsupported =
        status === 404 ||
        status === "NOT_FOUND" ||
        rawMsg.includes("404") ||
        rawMsg.includes("not found") ||
        rawMsg.includes("is not supported") ||
        rawMsg.includes("PERMISSION_DENIED");

      if (isQuotaOrRateLimit || isUnavailableOrBusy || isNotFoundOrUnsupported) {
        console.info(`[Model Retry] Switching candidate: ${model} -> next available...`);
        continue;
      }
      
      // If it's another non-transient error, rethrow immediately
      throw err;
    }
  }

  throw lastError;
}

// Groq chat handler with multi-model fallback and resilient error diagnostics
async function callGroqChat(
  messages: Array<{ role: string; content: string; attachment?: { data: string; type: string; name?: string } }>,
  model: string = "llama-3.3-70b-versatile",
  systemInstruction?: string,
  customKey?: string
): Promise<{ reply: string; modelUsed: string; failoverOccurred?: boolean }> {
  const groq = getGroq(customKey);

  const hasImage = messages.some((m) => m.attachment?.type?.startsWith("image/"));
  const candidateModels = [
    model,
    hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "openai/gpt-oss-120b",
    "openai/gpt-oss-20b",
    "groq/compound",
    "groq/compound-mini",
    "qwen/qwen3.8-27b",
    "allam-2-7b",
  ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

  const groqMessages: any[] = [];
  if (systemInstruction) {
    groqMessages.push({ role: "system", content: systemInstruction });
  }

  for (const m of messages) {
    const role = m.role === "assistant" ? "assistant" : "user";
    if (m.attachment?.data && m.attachment?.type?.startsWith("image/")) {
      const dataUrl = m.attachment.data.startsWith("data:")
        ? m.attachment.data
        : `data:${m.attachment.type};base64,${m.attachment.data}`;

      groqMessages.push({
        role,
        content: [
          { type: "text", text: m.content || "Analiza esta imagen adjunta." },
          { type: "image_url", image_url: { url: dataUrl } },
        ],
      });
    } else if (m.attachment?.data) {
      let textContent = m.attachment.data;
      if (m.attachment.data.includes(",")) {
        try {
          textContent = Buffer.from(m.attachment.data.split(",")[1], "base64").toString("utf-8");
        } catch {
          textContent = m.attachment.data;
        }
      }
      groqMessages.push({
        role,
        content: `${m.content || ""}\n\n[Documento Adjunto: ${m.attachment.name || "archivo"}]\n${textContent}`,
      });
    } else {
      groqMessages.push({
        role,
        content: m.content || "",
      });
    }
  }

  let lastError: any = null;

  for (const targetModel of candidateModels) {
    try {
      console.log(`[Groq Request] Invoking model: ${targetModel}`);
      const completion = await groq.chat.completions.create({
        model: targetModel,
        messages: groqMessages,
        temperature: 0.3,
        max_tokens: 4096,
      });

      const reply = completion.choices[0]?.message?.content || "No se generó respuesta desde Groq.";
      return { reply, modelUsed: targetModel, failoverOccurred: targetModel !== model };
    } catch (err: any) {
      lastError = err;
      const msg = String(err?.message || "");
      const isBlocked = msg.includes("blocked_org") || err?.status === 403;
      const isNotFound = msg.includes("model_not_found") || err?.status === 404;
      const isTerms = msg.includes("model_terms_required") || err?.status === 400;

      if (isBlocked || isNotFound || isTerms) {
        console.log(`[Groq Candidate] Model ${targetModel} unavailable (${isBlocked ? 'Blocked in Org Limits' : isNotFound ? 'Not Found' : 'Terms Required'}). Trying next candidate...`);
        continue;
      }
      throw err;
    }
  }

  const lastMsg = String(lastError?.message || "");
  if (lastMsg.includes("blocked_org") || lastError?.status === 403) {
    throw new Error(
      "La clave de API de Groq está conectada y validada correctamente, pero los modelos están desactivados en los límites de tu organización de Groq. " +
      "Por favor ingresa a https://console.groq.com/settings/limits y activa los modelos deseados."
    );
  }
  if (lastMsg.includes("model_terms_required")) {
    throw new Error("El modelo de Groq requiere aceptar términos en https://console.groq.com/playground.");
  }

  throw lastError;
}

// Groq structured document intelligence extraction with multi-model fallback
async function callGroqDocumentExtraction(
  files: Array<{ fileData: string; mimeType: string; fileName?: string }>,
  extractionMode: string,
  customPrompt?: string,
  preferredModel?: string,
  customKey?: string
): Promise<{ data: any; modelUsed: string }> {
  const groq = getGroq(customKey);

  const hasImage = files.some((f) => f.mimeType.startsWith("image/"));
  const candidateModels = [
    preferredModel,
    hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile",
    "openai/gpt-oss-120b",
    "openai/gpt-oss-20b",
    "groq/compound",
    "groq/compound-mini",
    "qwen/qwen3.8-27b",
    "llama-3.1-8b-instant",
    "allam-2-7b",
  ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

  const isMulti = files.length > 1;
  const fileTitles = files.map((f, i) => `[Archivo ${i + 1}: ${f.fileName || 'Documento'}]`).join(", ");

  const prompt = `
Act as an expert multimodal document intelligence and business analyst.
You are analyzing ${isMulti ? `${files.length} related documents: ${fileTitles}` : `a document titled: "${files[0]?.fileName || 'Documento'}"`}.
${isMulti ? `CRITICAL MULTI-DOCUMENT INSTRUCTION: You MUST cross-reference all ${files.length} documents. Complement information from one document with data from the others (for instance, linking orders to invoices, receipts to statements, comparing terms, aggregating line items, or combining parts into a coherent whole). Highlight connections and cross-document insights.` : ''}

Goal: Read and extract all text, numbers, entities, dates, itemized rows, tables, and narrative summaries, and structure them so they can be seamlessly inserted into Google Docs and Google Sheets.

Extraction Mode: "${extractionMode}".
${customPrompt ? `User Specific Instructions: "${customPrompt}"` : ""}

You MUST return a clean, valid JSON object with EXACTLY this structure:
{
  "documentType": "string (Classification in Spanish, e.g. ${isMulti ? 'Análisis Consolidado Multidocumento: Facturas y Comprobantes' : 'Factura Comercial, Recibo de Gastos, Contrato Legal'})",
  "documentSummary": "string (Detailed executive summary in Spanish explaining purpose, dates, amounts, parties${isMulti ? ', and how the documents complement each other' : ''})",
  "keyDataPoints": [
    { "label": "string", "value": "string" }
  ],
  ${isMulti ? `"crossDocumentInsights": [
    "string (Insight explaining complementary details found by combining documents, e.g. El comprobante #2 confirma el pago pendiente indicado en la factura #1)"
  ],
  "sourceFilesCount": ${files.length},
  "sourceFileNames": ${JSON.stringify(files.map(f => f.fileName || 'Documento'))},` : ''}
  "docsContent": {
    "title": "string (Professional document title for a new Google Doc${isMulti ? ' - Consolidado' : ''})",
    "formattedText": "string (Clear structured plain text with uppercase section headers and bullet points ready to insert into Google Docs)",
    "markdown": "string (Rich Markdown version with headings, bullet points, and tables)"
  },
  "sheetsData": {
    "title": "string (Suggested title for a Google Sheet)",
    "headers": ${isMulti ? '["Documento de Origen", "Fecha", "Concepto / Descripción", "Categoría", "Cantidad", "Precio Unitario", "Total"]' : '["Fecha", "Concepto / Descripción", "Categoría", "Cantidad", "Precio Unitario", "Total"]'},
    "rows": [["val1", "val2", "val3", "val4", "val5", "val6"${isMulti ? ', "val7"' : ''}]],
    "sheetName": "string (e.g. Datos Consolidados)"
  },
  "suggestedActions": ["string"]
}
`;

  const contentParts: any[] = [{ type: "text", text: prompt }];

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const isImg = f.mimeType.startsWith("image/");
    if (isImg) {
      const dataUrl = f.fileData.startsWith("data:") ? f.fileData : `data:${f.mimeType};base64,${f.fileData}`;
      contentParts.push({ type: "image_url", image_url: { url: dataUrl } });
    } else {
      let textContent = f.fileData;
      if (f.fileData.includes(",")) {
        try {
          textContent = Buffer.from(f.fileData.split(",")[1], "base64").toString("utf-8");
        } catch {
          textContent = f.fileData;
        }
      }
      contentParts.push({
        type: "text",
        text: `\n\n[Documento ${i + 1}/${files.length}: ${f.fileName || 'archivo'}]:\n${textContent}`,
      });
    }
  }

  const messages = [{ role: "user", content: contentParts }];

  let lastExtractionError: any = null;
  for (const targetModel of candidateModels) {
    try {
      console.log(`[Groq Extraction] Invoking model: ${targetModel} for ${files.length} document(s)`);
      const completion = await groq.chat.completions.create({
        model: targetModel,
        messages: messages as any,
        response_format: { type: "json_object" },
        temperature: 0.1,
        max_tokens: 4096,
      });

      const rawJson = completion.choices[0]?.message?.content;
      if (!rawJson) {
        throw new Error("Groq no devolvió ningún contenido JSON.");
      }

      let parsed: any;
      try {
        parsed = JSON.parse(rawJson);
      } catch {
        const match = rawJson.match(/\{[\s\S]*\}/);
        if (match) {
          parsed = JSON.parse(match[0]);
        } else {
          throw new Error("No se pudo analizar la respuesta JSON de Groq.");
        }
      }

      return { data: parsed, modelUsed: targetModel };
    } catch (err: any) {
      lastExtractionError = err;
      const msg = String(err?.message || "");
      const isBlocked = msg.includes("blocked_org") || err?.status === 403;
      const isNotFound = msg.includes("model_not_found") || err?.status === 404;
      const isTerms = msg.includes("model_terms_required") || err?.status === 400;

      if (isBlocked || isNotFound || isTerms) {
        console.log(`[Groq Extraction Retry] Model ${targetModel} unavailable. Trying next candidate...`);
        continue;
      }
      throw err;
    }
  }

  const lastMsg = String(lastExtractionError?.message || "");
  if (lastMsg.includes("blocked_org") || lastExtractionError?.status === 403) {
    throw new Error(
      "La clave de API de Groq está conectada y validada correctamente, pero los modelos están desactivados en los límites de tu organización de Groq. " +
      "Por favor ingresa a https://console.groq.com/settings/limits y activa los modelos deseados."
    );
  }

  throw lastExtractionError;
}

// 2. Multi-turn Chat & Automation endpoint (Gemini & Groq Multi-Provider)
app.post("/api/chat", async (req, res) => {
  try {
    const {
      messages,
      systemInstruction,
      model = "gemini-3.8-flash",
      provider = "gemini",
      enableThinking = false,
      useGoogleSearch = false,
      workflowContext,
    } = req.body;

    const isGroq = provider === "groq" || String(model).startsWith("llama-");

    const workspaceActionInstruction =
      "\n\nDIRECTIVA ESTRICTA: PROHIBIDA LA CREACIÓN AUTOMÁTICA DE DOCUMENTOS\n" +
      "1. NUNCA crees documentos automáticamente ni incluyas el bloque '```workspace_action' con la acción 'create_doc' a menos que el usuario use explícitamente el comando: 'crean un documento', 'crea un documento', 'crear un documento' o 'crea documento'.\n" +
      "2. En cualquier otra interacción (preguntas, debates, análisis, resúmenes, lluvia de ideas o charla cotidiana), RESPONDE EXCLUSIVAMENTE CONVERSANDO de forma fluida, natural, concisa y agradable. No crees documentos ni agregues bloques de workspace.\n" +
      "3. ÚNICAMENTE cuando el usuario diga o escriba expresamente 'crean un documento' o 'crea un documento':\n" +
      "   a) Confirma brevemente de forma hablada y cordial (ej. 'He redactado y guardado el documento solicitado.').\n" +
      "   b) Agrega al final el bloque estructurado:\n" +
      "```workspace_action\n" +
      "{\n" +
      "  \"action\": \"create_doc\",\n" +
      "  \"title\": \"Título claro y profesional\",\n" +
      "  \"content\": \"Texto completo formateado en Markdown\",\n" +
      "  \"summary\": \"Breve descripción del documento\"\n" +
      "}\n" +
      "```\n" +
      "4. Para hojas de cálculo, aplica la misma regla: solo crea hojas si el usuario pide explícitamente crear una hoja de cálculo o tabla en Sheets.";

    let sysInstruction = (systemInstruction ? systemInstruction + "\n" : "") +
      "Eres Lexi, una asistente de voz ejecutiva de IA de última generación.\n" +
      "DIRECTRICES PARA UNA CONVERSACIÓN FLUIDA, ÁGIL Y HUMANA:\n" +
      "- Habla en un español impecable, cálido, conversacional y elocuente, como una brillante colega de confianza.\n" +
      "- Respuestas fluidas y directas: ve directo al grano con agilidad, evitando introducciones mecánicas o disclaimers repetitivos.\n" +
      "- Dialoga con naturalidad: si el usuario reflexiona, debate o pregunta, respóndele conversando de tú a tú, manteniendo vivo el hilo de la charla.\n" +
      "- REGLA ESTRICTA ANTI-BUCLE Y CERO REPETICIÓN: NUNCA repitas la misma idea, frase, resumen ni saludo que ya hayas expresado en los turnos anteriores de esta conversación. Si el usuario continúa la charla o hace una repregunta breve, avanza el diálogo con nuevos datos, perspectivas o preguntas concretas; jamás reiteres lo ya dicho.\n" +
      "- ESCUCHA ATENTA: Concéntrate exactamente en lo que el usuario acaba de decir y responde a su necesidad inmediata sin entrar en monólogos circulares.\n" +
      "- Para respuestas habladas, prioriza oraciones claras, fluidas y con cadencia humana que suenen cálidas al ser pronunciadas." +
      workspaceActionInstruction;
    
    if (workflowContext) {
      sysInstruction += `\nCurrent Workspace Status: ${JSON.stringify(workflowContext)}`;
    }

    const customGroqKey = (req.headers["x-groq-api-key"] as string) || (req.body?.groqApiKey as string);

    if (isGroq) {
      try {
        const groqResult = await callGroqChat(messages, model || "llama-3.3-70b-versatile", sysInstruction, customGroqKey);
        return res.json({
          reply: groqResult.reply,
          model: groqResult.modelUsed,
          provider: "groq",
          usedThinking: false,
          failoverOccurred: groqResult.failoverOccurred,
        });
      } catch (directGroqErr: any) {
        console.warn("[Groq Direct Call Notice] Groq unavailable, seamlessly falling back to Gemini:", directGroqErr?.message || directGroqErr);
        // Fall back to Gemini flow below
      }
    }

    // Default: Gemini with automatic failover to Groq if Gemini hits quota/availability errors
    let ai: GoogleGenAI;
    try {
      ai = getAI();
    } catch (keyErr: any) {
      if (hasGroq(customGroqKey)) {
        console.log("[Failover] Gemini key not configured, falling back to Groq LPU...");
        const groqResult = await callGroqChat(messages, "llama-3.3-70b-versatile", sysInstruction, customGroqKey);
        return res.json({
          reply: groqResult.reply,
          model: groqResult.modelUsed,
          provider: "groq",
          failoverOccurred: true,
          failoverNotice: "Gemini no está configurado. La respuesta se generó a través de Groq LPU.",
          usedThinking: false,
        });
      }
      throw keyErr;
    }

    // Detect Real Estate Research intent from prompt or messages
    const lastUserMsg = (messages || []).slice().reverse().find((m: any) => m.role === 'user')?.content || "";
    const isRealEstateResearchQuery = 
      /(mercado inmobiliario|bienes ra[ií]ces|real estate|precio por metro|precio m2|precio por m2|costo por m2|plusval[ií]a|rentabilidad|alquiler|propiedades en|departamentos en|casas en|terrenos en|inversi[oó]n inmobiliaria|comps inmobiliarios|comparables de venta|zonas de inversi[oó]n|investiga el mercado|investigaci[oó]n inmobiliaria)/i.test(lastUserMsg);

    const isSearchActive = Boolean(useGoogleSearch || isRealEstateResearchQuery || model?.includes("search"));

    // Map model based on requested or specific tier
    let chosenModel = "gemini-3.8-flash";
    if (isSearchActive) {
      chosenModel = "gemini-3.8-flash";
    } else if (model === "gemini-3.1-pro-preview" || enableThinking) {
      chosenModel = "gemini-3.1-pro-preview";
    } else if (model === "gemini-3.1-flash-lite") {
      chosenModel = "gemini-3.1-flash-lite";
    } else if (model === "gemini-3.8-flash" || model === "gemini-flash-latest" || model === "gemini-2.5-flash") {
      chosenModel = model;
    } else if (model === "gemini-3.5-flash") {
      chosenModel = "gemini-3.8-flash";
    }

    if (isSearchActive) {
      sysInstruction += "\n\nINSTRUCCIÓN DE INVESTIGACIÓN INMOBILIARIA Y BÚSQUEDA EN VIVO (GOOGLE SEARCH GROUNDING):\n" +
        "Tienes activada la herramienta Google Search para obtener datos en tiempo real.\n" +
        "Cuando el usuario consulte o pida investigar sobre bienes raíces, mercado inmobiliario, precios por m², o propiedades:\n" +
        "1. Busca activamente datos actuales en vivo sobre la ubicación consultada.\n" +
        "2. Sintetiza los datos clave de forma conversacional y estructurada en el chat: precio promedio/m², rangos de precios de venta/renta, cap rate estimado y demanda.\n" +
        "3. Recuerda: NO crees documentos ni agregues workspace_action a menos que el usuario diga explícitamente el comando 'crean un documento' o 'crea un documento'.";
    }

    const config: any = {};
    config.systemInstruction = sysInstruction;

    // Enable Google Search Grounding with gemini-3.5-flash
    if (isSearchActive) {
      config.tools = [{ googleSearch: {} }];
    }

    if (enableThinking || chosenModel === "gemini-3.1-pro-preview") {
      config.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH,
      };
    }

    const contents = (messages || []).map((m: { role: string; content: string; attachment?: { data: string; type: string; name?: string } }) => {
      const parts: any[] = [];
      if (m.attachment?.data && m.attachment?.type) {
        const cleanData = m.attachment.data.includes(",") ? m.attachment.data.split(",")[1] : m.attachment.data;
        parts.push({
          inlineData: {
            mimeType: m.attachment.type,
            data: cleanData,
          },
        });
      }
      parts.push({ text: m.content || "Analyze the attached file." });
      return {
        role: m.role === "assistant" ? "model" : m.role,
        parts,
      };
    });

    if (contents.length === 0) {
      return res.status(400).json({ error: "No messages provided." });
    }

    try {
      const { response, modelUsed } = await generateWithQuotaFallback(
        ai,
        chosenModel,
        contents,
        config
      );

      const replyText = response.text || "No response generated.";

      // Extract Google Search grounding sources if present
      const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      let groundingSources: { title: string; uri: string }[] = [];
      if (Array.isArray(rawChunks)) {
        groundingSources = rawChunks
          .map((c: any) => ({
            title: c.web?.title || "Fuente Web",
            uri: c.web?.uri || "",
          }))
          .filter((s) => Boolean(s.uri));
      }

      return res.json({
        reply: replyText,
        model: modelUsed,
        provider: "gemini",
        usedThinking: Boolean(enableThinking || modelUsed === "gemini-3.1-pro-preview"),
        groundingSources,
      });
    } catch (geminiError: any) {
      // If Gemini quota/demand is exhausted and Groq is configured, seamlessly failover!
      if (hasGroq(customGroqKey)) {
        try {
          console.log("[Multi-Provider Failover] Gemini failed, seamlessly routing request to Groq LPU...");
          const groqResult = await callGroqChat(messages, "llama-3.3-70b-versatile", sysInstruction, customGroqKey);
          return res.json({
            reply: groqResult.reply,
            model: groqResult.modelUsed,
            provider: "groq",
            failoverOccurred: true,
            failoverNotice: "Gemini experimentó límites de disponibilidad o cuota. La respuesta se generó a través de Groq LPU.",
            usedThinking: false,
          });
        } catch (groqErr) {
          console.log("[Multi-Provider Failover] Groq failover also failed:", groqErr);
        }
      }
      throw geminiError;
    }
  } catch (error: any) {
    console.error("Chat API Error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 2b. Multimodal Document & Image Extraction Endpoint (Gemini & Groq Multi-Provider with Multi-Document Support)
app.post("/api/analyze-document", async (req, res) => {
  try {
    const {
      extractionMode = "hybrid",
      customPrompt,
      enableThinking = false,
      model = "gemini-3.8-flash",
      provider = "gemini",
    } = req.body;

    // Normalize input into an array of files with robust encoding support
    const files = normalizeFileInputs(req.body);

    if (files.length === 0) {
      return res.status(400).json({ error: "At least one document or image file is required." });
    }

    const isGroq = provider === "groq" || String(model).startsWith("llama-");
    const isMulti = files.length > 1;

    const customGroqKey = (req.headers["x-groq-api-key"] as string) || (req.body?.groqApiKey as string);

    if (isGroq) {
      try {
        const groqResult = await callGroqDocumentExtraction(
          files,
          extractionMode,
          customPrompt,
          model,
          customGroqKey
        );
        return res.json({
          success: true,
          data: groqResult.data,
          model: groqResult.modelUsed,
          provider: "groq",
        });
      } catch (directGroqErr: any) {
        console.warn("[Groq Direct Extraction Notice] Groq unavailable, falling back to Gemini:", directGroqErr?.message || directGroqErr);
        // Fall back to Gemini flow below
      }
    }

    // Default: Gemini extraction with automatic Groq failover
    let ai: GoogleGenAI;
    try {
      ai = getAI();
    } catch (keyErr: any) {
      if (hasGroq(customGroqKey)) {
        try {
          console.log("[Failover] Gemini key not configured, routing document extraction to Groq LPU...");
          const groqResult = await callGroqDocumentExtraction(
            files,
            extractionMode,
            customPrompt,
            undefined,
            customGroqKey
          );
          return res.json({
            success: true,
            data: groqResult.data,
            model: groqResult.modelUsed,
            provider: "groq",
            failoverOccurred: true,
            failoverNotice: "Gemini no configurado. Extracción completada a través de Groq LPU.",
          });
        } catch (groqErr) {
          console.log("[Failover] Groq failover failed:", groqErr);
        }
      }
      throw keyErr;
    }
    
    let chosenModel = "gemini-3.8-flash";
    if (enableThinking) {
      chosenModel = "gemini-3.1-pro-preview";
    } else if (model === "gemini-3.1-flash-lite" || model === "gemini-3.8-flash" || model === "gemini-flash-latest" || model === "gemini-2.5-flash") {
      chosenModel = model;
    }

    const fileTitles = files.map((f, i) => `[Archivo ${i + 1}: ${f.fileName || 'Documento'}]`).join(", ");

    const prompt = `
Act as an expert multimodal document intelligence and business analyst.
You are analyzing ${isMulti ? `${files.length} related documents: ${fileTitles}` : `an image or complex document (invoice, receipt, contract, legal agreement, financial statement, spreadsheet screenshot, chart, handwritten memo, technical report, or data table) titled: "${files[0]?.fileName || 'Documento'}"`}.

${isMulti ? `CRITICAL MULTI-DOCUMENT INSTRUCTION: You MUST cross-reference all ${files.length} documents. Complement information from one document with data from the others (for instance, linking orders to invoices, receipts to statements, comparing terms, aggregating line items, or combining parts into a coherent whole). Highlight connections and cross-document insights.` : ''}

Goal: Read and extract all text, numbers, entities, dates, itemized rows, tables, and narrative summaries, and structure them so they can be seamlessly inserted into Google Docs and Google Sheets.

Extraction Mode: "${extractionMode}".
${customPrompt ? `User Specific Instructions: "${customPrompt}"` : ""}

Generate a clean JSON object with this exact schema:
{
  "documentType": string, // Specific document classification in Spanish, e.g. "${isMulti ? 'Análisis Consolidado Multidocumento: Facturas y Comprobantes' : 'Factura Comercial, Recibo de Gastos, Contrato Legal'}"
  "documentSummary": string, // Detailed executive summary in Spanish explaining the purpose, key entities, totals, dates, and conclusions${isMulti ? ', and how the documents complement each other' : ''}.
  "keyDataPoints": [ // 4 to 10 critical key-value facts extracted across the document(s)
    { "label": string, "value": string }
  ],
  ${isMulti ? `"crossDocumentInsights": [
    string // 2 to 4 insights explaining how the documents complement each other, e.g. "El documento B detalla los impuestos que no estaban desglosados en el documento A."
  ],
  "sourceFilesCount": ${files.length},
  "sourceFileNames": ${JSON.stringify(files.map(f => f.fileName || 'Documento'))},` : ''}
  "docsContent": {
    "title": string, // Professional document title for a new Google Doc${isMulti ? ' - Consolidado' : ''}
    "formattedText": string, // Clear structured plain text with uppercase section headers and bullet points ready to insert into Google Docs
    "markdown": string // Rich Markdown version with # Headings, bullet points, and tables
  },
  "sheetsData": {
    "title": string, // Suggested title for a Google Sheet
    "headers": string[], // Column names for tabular data (e.g. ${isMulti ? '["Documento de Origen", "Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]' : '["Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]'})
    "rows": (string | number)[][], // 2D array of rows. For each line item or data row, provide a complete row matching the headers. Keep numbers clean.
    "sheetName": string // Clean name for the sheet tab, e.g. "${isMulti ? 'Datos Consolidados' : 'Datos Extraídos'}"
  },
  "suggestedActions": string[] // 3-4 recommended action steps
}

Ensure the extracted table in "sheetsData" is as thorough as possible, capturing every single itemized line or row visible across all documents.
Return ONLY valid JSON.
`;

    const config: any = {
      responseMimeType: "application/json",
      systemInstruction: "You are an elite multimodal document intelligence system with vision capabilities. You extract data with 100% precision from images, PDFs, charts, receipts, and complex documents, synthesizing and cross-referencing multiple files seamlessly.",
    };

    if (enableThinking) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    }

    const parts: any[] = [];

    // Add each file as text or inlineData part with description
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.isText && f.textContent) {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]\n--- CONTENIDO DEL DOCUMENTO ---\n${f.textContent}\n--- FIN DEL DOCUMENTO ---`,
        });
      } else {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]`,
        });
        parts.push({
          inlineData: {
            mimeType: f.mimeType,
            data: f.cleanBase64,
          },
        });
      }
    }

    parts.push({ text: prompt });

    const contents = [
      {
        role: "user",
        parts,
      },
    ];

    try {
      const { response, modelUsed } = await generateWithQuotaFallback(
        ai,
        chosenModel,
        contents,
        config
      );

      const text = response.text || "{}";
      let parsedData: any;
      try {
        parsedData = JSON.parse(text);
      } catch {
        const match = text.match(/\{[\s\S]*\}/);
        if (match) {
          parsedData = JSON.parse(match[0]);
        } else {
          throw new Error("Unable to parse structured JSON from model response.");
        }
      }

      return res.json({
        success: true,
        data: parsedData,
        model: modelUsed,
        provider: "gemini",
      });
    } catch (geminiError: any) {
      // Automatic failover to Groq if Gemini is exhausted/unavailable
      if (hasGroq(customGroqKey)) {
        try {
          console.log("[Multi-Provider Failover] Gemini failed, seamlessly routing document extraction to Groq LPU...");
          const groqResult = await callGroqDocumentExtraction(
            files,
            extractionMode,
            customPrompt,
            undefined,
            customGroqKey
          );
          return res.json({
            success: true,
            data: groqResult.data,
            model: groqResult.modelUsed,
            provider: "groq",
            failoverOccurred: true,
            failoverNotice: "Extracción completada mediante Groq LPU debido a alta demanda o cuota en Gemini.",
          });
        } catch (groqErr) {
          console.log("[Multi-Provider Failover] Groq document extraction also failed:", groqErr);
        }
      }
      throw geminiError;
    }
  } catch (error: any) {
    console.error("Document analysis endpoint error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 2c. Multimodal Document Extraction with Server-Sent Events (SSE) & generateContentStream
async function handleDocumentStreamingAnalysis(req: express.Request, res: express.Response) {
  // Set SSE Headers
  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
  });

  const sendSSE = (event: string, data: any) => {
    if (res.writableEnded) return;
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    if (typeof (res as any).flush === "function") {
      (res as any).flush();
    }
  };

  let isAborted = false;
  res.on("close", () => {
    if (!res.writableEnded) {
      isAborted = true;
    }
  });

  try {
    const {
      extractionMode = "hybrid",
      customPrompt,
      enableThinking = false,
      model = "gemini-3.8-flash",
      provider = "gemini",
    } = req.body;

    const files = normalizeFileInputs(req.body);

    if (files.length === 0) {
      sendSSE("error", { error: "At least one document or image file is required." });
      return res.end();
    }

    const isGroq = provider === "groq" || String(model).startsWith("llama-");
    const isMulti = files.length > 1;

    sendSSE("status", {
      phase: "preparing",
      message: `Procesando ${files.length} documento(s) en modo ${extractionMode}...`,
      fileCount: files.length,
      mode: extractionMode,
    });

    const fileTitles = files.map((f, i) => `[Archivo ${i + 1}: ${f.fileName || 'Documento'}]`).join(", ");

    const prompt = `
Act as an expert multimodal document intelligence and business analyst.
You are analyzing ${isMulti ? `${files.length} related documents: ${fileTitles}` : `an image or complex document (invoice, receipt, contract, legal agreement, financial statement, spreadsheet screenshot, chart, handwritten memo, technical report, or data table) titled: "${files[0]?.fileName || 'Documento'}"`}.

${isMulti ? `CRITICAL MULTI-DOCUMENT INSTRUCTION: You MUST cross-reference all ${files.length} documents. Complement information from one document with data from the others (for instance, linking orders to invoices, receipts to statements, comparing terms, aggregating line items, or combining parts into a coherent whole). Highlight connections and cross-document insights.` : ''}

Goal: Read and extract all text, numbers, entities, dates, itemized rows, tables, and narrative summaries, and structure them so they can be seamlessly inserted into Google Docs and Google Sheets.

Extraction Mode: "${extractionMode}".
${customPrompt ? `User Specific Instructions: "${customPrompt}"` : ""}

Generate a clean JSON object with this exact schema:
{
  "documentType": string, // Specific document classification in Spanish, e.g. "${isMulti ? 'Análisis Consolidado Multidocumento: Facturas y Comprobantes' : 'Factura Comercial, Recibo de Gastos, Contrato Legal'}"
  "documentSummary": string, // Detailed executive summary in Spanish explaining the purpose, key entities, totals, dates, and conclusions${isMulti ? ', and how the documents complement each other' : ''}.
  "keyDataPoints": [ // 4 to 10 critical key-value facts extracted across the document(s)
    { "label": string, "value": string }
  ],
  ${isMulti ? `"crossDocumentInsights": [
    string // 2 to 4 insights explaining how the documents complement each other
  ],
  "sourceFilesCount": ${files.length},
  "sourceFileNames": ${JSON.stringify(files.map(f => f.fileName || 'Documento'))},` : ''}
  "docsContent": {
    "title": string, // Professional document title for a new Google Doc${isMulti ? ' - Consolidado' : ''}
    "formattedText": string, // Clear structured plain text with uppercase section headers and bullet points ready to insert into Google Docs
    "markdown": string // Rich Markdown version with # Headings, bullet points, and tables
  },
  "sheetsData": {
    "title": string, // Suggested title for a Google Sheet
    "headers": string[], // Column names for tabular data (e.g. ${isMulti ? '["Documento de Origen", "Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]' : '["Fecha", "Descripción / Ítem", "Categoría", "Cantidad", "Precio Unitario", "Total"]'})
    "rows": (string | number)[][], // 2D array of rows. For each line item or data row, provide a complete row matching the headers. Keep numbers clean.
    "sheetName": string // Clean name for the sheet tab, e.g. "${isMulti ? 'Datos Consolidados' : 'Datos Extraídos'}"
  },
  "suggestedActions": string[] // 3-4 recommended action steps
}

Ensure the extracted table in "sheetsData" is as thorough as possible, capturing every single itemized line or row visible across all documents.
Return ONLY valid JSON.
`;

    // 1. If Groq was specifically selected:
    if (isGroq) {
      const groq = getGroq();
      const hasImage = files.some((f) => f.mimeType.startsWith("image/"));
      const targetModel = (model && model.startsWith("llama-"))
        ? model
        : (hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile");

      sendSSE("status", {
        phase: "streaming",
        message: `Extrayendo datos con Groq LPU (${targetModel}) en tiempo real...`,
        model: targetModel,
        provider: "groq",
      });

      const contentParts: any[] = [{ type: "text", text: prompt }];
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (f.mimeType.startsWith("image/")) {
          const dataUrl = f.fileData.startsWith("data:") ? f.fileData : `data:${f.mimeType};base64,${f.fileData}`;
          contentParts.push({ type: "image_url", image_url: { url: dataUrl } });
        } else {
          let textContent = f.fileData;
          if (f.fileData.includes(",")) {
            try {
              textContent = Buffer.from(f.fileData.split(",")[1], "base64").toString("utf-8");
            } catch {
              textContent = f.fileData;
            }
          }
          contentParts.push({
            type: "text",
            text: `\n\n[Documento ${i + 1}/${files.length}: ${f.fileName || 'archivo'}]:\n${textContent}`,
          });
        }
      }

      const stream = await groq.chat.completions.create({
        model: targetModel,
        messages: [{ role: "user", content: contentParts }] as any,
        response_format: { type: "json_object" },
        temperature: 0.1,
        max_tokens: 4096,
        stream: true,
      });

      let accumulatedText = "";
      let chunkCount = 0;
      for await (const chunk of stream) {
        if (isAborted) break;
        const delta = chunk.choices[0]?.delta?.content || "";
        if (delta) {
          accumulatedText += delta;
          chunkCount++;
          sendSSE("chunk", {
            delta,
            chunkCount,
            accumulatedLength: accumulatedText.length,
          });
        }
      }

      sendSSE("status", {
        phase: "parsing",
        message: "Estructurando datos para Google Sheets y Google Docs...",
      });

      let parsedData: any;
      try {
        parsedData = JSON.parse(accumulatedText);
      } catch {
        const match = accumulatedText.match(/\{[\s\S]*\}/);
        if (match) parsedData = JSON.parse(match[0]);
        else throw new Error("No se pudo interpretar el JSON devuelto por Groq.");
      }

      sendSSE("complete", {
        success: true,
        data: parsedData,
        model: targetModel,
        provider: "groq",
      });
      return res.end();
    }

    // 2. Default: Gemini generateContentStream with Multi-tier Quota Fallback and Groq Failover
    let ai: GoogleGenAI;
    try {
      ai = getAI();
    } catch (err: any) {
      if (hasGroq()) {
        sendSSE("status", {
          phase: "failover",
          message: "Gemini API key no detectada. Redirigiendo a Groq LPU (Streaming)...",
        });
      }
      throw err;
    }

    let chosenModel = "gemini-3.8-flash";
    if (enableThinking) {
      chosenModel = "gemini-3.1-pro-preview";
    } else if (model === "gemini-3.5-flash") {
      chosenModel = "gemini-3.8-flash";
    } else if (
      model === "gemini-3.1-flash-lite" ||
      model === "gemini-3.8-flash" ||
      model === "gemini-flash-latest"
    ) {
      chosenModel = model;
    }

    const config: any = {
      responseMimeType: "application/json",
      systemInstruction:
        "You are an elite multimodal document intelligence system with vision capabilities. You extract data with 100% precision from images, PDFs, charts, receipts, and complex documents, synthesizing and cross-referencing multiple files seamlessly.",
    };

    if (enableThinking) {
      config.thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    }

    const parts: any[] = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.isText && f.textContent) {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]\n--- CONTENIDO DEL DOCUMENTO ---\n${f.textContent}\n--- FIN DEL DOCUMENTO ---`,
        });
      } else {
        parts.push({
          text: `[Archivo ${i + 1} de ${files.length}: "${f.fileName}"]`,
        });
        parts.push({
          inlineData: {
            mimeType: f.mimeType,
            data: f.cleanBase64,
          },
        });
      }
    }
    parts.push({ text: prompt });

    const contents = [{ role: "user", parts }];

    const candidateModels = [
      chosenModel,
      "gemini-3.8-flash",
      "gemini-3.1-flash-lite",
      "gemini-flash-latest",
      "gemini-2.5-flash",
    ].filter((m, idx, arr) => Boolean(m) && arr.indexOf(m) === idx);

    let streamSucceeded = false;
    let lastError: any = null;
    let modelUsed = chosenModel;
    let accumulatedText = "";
    let totalChunks = 0;

    for (const currentModel of candidateModels) {
      if (isAborted) break;
      try {
        sendSSE("status", {
          phase: "connecting",
          message: `Iniciando streaming con ${currentModel}...`,
          model: currentModel,
          provider: "gemini",
        });

        const reqConfig = { ...config };
        if (currentModel !== chosenModel && reqConfig.thinkingConfig) {
          delete reqConfig.thinkingConfig;
        }

        const responseStream = await ai.models.generateContentStream({
          model: currentModel,
          contents,
          config: reqConfig,
        });

        sendSSE("status", {
          phase: "streaming",
          message: `Extrayendo datos progresivamente en tiempo real con ${currentModel}...`,
          model: currentModel,
          provider: "gemini",
        });

        accumulatedText = "";
        let chunkIndex = 0;

        for await (const chunk of responseStream) {
          if (isAborted) break;
          const textPart = chunk.text || "";
          if (textPart) {
            accumulatedText += textPart;
            chunkIndex++;
            totalChunks++;
            sendSSE("chunk", {
              delta: textPart,
              chunkIndex,
              accumulatedLength: accumulatedText.length,
            });
          }
        }

        if (accumulatedText.trim().length > 0) {
          modelUsed = currentModel;
          streamSucceeded = true;
          break;
        } else {
          lastError = new Error(`El modelo ${currentModel} finalizó la respuesta vacía.`);
        }
      } catch (err: any) {
        lastError = err;
        console.log(`[Stream Model Retry] ${currentModel} stream failed (${err?.message?.slice(0, 100)}). Trying fallback...`);
        sendSSE("status", {
          phase: "fallback",
          message: `Modelo ${currentModel} con alta demanda o límite. Conmutando al siguiente modelo...`,
          failedModel: currentModel,
        });
      }
    }

    if (!streamSucceeded) {
      // If Gemini quota/demand is exhausted and Groq is configured, seamlessly stream through Groq!
      if (hasGroq()) {
        try {
          console.log("[Multi-Provider Failover] Gemini streaming failed, seamlessly failover to Groq LPU stream...");
          sendSSE("status", {
            phase: "failover",
            message: "Gemini con cuota excedida. Conmutando a Groq LPU (Streaming)...",
            provider: "groq",
          });

          const groq = getGroq();
          const hasImage = files.some((f) => f.mimeType.startsWith("image/"));
          const groqTargetModel = hasImage ? "llama-3.2-11b-vision-preview" : "llama-3.3-70b-versatile";

          const contentParts: any[] = [{ type: "text", text: prompt }];
          for (let i = 0; i < files.length; i++) {
            const f = files[i];
            if (f.mimeType.startsWith("image/")) {
              const dataUrl = f.fileData.startsWith("data:") ? f.fileData : `data:${f.mimeType};base64,${f.fileData}`;
              contentParts.push({ type: "image_url", image_url: { url: dataUrl } });
            } else {
              contentParts.push({
                type: "text",
                text: `\n\n[Documento ${i + 1}/${files.length}: ${f.fileName}]:\n${f.textContent || f.fileData}`,
              });
            }
          }

          const groqStream = await groq.chat.completions.create({
            model: groqTargetModel,
            messages: [{ role: "user", content: contentParts }] as any,
            response_format: { type: "json_object" },
            temperature: 0.1,
            max_tokens: 4096,
            stream: true,
          });

          accumulatedText = "";
          let groqChunkCount = 0;
          for await (const chunk of groqStream) {
            if (isAborted) break;
            const delta = chunk.choices[0]?.delta?.content || "";
            if (delta) {
              accumulatedText += delta;
              groqChunkCount++;
              totalChunks++;
              sendSSE("chunk", {
                delta,
                chunkIndex: groqChunkCount,
                accumulatedLength: accumulatedText.length,
              });
            }
          }

          modelUsed = groqTargetModel;
          streamSucceeded = true;
        } catch (groqErr: any) {
          console.log("[Groq Stream Failover Error] Groq streaming failed:", groqErr?.message || groqErr);
          const msg = String(groqErr?.message || "");
          if (msg.includes("blocked_org") || msg.includes("model_not_found") || groqErr?.status === 403 || groqErr?.status === 404) {
            console.log("[Groq Stream Failover] Groq model restricted at org level.");
          }
        }
      }

      if (!streamSucceeded) {
        throw lastError || new Error("No se pudo completar el streaming con ningún modelo de Gemini.");
      }
    }

    sendSSE("status", {
      phase: "parsing",
      message: "Procesando estructura y vinculando columnas para Google Sheets y Docs...",
      model: modelUsed,
    });

    let parsedData: any;
    try {
      parsedData = JSON.parse(accumulatedText);
    } catch {
      const match = accumulatedText.match(/\{[\s\S]*\}/);
      if (match) {
        parsedData = JSON.parse(match[0]);
      } else {
        throw new Error("No se pudo analizar la estructura JSON del documento extraído.");
      }
    }

    sendSSE("complete", {
      success: true,
      data: parsedData,
      model: modelUsed,
      provider: modelUsed.startsWith("llama") ? "groq" : "gemini",
      chunksCount: totalChunks,
      accumulatedLength: accumulatedText.length,
    });
    res.end();
  } catch (error: any) {
    console.error("Document analysis stream endpoint error:", error);
    const formatted = formatApiError(error);
    sendSSE("error", formatted);
    res.end();
  }
}

app.post("/api/analyze-document/stream", handleDocumentStreamingAnalysis);
app.post("/api/analyze-document-stream", handleDocumentStreamingAnalysis);

// 2b. High-Fidelity AI Document Generation Endpoint
app.post("/api/generate-document", async (req, res) => {
  try {
    const {
      prompt = "",
      title: customTitle = "",
      templateType = "report",
      tone = "professional",
      model = "gemini-3.8-flash",
      provider = "gemini",
    } = req.body;

    const userPrompt = (prompt || customTitle || "").trim();
    if (!userPrompt) {
      return res.status(400).json({ error: "Debes proporcionar una instrucción o título para generar el documento." });
    }

    const templateGuidelines: Record<string, string> = {
      report: "Estructura de Informe Ejecutivo: 1. Resumen Ejecutivo, 2. Objetivos y Alcance, 3. Hallazgos y Análisis Detallado, 4. Métricas / Tabla Comparativa, 5. Conclusiones y Recomendaciones Clave.",
      contract: "Estructura de Contrato / Convenio Legal: Declaraciones de las partes, Cláusulas numeradas (Objeto, Plazo, Contraprestación, Obligaciones, Rescisión, Jurisdicción), y Espacio formal para firmas.",
      proposal: "Estructura de Propuesta Comercial / Proyecto: 1. Diagnóstico del Problema, 2. Solución Propuesta, 3. Metodología y Fases de Entrega, 4. Presupuesto / Inversión, 5. Beneficios y ROI esperado.",
      meeting_notes: "Estructura de Minuta de Reunión: Fecha, Asistentes, Agenda tratada, Acuerdos adoptados, Responsables y Fechas límite de entrega.",
      strategic_plan: "Estructura de Plan Estratégico: Visión, Objetivos OKR / KPI, Estrategias por pilar, Cronograma de hitos, y Gestión de riesgos.",
      technical: "Estructura de Guía / Especificación Técnica: Contexto, Requisitos, Arquitectura / Pasos detallados, Consideraciones operativas y Glosario.",
    };

    const specificGuideline = templateGuidelines[templateType] || templateGuidelines.report;

    const systemInstruction =
      "Eres un redactor y analista documental de élite en español corporativo. Tu especialidad es redactar documentos completos, profundos, profesionales y perfectamente formateados en Markdown.\n\n" +
      "REGLAS CRÍTICAS DE REDACCIÓN:\n" +
      `1. Tipo de documento solicitado: ${templateType.toUpperCase()}.\n` +
      `2. Tono: ${tone}.\n` +
      `3. Pauta de estructura recomendada: ${specificGuideline}\n` +
      "4. No uses texto de relleno ('lorem ipsum') ni dejes marcadores vacíos; redacta un documento completo, exhaustivo y listo para ser entregado o firmado.\n" +
      "5. Usa títulos en Markdown (# para título principal, ## para secciones, ### para subsecciones), listas con viñetas o números, y negritas para enfatizar.\n" +
      "6. Devuelve la respuesta EXCLUSIVAMENTE en formato JSON con la siguiente estructura:\n" +
      "{\n" +
      '  "title": "Título exacto, atractivo y formal del documento",\n' +
      '  "content": "Contenido completo en Markdown de alta calidad",\n' +
      '  "summary": "Resumen ejecutivo de 1 o 2 oraciones del documento",\n' +
      '  "tags": ["tag1", "tag2", "tag3"]\n' +
      "}";

    let resultPayload: { title: string; content: string; summary: string; tags: string[] } | null = null;
    let modelUsed = model;
    let effectiveProvider: "gemini" | "groq" = provider === "groq" ? "groq" : "gemini";

    // Intentar con Groq si el usuario lo solicitó específicamente
    if (provider === "groq" && hasGroq()) {
      try {
        const groq = getGroq();
        const completion = await groq.chat.completions.create({
          model: "llama-3.3-70b-versatile",
          messages: [
            { role: "system", content: systemInstruction },
            { role: "user", content: `Redacta el documento solicitado:\n"${userPrompt}"` },
          ],
          response_format: { type: "json_object" },
          temperature: 0.3,
          max_tokens: 4096,
        });
        const replyText = completion.choices[0]?.message?.content || "";
        resultPayload = JSON.parse(replyText);
        modelUsed = "llama-3.3-70b-versatile";
      } catch (groqErr) {
        console.warn("Groq document generation fallback to Gemini:", groqErr);
        effectiveProvider = "gemini";
      }
    }

    // Si aún no hay resultado, usar Gemini con fallback resiliente
    if (!resultPayload) {
      try {
        const ai = getAI();
        const preferredModel = (model && model.startsWith("gemini")) ? model : "gemini-3.8-flash";
        const { response, modelUsed: usedGeminiModel } = await generateWithQuotaFallback(
          ai,
          preferredModel,
          [{ parts: [{ text: `Instrucción para generar el documento:\n"${userPrompt}"\nTítulo preferido: "${customTitle || "Automático"}"` }] }],
          {
            systemInstruction,
            responseMimeType: "application/json",
          }
        );

        modelUsed = usedGeminiModel;
        const text = response.text || "";
        try {
          resultPayload = JSON.parse(text);
        } catch {
          const match = text.match(/\{[\s\S]*\}/);
          if (match) {
            resultPayload = JSON.parse(match[0]);
          } else {
            resultPayload = {
              title: customTitle || "Documento Generado por IA",
              content: text,
              summary: "Documento generado por asistente de voz e IA.",
              tags: ["documento", "ia", templateType],
            };
          }
        }
      } catch (geminiErr: any) {
        console.warn("Gemini doc generation error, attempting emergency Groq failover:", geminiErr?.message || geminiErr);
        if (hasGroq()) {
          const groq = getGroq();
          const completion = await groq.chat.completions.create({
            model: "llama-3.3-70b-versatile",
            messages: [
              { role: "system", content: systemInstruction },
              { role: "user", content: `Redacta el documento solicitado:\n"${userPrompt}"` },
            ],
            response_format: { type: "json_object" },
            temperature: 0.3,
            max_tokens: 4096,
          });
          const replyText = completion.choices[0]?.message?.content || "";
          resultPayload = JSON.parse(replyText);
          modelUsed = "llama-3.3-70b-versatile";
          effectiveProvider = "groq";
        } else {
          throw geminiErr;
        }
      }
    }

    if (!resultPayload || !resultPayload.content) {
      throw new Error("No se pudo generar el contenido del documento.");
    }

    return res.json({
      success: true,
      title: resultPayload.title || customTitle || "Documento sin título",
      content: resultPayload.content,
      summary: resultPayload.summary || "Documento generado exitosamente.",
      tags: Array.isArray(resultPayload.tags) ? resultPayload.tags : ["documento", templateType],
      modelUsed,
      provider: effectiveProvider,
      timestamp: Date.now(),
    });
  } catch (error: any) {
    console.error("Document generation error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 3. Fast Low-Latency Quick Command Endpoint (gemini-3.1-flash-lite with fallback)
app.post("/api/quick-command", async (req, res) => {
  try {
    const rawPrompt =
      (typeof req.body?.prompt === "string" && req.body.prompt.trim()) ||
      (typeof req.body?.text === "string" && req.body.text.trim()) ||
      (typeof req.body?.command === "string" && req.body.command.trim()) ||
      (typeof req.body?.query === "string" && req.body.query.trim()) ||
      "";

    if (!rawPrompt) {
      return res.status(400).json({ error: "El comando o prompt es requerido." });
    }

    const { systemInstruction } = req.body;
    const ai = getAI();

    const candidateModels = ["gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-latest", "gemini-2.5-flash"];
    let lastError: any = null;
    let responseText = "";
    let modelUsed = "gemini-3.1-flash-lite";

    for (const model of candidateModels) {
      try {
        const config: any = {
          systemInstruction: systemInstruction || "You are an ultra-fast assistant that provides instant, concise responses and structured commands.",
        };
        if (model.includes("3.1") || model.includes("3.8")) {
          config.thinkingConfig = {
            thinkingLevel: ThinkingLevel.MINIMAL,
          };
        }
        const response = await ai.models.generateContent({
          model,
          contents: rawPrompt,
          config,
        });
        responseText = response.text || "";
        modelUsed = model;
        break;
      } catch (err: any) {
        lastError = err;
        console.info(`[Quick Command] Notice: model ${model} unavailable, trying fallback...`);
      }
    }

    if (!responseText && hasGroq()) {
      try {
        const groq = getGroq();
        const groqRes = await groq.chat.completions.create({
          model: "llama-3.1-8b-instant",
          messages: [
            { role: "system", content: systemInstruction || "You are an ultra-fast assistant that provides instant, concise responses and structured commands." },
            { role: "user", content: rawPrompt }
          ],
          temperature: 0.3,
          max_tokens: 1024,
        });
        responseText = groqRes.choices[0]?.message?.content || "";
        modelUsed = "llama-3.1-8b-instant";
      } catch (groqErr) {
        console.log("[Quick Command] Groq failover error:", groqErr);
      }
    }

    if (!responseText && lastError) {
      throw lastError;
    }

    res.json({
      text: responseText,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error("Quick command error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 3b. Dedicated Live Real Estate Research Endpoint with Google Search Grounding (gemini-3.8-flash)
app.post("/api/realestate/research", async (req, res) => {
  try {
    const {
      query,
      location = "",
      propertyType = "",
      transactionType = "sale",
    } = req.body;

    const targetQuery = query || `Investigación de mercado inmobiliario en ${location || "zonas de alta plusvalía"} para ${propertyType || "propiedades residenciales y comerciales"}`;

    const ai = getAI();
    const systemInstruction = 
      "Eres un analista de inversión e inteligencia inmobiliaria de alto nivel con acceso en tiempo real a Google Search.\n" +
      "Tu objetivo es realizar una investigación exhaustiva, veraz y fundamentada sobre el mercado de bienes raíces solicitado.\n" +
      "Debes obtener datos actuales en vivo sobre:\n" +
      "1. Precio promedio por metro cuadrado ($/m² o $/sqft).\n" +
      "2. Rango de precios actual en el mercado para venta y/o renta.\n" +
      "3. Rentabilidad anual estimada (Cap Rate / Rental Yield).\n" +
      "4. Tendencia del mercado (alcista / estable / a la baja).\n" +
      "5. Ejemplos de comparables reales (comps) o propiedades activas en la zona con precios de referencia.\n" +
      "6. Factores de plusvalía, demografía y amenidades destacadas.\n" +
      "Proporciona un reporte estructurado y profesional en Markdown con cifras concretas y citas a fuentes reales.";

    const promptText = `Investiga en vivo el mercado inmobiliario para: "${targetQuery}". Ubicación: "${location}". Tipo: "${propertyType || "General"}". Transacción: "${transactionType}". Presenta un análisis detallado con métricas clave de precios por metro cuadrado, comparables recientes y fuentes web consultadas.`;

    const { response, modelUsed } = await generateWithQuotaFallback(
      ai,
      "gemini-3.8-flash",
      [{ parts: [{ text: promptText }] }],
      {
        systemInstruction,
        tools: [{ googleSearch: {} }],
      }
    );

    const reportText = response.text || "No se pudo generar el reporte de investigación.";

    // Extract grounding sources from search chunks
    const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    let groundingSources: { title: string; uri: string }[] = [];
    if (Array.isArray(rawChunks)) {
      groundingSources = rawChunks
        .map((c: any) => ({
          title: c.web?.title || "Portal Inmobiliario / Fuente Web",
          uri: c.web?.uri || "",
        }))
        .filter((s: any) => Boolean(s.uri));
    }

    return res.json({
      success: true,
      query: targetQuery,
      location,
      report: reportText,
      model: modelUsed || "gemini-3.8-flash",
      groundingSources,
      timestamp: Date.now(),
    });
  } catch (error: any) {
    console.error("Real estate research error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 3c. AI Prompt Enhancer for High-Conversion Image & Video Generation
app.post("/api/enhance-prompt", async (req, res) => {
  try {
    const { prompt, type = "image", stylePreset, cameraMotion } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const ai = getAI();
    const systemInstruction = `You are an elite creative visual director and AI prompt engineer specializing in Google Gemini (gemini-3.1-flash-image, gemini-3-pro-image) and Veo 3 video generation.
Your task is to take the user's initial idea and rewrite it into a highly detailed, descriptive, visually stunning prompt in English that maximizes photorealism, artistic coherence, lighting, textures, camera lenses, and spatial depth.
${type === "video" ? "For video: Focus on smooth camera motion, lighting transitions, physics, temporal coherence, and atmospheric presence. Mention frame rate, motion dynamics, and depth." : "For image: Focus on lighting (e.g., golden hour, rim light, volumetric fog), camera lens (e.g. 35mm f/1.4, Hasselblad medium format), textures, composition (rule of thirds, leading lines), and materials."}
${stylePreset ? `Incorporate the chosen artistic/visual style: "${stylePreset}".` : ""}
${cameraMotion ? `Incorporate the specific camera movement: "${cameraMotion}".` : ""}
Rules:
- Return ONLY the enhanced prompt string. No conversational filler, no markdown codeblocks, no explanations.
- Maximum 150-200 words. Keep it vivid, impactful, and coherent.`;

    let enhancedText = "";
    try {
      const { response } = await generateWithQuotaFallback(
        ai,
        "gemini-3.8-flash",
        [{ parts: [{ text: `Expand and enhance this prompt: "${prompt}"` }] }],
        {
          systemInstruction,
          temperature: 0.7,
        }
      );
      enhancedText = response.text?.trim() || "";
    } catch (geminiErr) {
      console.log("Gemini prompt enhance fallback chain failed, attempting Groq...", geminiErr);
      if (hasGroq()) {
        try {
          const groq = getGroq();
          const completion = await groq.chat.completions.create({
            messages: [
              { role: "system", content: systemInstruction },
              { role: "user", content: `Expand and enhance this prompt: "${prompt}"` },
            ],
            model: "llama-3.3-70b-versatile",
            temperature: 0.7,
            max_tokens: 300,
          });
          enhancedText = completion.choices[0]?.message?.content?.trim() || "";
        } catch (groqErr) {
          console.log("Groq prompt enhance also failed:", groqErr);
        }
      }
    }

    if (!enhancedText) {
      enhancedText = prompt;
    }

    res.json({ enhancedPrompt: enhancedText });
  } catch (error: any) {
    console.error("Enhance prompt error:", error);
    res.status(500).json({ error: error?.message || "Failed to enhance prompt" });
  }
});

// 4. Generate High-Quality Images with Multi-Tier Model Fallback & Search Grounding
app.post("/api/generate-image", async (req, res) => {
  try {
    const {
      prompt,
      imageSize = "1K",
      aspectRatio = "1:1",
      enableSearchGrounding = false,
    } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Image prompt is required." });
    }

    const ai = getAI();
    const validSizes = ["512px", "1K", "2K", "4K"];
    const chosenSize = validSizes.includes(imageSize) ? imageSize : "1K";

    const candidateModels = [
      "gemini-3.1-flash-image",
      "gemini-3.1-flash-lite-image",
      "gemini-3-pro-image",
      "gemini-3.1-flash-image-preview",
      "gemini-3-pro-image-preview",
    ];

    let imageUrl: string | null = null;
    let descriptionText = "";
    let modelUsed = "";
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        console.log(`[Image Generation] Attempting model: ${model}`);
        const config: any = {
          imageConfig: {
            aspectRatio: aspectRatio || "1:1",
          },
        };

        // imageSize supported on gemini-3.1-flash-image and gemini-3-pro-image
        if (!model.includes("lite")) {
          config.imageConfig.imageSize = chosenSize;
        }

        // Enable Google Search grounding if requested and model supports it
        if (enableSearchGrounding && (model.includes("flash-image") || model.includes("pro-image"))) {
          config.tools = [
            {
              googleSearch: {
                searchTypes: {
                  webSearch: {},
                  imageSearch: {},
                },
              },
            },
          ];
        }

        const response = await ai.models.generateContent({
          model,
          contents: {
            parts: [{ text: prompt }],
          },
          config,
        });

        if (response.candidates && response.candidates[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
            } else if (part.text) {
              descriptionText += part.text;
            }
          }
        }

        if (imageUrl) {
          modelUsed = model;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.log(`[Image Generation] Model ${model} failed (${err?.message?.slice(0, 100) || err}). Trying fallback...`);
      }
    }

    if (!imageUrl) {
      throw lastError || new Error("No se pudo generar la imagen con ninguno de los modelos disponibles. " + descriptionText);
    }

    res.json({
      imageUrl,
      description: descriptionText,
      imageSize: chosenSize,
      aspectRatio,
      model: modelUsed,
    });
  } catch (error: any) {
    console.error("Generate image error:", error);
    const formatted = formatApiError(error);
    if (formatted.isQuotaExceeded) {
      formatted.error = "Límite de cuota alcanzado para generación de imágenes (429). En el plan gratuito los modelos de imagen pueden tener cuota restringida o requerir facturación en Google AI Studio.";
    }
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 5. Create & Edit Images with Multi-Tier Model Fallback
app.post("/api/edit-image", async (req, res) => {
  try {
    const { prompt, imageBase64, mimeType = "image/png", aspectRatio } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required." });
    }

    const ai = getAI();
    const parts: any[] = [];

    // If an existing image is provided to edit:
    if (imageBase64) {
      const cleanBase64 = imageBase64.includes(",")
        ? imageBase64.split(",")[1]
        : imageBase64;

      parts.push({
        inlineData: {
          data: cleanBase64,
          mimeType: mimeType || "image/png",
        },
      });
    }

    parts.push({ text: prompt });

    const candidateModels = [
      "gemini-3.1-flash-image",
      "gemini-3.1-flash-lite-image",
      "gemini-3-pro-image",
      "gemini-3.1-flash-image-preview",
    ];

    let imageUrl: string | null = null;
    let textOut = "";
    let modelUsed = "";
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        console.log(`[Edit Image] Attempting model: ${model}`);
        const config: any = {};
        if (aspectRatio) {
          config.imageConfig = { aspectRatio };
        }

        const response = await ai.models.generateContent({
          model,
          contents: {
            parts,
          },
          ...(Object.keys(config).length > 0 ? { config } : {}),
        });

        if (response.candidates && response.candidates[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
            } else if (part.text) {
              textOut += part.text;
            }
          }
        }

        if (imageUrl) {
          modelUsed = model;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.log(`[Edit Image] Model ${model} failed (${err?.message?.slice(0, 100) || err}). Trying fallback...`);
      }
    }

    if (!imageUrl) {
      throw lastError || new Error("No se pudo procesar la imagen con los modelos disponibles. " + textOut);
    }

    res.json({
      imageUrl,
      notes: textOut,
      model: modelUsed,
      mode: imageBase64 ? "edited" : "created",
    });
  } catch (error: any) {
    console.error("Edit image error:", error);
    const formatted = formatApiError(error);
    if (formatted.isQuotaExceeded) {
      formatted.error = "Límite de cuota alcanzado para edición de imágenes (429). En el plan gratuito los modelos de imagen pueden tener cuota restringida.";
    }
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// TTS Quota Circuit Breaker (Free tier allows 10 requests/day per project)
let ttsQuotaCooldownUntil: number = 0;

// 6. Text-to-Speech endpoint (gemini-3.1-flash-tts-preview) with resilient fallback
app.post("/api/tts", async (req, res) => {
  try {
    const { text, voice = "Aoede" } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required." });
    }

    // Circuit Breaker: If quota was exceeded (10 free requests/day), immediately delegate to client SpeechSynthesis
    if (Date.now() < ttsQuotaCooldownUntil) {
      return res.json({
        fallbackToBrowser: true,
        reason: "TTS en enfriamiento por cuota (10 peticiones gratuitas/día). Delegando a síntesis nativa del navegador.",
      });
    }

    const ai = getAI();
    const validVoices = ["Aoede", "Kore", "Puck", "Charon", "Fenrir", "Zephyr"];
    const voiceName = validVoices.includes(voice) ? voice : "Aoede";

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const audioBase64 =
        response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

      if (!audioBase64) {
        return res.json({
          fallbackToBrowser: true,
          reason: "No se obtuvo stream de audio de Gemini TTS.",
        });
      }

      return res.json({
        audio: audioBase64,
        mimeType: "audio/pcm;rate=24000",
        sampleRate: 24000,
      });
    } catch (ttsGenError: any) {
      const formatted = formatApiError(ttsGenError);
      if (formatted.isQuotaExceeded || formatted.isHighDemand) {
        // Set circuit breaker for 30 minutes to protect rate limits and prevent repeated 429 logs
        ttsQuotaCooldownUntil = Date.now() + 30 * 60 * 1000;
        console.info(
          `[TTS Circuit Breaker] Gemini TTS cuota alcanzada (10 req/día). Delegando a síntesis nativa del navegador de manera silenciosa.`
        );
        return res.json({
          fallbackToBrowser: true,
          reason: "Cuota de Gemini TTS alcanzada (10 peticiones gratuitas/día). Utilizando síntesis de voz nativa del navegador.",
        });
      }
      return res.json({
        fallbackToBrowser: true,
        reason: "Servicio TTS no disponible, delegando a síntesis nativa.",
      });
    }
  } catch (error: any) {
    console.info("TTS request exception, falling back to browser:", error?.message || error);
    return res.json({ fallbackToBrowser: true });
  }
});

// 6b. Veo 3 Video Generation: Text to Video, Image to Video & Interpolation (Start + End Frame)
app.post("/api/generate-video", async (req, res) => {
  try {
    const {
      prompt,
      imageBase64,
      mimeType = "image/png",
      lastFrameBase64,
      lastFrameMimeType = "image/png",
      aspectRatio = "16:9",
      resolution = "720p",
      cameraMotion,
    } = req.body;

    if (!prompt && !imageBase64) {
      return res.status(400).json({ error: "Se requiere un prompt de texto o una imagen para generar el video con Veo 3." });
    }

    const ai = getAI();
    const candidateModels = [
      "veo-3.1-generate-preview",
      "veo-3.1-lite-generate-preview",
    ];

    let operation: any = null;
    let lastError: any = null;
    let modelUsed = "";

    const selectedRatio = aspectRatio === "9:16" ? "9:16" : "16:9";
    const selectedResolution = resolution === "1080p" ? "1080p" : "720p";

    // Combine prompt with camera motion directive if provided
    let finalPrompt = prompt || "";
    if (cameraMotion && cameraMotion.trim()) {
      finalPrompt = finalPrompt
        ? `${finalPrompt}. Camera motion: ${cameraMotion.trim()}`
        : `Camera motion: ${cameraMotion.trim()}`;
    }

    for (const model of candidateModels) {
      try {
        console.log(`[Veo Video] Attempting generation with model ${model}...`);
        const payload: any = {
          model,
          config: {
            numberOfVideos: 1,
            aspectRatio: selectedRatio,
            resolution: selectedResolution,
          },
        };

        if (finalPrompt) {
          payload.prompt = finalPrompt;
        }

        if (imageBase64) {
          const cleanBase64 = imageBase64.includes(",")
            ? imageBase64.split(",")[1]
            : imageBase64;
          payload.image = {
            imageBytes: cleanBase64,
            mimeType: mimeType || "image/png",
          };
        }

        if (lastFrameBase64) {
          const cleanLastBase64 = lastFrameBase64.includes(",")
            ? lastFrameBase64.split(",")[1]
            : lastFrameBase64;
          payload.config.lastFrame = {
            imageBytes: cleanLastBase64,
            mimeType: lastFrameMimeType || "image/png",
          };
        }

        operation = await ai.models.generateVideos(payload);
        if (operation?.name) {
          modelUsed = model;
          console.log(`[Veo Video] Operation started successfully: ${operation.name} (${model})`);
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.log(`[Veo Video] Model ${model} failed (${err?.message?.slice(0, 100) || err}). Retrying next...`);
      }
    }

    if (!operation?.name) {
      throw lastError || new Error("No se pudo iniciar la operación de video con Veo 3.");
    }

    return res.json({
      operationName: operation.name,
      modelUsed,
      aspectRatio: selectedRatio,
      resolution: selectedResolution,
      prompt: finalPrompt || "",
      hasStartingImage: Boolean(imageBase64),
      hasLastFrame: Boolean(lastFrameBase64),
    });
  } catch (error: any) {
    console.error("Veo Video Generation Error:", error);
    const formatted = formatApiError(error);
    res.status(formatted.isQuotaExceeded ? 429 : 500).json(formatted);
  }
});

// 6c. Veo 3 Video Status Poll
app.post("/api/video-status", async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    const ai = getAI();
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    return res.json({
      done: Boolean(updated.done),
      error: updated.error || null,
      operationName,
    });
  } catch (error: any) {
    console.error("Veo Video Status Error:", error);
    const formatted = formatApiError(error);
    res.status(500).json(formatted);
  }
});

// 6d. Veo 3 Video Download Stream
app.post("/api/video-download", async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    const ai = getAI();
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
    if (!uri) {
      return res.status(404).json({ error: "Video URI not found or generation not finished." });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const videoRes = await fetch(uri, {
      headers: { "x-goog-api-key": apiKey || "" },
    });

    if (!videoRes.ok) {
      return res.status(videoRes.status).json({ error: "Failed to download video stream." });
    }

    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Content-Disposition", `inline; filename="veo3-${Date.now()}.mp4"`);

    if (videoRes.body) {
      const reader = videoRes.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(Buffer.from(value));
      }
      res.end();
    } else {
      res.status(500).json({ error: "No video body stream available." });
    }
  } catch (error: any) {
    console.error("Veo Video Download Error:", error);
    const formatted = formatApiError(error);
    res.status(500).json(formatted);
  }
});

// Create HTTP server for both Express and WebSocket
const server = http.createServer(app);

// 7. WebSocket for Real-time Voice Conversations via Gemini Live API
const wss = new WebSocketServer({ server, path: "/live" });

wss.on("connection", async (clientWs: WebSocket) => {
  console.log("Client connected to /live WebSocket");
  let liveSession: any = null;

  try {
    const ai = getAI();
    const liveModel = "gemini-2.0-flash-exp";

    liveSession = await ai.live.connect({
      model: liveModel,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
        },
        systemInstruction: `Eres Lexi, una asistente de voz ejecutiva de IA de última generación para Google Workspace.
PERSONALIDAD Y DIRECTRICES DE CONVERSACIÓN:
- Eres una voz femenina amigable, cálida, cordial y empática, pero al mismo tiempo profundamente respetuosa, educada y profesional.
- Habla en un español impecable, natural, fluido y elocuente.
- Tus respuestas deben ser rápidas, ágiles y directas al grano, manteniendo siempre un trato cercano y de absoluto respeto hacia el usuario.
- NUNCA repitas la misma frase, saludo ni resumen expresado en turnos previos de esta conversación.
- Para Google Docs y Sheets: cuando el usuario pida crear o modificar un archivo, incluye la estructura formateada inmediatamente iniciando con "DOC_PROPOSAL:" o "SHEET_PROPOSAL:".`,
      },
      callbacks: {
        onmessage: (message: any) => {
          try {
            const parts = message.serverContent?.modelTurn?.parts;
            if (parts && parts.length > 0) {
              for (const part of parts) {
                if (part.inlineData?.data) {
                  clientWs.send(
                    JSON.stringify({
                      type: "audio",
                      audio: part.inlineData.data,
                      sampleRate: 24000,
                    })
                  );
                }
                if (part.text) {
                  clientWs.send(
                    JSON.stringify({
                      type: "transcript",
                      text: part.text,
                    })
                  );
                }
              }
            }
            if (message.serverContent?.turnComplete) {
              clientWs.send(JSON.stringify({ type: "turnComplete" }));
            }
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: "interrupted" }));
            }
          } catch (err) {
            console.error("Error sending Live message to client:", err);
          }
        },
        onclose: () => {
          console.log("Live session closed");
          try {
            clientWs.send(JSON.stringify({ type: "sessionClosed" }));
          } catch (_) {}
        },
        onerror: (err: any) => {
          console.error("Live session error:", err);
          try {
            clientWs.send(
              JSON.stringify({ type: "error", error: err?.message || String(err) })
            );
          } catch (_) {}
        },
      },
    });

    clientWs.send(JSON.stringify({ type: "connected", model: liveModel, voice: "Zephyr", sampleRate: 24000 }));
  } catch (err: any) {
    console.error("Failed to connect to Live API:", err);
    clientWs.send(
      JSON.stringify({
        type: "error",
        error: "Live API connection failed: " + (err?.message || String(err)),
      })
    );
  }

  clientWs.on("message", (raw: Buffer) => {
    try {
      const data = JSON.parse(raw.toString());
      if (data.type === "audio" && data.audio && liveSession) {
        liveSession.sendRealtimeInput({
          audio: {
            data: data.audio,
            mimeType: "audio/pcm;rate=16000",
          },
        });
      } else if (data.type === "text" && data.text && liveSession) {
        if (typeof liveSession.sendClientContent === "function") {
          liveSession.sendClientContent({
            turns: [{ role: "user", parts: [{ text: data.text }] }],
            turnComplete: true,
          });
        }
      } else if (data.type === "interrupt" && liveSession) {
        // Explicit interruption command requested by client
        if (typeof liveSession.sendClientContent === "function") {
          try {
            liveSession.sendClientContent({
              turns: [],
              turnComplete: true,
            });
          } catch (_) {}
        }
      }
    } catch (err) {
      console.error("Error processing client message:", err);
    }
  });

  clientWs.on("close", () => {
    console.log("Client disconnected from /live");
    if (liveSession && typeof liveSession.close === "function") {
      try {
        liveSession.close();
      } catch (_) {}
    }
  });
});

// Setup Vite middleware in dev or static serving in prod
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Server startup error:", err);
});
