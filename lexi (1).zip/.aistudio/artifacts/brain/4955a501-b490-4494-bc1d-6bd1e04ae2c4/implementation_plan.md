# Reconstrucción del Motor de la Asistente de Voz (Lexi)

Plan arquitectónico para reconstruir el software y la lógica interna de la asistente de voz, logrando conversación fluida de latencia mínima, voz fija sin variaciones esporádicas, eliminación de cortes involuntarios y retención continua de contexto, preservando intacta la estética actual.

## User Review & Critical Decisions

> [!IMPORTANT]
> Decisiones técnicas confirmadas para esta reconstrucción:

- **Motor de Voz Unificado (Confirmado)**: Migración completa al motor de audio nativo bidireccional en tiempo real **Gemini Live Streaming (`gemini-3.8-live`)**. Esto erradica el motor `speechSynthesis` del navegador, garantizando una voz neural de estudio idéntica en cualquier dispositivo sin alternar voces.
- **Interrupción Dirigida por Comando "Lexi" (Confirmado)**: Se elimina la interrupción por ruido ambiental o eco. Mientras la asistente habla, el micrófono filtra el audio y solo se detiene si detecta la palabra clave *"Lexi"* (o comandos directos como *"Detente"* / *"Para"*).
- **Memoria Continua y Ventana Deslizante (Confirmado)**: Inyección dinámica en la sesión en vivo de los últimos 10 turnos de conversación más un resumen estructurado de acuerdos previos, asegurando cero pérdida de contexto en sesiones prolongadas.
- **Cero Alteraciones Estéticas (Confirmado)**: Toda la UI existente (CyberParticleOrb, controles, modales, diseño de burbujas, paleta cibernética y modo oscuro) se mantiene 100% idéntica.

---

## 1. Overview & Core Concept

- **Qué hace**: Transforma el flujo de interacción de voz en una experiencia de conversación en tiempo real mediante WebSocket streaming bidireccional. La asistente escucha con cancelación de ruido adaptativa, responde de inmediato con voz neural fija (`Zephyr`), no se interrumpe sola con su propio audio ni con ruidos de fondo, y mantiene memoria perfecta de los temas hablados.
- **Público objetivo**: Usuarios de Lexi que dictan instrucciones, consultan información y gestionan documentos en Google Docs y Sheets sin fricción ni fallos de audio.
- **Valor diferencial**: Latencia inferior a 500ms desde que el usuario termina de hablar hasta el primer chunk de audio, estabilidad absoluta de voz (sin bugs del navegador) y diálogo sin interrupciones erráticas.

---

## 2. User Experience & Visual Design

*(Diseño estético 100% conservado; optimización enfocada en la fluidez de interacción)*

- **Flujo de Usuario Optimizado**:
  1. El usuario activa la escucha continua o presiona el orbe (`CyberParticleOrb`).
  2. La conexión WebSocket `/live` se inicia de inmediato o reutiliza el canal caliente.
  3. El usuario habla de forma natural en español. El umbral anti-ruido (Noise Gate) filtra respiraciones y ruidos de tecleo.
  4. La asistente transmite audio PCM en tiempo real (24kHz) y la transcripción se escribe progresivamente en la pantalla.
  5. **Comportamiento durante la respuesta**: La asistente habla con voz continua y cálida. Si el usuario tose, teclea o hay eco de fondo, la asistente **no se detiene**. Solo si el usuario pronuncia *"Lexi"* o *"Detente"*, la reproducción se silencia al instante y el sistema queda atento a la nueva orden.
  6. **Contexto persistente**: Al continuar la charla tras varios minutos o recargar la vista, Lexi recuerda los datos y temas tratados en los últimos 10 intercambios.

- **Indicadores de Estado Existentes**:
  - Orbe en modo *Listening* (verde/cian reactivo al volumen del micrófono).
  - Orbe en modo *Speaking* (ondas pulsantes sincronizadas con la reproducción).
  - Orbe en modo *Standby / Anti-ruido* (color base sutil cuando el ruido está por debajo del umbral).

---

## 3. Key Product Decisions & Trade-Offs

- **Decisión 1: Sustitución de `speechSynthesis` del navegador por audio nativo de Gemini Live**:
  - *Enfoque*: El servidor Express/WebSocket mantiene la sesión `ai.live.connect` con `model: "gemini-3.8-live"` y configuración preconstruida fija `voiceName: "Zephyr"`. El cliente reproduce los buffers de audio PCM directamente mediante `LiveAudioPlayer`.
  - *Por qué*: La API nativa del navegador (`window.speechSynthesis`) sufre de recolección de basura asíncrona que corta frases largas, y cambia aleatoriamente entre voces del sistema operativo cuando cambia el idioma o se refresca el navegador. Gemini Live elimina este problema de raíz.
  - *Alternativa descartada*: Intentar bloquear voces del navegador con reintentos; sigue fallando en diferentes dispositivos (Safari, Android, Windows).

- **Decisión 2: Control de Interrupciones (Directed Barge-in con palabra clave "Lexi")**:
  - *Enfoque*: Mientras la asistente está en estado `isPlaying`, el flujo de audio saliente no se retroalimenta al modelo Live. Se habilita un reconocedor ultraligero de palabras clave en el cliente enfocado exclusivamente en detectar el término *"Lexi"*, *"Detente"* o *"Para"*.
  - *Por qué*: El mayor reclamo de los asistentes de voz es que se auto-interrumpen con el sonido de los propios altavoces o con ruidos menores del entorno. Al exigir la mención explícita de "Lexi", se asegura fluidez total sin cortes no deseados.

- **Decisión 3: Arquitectura de Memoria Deslizante + Resumen en Firestore**:
  - *Enfoque*: Un buffer circular en memoria del cliente mantiene los últimos 10 turnos completos. Al mismo tiempo, en segundo plano se genera y actualiza un extracto de contexto acumulado (`sessionSummary`) que se pasa como `systemInstruction` al iniciar o renovar la conexión del Live API.
  - *Por qué*: Evita la sobrecarga de tokens, mantiene la latencia mínima y garantiza que la asistente nunca sufra amnesia conversacional ni olvide los nombres o acuerdos fijados al inicio de la sesión.

---

## 4. Technical Architecture & Data Strategy

### Diagrama de Flujo de Audio y Contexto

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CLIENTE BROWSER (React)                         │
│                                                                        │
│  ┌───────────────────────┐             ┌────────────────────────────┐  │
│  │    Micrófono Input    │             │   LiveAudioPlayer (24kHz)  │  │
│  │  (MediaStream 16kHz)  │             │   PCM Jitter Buffer Queue  │  │
│  └──────────┬────────────┘             └─────────────▲──────────────┘  │
│             │                                        │                 │
│             ▼                                        │ Audio PCM       │
│  ┌───────────────────────┐             ┌─────────────┴──────────────┐  │
│  │ VoiceNoiseFilter &    │             │ Directed Barge-in Monitor  │  │
│  │ Anti-Ruido Gate (RMS) │             │ (Detecta "Lexi" para parar)│  │
│  └──────────┬────────────┘             └─────────────▲──────────────┘  │
│             │ Audio limpio                           │                 │
│             │ (Silenciado si asistente habla)        │ Estado Playing  │
│             ▼                                        │                 │
│  ┌───────────────────────────────────────────────────┴──────────────┐  │
│  │         WebSocket Client (/live) + Rolling Context Store         │  │
│  │  (Historial Últimos 10 Turnos + Resumen Ejecutivo en Firestore)  │  │
│  └──────────────────────────────▲┬──────────────────────────────────┘  │
└─────────────────────────────────┼┼──────────────────────────────────────┘
                                  ││  WebSocket Bidireccional
                                  ││  (PCM Frames + JSON Eventos)
┌─────────────────────────────────┼┼──────────────────────────────────────┐
│                                 ││                                      │
│                        SERVIDOR (server.ts)                             │
│                                 ▼│                                      │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │              WebSocket Gateway (/live) en Node/Express            │  │
│  │       Mapeo de sesiones, canal PCM y bridging de herramientas      │  │
│  └──────────────────────────────▲┬───────────────────────────────────┘  │
│                                 ││  SDK @google/genai                   │
│                                 ▼│                                      │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │        Google Gemini Live Session (ai.live.connect)               │  │
│  │   • Modelo: gemini-3.8-live                                       │  │
│  │   • Voz fija: Zephyr (Español / Audio Streaming)                  │  │
│  │   • System Instruction con Contexto Dinámico & Workspace Tools    │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │        Firebase Firestore DB (ai-studio-lexi-...)                 │  │
│  │   • chat_sessions: historial de 10 turnos + resumen clave         │  │
│  │   • audit_logs: eventos de voz e interacciones                    │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

### Componentes de Software a Modificar y Optimizar

1. **`server.ts`**:
   - Mejorar el handler de WebSocket `/live` para admitir inicialización de sesión con contexto previo (`initialTurns` y `summaryContext`).
   - Configurar `gemini-3.8-live` con instrucciones estrictas de síntesis en español fluido, tono ejecutivo y herramientas automáticas (`DOC_PROPOSAL:` y `SHEET_PROPOSAL:`).
   - Optimizar el empaquetado de chunks PCM para eliminar crujidos o latencia innecesaria en la transmisión.

2. **`src/utils/audio.ts` & `LiveAudioPlayer`**:
   - Reforzar `LiveAudioPlayer` con un buffer de des-jittering que programe audio continuo y suave en el `AudioContext` a 24.000 Hz.
   - Implementar el hook de interrupción `interruptPlayback()` que libere fuentes activas únicamente ante la señal explícita del detector.
   - Proteger el `AudioContext` ante suspensiones del navegador con reanudación automática transparente.

3. **`src/components/VoiceAssistantHub.tsx`**:
   - Desacoplar el viejo flujo dependiente de `speechSynthesis` y canalizar la interacción oral prioritariamente a través del canal en vivo WebSocket.
   - Integrar el filtro **Directed Barge-in**: silenciar la subida de audio al servidor mientras la asistente habla, manteniendo activo un evaluador de la palabra clave *"Lexi"* para cancelar la reproducción sólo cuando el usuario lo solicite explícitamente.
   - Implementar el gestor de memoria continua: serialización de los últimos 10 turnos + generación silenciosa de resumen de fondo persistido en Firestore.
