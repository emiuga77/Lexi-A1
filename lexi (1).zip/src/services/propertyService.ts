import {
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import { db, logAuditEvent } from './firestoreDb';
import { auth } from './firebaseAuth';
import { PropertyCRMRecord } from '../types';
import { INITIAL_SAMPLE_PROPERTIES } from '../data/sampleProperties';

const CACHE_KEY_PREFIX = 'lexi_crm_properties_';

export async function getProperties(): Promise<PropertyCRMRecord[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'default_guest';
  const cacheKey = `${CACHE_KEY_PREFIX}${userId}`;

  if (user) {
    try {
      const colRef = collection(db, 'users', user.uid, 'properties');
      const q = query(colRef, orderBy('updatedAt', 'desc'));
      const snapshot = await getDocs(q);
      const list: PropertyCRMRecord[] = [];
      snapshot.forEach((d) => {
        list.push(d.data() as PropertyCRMRecord);
      });

      if (list.length > 0) {
        localStorage.setItem(cacheKey, JSON.stringify(list));
        return list;
      }
    } catch (err) {
      console.warn('Could not fetch properties from Firestore:', err);
    }
  }

  // Check local cache
  try {
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {}

  // Return initial sample properties and cache them
  try {
    localStorage.setItem(cacheKey, JSON.stringify(INITIAL_SAMPLE_PROPERTIES));
  } catch {}

  return INITIAL_SAMPLE_PROPERTIES;
}

export async function getPropertyById(id: string): Promise<PropertyCRMRecord | null> {
  const properties = await getProperties();
  return properties.find((p) => p.id === id) || null;
}

export async function saveProperty(
  property: Partial<PropertyCRMRecord> & { title: string; price: number }
): Promise<PropertyCRMRecord> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'default_guest';
  const id = property.id || `prop_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  const existing = await getPropertyById(id);

  const fullRecord: PropertyCRMRecord = {
    ...(existing || INITIAL_SAMPLE_PROPERTIES[0]),
    ...property,
    id,
    userId,
    updatedAt: now,
    createdAt: existing?.createdAt || now,
    referenceCode:
      property.referenceCode ||
      existing?.referenceCode ||
      `LX-REF-${Math.floor(1000 + Math.random() * 9000)}`,
  };

  // 1. Save to Firestore if user is authenticated
  if (user) {
    try {
      const docRef = doc(db, 'users', user.uid, 'properties', id);
      await setDoc(docRef, fullRecord, { merge: true });
    } catch (err) {
      console.warn('Error saving property to Firestore:', err);
    }
  }

  // 2. Save to local cache
  const cacheKey = `${CACHE_KEY_PREFIX}${userId}`;
  try {
    const currentList = await getProperties();
    const index = currentList.findIndex((p) => p.id === id);
    let updatedList: PropertyCRMRecord[];
    if (index >= 0) {
      updatedList = [...currentList];
      updatedList[index] = fullRecord;
    } else {
      updatedList = [fullRecord, ...currentList];
    }
    localStorage.setItem(cacheKey, JSON.stringify(updatedList));
  } catch {}

  // 3. Log Audit
  await logAuditEvent({
    actionType: 'doc_extraction',
    entityType: 'document',
    details: `Ficha CRM actualizada para propiedad "${fullRecord.title}" [${fullRecord.referenceCode}] - ${fullRecord.price.toLocaleString()} ${fullRecord.currency}`,
    status: 'success',
  }).catch(() => {});

  return fullRecord;
}

export async function deleteProperty(id: string): Promise<void> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'default_guest';

  if (user) {
    try {
      const docRef = doc(db, 'users', user.uid, 'properties', id);
      await deleteDoc(docRef);
    } catch (err) {
      console.warn('Error deleting property from Firestore:', err);
    }
  }

  const cacheKey = `${CACHE_KEY_PREFIX}${userId}`;
  try {
    const currentList = await getProperties();
    const updated = currentList.filter((p) => p.id !== id);
    localStorage.setItem(cacheKey, JSON.stringify(updated));
  } catch {}
}

export async function resetToSampleProperties(): Promise<PropertyCRMRecord[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'default_guest';
  const cacheKey = `${CACHE_KEY_PREFIX}${userId}`;

  localStorage.setItem(cacheKey, JSON.stringify(INITIAL_SAMPLE_PROPERTIES));

  if (user) {
    for (const prop of INITIAL_SAMPLE_PROPERTIES) {
      try {
        const docRef = doc(db, 'users', user.uid, 'properties', prop.id);
        await setDoc(docRef, { ...prop, userId: user.uid }, { merge: true });
      } catch {}
    }
  }

  return INITIAL_SAMPLE_PROPERTIES;
}
