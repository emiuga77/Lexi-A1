import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { ExtractionRecord, AuditLog, DocumentMetadata, VoiceCommandRecord } from '../types';

// Lazy-loaded Supabase client instance
let supabaseClientInstance: SupabaseClient | null = null;

/**
 * Retrieve the active Supabase project URL and anon key safely.
 * Checks both browser import.meta.env and process.env.
 */
export function getSupabaseCredentials(): { url: string; key: string; isConfigured: boolean } {
  let url = '';
  let key = '';

  try {
    // Client-side Vite environment variables
    const metaEnv = (import.meta as unknown as { env?: Record<string, string> }).env;
    if (metaEnv) {
      url = metaEnv.VITE_SUPABASE_URL || '';
      key = metaEnv.VITE_SUPABASE_ANON_KEY || '';
    }
  } catch {
    // Ignore in non-vite contexts
  }

  // Fallback to process.env if available
  if (!url && typeof process !== 'undefined' && process.env) {
    url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '';
    key = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || '';
  }

  const isConfigured = Boolean(url && key && url.startsWith('http') && !url.includes('placeholder'));
  return { url, key, isConfigured };
}

/**
 * Returns the Supabase client instance (or null if unconfigured).
 * Uses lazy initialization to prevent crashes on startup.
 */
export function getSupabaseClient(): SupabaseClient | null {
  if (supabaseClientInstance) {
    return supabaseClientInstance;
  }

  const { url, key, isConfigured } = getSupabaseCredentials();
  if (!isConfigured) {
    return null;
  }

  try {
    supabaseClientInstance = createClient(url, key, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    return supabaseClientInstance;
  } catch (error) {
    console.warn('Failed to initialize Supabase client:', error);
    return null;
  }
}

/**
 * Returns current status of Supabase configuration
 */
export function getSupabaseStatus(): { configured: boolean; url: string | null } {
  const { url, isConfigured } = getSupabaseCredentials();
  return {
    configured: isConfigured,
    url: isConfigured ? url : null,
  };
}

/**
 * Test connectivity to Supabase
 */
export async function testSupabaseConnection(): Promise<{ success: boolean; message: string }> {
  const client = getSupabaseClient();
  if (!client) {
    return {
      success: false,
      message: 'Supabase credentials not configured in environment (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY).',
    };
  }

  try {
    // Try pinging or querying a lightweight metadata table
    const { error } = await client.from('voice_commands').select('id').limit(1);
    if (error && error.code !== 'PGRST116' && !error.message.includes('relation "voice_commands" does not exist')) {
      return {
        success: false,
        message: `Supabase responded with: ${error.message}`,
      };
    }
    return {
      success: true,
      message: 'Supabase connection established successfully.',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Error connecting to Supabase.',
    };
  }
}

/* -------------------------------------------------------------------------- */
/*                       DATA PERSISTENCE TO SUPABASE                        */
/* -------------------------------------------------------------------------- */

/**
 * Persist an extraction record to Supabase table `extraction_records`
 */
export async function syncExtractionToSupabase(record: ExtractionRecord): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) return false;

  try {
    const { error } = await client.from('extraction_records').upsert({
      id: record.id,
      user_id: record.userId,
      file_name: record.fileName,
      file_type: record.fileType,
      provider: record.provider,
      model_used: record.modelUsed,
      summary: record.summary,
      fields_count: record.fieldsCount,
      tables_count: record.tablesCount,
      extracted_data: record.extractedData ? JSON.stringify(record.extractedData) : null,
      status: record.status,
      created_at: record.createdAt,
    });

    if (error) {
      console.warn('Supabase sync extraction notice:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase sync error (extraction):', err);
    return false;
  }
}

/**
 * Persist an audit log to Supabase table `audit_logs`
 */
export async function syncAuditLogToSupabase(log: AuditLog): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) return false;

  try {
    const { error } = await client.from('audit_logs').upsert({
      id: log.id,
      user_id: log.userId,
      user_email: log.userEmail,
      action_type: log.actionType,
      entity_type: log.entityType,
      details: log.details,
      status: log.status,
      timestamp: log.timestamp,
    });

    if (error) {
      console.warn('Supabase sync audit log notice:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase sync error (audit log):', err);
    return false;
  }
}

/**
 * Persist a voice command history record to Supabase table `voice_commands`
 */
export async function syncVoiceCommandToSupabase(command: VoiceCommandRecord): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) return false;

  try {
    const { error } = await client.from('voice_commands').upsert({
      id: command.id,
      user_id: command.userId || 'anonymous',
      command_text: command.commandText,
      action_type: command.actionType,
      target_document_title: command.targetDocumentTitle || null,
      model_used: command.modelUsed || 'gemini',
      status: command.status,
      result_url: command.resultUrl || null,
      result_summary: command.resultSummary || null,
      timestamp: command.timestamp,
      created_at: new Date(command.timestamp).toISOString(),
    });

    if (error) {
      console.warn('Supabase sync voice command notice:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase sync error (voice command):', err);
    return false;
  }
}

/**
 * Persist document metadata to Supabase table `document_metadata`
 */
export async function syncDocumentMetadataToSupabase(meta: DocumentMetadata): Promise<boolean> {
  const client = getSupabaseClient();
  if (!client) return false;

  try {
    const { error } = await client.from('document_metadata').upsert({
      id: meta.id,
      user_id: meta.userId,
      file_name: meta.fileName,
      file_size: meta.fileSize,
      mime_type: meta.mimeType,
      document_category: meta.documentCategory,
      key_entities: meta.keyEntities ? JSON.stringify(meta.keyEntities) : null,
      sheets_exported: meta.sheetsExported,
      docs_exported: meta.docsExported,
      created_at: meta.createdAt,
      updated_at: meta.updatedAt,
    });

    if (error) {
      console.warn('Supabase sync document metadata notice:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase sync error (document metadata):', err);
    return false;
  }
}

/**
 * SQL Schema migration statement for Supabase SQL Editor
 */
export const SUPABASE_SETUP_SQL = `-- Run this in your Supabase SQL Editor to create the tables for Lexi permanency:

create table if not exists public.extraction_records (
  id text primary key,
  user_id text not null,
  file_name text not null,
  file_type text,
  provider text,
  model_used text,
  summary text,
  fields_count integer default 0,
  tables_count integer default 0,
  extracted_data jsonb,
  status text default 'completed',
  created_at text not null
);

create table if not exists public.audit_logs (
  id text primary key,
  user_id text not null,
  user_email text,
  action_type text not null,
  entity_type text,
  details text,
  status text default 'success',
  timestamp text not null
);

create table if not exists public.voice_commands (
  id text primary key,
  user_id text not null,
  command_text text not null,
  action_type text not null,
  target_document_title text,
  model_used text,
  status text default 'success',
  result_url text,
  result_summary text,
  timestamp bigint,
  created_at text not null
);

create table if not exists public.document_metadata (
  id text primary key,
  user_id text not null,
  file_name text not null,
  file_size bigint default 0,
  mime_type text,
  document_category text,
  key_entities jsonb,
  sheets_exported boolean default false,
  docs_exported boolean default false,
  created_at text not null,
  updated_at text not null
);

-- Enable Row Level Security (RLS)
alter table public.extraction_records enable row level security;
alter table public.audit_logs enable row level security;
alter table public.voice_commands enable row level security;
alter table public.document_metadata enable row level security;

-- Create permissive policies for authenticated and anon users
create policy "Allow all operations for public.extraction_records" on public.extraction_records for all using (true) with check (true);
create policy "Allow all operations for public.audit_logs" on public.audit_logs for all using (true) with check (true);
create policy "Allow all operations for public.voice_commands" on public.voice_commands for all using (true) with check (true);
create policy "Allow all operations for public.document_metadata" on public.document_metadata for all using (true) with check (true);
`;
