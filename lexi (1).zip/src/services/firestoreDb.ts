import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  limit,
  getDocFromServer,
} from 'firebase/firestore';
import { auth, app } from './firebaseAuth';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  syncExtractionToSupabase,
  syncAuditLogToSupabase,
  syncVoiceCommandToSupabase,
  syncDocumentMetadataToSupabase,
} from './supabaseClient';
import { ExtractionRecord, AuditLog, DocumentMetadata, VoiceCommandRecord } from '../types';

// Initialize Cloud Firestore database instance with explicit database ID from config
export const db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);

// Test Firestore connection when requested (lazy, not executed on boot to prevent spurious network warnings)
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('Firebase Firestore connection verified successfully.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase Firestore client is offline or awaiting configuration.');
    } else {
      console.log('Firebase Firestore connection tested (rules applied).');
    }
    return false;
  }
}

/* -------------------------------------------------------------------------- */
/*                        HISTORIAL DE EXTRACCIONES                           */
/* -------------------------------------------------------------------------- */

export async function saveExtractionRecord(
  data: Omit<ExtractionRecord, 'id' | 'createdAt'>
): Promise<ExtractionRecord> {
  const user = auth.currentUser;
  const userId = user ? user.uid : (data.userId || 'anonymous');
  const extractionId = 'ext_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  const record: ExtractionRecord = {
    id: extractionId,
    ...data,
    userId,
    createdAt: now,
  };

  try {
    if (user && user.uid === userId) {
      const ref = doc(db, 'users', userId, 'extractions', extractionId);
      await setDoc(ref, record);
    }
  } catch (err) {
    console.warn('Could not persist extraction to Firebase cloud Firestore, saving locally:', err);
  }

  // Backup in local storage cache for offline responsiveness
  try {
    const key = `firebase_extractions_${userId}`;
    const cached = JSON.parse(localStorage.getItem(key) || '[]');
    cached.unshift(record);
    localStorage.setItem(key, JSON.stringify(cached.slice(0, 50)));
  } catch {}

  // Sync to Supabase for secondary cloud permanency
  syncExtractionToSupabase(record).catch(() => {});

  // Log audit event automatically
  await logAuditEvent({
    actionType: 'doc_extraction',
    entityType: 'document',
    details: `Extracción procesada para "${record.fileName}" usando ${record.modelUsed} (${record.fieldsCount} campos, ${record.tablesCount} tablas)`,
    status: 'success',
  }).catch(() => {});

  return record;
}

export async function getExtractionHistory(userId?: string): Promise<ExtractionRecord[]> {
  const currentUid = userId || auth.currentUser?.uid;
  if (!currentUid) {
    // Return local cached records
    try {
      return JSON.parse(localStorage.getItem('firebase_extractions_anonymous') || '[]');
    } catch {
      return [];
    }
  }

  try {
    const ref = collection(db, 'users', currentUid, 'extractions');
    const q = query(ref, orderBy('createdAt', 'desc'), limit(30));
    const snapshot = await getDocs(q);
    const results: ExtractionRecord[] = [];
    snapshot.forEach((d) => {
      results.push(d.data() as ExtractionRecord);
    });

    if (results.length > 0) {
      // Update local cache
      localStorage.setItem(`firebase_extractions_${currentUid}`, JSON.stringify(results));
      return results;
    }
  } catch (err) {
    console.warn('Error fetching extractions from Firestore:', err);
  }

  // Fallback to local cache
  try {
    return JSON.parse(localStorage.getItem(`firebase_extractions_${currentUid}`) || '[]');
  } catch {
    return [];
  }
}

export async function deleteExtractionRecord(extractionId: string): Promise<void> {
  const user = auth.currentUser;
  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'extractions', extractionId);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Error deleting extraction from Firestore:', err);
    }
    const key = `firebase_extractions_${user.uid}`;
    try {
      const cached: ExtractionRecord[] = JSON.parse(localStorage.getItem(key) || '[]');
      const filtered = cached.filter((r) => r.id !== extractionId);
      localStorage.setItem(key, JSON.stringify(filtered));
    } catch {}
  }
}

/* -------------------------------------------------------------------------- */
/*                            LOGS DE AUDITORÍA                               */
/* -------------------------------------------------------------------------- */

export async function logAuditEvent(params: {
  actionType: AuditLog['actionType'];
  entityType: AuditLog['entityType'];
  details: string;
  status?: 'success' | 'warning' | 'error';
}): Promise<AuditLog> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'system';
  const userEmail = user?.email || undefined;
  const logId = 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  const now = new Date().toISOString();

  const auditEntry: AuditLog = {
    id: logId,
    userId,
    userEmail,
    actionType: params.actionType,
    entityType: params.entityType,
    details: params.details,
    status: params.status || 'success',
    timestamp: now,
  };

  try {
    if (user) {
      const ref = doc(db, 'users', user.uid, 'audit_logs', logId);
      await setDoc(ref, auditEntry);
    }
  } catch (err) {
    console.warn('Could not persist audit log to Firestore:', err);
  }

  // Store in local cache
  try {
    const key = `firebase_audit_logs_${userId}`;
    const cached = JSON.parse(localStorage.getItem(key) || '[]');
    cached.unshift(auditEntry);
    localStorage.setItem(key, JSON.stringify(cached.slice(0, 100)));
  } catch {}

  // Sync to Supabase for audit trail permanency
  syncAuditLogToSupabase(auditEntry).catch(() => {});

  return auditEntry;
}

export async function getAuditLogs(limitCount: number = 50): Promise<AuditLog[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'system';

  if (user) {
    try {
      const ref = collection(db, 'users', user.uid, 'audit_logs');
      const q = query(ref, orderBy('timestamp', 'desc'), limit(limitCount));
      const snapshot = await getDocs(q);
      const logs: AuditLog[] = [];
      snapshot.forEach((d) => {
        logs.push(d.data() as AuditLog);
      });
      if (logs.length > 0) {
        localStorage.setItem(`firebase_audit_logs_${user.uid}`, JSON.stringify(logs));
        return logs;
      }
    } catch (err) {
      console.warn('Error fetching audit logs from Firestore:', err);
    }
  }

  try {
    return JSON.parse(localStorage.getItem(`firebase_audit_logs_${userId}`) || '[]');
  } catch {
    return [];
  }
}

/* -------------------------------------------------------------------------- */
/*                   METADATOS DE DOCUMENTOS PROCESADOS                       */
/* -------------------------------------------------------------------------- */

export async function saveDocumentMetadata(
  data: Omit<DocumentMetadata, 'id' | 'createdAt' | 'updatedAt'>
): Promise<DocumentMetadata> {
  const user = auth.currentUser;
  const userId = user ? user.uid : (data.userId || 'anonymous');
  const docId = 'meta_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  const metadata: DocumentMetadata = {
    id: docId,
    ...data,
    userId,
    createdAt: now,
    updatedAt: now,
  };

  try {
    if (user && user.uid === userId) {
      const ref = doc(db, 'users', userId, 'document_metadata', docId);
      await setDoc(ref, metadata);
    }
  } catch (err) {
    console.warn('Could not persist document metadata to Firestore:', err);
  }

  // Backup in local storage
  try {
    const key = `firebase_doc_metadata_${userId}`;
    const cached = JSON.parse(localStorage.getItem(key) || '[]');
    cached.unshift(metadata);
    localStorage.setItem(key, JSON.stringify(cached.slice(0, 50)));
  } catch {}

  // Sync to Supabase for document metadata permanency
  syncDocumentMetadataToSupabase(metadata).catch(() => {});

  return metadata;
}

export async function getDocumentMetadataList(): Promise<DocumentMetadata[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = collection(db, 'users', user.uid, 'document_metadata');
      const q = query(ref, orderBy('createdAt', 'desc'), limit(30));
      const snapshot = await getDocs(q);
      const list: DocumentMetadata[] = [];
      snapshot.forEach((d) => {
        list.push(d.data() as DocumentMetadata);
      });
      if (list.length > 0) {
        localStorage.setItem(`firebase_doc_metadata_${user.uid}`, JSON.stringify(list));
        return list;
      }
    } catch (err) {
      console.warn('Error fetching document metadata from Firestore:', err);
    }
  }

  try {
    return JSON.parse(localStorage.getItem(`firebase_doc_metadata_${userId}`) || '[]');
  } catch {
    return [];
  }
}

export async function deleteDocumentMetadata(id: string): Promise<void> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'document_metadata', id);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Error deleting document metadata from Firestore:', err);
    }
  }

  try {
    const key = `firebase_doc_metadata_${userId}`;
    const cached: DocumentMetadata[] = JSON.parse(localStorage.getItem(key) || '[]');
    const filtered = cached.filter((d) => d.id !== id);
    localStorage.setItem(key, JSON.stringify(filtered));
  } catch {}
}

export async function updateDocumentMetadata(
  id: string,
  updates: Partial<DocumentMetadata>
): Promise<void> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'document_metadata', id);
      await setDoc(ref, { ...updates, updatedAt: new Date().toISOString() }, { merge: true });
    } catch (err) {
      console.warn('Error updating document metadata in Firestore:', err);
    }
  }

  try {
    const key = `firebase_doc_metadata_${userId}`;
    const cached: DocumentMetadata[] = JSON.parse(localStorage.getItem(key) || '[]');
    const updatedList = cached.map((d) =>
      d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d
    );
    localStorage.setItem(key, JSON.stringify(updatedList));
  } catch {}
}

// Media Creations (Images & Veo 3 Videos)
export async function saveMediaCreation(record: {
  id?: string;
  type: 'image' | 'video';
  prompt: string;
  model: string;
  aspectRatio: string;
  mediaUrl: string;
  status: 'completed' | 'processing' | 'failed';
  hasStartingImage?: boolean;
}): Promise<any> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';
  const id = record.id || `media_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  const item = {
    ...record,
    id,
    userId,
    createdAt: new Date().toISOString(),
  };

  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'media_creations', id);
      await setDoc(ref, item);
    } catch (err) {
      console.warn('Could not persist media creation to Firestore:', err);
    }
  }

  try {
    const key = `firebase_media_${userId}`;
    const cached = JSON.parse(localStorage.getItem(key) || '[]');
    cached.unshift(item);
    localStorage.setItem(key, JSON.stringify(cached.slice(0, 50)));
  } catch {}

  return item;
}

export async function getMediaCreations(): Promise<any[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = collection(db, 'users', user.uid, 'media_creations');
      const q = query(ref, orderBy('createdAt', 'desc'), limit(30));
      const snapshot = await getDocs(q);
      const list: any[] = [];
      snapshot.forEach((d) => {
        list.push(d.data());
      });
      if (list.length > 0) {
        localStorage.setItem(`firebase_media_${user.uid}`, JSON.stringify(list));
        return list;
      }
    } catch (err) {
      console.warn('Error fetching media creations from Firestore:', err);
    }
  }

  try {
    return JSON.parse(localStorage.getItem(`firebase_media_${userId}`) || '[]');
  } catch {
    return [];
  }
}

// Chat Sessions (Multi-turn Gemini Chat)
export async function saveChatSession(session: {
  id?: string;
  title: string;
  model: string;
  role: string;
  messages: any[];
}): Promise<any> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';
  const id = session.id || `session_${Date.now()}`;

  const payload = {
    id,
    userId,
    title: session.title || 'Conversación Gemini',
    model: session.model,
    role: session.role,
    messagesCount: session.messages.length,
    messages: JSON.stringify(session.messages),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'chat_sessions', id);
      await setDoc(ref, payload, { merge: true });
    } catch (err) {
      console.warn('Could not persist chat session to Firestore:', err);
    }
  }

  try {
    const key = `firebase_chat_sessions_${userId}`;
    const cached = JSON.parse(localStorage.getItem(key) || '[]');
    const filtered = cached.filter((s: any) => s.id !== id);
    filtered.unshift(payload);
    localStorage.setItem(key, JSON.stringify(filtered.slice(0, 30)));
  } catch {}

  return payload;
}

export async function getChatSessions(): Promise<any[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = collection(db, 'users', user.uid, 'chat_sessions');
      const q = query(ref, orderBy('updatedAt', 'desc'), limit(20));
      const snapshot = await getDocs(q);
      const list: any[] = [];
      snapshot.forEach((d) => {
        list.push(d.data());
      });
      if (list.length > 0) {
        localStorage.setItem(`firebase_chat_sessions_${user.uid}`, JSON.stringify(list));
        return list;
      }
    } catch (err) {
      console.warn('Error fetching chat sessions from Firestore:', err);
    }
  }

  try {
    return JSON.parse(localStorage.getItem(`firebase_chat_sessions_${userId}`) || '[]');
  } catch {
    return [];
  }
}

/* -------------------------------------------------------------------------- */
/*                HISTORIAL DE COMANDOS DE VOZ DE LEXI EN DOCS               */
/* -------------------------------------------------------------------------- */

const DEFAULT_SAMPLE_COMMANDS: VoiceCommandRecord[] = [
  {
    id: 'cmd-sample-1',
    commandText: 'Crea un documento de Google Docs titulado "Plan de Estrategia y Objetivos 2026" con resumen ejecutivo, 3 metas clave y próximos pasos.',
    actionType: 'docs_create',
    targetDocumentTitle: 'Plan de Estrategia y Objetivos 2026',
    modelUsed: 'gemini-3.8-flash',
    status: 'executed',
    resultSummary: 'Documento creado y sincronizado en Google Drive con formato enriquecido.',
    timestamp: Date.now() - 1000 * 60 * 18,
  },
  {
    id: 'cmd-sample-2',
    commandText: 'Crea una hoja de cálculo en Google Sheets titulada "Presupuesto Operativo 2026" con columnas [Concepto, Categoría, Monto USD, Estado] y 4 filas de registros.',
    actionType: 'sheets_create',
    targetDocumentTitle: 'Presupuesto Operativo 2026',
    modelUsed: 'gemini-3.8-flash',
    status: 'executed',
    resultSummary: 'Hoja de cálculo creada con encabezados y 4 filas operativas.',
    timestamp: Date.now() - 1000 * 60 * 45,
  },
  {
    id: 'cmd-sample-3',
    commandText: 'Agrega a Google Sheets una fila con el gasto de suscripción de software de ingeniería: $149.00 hoy, categoría Cloud Tooling.',
    actionType: 'sheets_append',
    targetDocumentTitle: 'Presupuesto Operativo 2026',
    modelUsed: 'gemini-3.5-flash',
    status: 'executed',
    resultSummary: 'Registro insertado exitosamente en la fila 5.',
    timestamp: Date.now() - 1000 * 60 * 95,
  },
  {
    id: 'cmd-sample-4',
    commandText: 'Extrae los datos tabulares y el desglose de totales de la factura comercial para consolidar en la hoja de control financiero.',
    actionType: 'document_extract',
    targetDocumentTitle: 'Factura Comercial Consolidada',
    modelUsed: 'gemini-3.8-flash',
    status: 'executed',
    resultSummary: 'Extracción completada de 12 campos y 1 tabla contable.',
    timestamp: Date.now() - 1000 * 60 * 180,
  },
  {
    id: 'cmd-sample-5',
    commandText: 'Redacta un informe ejecutivo con resumen de prioridades, tareas pendientes y objetivos del trimestre.',
    actionType: 'docs_create',
    targetDocumentTitle: 'Informe Ejecutivo de Prioridades',
    modelUsed: 'gemini-3.1-pro-preview',
    status: 'executed',
    resultSummary: 'Documento estructurado generado y listo para sincronización con Google Docs.',
    timestamp: Date.now() - 1000 * 60 * 320,
  },
];

export async function saveCommandRecord(
  command: Omit<VoiceCommandRecord, 'id' | 'timestamp'> & { id?: string; timestamp?: number }
): Promise<VoiceCommandRecord> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';
  const id = command.id || `cmd_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const timestamp = command.timestamp || Date.now();

  const record: VoiceCommandRecord = {
    ...command,
    id,
    userId,
    timestamp,
  };

  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'command_history', id);
      await setDoc(ref, {
        ...record,
        createdAt: new Date(timestamp).toISOString(),
      });
    } catch (err) {
      console.warn('Could not persist voice command to Firestore:', err);
    }
  }

  try {
    const key = `lexi_command_history_${userId}`;
    const cached: VoiceCommandRecord[] = JSON.parse(localStorage.getItem(key) || '[]');
    // Evitar duplicados idénticos recientes
    const filtered = cached.filter((c) => c.id !== id);
    filtered.unshift(record);
    localStorage.setItem(key, JSON.stringify(filtered.slice(0, 100)));
  } catch {}

  // Sync to Supabase for voice command permanency
  syncVoiceCommandToSupabase(record).catch(() => {});

  return record;
}

export async function getCommandHistory(): Promise<VoiceCommandRecord[]> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = collection(db, 'users', user.uid, 'command_history');
      const q = query(ref, orderBy('timestamp', 'desc'), limit(50));
      const snapshot = await getDocs(q);
      const list: VoiceCommandRecord[] = [];
      snapshot.forEach((d) => {
        list.push(d.data() as VoiceCommandRecord);
      });
      if (list.length > 0) {
        localStorage.setItem(`lexi_command_history_${user.uid}`, JSON.stringify(list));
        return list;
      }
    } catch (err) {
      console.warn('Error fetching command history from Firestore:', err);
    }
  }

  try {
    const key = `lexi_command_history_${userId}`;
    const local = localStorage.getItem(key);
    if (local) {
      const parsed = JSON.parse(local);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {}

  // Fallback to initial contextual samples if empty
  return DEFAULT_SAMPLE_COMMANDS;
}

export async function deleteCommandRecord(id: string): Promise<void> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = doc(db, 'users', user.uid, 'command_history', id);
      await deleteDoc(ref);
    } catch (err) {
      console.warn('Error deleting command record from Firestore:', err);
    }
  }

  try {
    const key = `lexi_command_history_${userId}`;
    const cached: VoiceCommandRecord[] = JSON.parse(localStorage.getItem(key) || '[]');
    const filtered = cached.filter((c) => c.id !== id);
    localStorage.setItem(key, JSON.stringify(filtered));
  } catch {}
}

export async function clearCommandHistory(): Promise<void> {
  const user = auth.currentUser;
  const userId = user ? user.uid : 'anonymous';

  if (user) {
    try {
      const ref = collection(db, 'users', user.uid, 'command_history');
      const snapshot = await getDocs(ref);
      for (const d of snapshot.docs) {
        await deleteDoc(d.ref);
      }
    } catch (err) {
      console.warn('Error clearing command history from Firestore:', err);
    }
  }

  try {
    const key = `lexi_command_history_${userId}`;
    localStorage.setItem(key, JSON.stringify([]));
  } catch {}
}
