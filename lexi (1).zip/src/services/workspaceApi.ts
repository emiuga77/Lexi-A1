import { getAccessToken } from './firebaseAuth';
import { WorkspaceFile } from '../types';

async function getAuthHeaders(): Promise<Record<string, string>> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Google Workspace authentication required. Please sign in.');
  }
  return {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
}

// ---------------- GOOGLE DOCS ----------------

export async function listGoogleDocs(): Promise<WorkspaceFile[]> {
  const headers = await getAuthHeaders();
  const query = encodeURIComponent("mimeType='application/vnd.google-apps.document' and trashed=false");
  const response = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=modifiedTime desc&pageSize=20&fields=files(id,name,mimeType,modifiedTime,webViewLink)`,
    { headers }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to list documents: ${response.statusText}`);
  }

  const data = await response.json();
  return data.files || [];
}

export async function createGoogleDoc(title: string, initialContent?: string): Promise<{ id: string; title: string; url: string }> {
  const headers = await getAuthHeaders();
  
  // 1. Create the document
  const createRes = await fetch('https://docs.googleapis.com/v1/documents', {
    method: 'POST',
    headers,
    body: JSON.stringify({ title }),
  });

  if (!createRes.ok) {
    const err = await createRes.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to create Google Doc: ${createRes.statusText}`);
  }

  const doc = await createRes.json();
  const documentId = doc.documentId;

  // 2. Insert initial content if provided
  if (initialContent && initialContent.trim().length > 0) {
    const updateRes = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        requests: [
          {
            insertText: {
              location: { index: 1 },
              text: initialContent + '\n',
            },
          },
        ],
      }),
    });

    if (!updateRes.ok) {
      console.warn('Document created, but failed to insert initial text:', await updateRes.text());
    }
  }

  return {
    id: documentId,
    title,
    url: `https://docs.google.com/document/d/${documentId}/edit`,
  };
}

export async function appendToGoogleDoc(documentId: string, textToAppend: string): Promise<boolean> {
  const headers = await getAuthHeaders();
  const response = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      requests: [
        {
          insertText: {
            endOfSegmentLocation: {},
            text: '\n' + textToAppend + '\n',
          },
        },
      ],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to append text: ${response.statusText}`);
  }

  return true;
}

export async function readGoogleDoc(documentId: string): Promise<{ title: string; text: string }> {
  const headers = await getAuthHeaders();
  const response = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}`, {
    headers,
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to read document: ${response.statusText}`);
  }

  const data = await response.json();
  let fullText = '';

  if (data.body && data.body.content) {
    for (const element of data.body.content) {
      if (element.paragraph && element.paragraph.elements) {
        for (const pe of element.paragraph.elements) {
          if (pe.textRun && pe.textRun.content) {
            fullText += pe.textRun.content;
          }
        }
      }
    }
  }

  return {
    title: data.title || 'Untitled Document',
    text: fullText,
  };
}

export async function syncLocalDocToGoogleDrive(
  docId: string,
  title: string,
  content: string
): Promise<{ id: string; title: string; url: string }> {
  const result = await createGoogleDoc(title, content);
  try {
    const { updateDocumentMetadata } = await import('./firestoreDb');
    await updateDocumentMetadata(docId, {
      googleDocId: result.id,
      googleDriveUrl: result.url,
      docsExported: true,
    });
  } catch (err) {
    console.warn('Notice updating local metadata with Google Drive link:', err);
  }
  return result;
}

// ---------------- GOOGLE SHEETS ----------------

export async function listGoogleSheets(): Promise<WorkspaceFile[]> {
  const headers = await getAuthHeaders();
  const query = encodeURIComponent("mimeType='application/vnd.google-apps.spreadsheet' and trashed=false");
  const response = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=modifiedTime desc&pageSize=20&fields=files(id,name,mimeType,modifiedTime,webViewLink)`,
    { headers }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to list spreadsheets: ${response.statusText}`);
  }

  const data = await response.json();
  return data.files || [];
}

export async function createGoogleSheet(title: string, initialRows?: (string | number)[][]): Promise<{ id: string; title: string; url: string }> {
  const headers = await getAuthHeaders();

  const payload: any = {
    properties: { title },
  };

  if (initialRows && initialRows.length > 0) {
    payload.sheets = [
      {
        data: [
          {
            startRow: 0,
            startColumn: 0,
            rowData: initialRows.map((row) => ({
              values: row.map((cell) => ({
                userEnteredValue: typeof cell === 'number' ? { numberValue: cell } : { stringValue: String(cell) },
              })),
            })),
          },
        ],
      },
    ];
  }

  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to create Google Sheet: ${response.statusText}`);
  }

  const data = await response.json();
  return {
    id: data.spreadsheetId,
    title,
    url: `https://docs.google.com/spreadsheets/d/${data.spreadsheetId}/edit`,
  };
}

export async function appendSpreadsheetRow(
  spreadsheetId: string,
  rowValues: (string | number)[],
  sheetRange: string = 'Sheet1!A1'
): Promise<boolean> {
  const headers = await getAuthHeaders();
  const encodedRange = encodeURIComponent(sheetRange);

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodedRange}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        values: [rowValues],
      }),
    }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to append row: ${response.statusText}`);
  }

  return true;
}

export async function appendSpreadsheetRows(
  spreadsheetId: string,
  rows: (string | number)[][],
  sheetRange: string = 'Sheet1!A1'
): Promise<boolean> {
  if (!rows || rows.length === 0) return true;
  const headers = await getAuthHeaders();
  const encodedRange = encodeURIComponent(sheetRange);

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodedRange}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({
        values: rows,
      }),
    }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to append rows: ${response.statusText}`);
  }

  return true;
}

export async function readSpreadsheetValues(
  spreadsheetId: string,
  range: string = 'Sheet1!A1:Z50'
): Promise<{ range: string; values: string[][] }> {
  const headers = await getAuthHeaders();
  const encodedRange = encodeURIComponent(range);

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodedRange}`,
    { headers }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to read spreadsheet values: ${response.statusText}`);
  }

  const data = await response.json();
  return {
    range: data.range || range,
    values: data.values || [],
  };
}

export async function updateSpreadsheetCell(
  spreadsheetId: string,
  cellRange: string,
  value: string | number
): Promise<boolean> {
  const headers = await getAuthHeaders();
  const range = cellRange.includes('!') ? cellRange : `Sheet1!${cellRange}`;
  const encodedRange = encodeURIComponent(range);

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodedRange}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers,
      body: JSON.stringify({
        values: [[value]],
      }),
    }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to update cell ${cellRange}: ${response.statusText}`);
  }

  return true;
}

export async function updateSpreadsheetRange(
  spreadsheetId: string,
  range: string,
  values: (string | number)[][]
): Promise<boolean> {
  const headers = await getAuthHeaders();
  const fullRange = range.includes('!') ? range : `Sheet1!${range}`;
  const encodedRange = encodeURIComponent(fullRange);

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodedRange}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers,
      body: JSON.stringify({
        values,
      }),
    }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to update range ${range}: ${response.statusText}`);
  }

  return true;
}
