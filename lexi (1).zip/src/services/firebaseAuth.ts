import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Defined scopes matching user accepted permissions
export const SCOPES = [
  'https://www.googleapis.com/auth/documents',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/drive.file',
];

// Initialize Firebase App safely
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => {
  provider.addScope(scope);
});
provider.setCustomParameters({
  prompt: 'select_account',
});

// Flag to indicate if we are in the middle of a sign-in flow
let isSigningIn = false;
// Cache the access token in memory as required by Workspace integration guidelines, with session storage fallback
let cachedAccessToken: string | null = (typeof window !== 'undefined')
  ? sessionStorage.getItem('g_workspace_access_token')
  : null;

const notifyAuthChanged = (user: User | null) => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('workspace:auth_changed', {
        detail: {
          hasToken: Boolean(cachedAccessToken),
          user,
        },
      })
    );
  }
};

export const hasWorkspaceToken = (): boolean => {
  return Boolean(cachedAccessToken);
};

export const isWorkspaceConnected = (): boolean => {
  return Boolean(cachedAccessToken);
};

export const initAuth = (
  onAuthSuccess?: (user: User, token?: string) => void,
  onAuthFailure?: () => void
) => {
  try {
    return onAuthStateChanged(
      auth,
      async (user: User | null) => {
        if (user) {
          if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken || undefined);
          notifyAuthChanged(user);
        } else {
          cachedAccessToken = null;
          notifyAuthChanged(null);
          if (onAuthFailure) onAuthFailure();
        }
      },
      (error) => {
        console.warn('Firebase Auth state listener notice:', error);
        if (onAuthFailure) onAuthFailure();
      }
    );
  } catch (err) {
    console.warn('Firebase Auth initialization error:', err);
    if (onAuthFailure) onAuthFailure();
    return () => {};
  }
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Firebase Auth');
    }

    cachedAccessToken = credential.accessToken;
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.setItem('g_workspace_access_token', credential.accessToken);
      } catch (_) {}
    }
    notifyAuthChanged(result.user);
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    // Gracefully handle user cancellation, popup closure, or superseded popup requests
    if (
      error?.code === 'auth/popup-closed-by-user' ||
      error?.code === 'auth/cancelled-popup-request' ||
      error?.code === 'auth/user-cancelled'
    ) {
      // Benign user dismissal - not an application failure
      return null;
    }

    if (error?.code === 'auth/popup-blocked') {
      throw new Error('Sign-in popup was blocked by your browser. Please allow popups or open the app in a new tab.');
    }

    console.warn('Google sign-in could not be completed:', error?.message || error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  if (!cachedAccessToken && typeof window !== 'undefined') {
    try {
      cachedAccessToken = sessionStorage.getItem('g_workspace_access_token');
    } catch (_) {}
  }
  return cachedAccessToken;
};

export const logout = async () => {
  try {
    await signOut(auth);
  } catch (e) {
    console.warn('Logout notice:', e);
  }
  cachedAccessToken = null;
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.removeItem('g_workspace_access_token');
    } catch (_) {}
  }
  notifyAuthChanged(null);
};
