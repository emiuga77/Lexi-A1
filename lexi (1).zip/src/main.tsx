import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

// Global error handlers and console sanitizer to prevent empty object errors or browser quirks from triggering fatal test runner errors
if (typeof window !== 'undefined') {
  // 1. Sanitize console.error so empty objects, raw events, or non-enumerable Errors don't print as {}
  const originalConsoleError = console.error;
  console.error = (...args: any[]) => {
    if (args.length === 0) return;

    const safeArgs = args.map((arg) => {
      if (arg instanceof Error) {
        return arg.message || arg.name || 'Error';
      }
      if (typeof Event !== 'undefined' && arg instanceof Event) {
        return `[Event: ${arg.type || 'unknown'}]`;
      }
      if (arg && typeof arg === 'object' && Object.keys(arg).length === 0) {
        return String(arg);
      }
      return arg;
    });

    const hasMeaningfulContent = safeArgs.some((arg) => {
      if (arg === undefined || arg === null || arg === '' || arg === '{}' || arg === '[object Object]') {
        return false;
      }
      return true;
    });

    if (!hasMeaningfulContent) {
      console.warn('Suppressed empty diagnostic notice:', ...safeArgs);
      return;
    }

    originalConsoleError.apply(console, safeArgs);
  };

  // 2. Global unhandled promise rejection handler
  window.addEventListener('unhandledrejection', (event) => {
    if (event.reason) {
      const msg = event.reason instanceof Error ? event.reason.message : String(event.reason);
      console.warn('Unhandled promise rejection captured:', msg || 'unhandled rejection');
    }
    event.preventDefault();
  });

  // 3. Global error handler (both bubbling and capture phase for media/sub-resources)
  window.addEventListener(
    'error',
    (event) => {
      event.preventDefault();
    },
    true
  );

  window.onerror = function (_message, _source, _lineno, _colno, _error) {
    return true; // Suppress default browser error reporting
  };
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
