import { useState, useRef, useEffect, useCallback } from 'react';
import { OverlayView, parseVoiceNavigationCommand, isTurnOffMicCommand } from '../utils/commandParser';
import { getActiveProfile } from '../services/profileService';
import { calculateAudioRMS, rmsToNormalizedLevel } from '../utils/audio';
import { UserProfile } from '../types';
import {
  isAssistantEcho,
  isBargeInInterrupt,
  hasLexiKeyword,
  findBestNaturalVoice,
  protectUtterance,
} from '../utils/speechSynthesisHelper';

interface VoiceCommanderOptions {
  onNavigate: (view: OverlayView, feedback?: string) => void;
  onExecutePrompt: (prompt: string) => void;
}

export function useVoiceCommander({ onNavigate, onExecutePrompt }: VoiceCommanderOptions) {
  const [isMicOn, setIsMicOn] = useState<boolean>(false);
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [liveMicLevel, setLiveMicLevel] = useState<number>(0);
  const [isVoiceDetected, setIsVoiceDetected] = useState<boolean>(false);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  const isMicOnRef = useRef<boolean>(false);
  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isContinuousRef = useRef<boolean>(false);
  const silenceTimerRef = useRef<any>(null);
  const accumulatedTranscriptRef = useRef<string>('');
  const isSpeakingAssistantRef = useRef<boolean>(false);
  const echoCooldownUntilRef = useRef<number>(0);
  const lastExecutedPromptRef = useRef<string>('');
  const lastExecutedTimeRef = useRef<number>(0);
  const restartRetryCountRef = useRef<number>(0);

  const showFeedback = useCallback((msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => {
      setFeedbackToast((prev) => (prev === msg ? null : prev));
    }, 3500);
  }, []);

  const stopMicMonitoring = useCallback(() => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => track.stop());
      micStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (_) {}
      audioContextRef.current = null;
    }
    analyserRef.current = null;
    setLiveMicLevel(0);
    setIsVoiceDetected(false);
  }, []);

  const startMicMonitoring = useCallback(async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return;
      }
      if (micStreamRef.current && audioContextRef.current && audioContextRef.current.state !== 'closed') {
        return;
      }
      stopMicMonitoring();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      micStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);
      analyserRef.current = analyser;

      const buffer = new Float32Array(analyser.fftSize);

      const monitorLoop = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getFloatTimeDomainData(buffer);
        const rms = calculateAudioRMS(buffer);
        const level = rmsToNormalizedLevel(rms);
        setLiveMicLevel(level);

        const profile = getActiveProfile();
        const detected = level >= (profile?.noiseGateThreshold ?? 15);
        setIsVoiceDetected(detected);

        animFrameRef.current = requestAnimationFrame(monitorLoop);
      };

      monitorLoop();
    } catch (err) {
      console.warn('Microphone access warning:', err);
    }
  }, [stopMicMonitoring]);

  const interruptSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (_) {}
    }
    isSpeakingAssistantRef.current = false;
    window.dispatchEvent(new CustomEvent('voiceflow:stop_speaking'));
    if (!isMicOnRef.current) {
      setVoiceStatus('idle');
    }
  }, []);

  const stopListening = useCallback(() => {
    isMicOnRef.current = false;
    setIsMicOn(false);
    isContinuousRef.current = false;
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    accumulatedTranscriptRef.current = '';
    if (recognitionRef.current) {
      const rec = recognitionRef.current;
      recognitionRef.current = null;
      try {
        rec.stop();
      } catch (_) {}
    }
    stopMicMonitoring();
    setInterimTranscript('');
    setVoiceStatus('idle');
    // Stop assistant from speaking when microphone is turned off
    interruptSpeaking();
    window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
  }, [stopMicMonitoring, interruptSpeaking]);

  const startListening = useCallback(async () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      showFeedback('Reconocimiento de voz no soportado en este navegador.');
      return;
    }

    // Stop any existing speech before opening microphone
    interruptSpeaking();

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (_) {}
        recognitionRef.current = null;
      }

      isMicOnRef.current = true;
      setIsMicOn(true);
      isContinuousRef.current = true;

      const profile: UserProfile = getActiveProfile();
      const recognition = new SpeechRecognition();
      recognition.lang = profile.language || 'es-ES';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognitionRef.current = recognition;

      recognition.onstart = () => {
        setVoiceStatus('listening');
        startMicMonitoring();
        window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: true } }));
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const candidate = (final || interim).trim();

        // 0. Interruption Handling:
        // When assistant is speaking, strictly enforce that ONLY explicit keyword "Lexi" can interrupt
        if (isSpeakingAssistantRef.current) {
          if (candidate && (hasLexiKeyword(candidate) || isBargeInInterrupt(candidate))) {
            console.log('[VoiceCommander] Explicit Lexi keyword detected from user. Stopping assistant speech.');
            interruptSpeaking();
            setInterimTranscript(candidate);
            accumulatedTranscriptRef.current = candidate;
          } else {
            // Ignore ambient noise / speaker bleed so assistant is never interrupted accidentally
            return;
          }
        }

        // Anti-Echo & Anti-Loop Shield:
        // Discard speaker reverberation or assistant self-hearing frames
        if (Date.now() < echoCooldownUntilRef.current) {
          return;
        }
        if (candidate && isAssistantEcho(candidate)) {
          console.log('[VoiceCommander] Discarded assistant voice echo:', candidate);
          return;
        }

        // Check for explicit voice command to turn off microphone: "adios", "descansa", etc.
        if (candidate && isTurnOffMicCommand(candidate)) {
          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
            silenceTimerRef.current = null;
          }
          setInterimTranscript('');
          accumulatedTranscriptRef.current = '';

          showFeedback('Descansando. Micrófono apagado.');

          if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
            try {
              window.speechSynthesis.cancel();
              const utt = new SpeechSynthesisUtterance('Hasta luego. Descansando.');
              utt.lang = profile.language || 'es-ES';
              const bestVoice = findBestNaturalVoice(profile.language || 'es-ES');
              if (bestVoice) utt.voice = bestVoice;
              utt.rate = 1.0;
              utt.pitch = 1.0;
              protectUtterance(utt);
              window.speechSynthesis.speak(utt);
            } catch (_) {}
          }

          stopListening();
          return;
        }

        // 1. Check for immediate Voice Navigation (Instant execution with zero lag)
        if (candidate) {
          const navResult = parseVoiceNavigationCommand(candidate);
          if (navResult.isNavCommand) {
            if (silenceTimerRef.current) {
              clearTimeout(silenceTimerRef.current);
              silenceTimerRef.current = null;
            }
            setInterimTranscript('');
            accumulatedTranscriptRef.current = '';

            if (navResult.isTurnOffMicCommand) {
              showFeedback('Descansando. Micrófono apagado.');
              if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                try {
                  window.speechSynthesis.cancel();
                  const utt = new SpeechSynthesisUtterance('Hasta luego. Descansando.');
                  utt.lang = profile.language || 'es-ES';
                  const bestVoice = findBestNaturalVoice(profile.language || 'es-ES');
                  if (bestVoice) utt.voice = bestVoice;
                  utt.rate = 1.0;
                  utt.pitch = 1.0;
                  protectUtterance(utt);
                  window.speechSynthesis.speak(utt);
                } catch (_) {}
              }
              stopListening();
              return;
            }

            if (navResult.isCloseCommand || navResult.targetView === 'ORB_ONLY') {
              onNavigate('ORB_ONLY', 'Volviendo al orbe central...');
              showFeedback('Volviendo al orbe central...');
            } else if (navResult.targetView) {
              onNavigate(navResult.targetView, navResult.feedbackMessage);
              showFeedback(navResult.feedbackMessage || 'Desplegando vista...');
            }
            return;
          }
        }

        if (final.trim()) {
          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
            silenceTimerRef.current = null;
          }
          const spoken = final.trim();
          setInterimTranscript('');
          accumulatedTranscriptRef.current = '';

          // Anti-Echo & Anti-Loop Shield verification
          if (isAssistantEcho(spoken)) {
            return;
          }
          if (spoken === lastExecutedPromptRef.current && Date.now() - lastExecutedTimeRef.current < 3500) {
            return;
          }

          // Extra safety check for turn-off commands
          if (isTurnOffMicCommand(spoken)) {
            showFeedback('Descansando. Micrófono apagado.');
            if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
              try {
                window.speechSynthesis.cancel();
                const utt = new SpeechSynthesisUtterance('Hasta luego. Descansando.');
                utt.lang = profile.language || 'es-ES';
                const bestVoice = findBestNaturalVoice(profile.language || 'es-ES');
                if (bestVoice) utt.voice = bestVoice;
                utt.rate = 1.0;
                utt.pitch = 1.0;
                protectUtterance(utt);
                window.speechSynthesis.speak(utt);
              } catch (_) {}
            }
            stopListening();
            return;
          }

          // Execute prompt with AI assistant (microphone remains ON)
          lastExecutedPromptRef.current = spoken;
          lastExecutedTimeRef.current = Date.now();
          setVoiceStatus('thinking');
          showFeedback(`Procesando: "${spoken.slice(0, 35)}..."`);
          onExecutePrompt(spoken);
        } else if (interim.trim()) {
          setInterimTranscript(interim);
          accumulatedTranscriptRef.current = interim.trim();

          // Adaptive silence debounce:
          // Short phrases (1-3 words) respond in ~900ms; longer thoughts get ~1350ms
          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
          }
          const wordsCount = interim.trim().split(/\s+/).length;
          const adaptiveSilenceDelay = wordsCount <= 3 ? 900 : 1350;

          silenceTimerRef.current = setTimeout(() => {
            const pending = accumulatedTranscriptRef.current;
            if (pending && pending.length > 2) {
              accumulatedTranscriptRef.current = '';
              setInterimTranscript('');

              if (isAssistantEcho(pending)) {
                return;
              }
              if (pending === lastExecutedPromptRef.current && Date.now() - lastExecutedTimeRef.current < 3500) {
                return;
              }

              if (isTurnOffMicCommand(pending)) {
                showFeedback('Descansando. Micrófono apagado.');
                stopListening();
                return;
              }

              const navResult = parseVoiceNavigationCommand(pending);
              if (navResult.isNavCommand) {
                if (navResult.isCloseCommand || navResult.targetView === 'ORB_ONLY') {
                  onNavigate('ORB_ONLY', 'Volviendo al orbe central...');
                  showFeedback('Volviendo al orbe central...');
                } else if (navResult.targetView) {
                  onNavigate(navResult.targetView, navResult.feedbackMessage);
                  showFeedback(navResult.feedbackMessage || 'Desplegando vista...');
                }
              } else {
                lastExecutedPromptRef.current = pending;
                lastExecutedTimeRef.current = Date.now();
                setVoiceStatus('thinking');
                showFeedback(`Procesando: "${pending.slice(0, 35)}..."`);
                onExecutePrompt(pending);
              }
            }
          }, adaptiveSilenceDelay);
        }
      };

      recognition.onerror = (event: any) => {
        const error = event.error;
        if (error === 'not-allowed' || error === 'service-not-allowed') {
          isContinuousRef.current = false;
          showFeedback('Permiso de micrófono no concedido. Habilita el acceso en el navegador.');
          stopListening();
          return;
        }
        if (error === 'network') {
          console.warn('Speech recognition network notice:', error);
          return;
        }
        if (error !== 'no-speech' && error !== 'aborted') {
          console.warn('Speech recognition notice:', error);
        }
      };

      recognition.onend = () => {
        if (isMicOnRef.current && !isSpeakingAssistantRef.current) {
          // Restart with a safe debounce to cycle engine cleanly
          setTimeout(() => {
            if (isMicOnRef.current && !isSpeakingAssistantRef.current) {
              try {
                recognition.start();
              } catch (_) {}
            }
          }, 180);
        } else if (!isMicOnRef.current) {
          stopListening();
        }
      };

      recognition.start();
    } catch (err: any) {
      console.warn('Error starting speech listener:', err);
      stopListening();
    }
  }, [onNavigate, onExecutePrompt, showFeedback, startMicMonitoring, stopListening, interruptSpeaking]);

  // Primer click: Prendido. Solo se apaga con el segundo click o con un comando de voz ("adiós", "descansa").
  const toggleListening = useCallback(() => {
    if (isMicOnRef.current) {
      // Segundo click: apagar
      interruptSpeaking();
      stopListening();
      showFeedback('Micrófono apagado. Orbe diluido.');
    } else {
      // Primer click: prender
      interruptSpeaking();
      startListening();
      showFeedback('Micrófono prendido. Te escucho...');
    }
  }, [startListening, stopListening, interruptSpeaking, showFeedback]);

  // Listen for global assistant state changes ('thinking', 'speaking', 'idle')
  useEffect(() => {
    const handleStatusSync = (e: Event) => {
      const custom = e as CustomEvent<{ status: 'idle' | 'listening' | 'thinking' | 'speaking' }>;
      const newStatus = custom.detail?.status;
      if (newStatus) {
        if (newStatus === 'speaking') {
          isSpeakingAssistantRef.current = true;
          setVoiceStatus('speaking');
        } else if (newStatus === 'thinking') {
          setVoiceStatus('thinking');
        } else if (newStatus === 'idle') {
          isSpeakingAssistantRef.current = false;
          echoCooldownUntilRef.current = Date.now() + 650;
          accumulatedTranscriptRef.current = '';
          setInterimTranscript('');
          if (isMicOnRef.current) {
            // Asistente terminó de hablar; el micrófono sigue PRENDIDO: vuelve a escuchar
            setVoiceStatus('listening');
            if (recognitionRef.current) {
              try {
                recognitionRef.current.start();
              } catch (_) {}
            }
          } else {
            setVoiceStatus('idle');
          }
        } else {
          setVoiceStatus(newStatus);
        }
      }
    };

    const handleRemoteStop = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch (_) {}
      }
      isSpeakingAssistantRef.current = false;
      echoCooldownUntilRef.current = Date.now() + 400;
      accumulatedTranscriptRef.current = '';
      setInterimTranscript('');
      if (isMicOnRef.current) {
        setVoiceStatus('listening');
      } else {
        setVoiceStatus('idle');
      }
    };

    window.addEventListener('voiceflow:status_changed', handleStatusSync);
    window.addEventListener('voiceflow:stop_speaking', handleRemoteStop);
    return () => {
      window.removeEventListener('voiceflow:status_changed', handleStatusSync);
      window.removeEventListener('voiceflow:stop_speaking', handleRemoteStop);
    };
  }, []);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopListening();
    };
  }, [stopListening]);

  return {
    isMicOn,
    voiceStatus,
    setVoiceStatus,
    liveMicLevel,
    isVoiceDetected,
    interimTranscript,
    feedbackToast,
    showFeedback,
    startListening,
    stopListening,
    toggleListening,
    interruptSpeaking,
  };
}
