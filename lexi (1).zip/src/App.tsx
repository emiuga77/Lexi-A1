import React, { useState, useEffect, useCallback } from 'react';
import { User } from 'firebase/auth';
import { AlertCircle, X, Maximize2, Minimize2 } from 'lucide-react';
import { initAuth, googleSignIn, logout as firebaseLogout, isWorkspaceConnected } from './services/firebaseAuth';
import { ChatMessage, PendingActionConfirmation } from './types';
import { OrbCanvasView } from './components/OrbCanvasView';
import { CinematicOverlayDrawer } from './components/CinematicOverlayDrawer';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { VoiceAssistantHub } from './components/VoiceAssistantHub';
import { DocumentExtractorStudio } from './components/DocumentExtractorStudio';
import { GoogleDocsManager } from './components/GoogleDocsManager';
import { GoogleSheetsManager } from './components/GoogleSheetsManager';
import { ImageStudio } from './components/ImageStudio';
import { RealEstateStudio } from './components/RealEstateStudio';
import { CommandHistoryModal } from './components/CommandHistoryModal';
import { DataPermanencyModal } from './components/DataPermanencyModal';
import { ProfileModal } from './components/ProfileModal';
import { ConfirmationModal } from './components/ConfirmationModal';
import { ThemeProvider } from './context/ThemeContext';
import { OverlayView } from './utils/commandParser';
import { useVoiceCommander } from './hooks/useVoiceCommander';

function AppContent() {
  // Starts strictly in 'ORB_ONLY' on a pure black background
  const [activeOverlay, setActiveOverlay] = useState<OverlayView>('ORB_ONLY');
  const [user, setUser] = useState<User | null>(null);
  const [hasWorkspaceAuth, setHasWorkspaceAuth] = useState<boolean>(() => isWorkspaceConnected());
  const [isLiveConnected, setIsLiveConnected] = useState(false);
  const [authNotice, setAuthNotice] = useState<{ message: string; type: 'info' | 'warning' | 'error' } | null>(null);

  // Global Multi-turn Chat messages
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  // Chat Sidebar Resizing State ("sider")
  const [sidebarWidth, setSidebarWidth] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('lexi_chat_sidebar_width');
      if (saved) {
        const val = parseInt(saved, 10);
        if (!isNaN(val) && val >= 360 && val <= 1400) return val;
      }
    } catch {
      // ignore
    }
    return 560;
  });
  const [isSidebarMaximized, setIsSidebarMaximized] = useState(false);
  const [isResizingSidebar, setIsResizingSidebar] = useState(false);

  // Save custom width to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('lexi_chat_sidebar_width', sidebarWidth.toString());
    } catch {
      // ignore
    }
  }, [sidebarWidth]);

  // Resizing mouse & touch drag handlers
  const handleStartResize = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsResizingSidebar(true);
    setIsSidebarMaximized(false);

    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const startX = clientX;
    const startWidth = sidebarWidth;

    const onMove = (moveEvent: MouseEvent | TouchEvent) => {
      const currentX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const delta = startX - currentX; // Dragging to the left increases width
      const maxAllowed = Math.max(400, window.innerWidth - 24);
      const newWidth = Math.min(maxAllowed, Math.max(360, startWidth + delta));
      setSidebarWidth(newWidth);
    };

    const onEnd = () => {
      setIsResizingSidebar(false);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onEnd);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onEnd);
    window.addEventListener('touchmove', onMove);
    window.addEventListener('touchend', onEnd);
  }, [sidebarWidth]);

  // Mandatory user confirmation modal for mutating operations
  const [pendingAction, setPendingAction] = useState<PendingActionConfirmation | null>(null);
  const [isExecutingAction, setIsExecutingAction] = useState(false);

  // Initialize Auth state listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, token) => {
        setUser(currentUser);
        setHasWorkspaceAuth(Boolean(token || isWorkspaceConnected()));
      },
      () => {
        setUser(null);
        setHasWorkspaceAuth(false);
      }
    );

    const handleWorkspaceAuthEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ hasToken: boolean; user: User | null }>;
      setHasWorkspaceAuth(Boolean(customEvent.detail?.hasToken));
      if (customEvent.detail?.user !== undefined) {
        setUser(customEvent.detail.user);
      }
    };
    window.addEventListener('workspace:auth_changed', handleWorkspaceAuthEvent);

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      window.removeEventListener('workspace:auth_changed', handleWorkspaceAuthEvent);
    };
  }, []);

  const isWorkspaceAuthenticated = Boolean(user && hasWorkspaceAuth);

  const handleLogin = async () => {
    setAuthNotice(null);
    try {
      const res = await googleSignIn();
      if (res?.user) {
        setUser(res.user);
        setHasWorkspaceAuth(Boolean(res.accessToken));
        setAuthNotice(null);
      }
    } catch (err: any) {
      const message = err?.message || 'Unable to sign in. Please try again.';
      setAuthNotice({ message, type: 'warning' });
    }
  };

  const handleLogout = async () => {
    try {
      await firebaseLogout();
      setUser(null);
      setHasWorkspaceAuth(false);
      setAuthNotice(null);
    } catch (err: any) {
      console.warn('Logout issue:', err?.message || err);
    }
  };

  // Trigger explicit user confirmation before any mutating action
  const handleRequestAction = (action: PendingActionConfirmation) => {
    setPendingAction({
      ...action,
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          await action.onConfirm();
          setPendingAction(null);
        } catch (e: any) {
          console.warn('Error executing confirmed action:', e?.message || e);
        } finally {
          setIsExecutingAction(false);
        }
      },
      onCancel: () => {
        action.onCancel();
        setPendingAction(null);
      },
    });
  };

  const handleNavigate = useCallback(
    (view: OverlayView, _feedback?: string) => {
      setActiveOverlay(view);
    },
    []
  );

  const handlePromptExecution = useCallback((prompt: string) => {
    // El sidebar no tiene que ser abierto para que la asistente de voz conteste:
    // Se procesa y responde por voz directamente sin forzar la apertura del sidebar
    window.dispatchEvent(new CustomEvent('voiceflow:execute_prompt', { detail: { prompt } }));
  }, []);

  // Central Voice Commander Hook
  const {
    isMicOn,
    voiceStatus,
    liveMicLevel,
    isVoiceDetected,
    interimTranscript,
    feedbackToast,
    toggleListening,
    interruptSpeaking,
  } = useVoiceCommander({
    onNavigate: handleNavigate,
    onExecutePrompt: handlePromptExecution,
  });

  // Global Keyboard Shortcuts: Ctrl+K / Cmd+K and Esc to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setActiveOverlay((prev) => (prev === 'COMMAND_PALETTE' ? 'ORB_ONLY' : 'COMMAND_PALETTE'));
      }
      if (e.key === 'Escape' && activeOverlay !== 'ORB_ONLY') {
        setActiveOverlay('ORB_ONLY');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeOverlay]);

  return (
    <div className="relative w-screen h-screen min-h-screen overflow-hidden bg-black text-white font-sans select-none">
      {/* 1. Cinematic Orb Canvas: Always rendered as pure black full-screen foundation */}
      <OrbCanvasView
        onNavigate={handleNavigate}
        user={user}
        isWorkspaceConnected={isWorkspaceAuthenticated}
        onLogin={handleLogin}
        onLogout={handleLogout}
        onExecutePrompt={handlePromptExecution}
        voiceStatus={voiceStatus}
        liveMicLevel={liveMicLevel}
        isVoiceDetected={isVoiceDetected}
        isMicOn={isMicOn}
        interimTranscript={interimTranscript}
        onToggleListen={toggleListening}
        onInterruptSpeaking={interruptSpeaking}
        feedbackToast={feedbackToast}
      />

      {/* Dismissible Notice Banner (if any auth notification occurs) */}
      {authNotice && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 text-xs flex items-center gap-2.5 rounded-2xl bg-amber-950/90 border border-amber-500/40 text-amber-200 shadow-xl backdrop-blur-md animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{authNotice.message}</span>
          <button
            type="button"
            onClick={() => setAuthNotice(null)}
            className="p-1 hover:text-white rounded cursor-pointer ml-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 2. Slide-out Chat Sidebar ("Abre sidebar con chat") with resizable width */}
      <aside
        id="lexi-chat-sidebar"
        style={{
          width: isSidebarMaximized ? '100vw' : `${sidebarWidth}px`,
          maxWidth: '100vw',
        }}
        className={`fixed top-0 right-0 bottom-0 z-40 bg-slate-950/98 border-l border-cyan-500/30 backdrop-blur-2xl shadow-2xl shadow-black flex flex-col ${
          isResizingSidebar ? 'select-none transition-none' : 'transition-transform duration-300 ease-in-out'
        } ${
          activeOverlay === 'CHAT_SIDEBAR' || activeOverlay === 'CHAT'
            ? 'translate-x-0 pointer-events-auto'
            : 'translate-x-full pointer-events-none'
        }`}
      >
        {/* Left Interactive Resize Handle ("sider") */}
        <div
          id="chat-sidebar-resizer"
          onMouseDown={handleStartResize}
          onTouchStart={handleStartResize}
          onDoubleClick={() => {
            setIsSidebarMaximized(false);
            setSidebarWidth(560);
          }}
          title="Arrastra para ajustar el tamaño del chat (Doble clic: restablecer a 560px)"
          className="absolute top-0 -left-2.5 bottom-0 w-5 cursor-col-resize z-50 flex items-center justify-center group touch-none select-none"
        >
          <div
            className={`w-1 rounded-full transition-all ${
              isResizingSidebar
                ? 'h-36 bg-cyan-400 shadow-[0_0_12px_#22d3ee]'
                : 'h-16 bg-cyan-500/40 group-hover:bg-cyan-400 group-hover:h-24 group-hover:shadow-[0_0_8px_#22d3ee]'
            }`}
          />
        </div>

        {/* Sidebar Header */}
        <div className="px-4 py-3 border-b border-cyan-500/20 bg-slate-950/90 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] animate-pulse shrink-0" />
            <div className="truncate">
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-white truncate">Chat con Lexi</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                  {isSidebarMaximized ? '100%' : `${sidebarWidth}px`}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Quick Size Presets */}
            <div className="hidden sm:flex items-center gap-1 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 text-[10px] font-mono">
              <button
                type="button"
                onClick={() => {
                  setIsSidebarMaximized(false);
                  setSidebarWidth(420);
                }}
                className={`px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
                  !isSidebarMaximized && sidebarWidth <= 460
                    ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Tamaño Compacto (420px)"
              >
                420
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsSidebarMaximized(false);
                  setSidebarWidth(560);
                }}
                className={`px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
                  !isSidebarMaximized && sidebarWidth > 460 && sidebarWidth <= 680
                    ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Tamaño Estándar (560px)"
              >
                560
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsSidebarMaximized(false);
                  setSidebarWidth(850);
                }}
                className={`px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
                  !isSidebarMaximized && sidebarWidth > 680
                    ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Tamaño Amplio (850px)"
              >
                850
              </button>
            </div>

            {/* Maximize / Restore Toggle */}
            <button
              type="button"
              onClick={() => setIsSidebarMaximized(!isSidebarMaximized)}
              className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:border-cyan-400/50 transition-colors cursor-pointer"
              title={isSidebarMaximized ? 'Restaurar ancho de chat' : 'Maximizar chat a pantalla completa'}
            >
              {isSidebarMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>

            {/* Close / Hide Button */}
            <button
              type="button"
              onClick={() => setActiveOverlay('ORB_ONLY')}
              className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Cerrar chat (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sidebar Content */}
        <div className="flex-1 overflow-hidden flex flex-col">
          <VoiceAssistantHub
            messages={messages}
            setMessages={setMessages}
            onRequestAction={handleRequestAction}
            isAuthenticated={isWorkspaceAuthenticated}
            onPromptLogin={handleLogin}
            isLiveConnected={isLiveConnected}
            setIsLiveConnected={setIsLiveConnected}
            onNavigateOverlay={handleNavigate}
          />
        </div>
      </aside>

      {/* 3. Secondary Command Palette (Ctrl+K / Cmd+K or 'Comandos' Button) */}
      <CommandPaletteModal
        isOpen={activeOverlay === 'COMMAND_PALETTE'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
        onSelectView={handleNavigate}
        onVoiceCommandPrompt={toggleListening}
      />

      {/* 4. Cinematic Overlay Drawer for Other Fullscreen Modules */}
      <CinematicOverlayDrawer
        activeView={activeOverlay}
        onClose={() => setActiveOverlay('ORB_ONLY')}
        voiceStatus={voiceStatus}
        liveMicLevel={liveMicLevel}
        isVoiceDetected={isVoiceDetected}
        isMicOn={isMicOn}
        onToggleListen={toggleListening}
      >
        {activeOverlay === 'SHEETS' && (
          <div className="h-full overflow-y-auto">
            <GoogleSheetsManager
              isAuthenticated={isWorkspaceAuthenticated}
              onPromptLogin={handleLogin}
              onRequestAction={handleRequestAction}
            />
          </div>
        )}

        {activeOverlay === 'DOCS' && (
          <div className="h-full overflow-y-auto">
            <GoogleDocsManager
              isAuthenticated={isWorkspaceAuthenticated}
              onPromptLogin={handleLogin}
              onRequestAction={handleRequestAction}
            />
          </div>
        )}

        {activeOverlay === 'EXTRACTOR' && (
          <div className="h-full overflow-y-auto">
            <DocumentExtractorStudio
              isAuthenticated={isWorkspaceAuthenticated}
              onPromptLogin={handleLogin}
              onRequestAction={handleRequestAction}
            />
          </div>
        )}

        {activeOverlay === 'IMAGES' && (
          <div className="h-full overflow-y-auto">
            <ImageStudio />
          </div>
        )}

        {activeOverlay === 'REAL_ESTATE' && (
          <div className="h-full flex flex-col overflow-hidden">
            <RealEstateStudio />
          </div>
        )}
      </CinematicOverlayDrawer>

      {/* 5. Specialized Modals (History, Database, Profile) */}
      <CommandHistoryModal
        isOpen={activeOverlay === 'HISTORY'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
        onReExecute={(cmd) => handlePromptExecution(cmd)}
      />

      <DataPermanencyModal
        isOpen={activeOverlay === 'DATABASE'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
      />

      <ProfileModal
        isOpen={activeOverlay === 'PROFILE'}
        onClose={() => setActiveOverlay('ORB_ONLY')}
      />

      {/* Mandatory User Confirmation Modal for Destructive/Mutating Workspace API Calls */}
      <ConfirmationModal action={pendingAction} isLoading={isExecutingAction} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
