export interface FileAttachment {
  name: string;
  type: string;
  size: number;
  data: string; // base64 string
  previewUrl?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  modelUsed?: string;
  providerUsed?: 'gemini' | 'groq';
  usedThinking?: boolean;
  groundingSources?: { title: string; uri: string }[];
  attachment?: FileAttachment;
  actionProposal?: WorkflowActionProposal;
}

export interface MediaCreationRecord {
  id: string;
  userId: string;
  type: 'image' | 'video';
  prompt: string;
  model: string;
  aspectRatio: string;
  mediaUrl: string;
  status: 'completed' | 'processing' | 'failed';
  hasStartingImage?: boolean;
  createdAt: string;
}

export interface ChatSessionRecord {
  id: string;
  userId: string;
  title: string;
  model: string;
  role: string;
  messagesCount: number;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface WorkflowActionProposal {
  type: 'docs_create' | 'docs_append' | 'sheets_create' | 'sheets_append' | 'generate_image';
  title: string;
  description: string;
  payload: Record<string, any>;
  status: 'pending_confirmation' | 'approved' | 'executed' | 'cancelled';
  url?: string;
  resultLink?: string;
  resultMessage?: string;
}

export interface UploadedDocumentFile {
  id: string;
  name: string;
  type: string;
  size: number;
  data: string; // base64
  previewUrl?: string;
}

export interface ExtractedDocumentData {
  documentType: string;
  documentSummary: string;
  keyDataPoints: { label: string; value: string }[];
  crossDocumentInsights?: string[];
  sourceFilesCount?: number;
  sourceFileNames?: string[];
  docsContent: {
    title: string;
    formattedText: string;
    markdown: string;
  };
  sheetsData: {
    title: string;
    headers: string[];
    rows: (string | number)[][];
    sheetName?: string;
  };
  suggestedActions: string[];
}

export interface WorkspaceFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
  webViewLink?: string;
}

export interface PendingActionConfirmation {
  id: string;
  type: 'docs_create' | 'docs_append' | 'sheets_create' | 'sheets_append';
  title: string;
  targetName?: string;
  targetId?: string;
  details: {
    label: string;
    value: string | string[];
  }[];
  onConfirm: () => Promise<void>;
  onCancel: () => void;
}

export type AssistantRole = 
  | 'executive'
  | 'docs_specialist'
  | 'sheets_analyst'
  | 'creative_designer'
  | 'realestate_researcher';

export type GeminiModelTier =
  | 'gemini-3.8-flash'
  | 'gemini-3.5-flash'
  | 'gemini-3.1-pro-preview'
  | 'gemini-3.1-flash-lite'
  | 'gemini-flash-latest'
  | 'gemini-2.5-flash';

export type GroqModelTier =
  | 'llama-3.3-70b-versatile'
  | 'llama-3.1-8b-instant'
  | 'llama-3.2-11b-vision-preview'
  | 'llama-3.2-90b-vision-preview'
  | 'openai/gpt-oss-120b'
  | 'groq/compound'
  | string;

export type AIProvider = 'gemini' | 'groq';

export type SupportedModelTier = GeminiModelTier | GroqModelTier;

export interface ExtractionRecord {
  id: string;
  userId: string;
  fileName: string;
  fileType: string;
  provider: string;
  modelUsed: string;
  summary: string;
  fieldsCount: number;
  tablesCount: number;
  extractedData?: string;
  status: 'completed' | 'failed' | 'partial';
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail?: string;
  actionType: 
    | 'doc_extraction' 
    | 'google_doc_created' 
    | 'google_doc_appended'
    | 'google_sheet_created' 
    | 'google_sheet_appended' 
    | 'voice_command_executed'
    | 'profile_created'
    | 'profile_updated'
    | 'profile_deleted'
    | 'profile_switched'
    | 'voice_calibrated'
    | 'user_login' 
    | 'user_logout';
  entityType: 'document' | 'spreadsheet' | 'note' | 'session' | 'system' | 'profile';
  details: string;
  status: 'success' | 'warning' | 'error';
  timestamp: string;
}

export interface UserProfile {
  id: string;
  userId?: string;
  name: string;
  role: string;
  language: 'es-ES' | 'es-419' | 'es-MX' | 'en-US';
  noiseGateThreshold: number; // 0-100 (threshold for cutting background noise)
  noiseSuppressionEnabled: boolean;
  highpassFilterEnabled: boolean; // cuts low-frequency rumble / AC hum
  preferredModel: string;
  tone: 'analitico' | 'directo' | 'formal' | 'conversacional';
  customInstructions?: string;
  avatarColor: string;
  isDefault?: boolean;
  calibratedNoiseFloor?: number;
  createdAt: string;
  updatedAt: string;
}

export interface DocumentMetadata {
  id: string;
  userId?: string;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  documentCategory?: string;
  keyEntities?: string;
  sheetsExported?: boolean;
  docsExported?: boolean;
  createdAt: string;
  updatedAt: string;

  // Additional fields for voice-generated & assistant-created documents
  title?: string;
  content?: string;
  summary?: string;
  fileType?: string;
  googleDocId?: string;
  googleDriveUrl?: string;
  tags?: string[];
}

export type VoiceCommandActionType =
  | 'docs_create'
  | 'docs_append'
  | 'sheets_create'
  | 'sheets_append'
  | 'sheets_update_cell'
  | 'document_extract'
  | 'image_create'
  | 'general_voice';

export interface VoiceCommandRecord {
  id: string;
  userId?: string;
  commandText: string;
  actionType: VoiceCommandActionType;
  targetDocumentTitle?: string;
  modelUsed?: string;
  status: 'success' | 'failed' | 'executed' | 'pending';
  resultUrl?: string;
  resultSummary?: string;
  timestamp: number;
  metadata?: {
    spreadsheetId?: string;
    documentId?: string;
    rowCount?: number;
    wordCount?: number;
  };
}

export type AppTheme = 'night' | 'day';

/* -------------------------------------------------------------------------- */
/*                  REAL ESTATE CRM & TECHNICAL SHEET TYPES                   */
/* -------------------------------------------------------------------------- */

export type PropertyType =
  | 'penthouse'
  | 'villa'
  | 'apartment'
  | 'townhouse'
  | 'loft'
  | 'commercial'
  | 'estate';

export type PropertyStatus = 'available' | 'exclusive' | 'reserved' | 'sold';

export type PropertyTransaction = 'sale' | 'rent' | 'investment';

export interface PropertyImage {
  id: string;
  url: string;
  caption: string;
  category: 'exterior' | 'living' | 'kitchen' | 'master' | 'terrace' | 'view' | 'plan';
  isHero?: boolean;
}

export interface PropertyLocation {
  address: string;
  neighborhood: string;
  city: string;
  stateOrProvince: string;
  country: string;
  postalCode: string;
  zoneHighlights?: string[];
  nearbyLandmarks?: { name: string; distance: string }[];
}

export interface PropertySpecs {
  builtAreaM2: number;
  usableAreaM2: number;
  plotAreaM2?: number;
  terraceAreaM2?: number;
  bedrooms: number;
  bathrooms: number;
  halfBaths?: number;
  parkingSpots: number;
  storageRooms?: number;
  yearBuilt: number;
  floor: string;
  orientation: string;
  condition: string;
  energyRating: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G';
  energyConsumption?: string;
  energyEmissions?: string;
}

export interface PropertyFinancials {
  communityFeesMonthly?: number;
  propertyTaxAnnual?: number;
  estimatedRentalYieldPct?: number;
  estimatedMonthlyRent?: number;
  mortgageEstimateMonthly?: number;
}

export interface AgentContactInfo {
  name: string;
  title: string;
  licenseNumber: string;
  phone: string;
  whatsapp: string;
  email: string;
  agencyName: string;
  agencyWebsite: string;
  agencyAddress: string;
  agencyLogoUrl?: string;
  avatarUrl?: string;
}

export interface PropertyCRMRecord {
  id: string;
  userId?: string;
  referenceCode: string;
  title: string;
  tagline?: string;
  propertyType: PropertyType;
  status: PropertyStatus;
  transactionType: PropertyTransaction;
  price: number;
  currency: 'EUR' | 'USD' | 'GBP' | 'MXN';
  cadastralReference?: string;
  location: PropertyLocation;
  specs: PropertySpecs;
  financials: PropertyFinancials;
  features: string[];
  description: string;
  highlights: string[];
  images: PropertyImage[];
  agentContact: AgentContactInfo;
  clientNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TechnicalSheetPdfOptions {
  themeStyle: 'minimal_luxe' | 'corporate_executive' | 'modern_dark';
  language: 'es' | 'en';
  showExactAddress: boolean;
  showFinancials: boolean;
  showCadastral: boolean;
  showAgencyBranding: boolean;
  showQrVerification: boolean;
  includeFloorPlan: boolean;
  customClientGreeting?: string;
}
