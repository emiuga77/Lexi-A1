import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Mail,
  FileText,
} from 'lucide-react';
import { PropertyCRMRecord } from '../types';
import { buildWhatsAppShareText, buildClipboardSummary } from '../utils/pdfGenerator';

interface Props {
  isOpen: boolean;
  property: PropertyCRMRecord | null;
  onClose: () => void;
  onDownloadPdf: () => void;
}

export const ShareClientModal: React.FC<Props> = ({
  isOpen,
  property,
  onClose,
  onDownloadPdf,
}) => {
  if (!isOpen || !property) return null;

  const [copiedSummary, setCopiedSummary] = useState(false);

  const whatsappUrl = `https://wa.me/?text=${buildWhatsAppShareText(property)}`;
  const emailSubject = encodeURIComponent(`Ficha Técnica Oficial: ${property.title} [Ref: ${property.referenceCode}]`);
  const emailBody = encodeURIComponent(buildClipboardSummary(property));
  const mailtoUrl = `mailto:?subject=${emailSubject}&body=${emailBody}`;

  const handleCopySummary = () => {
    navigator.clipboard.writeText(buildClipboardSummary(property));
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden text-slate-900"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Compartir Ficha con Cliente
              </h2>
              <p className="text-xs text-slate-400">
                {property.title} · Ref: {property.referenceCode}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-xs">
          {/* Action Channels */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* WhatsApp Direct */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-950 flex items-center gap-3 transition-colors cursor-pointer"
            >
              <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-emerald-900">WhatsApp</div>
                <div className="text-[11px] text-emerald-700">Enviar mensaje formateado</div>
              </div>
            </a>

            {/* Email Direct */}
            <a
              href={mailtoUrl}
              className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-50 text-blue-950 flex items-center gap-3 transition-colors cursor-pointer"
            >
              <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-blue-900">Email Corporativo</div>
                <div className="text-[11px] text-blue-700">Abrir cliente de correo</div>
              </div>
            </a>
          </div>

          {/* Quick Copy Action */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-slate-600" />
                Resumen Ejecutivo de la Ficha
              </span>

              <button
                type="button"
                onClick={handleCopySummary}
                className="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 flex items-center gap-1.5 font-semibold text-[11px] transition-colors cursor-pointer"
              >
                {copiedSummary ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" /> Copiado
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> Copiar Texto
                  </>
                )}
              </button>
            </div>

            <p className="text-[11px] text-slate-500">
              Copia el resumen formateado con especificaciones, precio, fotos y datos de contacto para pegar en chats, propuestas comerciales o CRM.
            </p>
          </div>

          {/* Direct PDF Download Trigger */}
          <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/60 flex items-center justify-between gap-3">
            <div>
              <div className="font-bold text-amber-950 text-xs">Descargar PDF para Adjuntar</div>
              <div className="text-[11px] text-amber-800">
                Genera el archivo PDF A4 de 300 DPI para enviar como documento formal
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onDownloadPdf();
              }}
              className="px-4 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 font-semibold text-xs shrink-0 cursor-pointer"
            >
              Generar PDF
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-200/70 font-semibold text-xs cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
