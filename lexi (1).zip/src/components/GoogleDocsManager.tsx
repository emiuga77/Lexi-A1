import React, { useState, useEffect, useMemo } from 'react';
import { WorkspaceFile, PendingActionConfirmation, DocumentMetadata } from '../types';
import {
  listGoogleDocs,
  createGoogleDoc,
  appendToGoogleDoc,
  readGoogleDoc,
  syncLocalDocToGoogleDrive,
} from '../services/workspaceApi';
import {
  getDocumentMetadataList,
  saveDocumentMetadata,
  deleteDocumentMetadata,
} from '../services/firestoreDb';
import {
  FileText,
  Plus,
  RefreshCw,
  ExternalLink,
  Send,
  Sparkles,
  AlertCircle,
  Clock,
  Download,
  Copy,
  Check,
  Trash2,
  Printer,
  Search,
  Cloud,
  CloudOff,
  CheckCircle2,
  Wand2,
  Eye,
  Edit3,
  ArrowUpRight,
} from 'lucide-react';
import { downloadMarkdownFile } from '../utils/fileDownloader';

interface Props {
  isAuthenticated: boolean;
  onPromptLogin: () => void;
  onRequestAction: (action: PendingActionConfirmation) => void;
}

type GeneratorTemplate =
  | 'report'
  | 'contract'
  | 'proposal'
  | 'meeting_notes'
  | 'strategic_plan'
  | 'technical';

const TEMPLATE_PRESETS: { id: GeneratorTemplate; label: string; icon: string; prompt: string }[] = [
  {
    id: 'report',
    label: 'Informe Ejecutivo',
    icon: '📊',
    prompt: 'Redacta un informe ejecutivo trimestral detallado con resumen gerencial, métricas operativas clave, tabla comparativa de desempeño y recomendaciones estratégicas para dirección.',
  },
  {
    id: 'contract',
    label: 'Contrato de Arrendamiento',
    icon: '⚖️',
    prompt: 'Genera un contrato formal de arrendamiento inmobiliario para una propiedad urbana, con declaraciones de arrendador y arrendatario, cláusulas numeradas de vigencia, renta mensual, depósito, obligaciones y espacio para firmas.',
  },
  {
    id: 'proposal',
    label: 'Propuesta Comercial',
    icon: '💼',
    prompt: 'Redacta una propuesta de servicios profesionales integral para un cliente corporativo, detallando diagnóstico inicial, alcance del proyecto, fases de implementación, desglose de inversión y ROI estimado.',
  },
  {
    id: 'meeting_notes',
    label: 'Minuta de Reunión',
    icon: '📝',
    prompt: 'Crea una minuta formal de reunión de directorio o comité, incluyendo fecha, asistentes, agenda discutida, acuerdos aprobados por unanimidad y matriz de responsables con fechas límite.',
  },
  {
    id: 'strategic_plan',
    label: 'Plan Estratégico 2026',
    icon: '🎯',
    prompt: 'Elabora un plan estratégico de innovación y crecimiento para el año 2026, con visión, objetivos OKR prioritarios, iniciativas por área de negocio, cronograma por trimestres y mitigación de riesgos.',
  },
  {
    id: 'technical',
    label: 'Guía Técnica de Operaciones',
    icon: '🔧',
    prompt: 'Genera una especificación y guía técnica de procedimientos estandarizados (SOP) paso a paso, con prerrequisitos, arquitectura de flujo, controles de calidad y resolución de incidencias comunes.',
  },
];

export const GoogleDocsManager: React.FC<Props> = ({
  isAuthenticated,
  onPromptLogin,
  onRequestAction,
}) => {
  const [docs, setDocs] = useState<WorkspaceFile[]>([]);
  const [localDocs, setLocalDocs] = useState<DocumentMetadata[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Active creator tab: 'ai' | 'manual'
  const [activeTab, setActiveTab] = useState<'ai' | 'manual'>('ai');

  // AI Generator state
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiTitle, setAiTitle] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<GeneratorTemplate>('report');
  const [selectedTone, setSelectedTone] = useState<'professional' | 'executive' | 'technical' | 'formal'>('professional');
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.8-flash');
  const [selectedProvider, setSelectedProvider] = useState<'gemini' | 'groq'>('gemini');
  const [isGenerating, setIsGenerating] = useState(false);

  // Generated / Editable document preview
  const [previewTitle, setPreviewTitle] = useState('');
  const [previewContent, setPreviewContent] = useState('');
  const [previewSummary, setPreviewSummary] = useState('');
  const [previewViewMode, setPreviewViewMode] = useState<'formatted' | 'raw'>('formatted');
  const [isSavingDoc, setIsSavingDoc] = useState(false);

  // Manual Creation state
  const [manualTitle, setManualTitle] = useState('');
  const [manualContent, setManualContent] = useState('');
  const [isManualCreating, setIsManualCreating] = useState(false);

  // Selected Doc for Inspector
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [selectedDocDetails, setSelectedDocDetails] = useState<{
    id?: string;
    title: string;
    text: string;
    googleDriveUrl?: string;
    isLocal?: boolean;
    createdAt?: string;
  } | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [appendText, setAppendText] = useState('');
  const [isAppending, setIsAppending] = useState(false);
  const [isSyncingToDrive, setIsSyncingToDrive] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'local' | 'google'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchDocs = async () => {
    setIsLoading(true);
    setError(null);

    // 1. Fetch Local / Assistant created documents (independent, never fails)
    try {
      const local = await getDocumentMetadataList().catch(() => []);
      setLocalDocs(local.filter((d) => d.fileType === 'docs' || (!d.fileType && (d.title || d.content))));
    } catch (localErr) {
      console.warn('Error fetching local docs:', localErr);
    }

    // 2. Fetch Google Drive Docs if authenticated
    if (isAuthenticated) {
      try {
        const items = await listGoogleDocs();
        setDocs(items);
      } catch (err: any) {
        console.warn('Google Docs list warning:', err?.message || err);
        // Do not block local documents if drive.file permission has not been granted yet
      }
    }

    setIsLoading(false);
  };

  useEffect(() => {
    fetchDocs();

    // Listen for documents created by Lexi voice commands in real time
    const handleLexiDocCreated = () => {
      fetchDocs();
    };
    window.addEventListener('lexi:document_created', handleLexiDocCreated);
    return () => {
      window.removeEventListener('lexi:document_created', handleLexiDocCreated);
    };
  }, [isAuthenticated]);

  // Load single doc details
  const handleSelectDoc = async (id: string) => {
    setSelectedDocId(id);
    setIsLoadingDetails(true);
    setError(null);

    // Check local / assistant documents first
    const localFound = localDocs.find((d) => d.id === id);
    if (localFound) {
      setSelectedDocDetails({
        id: localFound.id,
        title: localFound.title || 'Documento Asistente',
        text: localFound.content || localFound.summary || '',
        googleDriveUrl: localFound.googleDriveUrl,
        isLocal: true,
        createdAt: localFound.createdAt,
      });
      setIsLoadingDetails(false);
      return;
    }

    // Otherwise read from Google Docs API
    try {
      const details = await readGoogleDoc(id);
      setSelectedDocDetails({
        id,
        title: details.title,
        text: details.text,
        googleDriveUrl: `https://docs.google.com/document/d/${id}/edit`,
        isLocal: false,
      });
    } catch (err: any) {
      console.warn('Error reading doc:', err?.message || err);
      setError(err?.message || 'No se pudo leer el contenido de este documento.');
    } finally {
      setIsLoadingDetails(false);
    }
  };

  // Generate Document with AI
  const handleGenerateDocument = async () => {
    const promptToSend = aiPrompt.trim() || TEMPLATE_PRESETS.find((t) => t.id === selectedTemplate)?.prompt || '';
    if (!promptToSend) {
      setError('Escribe una descripción o selecciona una plantilla para generar el documento.');
      return;
    }

    setIsGenerating(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await fetch('/api/generate-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToSend,
          title: aiTitle.trim(),
          templateType: selectedTemplate,
          tone: selectedTone,
          model: selectedModel,
          provider: selectedProvider,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || errData.message || `Error del servidor (${response.status})`);
      }

      const data = await response.json();
      if (!data.success || !data.content) {
        throw new Error('El modelo no devolvió contenido.');
      }

      setPreviewTitle(data.title || aiTitle || 'Documento Generado por IA');
      setPreviewContent(data.content);
      setPreviewSummary(data.summary || '');
      setSuccessMessage(`¡Documento "${data.title}" generado con éxito usando ${data.modelUsed || selectedModel}!`);
    } catch (err: any) {
      console.error('Error generating document:', err);
      setError(err?.message || 'Error al generar el documento. Intenta con otro modelo o ajusta la instrucción.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Save Preview to Assistant (Local / Firestore DB)
  const handleSaveToAssistant = async () => {
    if (!previewTitle.trim() || !previewContent.trim()) return;
    setIsSavingDoc(true);
    try {
      await saveDocumentMetadata({
        title: previewTitle,
        fileType: 'docs',
        content: previewContent,
        summary: previewSummary || 'Documento redactado con IA en Google Docs Manager',
        tags: ['ia', selectedTemplate, 'redactor'],
      });
      setSuccessMessage(`Documento "${previewTitle}" guardado en tu Asistente.`);
      await fetchDocs();
    } catch (err: any) {
      setError(err?.message || 'No se pudo guardar en el asistente.');
    } finally {
      setIsSavingDoc(false);
    }
  };

  // Save Preview to Google Docs (With confirmation proposal)
  const handleSaveToGoogleDocs = () => {
    if (!previewTitle.trim() || !previewContent.trim()) return;

    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }

    onRequestAction({
      id: 'create-doc-ai-' + Date.now(),
      type: 'docs_create',
      title: 'Crear Documento en Google Docs',
      targetName: previewTitle,
      details: [
        { label: 'Título del Documento', value: previewTitle },
        { label: 'Modelo Utilizado', value: selectedModel },
        { label: 'Longitud', value: `${previewContent.length} caracteres` },
      ],
      onConfirm: async () => {
        setIsSavingDoc(true);
        try {
          const res = await createGoogleDoc(previewTitle, previewContent);
          await saveDocumentMetadata({
            title: previewTitle,
            fileType: 'docs',
            content: previewContent,
            summary: previewSummary || 'Documento creado en Google Docs',
            googleDocId: res.id,
            googleDriveUrl: res.url,
            tags: ['google-docs', 'ia'],
          });
          setSuccessMessage(`¡Documento creado en Google Docs! [${res.title}]`);
          await fetchDocs();
          handleSelectDoc(res.id);
        } catch (err: any) {
          setError(err?.message || 'Error al crear en Google Docs');
        } finally {
          setIsSavingDoc(false);
        }
      },
      onCancel: () => {},
    });
  };

  // Sync a local / assistant document to Google Drive
  const handleSyncSelectedToDrive = async () => {
    if (!selectedDocDetails || !selectedDocDetails.id) return;
    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }

    setIsSyncingToDrive(true);
    try {
      const res = await syncLocalDocToGoogleDrive(
        selectedDocDetails.id,
        selectedDocDetails.title,
        selectedDocDetails.text
      );
      setSelectedDocDetails((prev) => (prev ? { ...prev, googleDriveUrl: res.url } : prev));
      setSuccessMessage(`¡Documento sincronizado exitosamente con Google Drive!`);
      await fetchDocs();
    } catch (err: any) {
      setError(err?.message || 'Error al sincronizar con Google Drive.');
    } finally {
      setIsSyncingToDrive(false);
    }
  };

  // Delete local document
  const handleDeleteLocalDoc = async (id: string, title: string) => {
    if (!window.confirm(`¿Estás seguro de eliminar "${title}" del historial?`)) return;
    try {
      await deleteDocumentMetadata(id);
      if (selectedDocId === id) {
        setSelectedDocId(null);
        setSelectedDocDetails(null);
      }
      await fetchDocs();
      setSuccessMessage(`Documento eliminado.`);
    } catch (err: any) {
      setError(err?.message || 'Error al eliminar el documento.');
    }
  };

  // Manual Create Document
  const handleInitiateManualCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualTitle.trim()) return;

    if (!isAuthenticated) {
      // Save locally if not signed into Google
      saveDocumentMetadata({
        title: manualTitle,
        fileType: 'docs',
        content: manualContent,
        summary: 'Borrador creado manualmente',
        tags: ['manual', 'borrador'],
      })
        .then(() => {
          setManualTitle('');
          setManualContent('');
          setSuccessMessage(`Documento "${manualTitle}" guardado en el asistente.`);
          fetchDocs();
        })
        .catch((err) => setError(err?.message || 'Error al guardar'));
      return;
    }

    onRequestAction({
      id: 'create-doc-manual-' + Date.now(),
      type: 'docs_create',
      title: 'Crear Nuevo Google Doc',
      targetName: manualTitle,
      details: [
        { label: 'Título', value: manualTitle },
        { label: 'Contenido Inicial', value: manualContent || '(Documento en blanco)' },
      ],
      onConfirm: async () => {
        setIsManualCreating(true);
        try {
          const res = await createGoogleDoc(manualTitle, manualContent);
          await saveDocumentMetadata({
            title: manualTitle,
            fileType: 'docs',
            content: manualContent,
            summary: 'Documento creado en Google Docs',
            googleDocId: res.id,
            googleDriveUrl: res.url,
          });
          setManualTitle('');
          setManualContent('');
          await fetchDocs();
          handleSelectDoc(res.id);
        } catch (err: any) {
          setError(err?.message || 'Error al crear documento');
        } finally {
          setIsManualCreating(false);
        }
      },
      onCancel: () => {},
    });
  };

  // Append Text to Selected Google Doc
  const handleInitiateAppend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDocId || !appendText.trim() || !selectedDocDetails) return;

    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }

    onRequestAction({
      id: 'append-doc-' + Date.now(),
      type: 'docs_append',
      title: 'Añadir Contenido a Google Doc',
      targetName: selectedDocDetails.title,
      targetId: selectedDocId,
      details: [
        { label: 'Documento Destino', value: selectedDocDetails.title },
        { label: 'Texto a Añadir', value: appendText },
      ],
      onConfirm: async () => {
        setIsAppending(true);
        try {
          await appendToGoogleDoc(selectedDocId, appendText);
          setAppendText('');
          await handleSelectDoc(selectedDocId);
          setSuccessMessage('Texto añadido exitosamente al documento.');
        } catch (err: any) {
          setError(err?.message || 'Error al añadir texto');
        } finally {
          setIsAppending(false);
        }
      },
      onCancel: () => {},
    });
  };

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {}
  };

  // Filtered documents list
  const filteredDocs = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    let list: {
      id: string;
      title: string;
      isLocal: boolean;
      date?: string;
      googleDriveUrl?: string;
      snippet?: string;
    }[] = [];

    if (filterType === 'all' || filterType === 'local') {
      localDocs.forEach((d) => {
        list.push({
          id: d.id,
          title: d.title || 'Documento Asistente',
          isLocal: true,
          date: d.createdAt,
          googleDriveUrl: d.googleDriveUrl,
          snippet: (d.summary || d.content || '').slice(0, 120),
        });
      });
    }

    if (filterType === 'all' || filterType === 'google') {
      docs.forEach((d) => {
        // Skip duplicates already in local list with matching ID
        if (!list.some((existing) => existing.googleDriveUrl?.includes(d.id))) {
          list.push({
            id: d.id,
            title: d.name,
            isLocal: false,
            date: d.modifiedTime,
            googleDriveUrl: d.webViewLink || `https://docs.google.com/document/d/${d.id}/edit`,
            snippet: 'Google Docs en Google Drive',
          });
        }
      });
    }

    if (q) {
      list = list.filter(
        (item) =>
          item.title.toLowerCase().includes(q) || (item.snippet && item.snippet.toLowerCase().includes(q))
      );
    }

    return list;
  }, [docs, localDocs, searchQuery, filterType]);

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header with Connection State & Refresh */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-blue-500/20 border border-blue-500/30 text-blue-400">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white">Centro de Creación y Gestión Documental</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                IA & Google Docs
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Genera documentos profesionales con Gemini y sincronízalos en tiempo real con Google Docs.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
              <span>Google Drive Conectado</span>
            </div>
          ) : (
            <button
              type="button"
              onClick={onPromptLogin}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <CloudOff className="w-3.5 h-3.5" />
              <span>Conectar Google Drive</span>
            </button>
          )}

          <button
            type="button"
            onClick={fetchDocs}
            disabled={isLoading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
            title="Actualizar documentos"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Notifications */}
      {error && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center justify-between shadow-xs">
          <span className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            {error}
          </span>
          <button type="button" onClick={() => setError(null)} className="text-rose-500 hover:text-rose-800 font-bold px-1">
            ✕
          </button>
        </div>
      )}

      {successMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between shadow-xs">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            {successMessage}
          </span>
          <button type="button" onClick={() => setSuccessMessage(null)} className="text-emerald-500 hover:text-emerald-800 font-bold px-1">
            ✕
          </button>
        </div>
      )}

      {/* Main Grid: Left Creator / Right Document Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Document Creator & AI Studio */}
        <div className="lg:col-span-7 space-y-4">
          {/* Creator Tabs */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <button
              type="button"
              onClick={() => setActiveTab('ai')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'ai'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>Generador con IA</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('manual')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'manual'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Redactar en Blanco / Borrador</span>
            </button>
          </div>

          {activeTab === 'ai' ? (
            /* AI Document Generation Studio */
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    Redactor Documental Inteligente
                  </h2>
                  <p className="text-[11px] text-slate-500">
                    Selecciona una plantilla o describe el documento que necesitas redactar.
                  </p>
                </div>
              </div>

              {/* Template Presets */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                  Plantillas Rápidas:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {TEMPLATE_PRESETS.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        setSelectedTemplate(t.id);
                        setAiPrompt(t.prompt);
                        setAiTitle(t.label);
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        selectedTemplate === t.id
                          ? 'border-blue-600 bg-blue-50/60 shadow-2xs'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{t.icon}</span>
                        <span className="text-xs font-bold text-slate-900 truncate">{t.label}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Title & Prompt Inputs */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Título o Asunto del Documento
                  </label>
                  <input
                    type="text"
                    placeholder="Ej. Plan de Negocios y Expansión 2026"
                    value={aiTitle}
                    onChange={(e) => setAiTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Instrucciones de Redacción / Contenido Deseado
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Describe los puntos clave, secciones o datos que debe contener el documento..."
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden leading-relaxed"
                  />
                </div>
              </div>

              {/* Model, Provider & Tone Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Modelo de IA</label>
                  <select
                    value={selectedModel}
                    onChange={(e) => {
                      const val = e.target.value;
                      setSelectedModel(val);
                      if (val.startsWith('llama')) {
                        setSelectedProvider('groq');
                      } else {
                        setSelectedProvider('gemini');
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white font-medium cursor-pointer"
                  >
                    <option value="gemini-3.8-flash">Gemini 3.8 Flash (Recomendado)</option>
                    <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Rápido)</option>
                    <option value="gemini-flash-latest">Gemini Flash Latest</option>
                    <option value="llama-3.3-70b-versatile">Groq Llama 3.3 70B</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Tono de Redacción</label>
                  <select
                    value={selectedTone}
                    onChange={(e) => setSelectedTone(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white font-medium cursor-pointer"
                  >
                    <option value="professional">Profesional Corporativo</option>
                    <option value="executive">Ejecutivo / Directivo</option>
                    <option value="technical">Técnico / Estructurado</option>
                    <option value="formal">Formal Legal</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Proveedor de Motor</label>
                  <div className="flex items-center gap-1 mt-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProvider('gemini');
                        setSelectedModel('gemini-3.8-flash');
                      }}
                      className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border cursor-pointer ${
                        selectedProvider === 'gemini'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-slate-700 border-slate-300'
                      }`}
                    >
                      Gemini
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProvider('groq');
                        setSelectedModel('llama-3.3-70b-versatile');
                      }}
                      className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border cursor-pointer ${
                        selectedProvider === 'groq'
                          ? 'bg-amber-600 text-white border-amber-600'
                          : 'bg-white text-slate-700 border-slate-300'
                      }`}
                    >
                      Groq LPU
                    </button>
                  </div>
                </div>
              </div>

              {/* Generate Button */}
              <button
                type="button"
                onClick={handleGenerateDocument}
                disabled={isGenerating || (!aiPrompt.trim() && !aiTitle.trim())}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm shadow-blue-500/20 transition-all cursor-pointer disabled:opacity-50"
              >
                <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
                <span>
                  {isGenerating ? 'Redactando documento de alta fidelidad...' : 'Generar Documento con IA'}
                </span>
              </button>

              {/* Generated Document Preview & Actions */}
              {previewContent && (
                <div className="mt-6 pt-4 border-t border-slate-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <input
                        type="text"
                        value={previewTitle}
                        onChange={(e) => setPreviewTitle(e.target.value)}
                        className="font-bold text-sm text-slate-900 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 outline-hidden w-full"
                      />
                      <span className="text-[11px] text-slate-400">
                        {previewContent.length} caracteres • {previewContent.split(/\s+/).length} palabras
                      </span>
                    </div>

                    <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-[11px] font-semibold">
                      <button
                        type="button"
                        onClick={() => setPreviewViewMode('formatted')}
                        className={`px-2.5 py-1 rounded-lg cursor-pointer transition-colors ${
                          previewViewMode === 'formatted'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <Eye className="w-3.5 h-3.5 inline mr-1" />
                        Vista Previa
                      </button>
                      <button
                        type="button"
                        onClick={() => setPreviewViewMode('raw')}
                        className={`px-2.5 py-1 rounded-lg cursor-pointer transition-colors ${
                          previewViewMode === 'raw'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <Edit3 className="w-3.5 h-3.5 inline mr-1" />
                        Editar Markdown
                      </button>
                    </div>
                  </div>

                  {/* Document View: Formatted or Textarea */}
                  {previewViewMode === 'formatted' ? (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 max-h-80 overflow-y-auto whitespace-pre-wrap font-sans leading-relaxed">
                      {previewContent}
                    </div>
                  ) : (
                    <textarea
                      rows={12}
                      value={previewContent}
                      onChange={(e) => setPreviewContent(e.target.value)}
                      className="w-full p-3 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 font-mono leading-relaxed outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  )}

                  {/* Action Bar for Generated Doc */}
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      disabled={isSavingDoc}
                      onClick={handleSaveToGoogleDocs}
                      className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                      title="Crear y abrir en Google Docs"
                    >
                      <Cloud className="w-3.5 h-3.5" />
                      <span>{isAuthenticated ? 'Guardar en Google Docs' : 'Conectar y Guardar en Docs'}</span>
                    </button>

                    <button
                      type="button"
                      disabled={isSavingDoc}
                      onClick={handleSaveToAssistant}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Guardar en base de datos local y del asistente"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Guardar en Asistente</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => downloadMarkdownFile(previewTitle, previewContent)}
                      className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      title="Descargar archivo Markdown"
                    >
                      <Download className="w-3.5 h-3.5 text-slate-600" />
                      <span>.md</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => copyToClipboard(previewContent, 'preview')}
                      className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      title="Copiar texto"
                    >
                      {copiedId === 'preview' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedId === 'preview' ? 'Copiado' : 'Copiar'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1 transition-colors cursor-pointer"
                      title="Imprimir o guardar como PDF"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>PDF</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Manual Draft Creator */
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-blue-600" />
                Redacción de Borrador Manual
              </h2>

              <form onSubmit={handleInitiateManualCreate} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Título</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Acta de Acuerdos y Decisiones"
                    value={manualTitle}
                    onChange={(e) => setManualTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Cuerpo del Documento</label>
                  <textarea
                    rows={8}
                    placeholder="Escribe el contenido del documento en texto o formato Markdown..."
                    value={manualContent}
                    onChange={(e) => setManualContent(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden font-mono leading-relaxed"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="submit"
                    disabled={!manualTitle.trim() || isManualCreating}
                    className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center gap-2 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isAuthenticated ? 'Crear en Google Docs' : 'Guardar Borrador en Asistente'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Document Inspector Card for Selected Document */}
          {selectedDocId && selectedDocDetails && (
            <div className="p-5 rounded-2xl bg-white border border-blue-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2 min-w-0">
                  {selectedDocDetails.isLocal ? (
                    <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                  ) : (
                    <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                  )}
                  <span className="text-xs font-bold text-slate-900 truncate">
                    {selectedDocDetails.title}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {selectedDocDetails.isLocal && !selectedDocDetails.googleDriveUrl && (
                    <button
                      type="button"
                      disabled={isSyncingToDrive}
                      onClick={handleSyncSelectedToDrive}
                      className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                      title="Subir y sincronizar este documento con Google Docs"
                    >
                      <Cloud className="w-3 h-3" />
                      <span>{isSyncingToDrive ? 'Subiendo...' : 'Sincronizar a Drive'}</span>
                    </button>
                  )}

                  {selectedDocDetails.googleDriveUrl && (
                    <a
                      href={selectedDocDetails.googleDriveUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-[11px] font-semibold flex items-center gap-1"
                    >
                      <span>Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => downloadMarkdownFile(selectedDocDetails.title, selectedDocDetails.text)}
                    className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium flex items-center gap-1"
                  >
                    <Download className="w-3 h-3" />
                    <span>.md</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => copyToClipboard(selectedDocDetails.text, selectedDocDetails.id || 'sel')}
                    className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium flex items-center gap-1"
                  >
                    {copiedId === (selectedDocDetails.id || 'sel') ? (
                      <Check className="w-3 h-3 text-emerald-600" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>

                  {selectedDocDetails.isLocal && selectedDocDetails.id && (
                    <button
                      type="button"
                      onClick={() => handleDeleteLocalDoc(selectedDocDetails.id!, selectedDocDetails.title)}
                      className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Eliminar documento del historial"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Document Text Preview */}
              <div className="max-h-60 overflow-y-auto p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700 whitespace-pre-wrap font-sans leading-relaxed">
                {isLoadingDetails ? 'Cargando contenido del documento...' : selectedDocDetails.text || '(Documento sin texto)'}
              </div>

              {/* Append Text Form (for Google Docs or synchronized docs) */}
              {isAuthenticated && (
                <form onSubmit={handleInitiateAppend} className="space-y-2 pt-1">
                  <label className="block text-xs font-semibold text-slate-700">
                    Añadir contenido adicional al documento
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Escribe o dicta texto adicional para adjuntar al final..."
                    value={appendText}
                    onChange={(e) => setAppendText(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden"
                  />
                  <button
                    type="submit"
                    disabled={!appendText.trim() || isAppending}
                    className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isAppending ? 'Adjuntando...' : 'Añadir al Documento (Con Confirmación)'}</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Right Column (5 cols): Document Explorer & Real-Time List */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">
                Documentos Disponibles ({filteredDocs.length})
              </h2>
              <span className="text-[11px] text-slate-400">Drive y Asistente</span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Buscar por título o contenido..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden"
              />
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`px-2.5 py-1 rounded-lg cursor-pointer font-medium transition-colors ${
                  filterType === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Todos ({localDocs.length + docs.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterType('local')}
                className={`px-2.5 py-1 rounded-lg cursor-pointer font-medium transition-colors ${
                  filterType === 'local'
                    ? 'bg-purple-600 text-white'
                    : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
                }`}
              >
                Asistente / IA ({localDocs.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterType('google')}
                className={`px-2.5 py-1 rounded-lg cursor-pointer font-medium transition-colors ${
                  filterType === 'google'
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                }`}
              >
                Google Drive ({docs.length})
              </button>
            </div>

            {/* Document List */}
            {isLoading ? (
              <div className="p-8 rounded-xl bg-slate-50 text-center text-xs text-slate-500 space-y-2">
                <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
                <span>Cargando documentos...</span>
              </div>
            ) : filteredDocs.length === 0 ? (
              <div className="p-8 rounded-xl bg-slate-50 text-center text-xs text-slate-500 space-y-2">
                <FileText className="w-7 h-7 text-slate-300 mx-auto" />
                <p className="font-semibold text-slate-700">No hay documentos que coincidan.</p>
                <p className="text-[11px] text-slate-400">
                  Usa el generador con IA a la izquierda o pídele a Lexi por voz: &quot;Crea un documento sobre...&quot;
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[620px] overflow-y-auto pr-1">
                {filteredDocs.map((doc) => {
                  const isSelected = selectedDocId === doc.id;
                  return (
                    <div
                      key={doc.id}
                      className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-2.5 ${
                        isSelected
                          ? 'bg-blue-50/80 border-blue-300 shadow-2xs'
                          : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-2xs'
                      }`}
                    >
                      <div
                        onClick={() => handleSelectDoc(doc.id)}
                        className="min-w-0 flex-1 flex items-start gap-2.5 cursor-pointer"
                      >
                        <div
                          className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                            doc.isLocal
                              ? 'bg-purple-100 text-purple-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}
                        >
                          {doc.isLocal ? <Sparkles className="w-3.5 h-3.5" /> : <FileText className="w-3.5 h-3.5" />}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-xs font-bold text-slate-900 truncate">{doc.title}</h4>
                          </div>

                          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5 font-mono">
                            {doc.isLocal && (
                              <span className="px-1.5 py-0.2 rounded bg-purple-100 text-purple-700 font-sans font-medium">
                                IA Asistente
                              </span>
                            )}
                            {doc.googleDriveUrl && (
                              <span className="px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 font-sans font-medium">
                                Drive
                              </span>
                            )}
                            {doc.date && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-2.5 h-2.5" />
                                {new Date(doc.date).toLocaleDateString([], {
                                  month: 'short',
                                  day: 'numeric',
                                })}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleSelectDoc(doc.id)}
                          className="px-2 py-1 rounded-lg text-[11px] font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
                        >
                          Ver
                        </button>

                        {doc.googleDriveUrl && (
                          <a
                            href={doc.googleDriveUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            title="Abrir en Google Docs"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {doc.isLocal && (
                          <button
                            type="button"
                            onClick={() => handleDeleteLocalDoc(doc.id, doc.title)}
                            className="p-1 rounded-lg text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Eliminar del historial"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
