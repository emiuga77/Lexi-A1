import React, { useEffect, useRef, useState } from 'react';
import { Volume2, Brain, Sparkles, Radio } from 'lucide-react';

export type OrbState = 'idle' | 'listening' | 'thinking' | 'speaking';

export interface CyberParticleOrbProps {
  status: OrbState;
  audioLevel?: number; // 0 to 100
  isVoiceDetected?: boolean;
  isMicOn?: boolean; // Microfono prendido (nebulosa activa) vs apagado (nebulosa en reposo)
  onClick?: () => void;
  size?: number; // default: 340
  showControls?: boolean;
  interimTranscript?: string;
  className?: string;
  title?: string;
  subtitle?: string;
  fullBackground?: boolean;
}

interface NebulaParticle3D {
  baseX: number;
  baseY: number;
  baseZ: number;
  sphereX: number;
  sphereY: number;
  sphereZ: number;
  sphereTheta: number;
  spherePhi: number;
  sphereR: number;
  dispX: number;
  dispY: number;
  dispZ: number;
  driftSpeed: number;
  driftPhase: number;
  driftRadius: number;
  twinkleSpeed: number;
  twinklePhase: number;
  size: number;
  alpha: number;
  baseAlpha: number;
  color: string; // Base RGBA prefix, e.g. "rgba(249, 115, 22, "
  r: number;
  g: number;
  b: number;
  coreColor?: string; // Specular center
  isCoreStar: boolean;
  isDiffractionStar: boolean;
  diffractionType: 'webb_6' | 'hubble_4' | 'none';
  starTempColor: string;
  zone:
    | 'core_nursery'
    | 'sulfur_carina_ridge'
    | 'oxygen_cavity'
    | 'hydrogen_canopy'
    | 'nitrogen_flame'
    | 'dark_dust_pillar'
    | 'diffuse_stardust';
  gasFlowSpeed: number;
}

interface AmbientParticle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  alpha: number;
  color: string;
}

export const CyberParticleOrb: React.FC<CyberParticleOrbProps> = ({
  status,
  audioLevel = 0,
  isVoiceDetected = false,
  isMicOn,
  onClick,
  size = 340,
  showControls = true,
  interimTranscript = '',
  className = '',
  title,
  subtitle,
  fullBackground = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  // First-click sphere activation: initially relaxed nebula; becomes 3D sphere upon first click
  const [hasClicked, setHasClicked] = useState(() => {
    try {
      return sessionStorage.getItem('lexi_orb_has_clicked') === 'true';
    } catch {
      return false;
    }
  });
  const hasClickedRef = useRef(hasClicked);
  const sphereMorphRef = useRef<number>(hasClicked ? 1.0 : 0.0);

  // If status is active or mic is toggled on, immediately activate sphere mode
  useEffect(() => {
    if (status !== 'idle' || isMicOn || isVoiceDetected) {
      if (!hasClickedRef.current) {
        hasClickedRef.current = true;
        setHasClicked(true);
        try {
          sessionStorage.setItem('lexi_orb_has_clicked', 'true');
        } catch {
          // safe fallback
        }
      }
    }
  }, [status, isMicOn, isVoiceDetected]);

  // Mutable refs for high-frequency props to avoid restarting the 60fps render loop
  const statusRef = useRef<OrbState>(status);
  statusRef.current = status;
  const audioLevelRef = useRef<number>(audioLevel);
  audioLevelRef.current = audioLevel;
  const isVoiceDetectedRef = useRef<boolean>(isVoiceDetected);
  isVoiceDetectedRef.current = isVoiceDetected;
  const isMicOnRef = useRef<boolean | undefined>(isMicOn);
  isMicOnRef.current = isMicOn;

  // 3D Orbital Cursor Interaction Refs
  const isDraggingRef = useRef(false);
  const lastMousePosRef = useRef({ x: 0, y: 0, time: 0 });
  const dragVelocityRef = useRef({ yaw: 0, pitch: 0 });
  const totalDragDistRef = useRef(0);
  const cursorHoverRef = useRef({ yaw: 0, pitch: 0 });
  const hoverTiltRef = useRef({ yaw: 0, pitch: 0 });

  // Animation & simulation refs
  const animFrameIdRef = useRef<number | null>(null);
  const rotationRef = useRef<{ yaw: number; pitch: number; roll: number }>({
    yaw: 0.15,
    pitch: 0.08,
    roll: 0,
  });
  const audioSmoothRef = useRef<number>(0);
  const pulseTimeRef = useRef<number>(0);

  // Smooth state transition refs (dispersion and brightness)
  const dispersionRef = useRef<number>(status === 'idle' ? 0.35 : 0.0);
  const brightnessRef = useRef<number>(status === 'idle' ? 0.35 : 1.0);

  // Particles cache
  const particlesRef = useRef<NebulaParticle3D[]>([]);
  const ambientParticlesRef = useRef<AmbientParticle[]>([]);

  // Initialize Astronomical Multi-Wavelength Nebula Geometry & Spectrum
  useEffect(() => {
    const TOTAL_PARTICLES = 3400;
    const particles: NebulaParticle3D[] = [];

    // Helper to extract [r, g, b] from 'rgba(r, g, b, '
    const parseRgba = (prefix: string): [number, number, number] => {
      const match = prefix.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
      if (match) {
        return [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3], 10)];
      }
      return [255, 255, 255];
    };

    // Helper random gaussian approximation for realistic gas clumpiness
    const randn = () => {
      let u = 0;
      let v = 0;
      while (u === 0) u = Math.random();
      while (v === 0) v = Math.random();
      return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    };

    // =========================================================================
    // Fibonacci Spherical Lattice Generator:
    // Guarantees mathematically uniform, non-collapsing 3D spherical shells
    // matching the classic Lexi particle orb sphere design.
    // =========================================================================
    const computeSpherePoint = (zone: string, idx: number, count: number) => {
      const goldenRatio = (1 + Math.sqrt(5)) / 2;
      const i = idx + 0.5;
      const phi = Math.acos(Math.max(-1, Math.min(1, 1 - (2 * i) / count)));
      const theta = 2 * Math.PI * (i / goldenRatio);

      let r = 0.98;
      if (zone === 'core_nursery') {
        // Concentrated luminous inner sphere core
        r = 0.22 + Math.pow(Math.random(), 1.5) * 0.28;
      } else if (zone === 'nitrogen_flame') {
        // Equatorial orbital halo ring (classic sci-fi ringed spherical orb geometry)
        r = 1.18 + Math.random() * 0.16;
        const ringPhi = Math.PI * 0.5 + randn() * 0.06;
        return {
          sphereX: r * Math.sin(ringPhi) * Math.cos(theta),
          sphereY: r * Math.sin(ringPhi) * Math.sin(theta),
          sphereZ: r * Math.cos(ringPhi),
          sphereTheta: theta,
          spherePhi: ringPhi,
          sphereR: r,
        };
      } else if (zone === 'sulfur_carina_ridge') {
        // Mid-mantle & lower surface of sphere
        r = idx % 3 === 0 ? 0.68 + Math.random() * 0.2 : 0.96 + (Math.random() - 0.5) * 0.07;
      } else if (zone === 'oxygen_cavity') {
        // Main luminous outer surface shell
        r = 0.98 + (Math.random() - 0.5) * 0.06;
      } else if (zone === 'hydrogen_canopy') {
        // External translucent corona shell
        r = 1.02 + (Math.random() - 0.5) * 0.08;
      } else if (zone === 'dark_dust_pillar') {
        r = 0.82 + Math.random() * 0.18;
      } else {
        r = 0.88 + Math.random() * 0.22;
      }

      return {
        sphereX: r * Math.sin(phi) * Math.cos(theta),
        sphereY: r * Math.sin(phi) * Math.sin(theta),
        sphereZ: r * Math.cos(phi),
        sphereTheta: theta,
        spherePhi: phi,
        sphereR: r,
      };
    };

    // =========================================================================
    // 1. Central Protostellar Nursery (Dense Core with Hot O/B Stars)
    // =========================================================================
    const CORE_COUNT = 560;
    for (let i = 0; i < CORE_COUNT; i++) {
      const r = Math.pow(Math.random(), 2.3) * 0.42; // strongly concentrated towards center
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      // Slightly flattened elliptical disk geometry of a stellar nursery
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta) * 0.82;
      const z = r * Math.cos(phi) * 0.65;

      const isDiffractionStar = i < 22;
      const diffractionType: 'webb_6' | 'hubble_4' | 'none' = isDiffractionStar
        ? i % 2 === 0
          ? 'webb_6'
          : 'hubble_4'
        : 'none';

      const baseSize = isDiffractionStar
        ? 2.8 + Math.random() * 1.6
        : 0.9 + Math.random() * 1.4;

      // Realistic stellar temperature colors: O/B blue-white, A white, newborn golden protostar
      let color = 'rgba(255, 255, 255, ';
      let starTempColor = '#ffffff';
      const cRand = Math.random();
      if (cRand > 0.65) {
        color = 'rgba(224, 248, 255, '; // crystalline hot cyan-white
        starTempColor = '#cffafe';
      } else if (cRand > 0.4) {
        color = 'rgba(165, 243, 252, '; // incandescent electric aqua
        starTempColor = '#67e8f9';
      } else if (cRand > 0.2) {
        color = 'rgba(254, 240, 138, '; // warm newborn protostellar gold (JWST IR)
        starTempColor = '#fef08a';
      } else {
        color = 'rgba(191, 219, 254, '; // stellar diamond blue
        starTempColor = '#93c5fd';
      }

      const scatter = 0.6 + Math.random() * 1.8;
      const dispX = x * scatter + randn() * 0.25;
      const dispY = y * scatter + randn() * 0.25;
      const dispZ = z * scatter + randn() * 0.25;

      const sp = computeSpherePoint('core_nursery', i, CORE_COUNT);

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.2 + Math.random() * 0.5,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.04 + Math.random() * 0.06,
        twinkleSpeed: 2.0 + Math.random() * 4.0,
        twinklePhase: Math.random() * Math.PI * 2,
        size: baseSize,
        alpha: 0.85 + Math.random() * 0.15,
        baseAlpha: 0.85 + Math.random() * 0.15,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#ffffff',
        isCoreStar: true,
        isDiffractionStar,
        diffractionType,
        starTempColor,
        zone: 'core_nursery',
        gasFlowSpeed: 0.4 + Math.random() * 0.4,
      });
    }

    // =========================================================================
    // 2. Cosmic Cliffs & Ionized Sulfur [S II] Ridge (Carina / Pillars Palette)
    // Fiery copper, molten amber, warm terracotta, and solar gold emissions (672 nm)
    // =========================================================================
    const SULFUR_COUNT = 740;
    for (let i = 0; i < SULFUR_COUNT; i++) {
      const u = (Math.random() - 0.5) * 2; // -1 to 1 across the transverse ridge
      const armR = 0.2 + Math.abs(u) * 0.95;
      const angle = 0.15 * Math.PI + u * 0.85 + randn() * 0.18;

      // Volumetric mountain-like ridge shelf
      const thickness = 0.16 + Math.cos(u * Math.PI * 0.5) * 0.22;
      const x = Math.cos(angle) * armR * 1.15 + randn() * thickness;
      const y = Math.sin(angle) * armR * 0.7 - 0.15 + randn() * thickness;
      const z = Math.sin(u * Math.PI) * 0.35 + randn() * (thickness * 0.8);

      // Multi-tonal ionized sulfur & dust emission
      let color = 'rgba(249, 115, 22, '; // molten copper
      let starTempColor = '#fb923c';
      const cRand = Math.random();
      if (cRand > 0.8) {
        color = 'rgba(254, 240, 138, '; // radiant solar white-gold
        starTempColor = '#fef08a';
      } else if (cRand > 0.6) {
        color = 'rgba(245, 158, 11, '; // warm amber gold
        starTempColor = '#fbbf24';
      } else if (cRand > 0.4) {
        color = 'rgba(234, 88, 12, '; // rich terracotta
        starTempColor = '#ea580c';
      } else if (cRand > 0.2) {
        color = 'rgba(253, 186, 116, '; // apricot glow
        starTempColor = '#fed7aa';
      } else {
        color = 'rgba(217, 119, 6, '; // deep burnt ochre
        starTempColor = '#d97706';
      }

      const scatter = 0.8 + Math.random() * 2.2;
      const dispX = x * scatter + randn() * 0.28;
      const dispY = y * scatter + randn() * 0.28;
      const dispZ = z * scatter + randn() * 0.28;

      const sp = computeSpherePoint('sulfur_carina_ridge', i, SULFUR_COUNT);

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.18 + Math.random() * 0.4,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.05 + Math.random() * 0.07,
        twinkleSpeed: 1.8 + Math.random() * 3.2,
        twinklePhase: Math.random() * Math.PI * 2,
        size: 1.0 + Math.random() * 1.5,
        alpha: 0.8 + Math.random() * 0.2,
        baseAlpha: 0.8 + Math.random() * 0.2,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#fef3c7',
        isCoreStar: false,
        isDiffractionStar: i < 6,
        diffractionType: i < 6 ? 'hubble_4' : 'none',
        starTempColor,
        zone: 'sulfur_carina_ridge',
        gasFlowSpeed: 0.35 + Math.random() * 0.4,
      });
    }

    // =========================================================================
    // 3. Doubly Ionized Oxygen [O III] Cavity & Filaments (500.7 nm)
    // Crystalline cyan, glacial aqua, emerald-turquoise, and electric cerulean
    // =========================================================================
    const OXYGEN_COUNT = 820;
    for (let i = 0; i < OXYGEN_COUNT; i++) {
      const u = Math.random(); // 0 to 1 along the upper-east ionized bubble
      const armR = 0.24 + Math.pow(u, 0.75) * 1.38;
      const armAngle = 0.65 * Math.PI - u * 1.35 + randn() * 0.2;

      const thickness = 0.16 + Math.sin(u * Math.PI) * 0.26;
      const x = Math.cos(armAngle) * armR + randn() * thickness;
      const y = Math.sin(armAngle) * armR * 0.88 + randn() * thickness;
      const z = (u - 0.35) * 0.58 + randn() * (thickness * 0.75);

      let color = 'rgba(34, 211, 238, '; // [O III] vivid cyan (500.7nm)
      let starTempColor = '#67e8f9';
      const cRand = Math.random();
      if (cRand > 0.8) {
        color = 'rgba(255, 255, 255, '; // embedded hot star
        starTempColor = '#ffffff';
      } else if (cRand > 0.6) {
        color = 'rgba(103, 232, 249, '; // electric neon cyan
        starTempColor = '#a5f3fc';
      } else if (cRand > 0.4) {
        color = 'rgba(45, 212, 191, '; // turquoise ionization edge
        starTempColor = '#5eead4';
      } else if (cRand > 0.2) {
        color = 'rgba(56, 189, 248, '; // azure sky blue
        starTempColor = '#7dd3fc';
      } else {
        color = 'rgba(52, 211, 153, '; // emerald-teal transition
        starTempColor = '#6ee7b7';
      }

      const scatter = 0.8 + Math.random() * 2.2;
      const dispX = x * scatter + randn() * 0.3;
      const dispY = y * scatter + randn() * 0.3;
      const dispZ = z * scatter + randn() * 0.3;

      const sp = computeSpherePoint('oxygen_cavity', i, OXYGEN_COUNT);

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.16 + Math.random() * 0.4,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.05 + Math.random() * 0.08,
        twinkleSpeed: 1.6 + Math.random() * 3.0,
        twinklePhase: Math.random() * Math.PI * 2,
        size: 1.0 + Math.random() * 1.5,
        alpha: 0.75 + Math.random() * 0.25,
        baseAlpha: 0.75 + Math.random() * 0.25,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#cffafe',
        isCoreStar: false,
        isDiffractionStar: i < 5,
        diffractionType: i < 5 ? 'webb_6' : 'none',
        starTempColor,
        zone: 'oxygen_cavity',
        gasFlowSpeed: 0.3 + Math.random() * 0.5,
      });
    }

    // =========================================================================
    // 4. Ionized Hydrogen [H-alpha] Outer Canopy (656.3 nm)
    // Deep ruby crimson, velvet cosmic magenta, hot fuchsia, and celestial rose
    // =========================================================================
    const HYDROGEN_COUNT = 760;
    for (let i = 0; i < HYDROGEN_COUNT; i++) {
      const u = Math.random();
      const armR = 0.24 + Math.pow(u, 0.75) * 1.38;
      const armAngle = 1.62 * Math.PI - u * 1.35 + randn() * 0.2;

      const thickness = 0.16 + Math.sin(u * Math.PI) * 0.26;
      const x = Math.cos(armAngle) * armR + randn() * thickness;
      const y = Math.sin(armAngle) * armR * 0.88 + randn() * thickness;
      const z = -(u - 0.35) * 0.58 + randn() * (thickness * 0.75);

      let color = 'rgba(232, 121, 249, '; // [H-alpha] cosmic magenta (656.3nm)
      let starTempColor = '#f0abfc';
      const cRand = Math.random();
      if (cRand > 0.8) {
        color = 'rgba(244, 63, 94, '; // luminous ruby crimson
        starTempColor = '#fb7185';
      } else if (cRand > 0.6) {
        color = 'rgba(236, 72, 153, '; // vibrant hot fuchsia
        starTempColor = '#f472b6';
      } else if (cRand > 0.4) {
        color = 'rgba(192, 132, 252, '; // celestial violet
        starTempColor = '#c084fc';
      } else if (cRand > 0.2) {
        color = 'rgba(168, 85, 247, '; // deep royal orchid
        starTempColor = '#c084fc';
      } else {
        color = 'rgba(251, 113, 133, '; // warm rose nebula gas
        starTempColor = '#fda4af';
      }

      const scatter = 0.8 + Math.random() * 2.2;
      const dispX = x * scatter + randn() * 0.3;
      const dispY = y * scatter + randn() * 0.3;
      const dispZ = z * scatter + randn() * 0.3;

      const sp = computeSpherePoint('hydrogen_canopy', i, HYDROGEN_COUNT);

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.16 + Math.random() * 0.4,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.05 + Math.random() * 0.08,
        twinkleSpeed: 1.6 + Math.random() * 3.0,
        twinklePhase: Math.random() * Math.PI * 2,
        size: 1.0 + Math.random() * 1.5,
        alpha: 0.75 + Math.random() * 0.25,
        baseAlpha: 0.75 + Math.random() * 0.25,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#fce7f3',
        isCoreStar: false,
        isDiffractionStar: i < 5,
        diffractionType: i < 5 ? 'webb_6' : 'none',
        starTempColor,
        zone: 'hydrogen_canopy',
        gasFlowSpeed: 0.3 + Math.random() * 0.5,
      });
    }

    // =========================================================================
    // 5. Ionized Nitrogen [N II] Shock Arc & Filament Fronts
    // Scarlet cinnabar, electric persimmon, and fiery solar amber
    // =========================================================================
    const NITROGEN_COUNT = 240;
    for (let i = 0; i < NITROGEN_COUNT; i++) {
      const u = (Math.random() - 0.5) * 2;
      const arcR = 0.55 + Math.random() * 0.65;
      const angle = 1.15 * Math.PI + u * 0.6 + randn() * 0.15;

      const x = Math.cos(angle) * arcR + randn() * 0.14;
      const y = Math.sin(angle) * arcR * 0.9 + randn() * 0.14;
      const z = u * 0.45 + randn() * 0.18;

      let color = 'rgba(239, 68, 68, '; // electric cinnabar
      let starTempColor = '#f87171';
      if (Math.random() > 0.5) {
        color = 'rgba(251, 146, 60, '; // persimmon flame
        starTempColor = '#fdba74';
      } else if (Math.random() > 0.25) {
        color = 'rgba(252, 211, 77, '; // solar amber shock tip
        starTempColor = '#fef08a';
      }

      const scatter = 0.9 + Math.random() * 2.0;
      const dispX = x * scatter + randn() * 0.25;
      const dispY = y * scatter + randn() * 0.25;
      const dispZ = z * scatter + randn() * 0.25;

      const sp = computeSpherePoint('nitrogen_flame', i, NITROGEN_COUNT);

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.2 + Math.random() * 0.4,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.04 + Math.random() * 0.07,
        twinkleSpeed: 2.0 + Math.random() * 3.5,
        twinklePhase: Math.random() * Math.PI * 2,
        size: 1.1 + Math.random() * 1.3,
        alpha: 0.8 + Math.random() * 0.2,
        baseAlpha: 0.8 + Math.random() * 0.2,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#fee2e2',
        isCoreStar: false,
        isDiffractionStar: false,
        diffractionType: 'none',
        starTempColor,
        zone: 'nitrogen_flame',
        gasFlowSpeed: 0.4 + Math.random() * 0.4,
      });
    }

    // =========================================================================
    // 6. Cold Interstellar Dust Pillars & Bok Globules (Dark Silhouette Contrast)
    // Dark absorbing silicates, smoky bronze, and interstellar indigo shadows
    // =========================================================================
    const DUST_PILLARS_COUNT = 160;
    for (let i = 0; i < DUST_PILLARS_COUNT; i++) {
      // Create column-like tendrils cutting across the glowing interior
      const u = Math.random();
      const colX = -0.18 + u * 0.35 + randn() * 0.08;
      const colY = -0.3 + u * 0.75 + randn() * 0.09;
      const colZ = 0.12 + randn() * 0.12; // slightly in front to occlude back emissions

      let color = 'rgba(120, 53, 15, '; // dark interstellar bronze dust
      let starTempColor = '#78350f';
      if (Math.random() > 0.5) {
        color = 'rgba(71, 85, 105, '; // smoky slate-indigo
        starTempColor = '#475569';
      } else if (Math.random() > 0.25) {
        color = 'rgba(88, 28, 135, '; // deep dark plum dust
        starTempColor = '#581c87';
      }

      const scatter = 0.9 + Math.random() * 2.0;
      const dispX = colX * scatter;
      const dispY = colY * scatter;
      const dispZ = colZ * scatter;

      const sp = computeSpherePoint('dark_dust_pillar', i, DUST_PILLARS_COUNT);

      particles.push({
        baseX: colX,
        baseY: colY,
        baseZ: colZ,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.12 + Math.random() * 0.25,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.04 + Math.random() * 0.06,
        twinkleSpeed: 1.0 + Math.random() * 2.0,
        twinklePhase: Math.random() * Math.PI * 2,
        size: 1.4 + Math.random() * 1.4,
        alpha: 0.6 + Math.random() * 0.35,
        baseAlpha: 0.6 + Math.random() * 0.35,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#334155',
        isCoreStar: false,
        isDiffractionStar: false,
        diffractionType: 'none',
        starTempColor,
        zone: 'dark_dust_pillar',
        gasFlowSpeed: 0.2 + Math.random() * 0.2,
      });
    }

    // =========================================================================
    // 7. Diffuse Outer Gas Veil & Cosmic Stardust
    // =========================================================================
    const VEIL_COUNT = TOTAL_PARTICLES - particles.length;
    for (let i = 0; i < VEIL_COUNT; i++) {
      const r = 0.42 + Math.random() * 1.38;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta) * 0.9;
      const z = r * Math.cos(phi) * 0.72;

      let color = 'rgba(147, 197, 253, '; // soft interstellar blue
      let starTempColor = '#93c5fd';
      const cRand = Math.random();
      if (cRand > 0.7) {
        color = 'rgba(196, 181, 253, '; // ethereal lavender dust
        starTempColor = '#c4b5fd';
      } else if (cRand > 0.45) {
        color = 'rgba(251, 207, 232, '; // pale cosmic rose
        starTempColor = '#fbcfe8';
      } else if (cRand > 0.2) {
        color = 'rgba(254, 215, 170, '; // warm stellar peach
        starTempColor = '#fed7aa';
      } else {
        color = 'rgba(167, 243, 208, '; // soft mint stardust
        starTempColor = '#a7f3d0';
      }

      const scatter = 1.0 + Math.random() * 2.0;
      const dispX = x * scatter;
      const dispY = y * scatter;
      const dispZ = z * scatter;

      const sp = computeSpherePoint('diffuse_stardust', i, VEIL_COUNT);

      particles.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        ...sp,
        dispX,
        dispY,
        dispZ,
        driftSpeed: 0.1 + Math.random() * 0.3,
        driftPhase: Math.random() * Math.PI * 2,
        driftRadius: 0.06 + Math.random() * 0.08,
        twinkleSpeed: 1.0 + Math.random() * 2.2,
        twinklePhase: Math.random() * Math.PI * 2,
        size: 0.8 + Math.random() * 1.2,
        alpha: 0.45 + Math.random() * 0.3,
        baseAlpha: 0.45 + Math.random() * 0.3,
        color,
        r: parseRgba(color)[0],
        g: parseRgba(color)[1],
        b: parseRgba(color)[2],
        coreColor: '#ffffff',
        isCoreStar: false,
        isDiffractionStar: false,
        diffractionType: 'none',
        starTempColor,
        zone: 'diffuse_stardust',
        gasFlowSpeed: 0.2 + Math.random() * 0.3,
      });
    }

    particlesRef.current = particles;

    // Ambient Outer Stardust Particles with realistic stellar spectral types
    const ambient: AmbientParticle[] = [];
    const NUM_AMBIENT_COUNT = fullBackground ? 320 : 160;
    for (let i = 0; i < NUM_AMBIENT_COUNT; i++) {
      const dist = 0.9 + Math.random() * 2.9;
      const theta = Math.random() * Math.PI * 2;
      const phiAngle = Math.acos(Math.random() * 2 - 1);

      let color = 'rgba(224, 242, 254, '; // Class A/B white-blue star
      const rColor = Math.random();
      if (rColor > 0.75) {
        color = 'rgba(254, 240, 138, '; // Class G yellow/gold star
      } else if (rColor > 0.5) {
        color = 'rgba(253, 186, 116, '; // Class K orange dwarf
      } else if (rColor > 0.25) {
        color = 'rgba(244, 114, 182, '; // Class M red/rose protostar
      } else {
        color = 'rgba(165, 243, 252, '; // Class O hot cyan star
      }

      ambient.push({
        x: dist * Math.sin(phiAngle) * Math.cos(theta),
        y: dist * Math.sin(phiAngle) * Math.sin(theta),
        z: dist * Math.cos(phiAngle),
        vx: (Math.random() - 0.5) * 0.0016,
        vy: (Math.random() - 0.5) * 0.0016,
        vz: (Math.random() - 0.5) * 0.0016,
        size: 0.6 + Math.random() * 1.6,
        alpha: 0.25 + Math.random() * 0.45,
        color,
      });
    }
    ambientParticlesRef.current = ambient;
  }, [fullBackground]);

  // Main 60fps Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let lastTime = performance.now();

    const render = (currentTime: number) => {
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;
      pulseTimeRef.current += dt;

      const currentStatus = statusRef.current;
      const currentAudio = audioLevelRef.current;
      const targetAudio = Math.min(100, Math.max(0, currentAudio));
      audioSmoothRef.current += (targetAudio - audioSmoothRef.current) * (dt * 12);
      const audioNorm = audioSmoothRef.current / 100; // 0 to 1

      // DPR sharpness & container adaptation
      const dpr = window.devicePixelRatio || 1;
      let displayWidth = size;
      let displayHeight = size;

      if (fullBackground) {
        displayWidth = containerRef.current?.clientWidth || window.innerWidth;
        displayHeight = containerRef.current?.clientHeight || window.innerHeight;
      }

      if (
        canvas.width !== Math.floor(displayWidth * dpr) ||
        canvas.height !== Math.floor(displayHeight * dpr)
      ) {
        canvas.width = Math.floor(displayWidth * dpr);
        canvas.height = Math.floor(displayHeight * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, displayWidth, displayHeight);

      const centerX = displayWidth / 2;
      const centerY = displayHeight / 2;
      const baseRadius = fullBackground
        ? Math.min(displayWidth, displayHeight) * 0.22
        : displayWidth * 0.36;

      // Microphone active state determination
      const isMicActive =
        isMicOnRef.current !== undefined
          ? isMicOnRef.current
          : currentStatus === 'listening' ||
            currentStatus === 'thinking' ||
            currentStatus === 'speaking';

      // 3D Sphere morph interpolation: smoothly transition to 1.0 after the first click
      const targetSphere = hasClickedRef.current ? 1.0 : 0.0;
      sphereMorphRef.current +=
        (targetSphere - sphereMorphRef.current) * Math.min(1, dt * 2.4);
      const sMorph = sphereMorphRef.current;
      const easeSphere = sMorph * sMorph * (3 - 2 * sMorph);

      // Smooth state transitions: active luminous orb/sphere vs calm reflection nebula
      const targetDispersion = isMicActive || easeSphere > 0.08 ? 0.0 : 0.65;
      const targetBrightness = isMicActive
        ? 1.45 + audioNorm * 1.3
        : easeSphere > 0.4
        ? 1.15
        : 0.28;

      dispersionRef.current +=
        (targetDispersion - dispersionRef.current) * Math.min(1, dt * 3.2);
      brightnessRef.current +=
        (targetBrightness - brightnessRef.current) * Math.min(1, dt * 4.0);

      const disp = dispersionRef.current;
      const easeDisp = disp * disp * (3 - 2 * disp);
      const brightness = brightnessRef.current;

      // 3D Physics:
      if (!isDraggingRef.current) {
        const inertiaSpeed = Math.hypot(
          dragVelocityRef.current.yaw,
          dragVelocityRef.current.pitch
        );
        if (inertiaSpeed > 0.012) {
          rotationRef.current.yaw += dragVelocityRef.current.yaw * dt;
          rotationRef.current.pitch += dragVelocityRef.current.pitch * dt;
          const decay = Math.pow(0.88, dt * 60);
          dragVelocityRef.current.yaw *= decay;
          dragVelocityRef.current.pitch *= decay;
        } else {
          // When in sphere mode, add a subtle, majestic ambient planetary spin
          if (easeSphere > 0.3) {
            rotationRef.current.yaw += 0.22 * dt * easeSphere;
            rotationRef.current.pitch +=
              (0.04 - rotationRef.current.pitch) * Math.min(1, dt * 2.0);
          } else {
            // Gently settle back to front-facing stable angle in nebula mode
            rotationRef.current.yaw +=
              (0.15 - rotationRef.current.yaw) * Math.min(1, dt * 2.8);
            rotationRef.current.pitch +=
              (0.08 - rotationRef.current.pitch) * Math.min(1, dt * 2.8);
          }
        }
      }

      // Clamp pitch so the nebula doesn't flip upside-down
      const maxPitch = Math.PI * 0.42;
      rotationRef.current.pitch = Math.max(
        -maxPitch,
        Math.min(maxPitch, rotationRef.current.pitch)
      );

      // Smooth magnetic cursor hover tilt
      const targetHoverYaw = cursorHoverRef.current.yaw;
      const targetHoverPitch = cursorHoverRef.current.pitch;
      hoverTiltRef.current.yaw +=
        (targetHoverYaw - hoverTiltRef.current.yaw) * Math.min(1, dt * 6);
      hoverTiltRef.current.pitch +=
        (targetHoverPitch - hoverTiltRef.current.pitch) * Math.min(1, dt * 6);

      const totalYaw = rotationRef.current.yaw + hoverTiltRef.current.yaw;
      const totalPitch = rotationRef.current.pitch + hoverTiltRef.current.pitch;

      const cosYaw = Math.cos(totalYaw);
      const sinYaw = Math.sin(totalYaw);
      const cosPitch = Math.cos(totalPitch);
      const sinPitch = Math.sin(totalPitch);

      // =======================================================================
      // 1. Multi-Wavelength Volumetric Gas Plumes (Screen Blended Nebular Light)
      // Realistic false-color composite modeled after Hubble/JWST palettes
      // =======================================================================
      ctx.globalCompositeOperation = 'screen';
      const t = pulseTimeRef.current;
      const breathe = Math.sin(t * 1.2) * 0.03;

      // Layer A: Deep Cosmic Abyss Halo (Ultramarine & Deep Violet base)
      const bgHaloRadius = fullBackground
        ? Math.max(displayWidth, displayHeight) * 0.65
        : baseRadius * 1.95;
      const bgHaloGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        baseRadius * 0.1,
        centerX,
        centerY,
        bgHaloRadius
      );
      if (isMicActive) {
        bgHaloGrad.addColorStop(0, `rgba(14, 165, 233, ${(0.35 * brightness).toFixed(3)})`);
        bgHaloGrad.addColorStop(0.3, `rgba(147, 51, 234, ${(0.22 * brightness).toFixed(3)})`);
        bgHaloGrad.addColorStop(0.55, `rgba(244, 63, 94, ${(0.14 * brightness).toFixed(3)})`);
        bgHaloGrad.addColorStop(0.75, `rgba(30, 27, 75, ${(0.08 * brightness).toFixed(3)})`);
        bgHaloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else {
        bgHaloGrad.addColorStop(0, `rgba(14, 165, 233, ${(0.14 + breathe).toFixed(3)})`);
        bgHaloGrad.addColorStop(0.4, `rgba(88, 28, 135, ${(0.07 + breathe).toFixed(3)})`);
        bgHaloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      }
      ctx.fillStyle = bgHaloGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, bgHaloRadius, 0, Math.PI * 2);
      ctx.fill();

      // When transitioning to sphere mode, smoothly center all asymmetrical nebula offsets
      // into a brilliant, concentric spherical coronal halo and core
      const offsetFactor = 1 - easeSphere;

      // Layer B: Cosmic Cliffs / Sulfur [S II] Molten Amber-Copper Shelf
      const sulfurOffsetX = (baseRadius * 0.35) * cosYaw * offsetFactor;
      const sulfurOffsetY = (baseRadius * 0.18) * cosPitch * offsetFactor;
      const sulfurRadius = baseRadius * (0.95 + audioNorm * 0.25);
      const sulfurGrad = ctx.createRadialGradient(
        centerX + sulfurOffsetX,
        centerY + sulfurOffsetY,
        0,
        centerX + sulfurOffsetX,
        centerY + sulfurOffsetY,
        sulfurRadius
      );
      sulfurGrad.addColorStop(0, `rgba(249, 115, 22, ${(0.32 * brightness).toFixed(3)})`); // copper
      sulfurGrad.addColorStop(0.35, `rgba(245, 158, 11, ${(0.22 * brightness).toFixed(3)})`); // amber
      sulfurGrad.addColorStop(0.65, `rgba(194, 65, 12, ${(0.10 * brightness).toFixed(3)})`); // terracotta
      sulfurGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = sulfurGrad;
      ctx.beginPath();
      ctx.arc(centerX + sulfurOffsetX, centerY + sulfurOffsetY, sulfurRadius, 0, Math.PI * 2);
      ctx.fill();

      // Layer C: Doubly Ionized Oxygen [O III] Cavity (North-East Cyan & Turquoise Plume)
      const o3OffsetX = (baseRadius * 0.48) * cosYaw * offsetFactor;
      const o3OffsetY = -(baseRadius * 0.38) * cosPitch * offsetFactor;
      const o3Radius = baseRadius * (0.88 + audioNorm * 0.25);
      const o3Grad = ctx.createRadialGradient(
        centerX + o3OffsetX,
        centerY + o3OffsetY,
        0,
        centerX + o3OffsetX,
        centerY + o3OffsetY,
        o3Radius
      );
      o3Grad.addColorStop(0, `rgba(34, 211, 238, ${(0.32 * brightness).toFixed(3)})`); // vivid cyan
      o3Grad.addColorStop(0.4, `rgba(45, 212, 191, ${(0.18 * brightness).toFixed(3)})`); // turquoise
      o3Grad.addColorStop(0.7, `rgba(14, 116, 144, ${(0.08 * brightness).toFixed(3)})`); // deep ocean
      o3Grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = o3Grad;
      ctx.beginPath();
      ctx.arc(centerX + o3OffsetX, centerY + o3OffsetY, o3Radius, 0, Math.PI * 2);
      ctx.fill();

      // Layer D: Ionized Hydrogen [H-alpha] Canopy (South-West Magenta & Ruby Plume)
      const hAlphaOffsetX = -(baseRadius * 0.48) * cosYaw * offsetFactor;
      const hAlphaOffsetY = (baseRadius * 0.38) * cosPitch * offsetFactor;
      const hAlphaRadius = baseRadius * (0.88 + audioNorm * 0.25);
      const hAlphaGrad = ctx.createRadialGradient(
        centerX + hAlphaOffsetX,
        centerY + hAlphaOffsetY,
        0,
        centerX + hAlphaOffsetX,
        centerY + hAlphaOffsetY,
        hAlphaRadius
      );
      hAlphaGrad.addColorStop(0, `rgba(232, 121, 249, ${(0.32 * brightness).toFixed(3)})`); // magenta
      hAlphaGrad.addColorStop(0.4, `rgba(244, 63, 94, ${(0.2 * brightness).toFixed(3)})`); // ruby crimson
      hAlphaGrad.addColorStop(0.7, `rgba(168, 85, 247, ${(0.1 * brightness).toFixed(3)})`); // royal orchid
      hAlphaGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = hAlphaGrad;
      ctx.beginPath();
      ctx.arc(centerX + hAlphaOffsetX, centerY + hAlphaOffsetY, hAlphaRadius, 0, Math.PI * 2);
      ctx.fill();

      // Layer E: Central Protostellar Core Glow (Incandescent Diamond Glare)
      const coreGlowRadius = baseRadius * (0.44 + audioNorm * 0.2);
      const coreGlowGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        coreGlowRadius
      );
      coreGlowGrad.addColorStop(0, `rgba(255, 255, 255, ${(0.55 * brightness).toFixed(3)})`);
      coreGlowGrad.addColorStop(0.3, `rgba(254, 240, 138, ${(0.32 * brightness).toFixed(3)})`); // golden stellar corona
      coreGlowGrad.addColorStop(0.65, `rgba(165, 243, 252, ${(0.18 * brightness).toFixed(3)})`); // cyan halo
      coreGlowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = coreGlowGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, coreGlowRadius, 0, Math.PI * 2);
      ctx.fill();

      // =======================================================================
      // 2. Ambient Drifting Outer Stardust Field (Class O, B, A, G, M Stars)
      // =======================================================================
      ctx.globalCompositeOperation = 'lighter';
      const ambients = ambientParticlesRef.current;
      for (let i = 0; i < ambients.length; i++) {
        const p = ambients[i];
        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;

        const d = Math.hypot(p.x, p.y, p.z);
        if (d > 3.4 || d < 0.7) {
          p.vx *= -1;
          p.vy *= -1;
          p.vz *= -1;
        }

        const fov = 340;
        const scale = fov / (fov + p.z * baseRadius);
        const spreadMultiplier = fullBackground ? 2.4 : 1.0;
        const px = centerX + p.x * baseRadius * scale * spreadMultiplier;
        const py = centerY + p.y * baseRadius * scale * spreadMultiplier;

        ctx.fillStyle = `${p.color}${(p.alpha * (p.z > 0 ? 1 : 0.45) * brightness * 0.85).toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(px, py, Math.max(0.6, p.size * scale), 0, Math.PI * 2);
        ctx.fill();
      }

      // =======================================================================
      // 3. Main 3D Nebula Point Cloud & Stars (Gas Filaments & Star Clusters)
      // =======================================================================
      const particles = particlesRef.current;
      const fov = 380;

      // Wave ripple propagation through the cosmic gas
      const waveFreq = currentStatus === 'thinking' ? 4.2 : 2.6;
      const waveAmp = (0.045 + (isMicActive ? audioNorm * 0.08 : 0)) * (1 - easeDisp);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Structural morphing between initial nebula layout and 3D spherical orb
        const structX = p.baseX * (1 - easeSphere) + p.sphereX * easeSphere;
        const structY = p.baseY * (1 - easeSphere) + p.sphereY * easeSphere;
        const structZ = p.baseZ * (1 - easeSphere) + p.sphereZ * easeSphere;

        // Dynamics:
        // 1. Nebula mode: organic fluid ripple & convective flow
        const gasFlow = Math.sin(p.driftPhase + t * (0.8 + p.gasFlowSpeed)) * p.driftRadius;
        const nebulaSoundRipple =
          Math.sin(p.baseX * 4.0 + p.baseY * 3.5 + t * waveFreq) * waveAmp;
        const nebulaRMultiplier = 1 + nebulaSoundRipple + gasFlow;

        // 2. Sphere mode: spherical harmonic surface ripples & radial audio breathing
        const sphereSurfaceWave =
          Math.sin(p.sphereTheta * 3.5 + p.spherePhi * 2.5 + t * waveFreq) * (waveAmp * 0.85);
        const sphereAudioPulse =
          (isMicActive ? audioNorm * 0.16 : 0) + Math.sin(t * 1.6 + p.driftPhase) * 0.025;
        const sphereRMultiplier = 1 + sphereSurfaceWave + sphereAudioPulse;

        const curRMultiplier =
          nebulaRMultiplier * (1 - easeSphere) + sphereRMultiplier * easeSphere;

        // Dispersion blending (contracting into sphere bounds when in sphere mode)
        const effectiveDisp = easeDisp * (1 - easeSphere);
        const dispMultiplier = fullBackground ? 1.4 : 1.0;
        const curX =
          structX * curRMultiplier * (1 - effectiveDisp) +
          p.dispX * effectiveDisp * dispMultiplier;
        const curY =
          structY * curRMultiplier * (1 - effectiveDisp) +
          p.dispY * effectiveDisp * dispMultiplier;
        const curZ =
          structZ * curRMultiplier * (1 - effectiveDisp) +
          p.dispZ * effectiveDisp * dispMultiplier;

        // 3D Rotation (Yaw around Y, then Pitch around X)
        // 1. Rotate around Y axis
        const x1 = curX * cosYaw - curZ * sinYaw;
        const z1 = curZ * cosYaw + curX * sinYaw;
        const y1 = curY;

        // 2. Rotate around X axis
        const y2 = y1 * cosPitch - z1 * sinPitch;
        const z2 = z1 * cosPitch + y1 * sinPitch;
        const x2 = x1;

        // 3. Perspective Projection
        const scale = fov / (fov + z2 * baseRadius);
        const px = centerX + x2 * baseRadius * scale;
        const py = centerY + y2 * baseRadius * scale;

        // Depth shading & star twinkle
        const depthFactor = (z2 + 1.2) * 0.45; // 0 to 1
        const twinkle = 0.82 + 0.18 * Math.sin(t * p.twinkleSpeed + p.twinklePhase);
        const pointSize = Math.max(
          0.8,
          p.size * scale * (0.75 + depthFactor * 0.5) * (p.isCoreStar ? 1.3 : 1.0)
        );

        let finalAlpha =
          p.baseAlpha * (0.35 + depthFactor * 0.75) * twinkle * brightness;

        if (!isMicActive) {
          finalAlpha *= 0.42;
        }

        if (p.isCoreStar && isMicActive) {
          finalAlpha = Math.min(1.0, finalAlpha * 1.4 + 0.25 * brightness);
        }

        if (currentStatus === 'listening') {
          finalAlpha = Math.min(1.0, finalAlpha * (1.2 + audioNorm * 0.7));
        } else if (currentStatus === 'thinking') {
          finalAlpha = Math.min(1.0, finalAlpha * (1.1 + Math.sin(t * 4.8 + p.driftPhase) * 0.2));
        } else if (currentStatus === 'speaking') {
          finalAlpha = Math.min(1.0, finalAlpha * (1.15 + audioNorm * 0.85));
        }

        // Draw individual gas/star particle point with vivid astronomical color & state harmony
        const alphaClamped = Math.max(0.04, Math.min(1, finalAlpha)).toFixed(3);
        if (currentStatus === 'thinking') {
          const pr = Math.round(p.r * 0.7 + 168 * 0.3);
          const pg = Math.round(p.g * 0.65 + 85 * 0.35);
          const pb = Math.round(p.b * 0.7 + 247 * 0.3);
          ctx.fillStyle = `rgba(${pr}, ${pg}, ${pb}, ${alphaClamped})`;
        } else if (currentStatus === 'listening') {
          const pr = Math.round(p.r * 0.8 + 34 * 0.2);
          const pg = Math.round(p.g * 0.8 + 211 * 0.2);
          const pb = Math.round(p.b * 0.8 + 238 * 0.2);
          ctx.fillStyle = `rgba(${pr}, ${pg}, ${pb}, ${alphaClamped})`;
        } else if (currentStatus === 'speaking' && audioNorm > 0.05) {
          const boost = Math.min(0.35, audioNorm * 0.45);
          const pr = Math.round(p.r * (1 - boost) + 96 * boost);
          const pg = Math.round(p.g * (1 - boost) + 165 * boost);
          const pb = Math.round(p.b * (1 - boost) + 250 * boost);
          ctx.fillStyle = `rgba(${pr}, ${pg}, ${pb}, ${alphaClamped})`;
        } else {
          ctx.fillStyle = `${p.color}${alphaClamped})`;
        }
        ctx.beginPath();
        ctx.arc(px, py, pointSize, 0, Math.PI * 2);
        ctx.fill();

        // Crystalline diamond specular highlight on bright stars
        if (finalAlpha > 0.52 && z2 > -0.3) {
          ctx.fillStyle = `${p.coreColor || '#ffffff'}`;
          ctx.beginPath();
          ctx.arc(px, py, pointSize * 0.42, 0, Math.PI * 2);
          ctx.fill();
        }

        // =====================================================================
        // Astronomical Diffraction Optics (James Webb 6-Point & Hubble 4-Point)
        // Realistic chromatic diffraction spikes on prominent newborn protostars
        // =====================================================================
        if (
          p.isDiffractionStar &&
          isMicActive &&
          finalAlpha > 0.62 &&
          z2 > 0.05 &&
          p.diffractionType !== 'none'
        ) {
          const spikeLen = pointSize * (4.8 + audioNorm * 3.5);
          const spikeAlpha = Math.min(0.85, finalAlpha * 0.65).toFixed(3);

          ctx.save();
          ctx.translate(px, py);

          // Subtle chromatic dispersion: primary rays in star temperature color, faint blue/gold offsets
          if (p.diffractionType === 'webb_6') {
            // James Webb Space Telescope: 6-pointed hexagonal diffraction pattern (60-deg intervals)
            ctx.strokeStyle = `rgba(255, 255, 255, ${spikeAlpha})`;
            ctx.lineWidth = 0.8;
            for (let k = 0; k < 3; k++) {
              const rad = (k * Math.PI) / 3;
              ctx.beginPath();
              ctx.moveTo(-Math.cos(rad) * spikeLen, -Math.sin(rad) * spikeLen);
              ctx.lineTo(Math.cos(rad) * spikeLen, Math.sin(rad) * spikeLen);
              ctx.stroke();
            }

            // Subtle chromatic secondary fringe (cyan and golden dispersion)
            ctx.strokeStyle = `${p.starTempColor}44`;
            ctx.lineWidth = 0.5;
            for (let k = 0; k < 3; k++) {
              const rad = (k * Math.PI) / 3 + 0.04;
              ctx.beginPath();
              ctx.moveTo(-Math.cos(rad) * (spikeLen * 0.85), -Math.sin(rad) * (spikeLen * 0.85));
              ctx.lineTo(Math.cos(rad) * (spikeLen * 0.85), Math.sin(rad) * (spikeLen * 0.85));
              ctx.stroke();
            }
          } else {
            // Hubble Space Telescope: Classic 4-pointed cross pattern (90-deg intervals)
            ctx.strokeStyle = `rgba(255, 255, 255, ${spikeAlpha})`;
            ctx.lineWidth = 0.85;
            ctx.beginPath();
            ctx.moveTo(-spikeLen, 0);
            ctx.lineTo(spikeLen, 0);
            ctx.moveTo(0, -spikeLen);
            ctx.lineTo(0, spikeLen);
            ctx.stroke();

            // Warm golden core fringe
            ctx.strokeStyle = `${p.starTempColor}44`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(-spikeLen * 0.8, 0);
            ctx.lineTo(spikeLen * 0.8, 0);
            ctx.moveTo(0, -spikeLen * 0.8);
            ctx.lineTo(0, spikeLen * 0.8);
            ctx.stroke();
          }

          // Soft radiant flare halo centered on the star
          const flareR = pointSize * 3.2;
          const flareGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, flareR);
          flareGrad.addColorStop(0, `rgba(255, 255, 255, ${spikeAlpha})`);
          flareGrad.addColorStop(0.4, `${p.starTempColor}55`);
          flareGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = flareGrad;
          ctx.beginPath();
          ctx.arc(0, 0, flareR, 0, Math.PI * 2);
          ctx.fill();

          ctx.restore();
        }
      }

      ctx.restore();

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    animFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [size, fullBackground]);

  // 3D Orbital Cursor Interaction Handlers (Tilt and spatial depth inspection)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement | null;
    if (target?.closest('button, a, input, textarea, select')) {
      return;
    }
    isDraggingRef.current = true;
    setIsDragging(true);
    lastMousePosRef.current = { x: e.clientX, y: e.clientY, time: performance.now() };
    dragVelocityRef.current = { yaw: 0, pitch: 0 };
    totalDragDistRef.current = 0;
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const now = performance.now();
    const dtMouse = Math.max(0.001, (now - lastMousePosRef.current.time) / 1000);

    if (isDraggingRef.current) {
      const dx = e.clientX - lastMousePosRef.current.x;
      const dy = e.clientY - lastMousePosRef.current.y;
      totalDragDistRef.current += Math.hypot(dx, dy);

      const sensitivity = 0.006;
      const dYaw = dx * sensitivity;
      const dPitch = dy * sensitivity;

      rotationRef.current.yaw += dYaw;
      rotationRef.current.pitch += dPitch;

      const maxPitch = Math.PI * 0.42;
      rotationRef.current.pitch = Math.max(-maxPitch, Math.min(maxPitch, rotationRef.current.pitch));

      dragVelocityRef.current = {
        yaw: dYaw / dtMouse,
        pitch: dPitch / dtMouse,
      };

      lastMousePosRef.current = { x: e.clientX, y: e.clientY, time: now };
    } else {
      // Magnetic hover tilt towards cursor position to inspect depth
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const nx = (e.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
        const ny = (e.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
        cursorHoverRef.current = {
          yaw: Math.max(-0.25, Math.min(0.25, nx * 0.22)),
          pitch: Math.max(-0.25, Math.min(0.25, ny * 0.22)),
        };
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    setIsDragging(false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }

    // Only click if it was not a rotation drag
    if (totalDragDistRef.current < 7) {
      if (!hasClickedRef.current) {
        hasClickedRef.current = true;
        setHasClicked(true);
        try {
          sessionStorage.setItem('lexi_orb_has_clicked', 'true');
        } catch {
          // safe fallback
        }
      }
      onClick?.();
    }
  };

  const getStatusBadge = () => {
    switch (status) {
      case 'listening':
        return {
          icon: <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-300" />,
          label: 'Escuchando tu voz...',
          badgeClass: 'bg-cyan-950/80 border-cyan-500/60 text-cyan-200 shadow-cyan-500/30',
          pulseColor: 'bg-cyan-400',
        };
      case 'thinking':
        return {
          icon: <Brain className="w-3.5 h-3.5 animate-spin text-purple-300" />,
          label: 'Analizando instrucción...',
          badgeClass: 'bg-purple-950/80 border-purple-500/60 text-purple-200 shadow-purple-500/30',
          pulseColor: 'bg-purple-400',
        };
      case 'speaking':
        return {
          icon: <Volume2 className="w-3.5 h-3.5 animate-bounce text-blue-300" />,
          label: 'Lexi respondiendo...',
          badgeClass: 'bg-blue-950/80 border-blue-500/60 text-blue-200 shadow-blue-500/30',
          pulseColor: 'bg-blue-400',
        };
      default:
        return {
          icon: <Sparkles className="w-3.5 h-3.5 text-sky-400" />,
          label: isHovered
            ? '¡Haz clic para hablar!'
            : hasClicked
            ? 'Toca la esfera para hablar'
            : 'Toca el orbe para hablar',
          badgeClass: 'bg-slate-900/80 border-slate-700/80 text-slate-300 hover:border-cyan-500/50',
          pulseColor: 'bg-sky-400',
        };
    }
  };

  const badge = getStatusBadge();

  return (
    <div
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        cursorHoverRef.current = { yaw: 0, pitch: 0 };
      }}
      className={`relative select-none touch-none ${
        fullBackground
          ? 'w-full h-full absolute inset-0 overflow-hidden flex items-center justify-center'
          : 'flex flex-col items-center justify-center'
      } ${isDragging ? 'cursor-grabbing' : 'cursor-grab'} ${className}`}
      style={fullBackground ? undefined : { minWidth: size, minHeight: size }}
      title={
        isMicOn
          ? hasClicked
            ? 'Micrófono encendido (Esfera activa) • Clic para apagar o di "adiós" / "descansa"'
            : 'Micrófono encendido (Orbe activo) • Clic para apagar o di "adiós" / "descansa"'
          : hasClicked
          ? 'Micrófono apagado (Esfera en reposo) • Clic para encender'
          : 'Micrófono apagado • Clic para activar la esfera'
      }
    >
      {/* Outer ambient deep glow backdrop with multi-spectral hues */}
      <div
        className={`absolute rounded-full transition-all duration-700 pointer-events-none ${
          fullBackground ? 'w-[620px] h-[620px]' : 'w-88 h-88'
        } ${
          isMicOn || status === 'listening'
            ? 'bg-radial from-cyan-400/25 via-fuchsia-500/20 to-transparent blur-3xl animate-pulse'
            : status === 'thinking'
            ? 'bg-radial from-purple-400/25 via-amber-500/20 to-transparent blur-3xl animate-pulse'
            : status === 'speaking'
            ? 'bg-radial from-blue-400/25 via-rose-500/20 to-transparent blur-3xl animate-pulse'
            : 'bg-cyan-600/5 blur-3xl opacity-20'
        }`}
      />

      {/* HTML5 Canvas Simulation: Deep Space Nebula Point Cloud */}
      <canvas
        ref={canvasRef}
        className={`${fullBackground ? 'absolute inset-0 w-full h-full' : 'relative'} z-10 touch-none`}
        style={fullBackground ? { width: '100%', height: '100%' } : { width: size, height: size }}
      />

      {/* Interactive HUD & Status Bar below the Nebula (when showControls is active) */}
      {showControls && (
        <div
          className={`${
            fullBackground
              ? 'absolute bottom-8 z-20 pointer-events-auto'
              : 'flex flex-col items-center gap-2 mt-1 z-20'
          } flex flex-col items-center gap-2`}
        >
          <button
            id="btn-cyber-orb-activate"
            type="button"
            onClick={onClick}
            className={`px-4 py-2 rounded-full border text-xs font-semibold backdrop-blur-md flex items-center gap-2 shadow-sm transition-all duration-300 cursor-pointer ${badge.badgeClass}`}
          >
            <span className={`w-2 h-2 rounded-full ${badge.pulseColor} animate-ping`} />
            {badge.icon}
            <span className="tracking-wide">{badge.label}</span>
          </button>

          {/* Interim speech transcript display */}
          {interimTranscript && (
            <div className="max-w-md px-3.5 py-1.5 rounded-xl bg-slate-900/90 border border-cyan-500/40 text-cyan-200 text-xs font-mono text-center shadow-lg animate-fade-in backdrop-blur-md">
              <span className="text-cyan-400 mr-1.5">“</span>
              <span>{interimTranscript}</span>
              <span className="text-cyan-400 ml-1.5">”</span>
            </div>
          )}

          {/* Optional custom titles */}
          {title && (
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
              {title}
            </h2>
          )}
          {subtitle && (
            <p className="text-xs text-slate-500 dark:text-zinc-400 max-w-sm text-center">
              {subtitle}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
