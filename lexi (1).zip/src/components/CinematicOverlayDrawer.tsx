import React, { useEffect } from 'react';
import {
  X,
  Sparkles,
  FileSpreadsheet,
  FileText,
  History,
  Image,
  Layers,
  Building2,
  Database,
  Users,
  Bot,
  Command,
} from 'lucide-react';
import { OverlayView } from '../utils/commandParser';
import { CyberParticleOrb } from './CyberParticleOrb';

interface Props {
  activeView: OverlayView;
  onClose: () => void;
  voiceStatus: 'idle' | 'listening' | 'thinking' | 'speaking';
  liveMicLevel: number;
  isVoiceDetected: boolean;
  isMicOn?: boolean;
  onToggleListen: () => void;
  children: React.ReactNode;
}

const VIEW_METADATA: Record<
  OverlayView,
  { title: string; subtitle: string; icon: React.ComponentType<{ className?: string }> }
> = {
  ORB_ONLY: {
    title: 'Orbe Central',
    subtitle: 'Modo Minimalista',
    icon: Sparkles,
  },
  CHAT_SIDEBAR: {
    title: 'Sidebar con Chat',
    subtitle: 'Asistente IA en panel lateral',
    icon: Bot,
  },
  SHEETS: {
    title: 'Google Sheets Manager',
    subtitle: 'Hojas de cálculo en Google Drive',
    icon: FileSpreadsheet,
  },
  DOCS: {
    title: 'Google Docs Manager',
    subtitle: 'Documentos ejecutivos y actas',
    icon: FileText,
  },
  EXTRACTOR: {
    title: 'Extractor Multidocumento IA',
    subtitle: 'Consolidación de PDFs e informes',
    icon: Layers,
  },
  IMAGES: {
    title: 'Estudio de Imágenes IA',
    subtitle: 'Generación visual con Gemini Imagen 3',
    icon: Image,
  },
  REAL_ESTATE: {
    title: 'Fichas Técnicas Inmobiliarias',
    subtitle: 'CRM y exportación a PDF para clientes',
    icon: Building2,
  },
  HISTORY: {
    title: 'Historial de Comandos de Voz',
    subtitle: 'Registro y re-ejecución de órdenes',
    icon: History,
  },
  CHAT: {
    title: 'Conversación con Lexi',
    subtitle: 'Respuestas detalladas y automatizaciones',
    icon: Bot,
  },
  DATABASE: {
    title: 'Base de Datos & Supabase',
    subtitle: 'Auditoría Firestore y scripts SQL',
    icon: Database,
  },
  PROFILE: {
    title: 'Perfiles de Voz & Anti-Ruido',
    subtitle: 'Calibración de sensibilidad y micrófono',
    icon: Users,
  },
  COMMAND_PALETTE: {
    title: 'Panel de Comandos',
    subtitle: 'Atajos y navegación rápida',
    icon: Command,
  },
};

export const CinematicOverlayDrawer: React.FC<Props> = ({
  activeView,
  onClose,
  voiceStatus,
  liveMicLevel,
  isVoiceDetected,
  isMicOn,
  onToggleListen,
  children,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (activeView === 'ORB_ONLY' || activeView === 'COMMAND_PALETTE' || activeView === 'CHAT_SIDEBAR') {
    return null;
  }

  const meta = VIEW_METADATA[activeView] || {
    title: 'Panel Secundario',
    subtitle: 'Módulo de Automatización',
    icon: Sparkles,
  };
  const Icon = meta.icon;

  return (
    <div
      id="cinematic-overlay-backdrop"
      className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/70 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="cinematic-overlay-sheet"
        className="relative w-full max-w-7xl h-[92vh] max-h-[95vh] rounded-3xl bg-slate-950/95 border border-cyan-500/40 shadow-2xl shadow-cyan-950/90 flex flex-col overflow-hidden text-white ring-1 ring-cyan-500/20 animate-in zoom-in-95 duration-200"
      >
        {/* Top Header Bar */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-cyan-500/20 bg-slate-950/90 flex items-center justify-between gap-3 shrink-0 backdrop-blur-md">
          {/* Title & Icon */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shrink-0 shadow-xs">
              <Icon className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-white truncate">{meta.title}</h2>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
                  Overlay Activo
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate">{meta.subtitle}</p>
            </div>
          </div>

          {/* Controls: Mini Interactive Orb + Return to Orb Button + Close */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Mini Orb Visualizer */}
            <button
              id="btn-overlay-mini-orb"
              type="button"
              onClick={onToggleListen}
              className="p-1 rounded-xl bg-black border border-cyan-500/30 hover:border-cyan-400 hover:scale-105 transition-all cursor-pointer flex items-center justify-center"
              title={
                voiceStatus === 'listening'
                  ? 'Escuchando voz... Haz clic para detener'
                  : 'Orbe activo en segundo plano. Haz clic para hablar'
              }
            >
              <CyberParticleOrb
                size={38}
                status={voiceStatus}
                audioLevel={liveMicLevel}
                isVoiceDetected={isVoiceDetected}
                isMicOn={isMicOn}
                showControls={false}
              />
            </button>

            {/* Return to Orb Button */}
            <button
              id="btn-return-to-orb"
              type="button"
              onClick={onClose}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/90 border border-cyan-500/40 hover:bg-cyan-900 text-cyan-300 hover:text-white transition-all text-xs font-mono cursor-pointer shadow-xs"
              title="Volver al lienzo del orbe (Esc o decir 'Volver al orbe')"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Volver al Orbe</span>
              <kbd className="px-1 py-0.5 rounded bg-slate-900 border border-slate-700 text-[9px] text-slate-400">
                Esc
              </kbd>
            </button>

            {/* Close Button */}
            <button
              id="btn-close-overlay"
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors cursor-pointer"
              title="Cerrar ventana"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Overlay Content View */}
        <div className="flex-1 overflow-y-auto bg-slate-900/40">{children}</div>
      </div>
    </div>
  );
};
