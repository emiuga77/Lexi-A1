import React, { useState, useEffect, useRef } from 'react';
import {
  Building2,
  FileDown,
  Printer,
  Share2,
  Edit3,
  Plus,
  RefreshCw,
  Sliders,
  Check,
  ChevronDown,
  Loader2,
} from 'lucide-react';
import {
  PropertyCRMRecord,
  TechnicalSheetPdfOptions,
} from '../types';
import {
  getProperties,
  saveProperty,
  resetToSampleProperties,
} from '../services/propertyService';
import { RealEstateDossierView } from './RealEstateDossierView';
import { PropertyEditorModal } from './PropertyEditorModal';
import { ShareClientModal } from './ShareClientModal';
import {
  generatePropertyPdf,
  GeneratePdfProgress,
} from '../utils/pdfGenerator';
import { useTheme } from '../context/ThemeContext';

export const RealEstateStudio: React.FC = () => {
  const { isNight } = useTheme();
  const [properties, setProperties] = useState<PropertyCRMRecord[]>([]);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);

  // PDF Generation State
  const [pdfProgress, setPdfProgress] = useState<GeneratePdfProgress | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfSuccessMessage, setPdfSuccessMessage] = useState<string | null>(null);

  // PDF Options
  const [pdfOptions, setPdfOptions] = useState<TechnicalSheetPdfOptions>({
    themeStyle: 'minimal_luxe',
    language: 'es',
    showExactAddress: true,
    showFinancials: true,
    showCadastral: true,
    showAgencyBranding: true,
    showQrVerification: true,
    includeFloorPlan: true,
  });

  const dossierRef = useRef<HTMLDivElement>(null);

  // Load properties on mount
  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    setIsLoading(true);
    try {
      const data = await getProperties();
      setProperties(data);
      if (data.length > 0 && !selectedPropertyId) {
        setSelectedPropertyId(data[0].id);
      }
    } catch (err) {
      console.warn('Error loading properties:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const selectedProperty =
    properties.find((p) => p.id === selectedPropertyId) || properties[0] || null;

  // Handle PDF Generation and Download
  const handleDownloadPdf = async () => {
    if (!selectedProperty || !dossierRef.current) return;

    setIsGeneratingPdf(true);
    setPdfSuccessMessage(null);
    try {
      await generatePropertyPdf(
        dossierRef.current,
        selectedProperty,
        pdfOptions,
        (progress) => {
          setPdfProgress(progress);
        }
      );
      setPdfSuccessMessage(`Ficha Técnica "${selectedProperty.referenceCode}" generada y descargada.`);
      setTimeout(() => setPdfSuccessMessage(null), 5000);
    } catch (err: any) {
      console.warn('Error generating PDF:', err?.message || err);
      alert('Hubo un inconveniente al generar el PDF. Puedes usar "Imprimir / Guardar como PDF" como alternativa vectorial directa.');
    } finally {
      setIsGeneratingPdf(false);
      setPdfProgress(null);
    }
  };

  // Direct Browser Print-to-PDF
  const handlePrint = () => {
    window.print();
  };

  const handleSaveProperty = async (updated: PropertyCRMRecord) => {
    const saved = await saveProperty(updated);
    await loadProperties();
    setSelectedPropertyId(saved.id);
  };

  const handleCreateNew = () => {
    if (!selectedProperty) return;
    const newRecord: PropertyCRMRecord = {
      ...selectedProperty,
      id: `prop_${Date.now()}`,
      referenceCode: `LX-REF-${Math.floor(1000 + Math.random() * 9000)}`,
      title: 'Nueva Propiedad Exclusiva',
      tagline: 'Residencia de alto standing',
      price: 1200000,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    saveProperty(newRecord).then((saved) => {
      loadProperties().then(() => {
        setSelectedPropertyId(saved.id);
        setIsEditorOpen(true);
      });
    });
  };

  const handleResetSamples = async () => {
    if (!window.confirm('¿Deseas recargar las fichas técnicas inmobiliarias de ejemplo predeterminadas?')) return;
    const reset = await resetToSampleProperties();
    setProperties(reset);
    if (reset.length > 0) {
      setSelectedPropertyId(reset[0].id);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto">
      {/* Top Header & Context Bar */}
      <div
        className={`px-4 sm:px-6 py-4 border-b flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors ${
          isNight ? 'bg-black border-zinc-900 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-xs ${
              isNight
                ? 'bg-zinc-900 text-amber-400 border border-zinc-800'
                : 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
            }`}
          >
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight">
                Ficha Técnica Inmobiliaria CRM
              </h1>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  isNight
                    ? 'bg-zinc-850 text-zinc-300 border border-zinc-800'
                    : 'bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                PDF 300 DPI
              </span>
            </div>
            <p className={`text-xs ${isNight ? 'text-zinc-400' : 'text-slate-500'}`}>
              Generador de dossiers profesionales listos para compartir con clientes e inversores
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Customize PDF Drawer Trigger */}
          <button
            id="btn-toggle-pdf-customizer"
            type="button"
            onClick={() => setIsCustomizerOpen((prev) => !prev)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isCustomizerOpen
                ? isNight
                  ? 'bg-zinc-800 border-zinc-700 text-white'
                  : 'bg-slate-200 border-slate-300 text-slate-900'
                : isNight
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-850 hover:border-zinc-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-amber-500" />
            <span>Configurar Ficha</span>
            <ChevronDown
              className={`w-3.5 h-3.5 transition-transform ${
                isCustomizerOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {/* Edit CRM Data */}
          <button
            id="btn-edit-property-crm"
            type="button"
            onClick={() => setIsEditorOpen(true)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isNight
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-850 hover:border-zinc-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5 text-blue-500" />
            <span>Editar Datos</span>
          </button>

          {/* Share with Client */}
          <button
            id="btn-share-client-modal"
            type="button"
            onClick={() => setIsShareOpen(true)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isNight
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-850 hover:border-zinc-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-500" />
            <span>Compartir</span>
          </button>

          {/* Print / Save as PDF */}
          <button
            id="btn-print-technical-sheet"
            type="button"
            onClick={handlePrint}
            title="Abre el cuadro de diálogo de impresión para guardar como PDF vectorial"
            className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isNight
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-850 hover:border-zinc-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Printer className="w-3.5 h-3.5 text-indigo-400" />
            <span>Imprimir / PDF</span>
          </button>

          {/* Primary High-Resolution PDF Download */}
          <button
            id="btn-download-highres-pdf"
            type="button"
            onClick={handleDownloadPdf}
            disabled={isGeneratingPdf || !selectedProperty}
            className={`px-4 py-2 rounded-xl font-semibold text-xs flex items-center gap-2 shadow-xs transition-all cursor-pointer ${
              isNight
                ? 'bg-zinc-850 hover:bg-zinc-800 text-white border border-zinc-700'
                : 'bg-slate-900 hover:bg-slate-800 text-white border border-slate-800'
            }`}
          >
            {isGeneratingPdf ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                <span>Generando PDF...</span>
              </>
            ) : (
              <>
                <FileDown className="w-4 h-4 text-amber-400" />
                <span>Descargar PDF</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Generation Progress Indicator Banner */}
      {pdfProgress && (
        <div
          className={`px-4 sm:px-6 py-2.5 text-xs flex items-center justify-between border-b animate-in fade-in duration-150 ${
            isNight
              ? 'bg-zinc-900/90 border-zinc-800 text-zinc-200'
              : 'bg-blue-50 border-blue-200 text-blue-900'
          }`}
        >
          <div className="flex items-center gap-3">
            <Loader2 className="w-4 h-4 animate-spin text-amber-500 shrink-0" />
            <span className="font-medium">{pdfProgress.message}</span>
          </div>
          <div className="flex items-center gap-2 font-mono font-bold text-amber-500">
            <span>{pdfProgress.percent}%</span>
          </div>
        </div>
      )}

      {/* Success Notification */}
      {pdfSuccessMessage && (
        <div
          className={`px-4 sm:px-6 py-2.5 text-xs flex items-center gap-2 border-b animate-in fade-in duration-150 ${
            isNight
              ? 'bg-emerald-950/60 border-emerald-900 text-emerald-200'
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}
        >
          <Check className="w-4 h-4 text-emerald-500 shrink-0" />
          <span className="font-medium">{pdfSuccessMessage}</span>
        </div>
      )}

      {/* Properties Selector Ribbon */}
      <div
        className={`px-4 sm:px-6 py-3 border-b flex items-center justify-between gap-3 overflow-x-auto transition-colors ${
          isNight ? 'bg-black border-zinc-900' : 'bg-slate-50/80 border-slate-200'
        }`}
      >
        <div className="flex items-center gap-2">
          <span
            className={`text-[10px] font-bold uppercase tracking-wider whitespace-nowrap ${
              isNight ? 'text-zinc-500' : 'text-slate-400'
            }`}
          >
            Propiedades CRM:
          </span>

          <div className="flex items-center gap-2">
            {properties.map((prop) => {
              const isSelected = prop.id === selectedPropertyId;
              const formattedPrice = new Intl.NumberFormat('es-ES', {
                style: 'currency',
                currency: prop.currency,
                maximumFractionDigits: 0,
              }).format(prop.price);

              return (
                <button
                  key={prop.id}
                  id={`btn-select-property-${prop.id}`}
                  type="button"
                  onClick={() => setSelectedPropertyId(prop.id)}
                  className={`px-3 py-1.5 rounded-xl border text-xs flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? isNight
                        ? 'bg-zinc-850 border-zinc-700 text-white shadow-xs font-semibold'
                        : 'bg-white border-slate-300 text-slate-900 shadow-xs font-semibold ring-1 ring-slate-900/10'
                      : isNight
                      ? 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:bg-zinc-850 hover:text-zinc-200'
                      : 'bg-white/60 border-slate-200 text-slate-600 hover:bg-white hover:text-slate-900'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                  <span className="font-mono text-[11px] font-bold">{prop.referenceCode}</span>
                  <span className="truncate max-w-[140px] hidden sm:inline">{prop.title}</span>
                  <span
                    className={`font-mono text-[11px] font-semibold ${
                      isNight ? 'text-amber-400' : 'text-slate-900'
                    }`}
                  >
                    {formattedPrice}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            id="btn-add-new-property"
            type="button"
            onClick={handleCreateNew}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isNight
                ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-850 hover:border-zinc-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Nueva Propiedad</span>
          </button>

          <button
            id="btn-reset-sample-properties"
            type="button"
            onClick={handleResetSamples}
            title="Recargar ejemplos de lujo"
            className={`p-1.5 rounded-xl border text-xs transition-all cursor-pointer ${
              isNight
                ? 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
                : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* PDF Customization Drawer */}
      {isCustomizerOpen && (
        <div
          className={`px-4 sm:px-6 py-4 border-b animate-in slide-in-from-top-2 duration-150 transition-colors ${
            isNight ? 'bg-zinc-950 border-zinc-850 text-zinc-200' : 'bg-slate-100/70 border-slate-200 text-slate-800'
          }`}
        >
          <div className="max-w-5xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider">
                <Sliders className="w-4 h-4 text-amber-500" />
                <span>Opciones de la Ficha Técnica PDF para el Cliente</span>
              </div>
              <button
                type="button"
                onClick={() => setIsCustomizerOpen(false)}
                className="text-xs text-slate-500 hover:underline cursor-pointer"
              >
                Ocultar opciones
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              {/* Language Selection */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider mb-1 opacity-70">
                  Idioma del Dossier
                </label>
                <div className="grid grid-cols-2 gap-1">
                  <button
                    type="button"
                    onClick={() => setPdfOptions({ ...pdfOptions, language: 'es' })}
                    className={`py-1.5 px-2 rounded-lg border text-center font-medium cursor-pointer ${
                      pdfOptions.language === 'es'
                        ? isNight
                          ? 'bg-zinc-800 border-zinc-600 text-white font-bold'
                          : 'bg-white border-slate-400 text-slate-900 font-bold shadow-2xs'
                        : isNight
                        ? 'bg-zinc-900 border-zinc-800 text-zinc-400'
                        : 'bg-white/60 border-slate-200 text-slate-600'
                    }`}
                  >
                    Español
                  </button>
                  <button
                    type="button"
                    onClick={() => setPdfOptions({ ...pdfOptions, language: 'en' })}
                    className={`py-1.5 px-2 rounded-lg border text-center font-medium cursor-pointer ${
                      pdfOptions.language === 'en'
                        ? isNight
                          ? 'bg-zinc-800 border-zinc-600 text-white font-bold'
                          : 'bg-white border-slate-400 text-slate-900 font-bold shadow-2xs'
                        : isNight
                        ? 'bg-zinc-900 border-zinc-800 text-zinc-400'
                        : 'bg-white/60 border-slate-200 text-slate-600'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              {/* Show Financials Toggle */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider mb-1 opacity-70">
                  Datos Financieros & Fiscales
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setPdfOptions({ ...pdfOptions, showFinancials: !pdfOptions.showFinancials })
                  }
                  className={`w-full py-1.5 px-3 rounded-lg border text-left flex items-center justify-between cursor-pointer ${
                    pdfOptions.showFinancials
                      ? isNight
                        ? 'bg-zinc-850 border-zinc-700 text-white'
                        : 'bg-white border-slate-300 text-slate-900 shadow-2xs'
                      : isNight
                      ? 'bg-zinc-900 border-zinc-800 text-zinc-400'
                      : 'bg-white/60 border-slate-200 text-slate-500'
                  }`}
                >
                  <span>Comunidad, IBI y Rentabilidad</span>
                  <div
                    className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                      pdfOptions.showFinancials ? 'bg-amber-500 text-black font-bold' : 'border border-zinc-600'
                    }`}
                  >
                    {pdfOptions.showFinancials && '✓'}
                  </div>
                </button>
              </div>

              {/* Show Exact Address */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider mb-1 opacity-70">
                  Nivel de Privacidad / Dirección
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setPdfOptions({
                      ...pdfOptions,
                      showExactAddress: !pdfOptions.showExactAddress,
                    })
                  }
                  className={`w-full py-1.5 px-3 rounded-lg border text-left flex items-center justify-between cursor-pointer ${
                    pdfOptions.showExactAddress
                      ? isNight
                        ? 'bg-zinc-850 border-zinc-700 text-white'
                        : 'bg-white border-slate-300 text-slate-900 shadow-2xs'
                      : isNight
                      ? 'bg-zinc-900 border-zinc-800 text-zinc-400'
                      : 'bg-white/60 border-slate-200 text-slate-500'
                  }`}
                >
                  <span>{pdfOptions.showExactAddress ? 'Dirección Completa' : 'Solo Zona / Barrio'}</span>
                  <div
                    className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                      pdfOptions.showExactAddress ? 'bg-amber-500 text-black font-bold' : 'border border-zinc-600'
                    }`}
                  >
                    {pdfOptions.showExactAddress && '✓'}
                  </div>
                </button>
              </div>

              {/* QR Verification */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider mb-1 opacity-70">
                  Código QR de Verificación
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setPdfOptions({
                      ...pdfOptions,
                      showQrVerification: !pdfOptions.showQrVerification,
                    })
                  }
                  className={`w-full py-1.5 px-3 rounded-lg border text-left flex items-center justify-between cursor-pointer ${
                    pdfOptions.showQrVerification
                      ? isNight
                        ? 'bg-zinc-850 border-zinc-700 text-white'
                        : 'bg-white border-slate-300 text-slate-900 shadow-2xs'
                      : isNight
                      ? 'bg-zinc-900 border-zinc-800 text-zinc-400'
                      : 'bg-white/60 border-slate-200 text-slate-500'
                  }`}
                >
                  <span>Sello de Validación</span>
                  <div
                    className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                      pdfOptions.showQrVerification ? 'bg-amber-500 text-black font-bold' : 'border border-zinc-600'
                    }`}
                  >
                    {pdfOptions.showQrVerification && '✓'}
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Studio Canvas: Interactive Live Preview of the High-End A4 Dossier */}
      <div
        className={`flex-1 p-4 sm:p-8 flex justify-center items-start overflow-y-auto transition-colors ${
          isNight ? 'bg-black' : 'bg-slate-100'
        }`}
      >
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
            <p className={`text-xs ${isNight ? 'text-zinc-400' : 'text-slate-500'}`}>
              Cargando fichas técnicas del CRM...
            </p>
          </div>
        ) : selectedProperty ? (
          <div className="w-full max-w-4xl flex flex-col items-center">
            {/* Visual Paper Shadow Wrapper */}
            <div className="w-full transition-all">
              <RealEstateDossierView
                containerRef={dossierRef}
                property={selectedProperty}
                options={pdfOptions}
              />
            </div>
          </div>
        ) : (
          <div className="py-20 text-center">
            <Building2 className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-600">No hay propiedades seleccionadas</p>
          </div>
        )}
      </div>

      {/* Modals */}
      <PropertyEditorModal
        isOpen={isEditorOpen}
        property={selectedProperty}
        onClose={() => setIsEditorOpen(false)}
        onSave={handleSaveProperty}
      />

      <ShareClientModal
        isOpen={isShareOpen}
        property={selectedProperty}
        onClose={() => setIsShareOpen(false)}
        onDownloadPdf={handleDownloadPdf}
      />
    </div>
  );
};
