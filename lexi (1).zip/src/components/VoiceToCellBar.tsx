import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  HelpCircle,
  Radio,
  CheckCircle2,
  Send,
  CornerDownRight,
  Zap,
} from 'lucide-react';
import {
  parseVoiceToCell,
  ParsedVoiceCellCommand,
} from '../utils/voiceToCellParser';

interface Props {
  isEnabled: boolean;
  onToggle: (enabled: boolean) => void;
  activeCell: string;
  headers: string[];
  onApplyVoiceCommand: (parsed: ParsedVoiceCellCommand) => Promise<void>;
  isProcessing: boolean;
  lastAction: { cell: string; value: string | number; timestamp: number } | null;
  spreadsheetTitle?: string;
  hasSheetSelected: boolean;
}

export const VoiceToCellBar: React.FC<Props> = ({
  isEnabled,
  onToggle,
  activeCell,
  headers,
  onApplyVoiceCommand,
  isProcessing,
  lastAction,
  spreadsheetTitle,
  hasSheetSelected,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [lastTranscript, setLastTranscript] = useState('');
  const [detectedCommand, setDetectedCommand] = useState<ParsedVoiceCellCommand | null>(null);
  const [voiceFeedback, setVoiceFeedback] = useState(true);
  const [showCheatsheet, setShowCheatsheet] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [lang, setLang] = useState<'es-ES' | 'en-US'>('es-ES');
  const [audioLevel, setAudioLevel] = useState(0);

  const recognitionRef = useRef<any>(null);
  const audioIntervalRef = useRef<any>(null);

  // Initialize Web Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn('SpeechRecognition API is not supported in this browser.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = lang;

    recognition.onstart = () => {
      setIsListening(true);
      // Simulate audio frequency pulse while listening
      audioIntervalRef.current = setInterval(() => {
        setAudioLevel(Math.floor(Math.random() * 80) + 20);
      }, 150);
    };

    recognition.onend = () => {
      clearInterval(audioIntervalRef.current);
      setAudioLevel(0);
      // If user kept Voice-to-Cell enabled, automatically resume listening
      if (isEnabled) {
        try {
          recognition.start();
        } catch {
          setIsListening(false);
        }
      } else {
        setIsListening(false);
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        setIsListening(false);
        onToggle(false);
      }
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          final += event.results[i][0].transcript;
        } else {
          interim += event.results[i][0].transcript;
        }
      }

      if (interim) {
        setInterimTranscript(interim);
        // Live preview of parsed command while speaking
        const preview = parseVoiceToCell(interim, headers, activeCell);
        if (preview) {
          setDetectedCommand(preview);
        }
      }

      if (final) {
        const finalTrimmed = final.trim();
        setLastTranscript(finalTrimmed);
        setInterimTranscript('');
        processSpokenPhrase(finalTrimmed);
      }
    };

    recognitionRef.current = recognition;

    return () => {
      clearInterval(audioIntervalRef.current);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
    };
  }, [headers, activeCell, lang, isEnabled]);

  // Handle Mode Toggle
  useEffect(() => {
    if (isEnabled && hasSheetSelected) {
      if (recognitionRef.current && !isListening) {
        try {
          recognitionRef.current.lang = lang;
          recognitionRef.current.start();
        } catch (e) {
          console.warn('Could not start recognition:', e);
        }
      }
    } else {
      if (recognitionRef.current && isListening) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
      clearInterval(audioIntervalRef.current);
      setAudioLevel(0);
    }
  }, [isEnabled, hasSheetSelected, lang]);

  // Speak audio confirmation via Lexi
  const speakFeedback = (text: string) => {
    if (!voiceFeedback || typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = lang;
      utter.rate = 1.05;
      window.speechSynthesis.speak(utter);
    } catch (e) {
      console.warn('TTS error:', e);
    }
  };

  // Process and apply command
  const processSpokenPhrase = async (phrase: string) => {
    if (!phrase.trim()) return;

    const parsed = parseVoiceToCell(phrase, headers, activeCell);
    setDetectedCommand(parsed);

    if (parsed) {
      try {
        await onApplyVoiceCommand(parsed);

        // Auditory voice feedback
        if (parsed.type === 'set_cell' && parsed.cell) {
          const valDesc = String(parsed.value);
          const headerDesc = parsed.matchedHeader ? ` (${parsed.matchedHeader})` : '';
          speakFeedback(`Celda ${parsed.cell}${headerDesc} actualizada a ${valDesc}`);
        } else if (parsed.type === 'clear_cell' && parsed.cell) {
          speakFeedback(`Celda ${parsed.cell} limpiada`);
        } else if (parsed.type === 'select_cell' && parsed.cell) {
          speakFeedback(`Celda ${parsed.cell} seleccionada`);
        } else if (parsed.type === 'navigate') {
          speakFeedback('Avanzando celda');
        } else if (parsed.type === 'set_row' && parsed.rowIndex) {
          speakFeedback(`Fila ${parsed.rowIndex} actualizada con ${parsed.rowValues?.length || 0} valores`);
        }
      } catch (err: any) {
        speakFeedback('Error al actualizar la celda');
      }
    } else {
      speakFeedback('No identifiqué la celda o el valor. Intenta de nuevo.');
    }
  };

  // Quick manual execution for test or silent environment
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    setLastTranscript(manualInput);
    processSpokenPhrase(manualInput);
    setManualInput('');
  };

  const sampleVoiceChips = [
    { label: 'En B2 pon 1250', command: 'En B2 pon 1250' },
    { label: 'Columna Monto, fila 3: 450', command: 'Columna Monto, fila 3: 450' },
    { label: 'Fila 2, columna Estado: Aprobado', command: 'Fila 2, columna Estado: Aprobado' },
    { label: 'Escribe $89.00 (Celda Activa)', command: 'Escribe $89.00' },
    { label: 'Siguiente celda: 350', command: 'Siguiente celda: 350' },
    { label: 'Borra B2', command: 'Borra B2' },
  ];

  return (
    <div
      id="voice-to-cell-container"
      className={`rounded-2xl border transition-all duration-300 ${
        isEnabled
          ? 'bg-gradient-to-br from-emerald-950/90 via-slate-900 to-slate-950 text-white border-emerald-500/50 shadow-lg shadow-emerald-950/30'
          : 'bg-white border-slate-200 text-slate-900 shadow-xs'
      } p-4 sm:p-5`}
    >
      {/* Top Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-emerald-500/20">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              isEnabled
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30 animate-pulse'
                : 'bg-emerald-100/80 text-emerald-700'
            }`}
          >
            <Radio className="w-5 h-5" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold tracking-tight">
                Modo Voice-to-Cell en Tiempo Real
              </h3>
              {isEnabled && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse">
                  EN VIVO
                </span>
              )}
            </div>
            <p
              className={`text-xs ${
                isEnabled ? 'text-slate-300' : 'text-slate-500'
              }`}
            >
              Habla valores directamente a filas, columnas o coordenadas (ej. «En B3 pon 450»).
            </p>
          </div>
        </div>

        {/* Action Toggles & Controls */}
        <div className="flex items-center gap-2">
          {/* Audio TTS Toggle */}
          <button
            type="button"
            onClick={() => setVoiceFeedback(!voiceFeedback)}
            title={voiceFeedback ? 'Respuesta de voz de Lexi activada' : 'Voz silenciada'}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              isEnabled
                ? voiceFeedback
                  ? 'bg-emerald-900/60 border-emerald-600/60 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
                : voiceFeedback
                ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                : 'bg-slate-100 border-slate-200 text-slate-400'
            }`}
          >
            {voiceFeedback ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">Voz Lexi</span>
          </button>

          {/* Language toggle */}
          <button
            type="button"
            onClick={() => setLang(lang === 'es-ES' ? 'en-US' : 'es-ES')}
            className={`px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
              isEnabled
                ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                : 'bg-slate-100 border-slate-200 text-slate-700'
            }`}
          >
            {lang === 'es-ES' ? 'ES 🇪🇸' : 'EN 🇺🇸'}
          </button>

          {/* Help cheatsheet */}
          <button
            type="button"
            onClick={() => setShowCheatsheet(!showCheatsheet)}
            title="Ver ejemplos de comandos de voz"
            className={`p-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
              isEnabled
                ? 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Master Mode Switch */}
          <button
            id="btn-toggle-voice-to-cell"
            type="button"
            onClick={() => onToggle(!isEnabled)}
            disabled={!hasSheetSelected}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
              isEnabled
                ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-600/30'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20'
            }`}
          >
            {isEnabled ? (
              <>
                <MicOff className="w-4 h-4" />
                <span>Detener Dictado</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                <span>Iniciar Voice-to-Cell</span>
              </>
            )}
          </button>
        </div>
      </div>

      {!hasSheetSelected ? (
        <div className="py-4 text-center text-xs text-slate-400">
          Selecciona una hoja de cálculo en la lista inferior para activar el dictado por voz.
        </div>
      ) : (
        <div className="pt-3 space-y-3">
          {/* Active Status & Live Transcript HUD */}
          {isEnabled && (
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-emerald-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </span>
                  <span className="text-xs font-bold text-emerald-400">
                    {isListening ? 'Micrófono Activo — Escuchando en vivo...' : 'Iniciando micrófono...'}
                  </span>
                  {spreadsheetTitle && (
                    <span className="text-[11px] text-slate-400 truncate max-w-xs">
                      en «{spreadsheetTitle}»
                    </span>
                  )}
                </div>

                {/* Simulated decibel waveform */}
                <div className="flex items-center gap-1 h-3">
                  {[...Array(6)].map((_, i) => (
                    <span
                      key={i}
                      className="w-1 bg-emerald-400 rounded-full transition-all duration-100"
                      style={{
                        height: isListening ? `${Math.max(4, (audioLevel * (i + 1)) % 16)}px` : '4px',
                        opacity: isListening ? 0.9 : 0.3,
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Transcript Display */}
              <div className="bg-slate-950/70 rounded-lg p-2.5 border border-slate-800 text-xs font-mono min-h-9 flex items-center justify-between gap-2">
                <div className="flex-1 truncate">
                  {interimTranscript ? (
                    <span className="text-emerald-300 font-semibold animate-pulse">
                      «{interimTranscript}»
                    </span>
                  ) : lastTranscript ? (
                    <span className="text-slate-200">Último: «{lastTranscript}»</span>
                  ) : (
                    <span className="text-slate-500 italic">
                      Di una instrucción, ej: «En B3 pon 450» o «Columna Estado, fila 2: Aprobado»
                    </span>
                  )}
                </div>

                {/* Active cell badge */}
                <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[11px] font-bold border border-slate-700 shrink-0">
                  Celda activa: {activeCell}
                </span>
              </div>

              {/* Real-time Parsed Command Preview Card */}
              {detectedCommand && (
                <div className="p-2.5 rounded-lg bg-emerald-950/50 border border-emerald-500/40 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span className="font-semibold text-emerald-200">Comando Detectado:</span>
                    {detectedCommand.cell && (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                        {detectedCommand.cell}
                      </span>
                    )}
                    {detectedCommand.matchedHeader && (
                      <span className="text-slate-300 text-[11px]">
                        Columna: «{detectedCommand.matchedHeader}»
                      </span>
                    )}
                    {detectedCommand.value !== undefined && (
                      <span className="text-white font-bold font-mono">
                        = {String(detectedCommand.value)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isProcessing ? (
                      <span className="text-[11px] text-amber-300 animate-pulse font-semibold flex items-center gap-1">
                        <Zap className="w-3 h-3" /> Sincronizando en Google Sheets...
                      </span>
                    ) : (
                      <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Aplicado en hoja
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quick Voice Command Simulator & Chips */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span
                className={`text-[11px] font-bold uppercase tracking-wider ${
                  isEnabled ? 'text-slate-300' : 'text-slate-500'
                }`}
              >
                Comandos rápidos o prueba por texto:
              </span>
              {lastAction && (
                <span className="text-[11px] text-emerald-500 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Última celda: {lastAction.cell} = {String(lastAction.value)}
                </span>
              )}
            </div>

            {/* Clickable Quick Chips */}
            <div className="flex flex-wrap gap-1.5">
              {sampleVoiceChips.map((chip, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setLastTranscript(chip.command);
                    processSpokenPhrase(chip.command);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all cursor-pointer flex items-center gap-1 ${
                    isEnabled
                      ? 'bg-slate-800/80 hover:bg-emerald-600 hover:text-white text-slate-200 border border-slate-700'
                      : 'bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 border border-slate-200'
                  }`}
                >
                  <CornerDownRight className="w-3 h-3 opacity-60" />
                  <span>{chip.label}</span>
                </button>
              ))}
            </div>

            {/* Manual test input */}
            <form onSubmit={handleManualSubmit} className="flex gap-2 pt-1">
              <input
                type="text"
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                placeholder="Escribe o simula un comando de voz (ej: «En B3 pon 450» o «Columna Estado, fila 3: Aprobado»)..."
                className={`flex-1 px-3 py-1.5 text-xs rounded-xl border outline-hidden transition-all ${
                  isEnabled
                    ? 'bg-slate-900 border-slate-700 text-white placeholder:text-slate-500 focus:border-emerald-400'
                    : 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-emerald-500'
                }`}
              />
              <button
                type="submit"
                disabled={!manualInput.trim() || isProcessing}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-40"
              >
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Ejecutar</span>
              </button>
            </form>
          </div>

          {/* Cheatsheet Expandable */}
          {showCheatsheet && (
            <div
              className={`p-4 rounded-xl border text-xs space-y-2.5 transition-all ${
                isEnabled
                  ? 'bg-slate-900/90 border-slate-800 text-slate-300'
                  : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
            >
              <div className="flex items-center justify-between border-b border-slate-700/40 pb-1.5">
                <span className="font-bold flex items-center gap-1.5 text-emerald-400">
                  <Sparkles className="w-3.5 h-3.5" /> Guía de Voz para Celdas (Español / English)
                </span>
                <button
                  type="button"
                  onClick={() => setShowCheatsheet(false)}
                  className="text-slate-400 hover:text-slate-200"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div className="space-y-1">
                  <span className="font-bold block text-slate-200">1. Por Coordenada Directa:</span>
                  <p>• «En B3 pon 450»</p>
                  <p>• «Escribe Aprobado en la celda C2»</p>
                  <p>• «Celda D5: $1,200.00»</p>
                  <p>• «Set B4 to 99.50»</p>
                </div>

                <div className="space-y-1">
                  <span className="font-bold block text-slate-200">2. Por Nombre de Columna & Fila:</span>
                  <p>• «En la columna Monto, fila 3, pon 500»</p>
                  <p>• «Fila 2, columna Categoría: Software»</p>
                  <p>• «Columna Estado, fila 4: Pendiente»</p>
                </div>

                <div className="space-y-1">
                  <span className="font-bold block text-slate-200">3. En la Celda Activa:</span>
                  <p>• Haz clic en cualquier celda de la tabla</p>
                  <p>• Di: «Escribe 750» o «Pon Revisado»</p>
                  <p>• Di: «Siguiente celda: 120» (avanza automáticamente)</p>
                </div>

                <div className="space-y-1">
                  <span className="font-bold block text-slate-200">4. Navegación y Borrado:</span>
                  <p>• «Ir a C4» o «Selecciona B2»</p>
                  <p>• «Borra B3» o «Limpia esta celda»</p>
                  <p>• «Siguiente fila» o «Next cell»</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
