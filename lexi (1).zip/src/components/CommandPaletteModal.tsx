import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  FileSpreadsheet,
  FileText,
  History,
  Image,
  Layers,
  Building2,
  Database,
  Users,
  Bot,
  Sparkles,
  CornerDownLeft,
  Mic,
  ArrowRight,
} from 'lucide-react';
import { OverlayView } from '../utils/commandParser';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSelectView: (view: OverlayView, feedback?: string) => void;
  onVoiceCommandPrompt?: () => void;
}

interface CommandItem {
  id: OverlayView;
  key?: string;
  title: string;
  category: string;
  description: string;
  voicePhrase: string;
  icon: React.ComponentType<{ className?: string }>;
  hotkey?: string;
  badge?: string;
}

const COMMAND_ITEMS: CommandItem[] = [
  {
    id: 'ORB_ONLY',
    title: 'Volver al Orbe Central',
    category: 'Vistas Principales',
    description: 'Regresa al lienzo minimalista en pantalla completa con el orbe cuántico.',
    voicePhrase: '"Volver al orbe" o "Cerrar"',
    icon: Sparkles,
    hotkey: 'Esc',
    badge: 'Cinemático',
  },
  {
    id: 'CHAT_SIDEBAR',
    title: 'Chat con Lexi',
    category: 'Asistente IA',
    description: 'Despliega el chat inteligente de Lexi.',
    voicePhrase: '"Chat"',
    icon: Bot,
    hotkey: 'C',
    badge: 'Chat',
  },
  {
    id: 'SHEETS',
    title: 'Google Sheets Manager',
    category: 'Productividad',
    description: 'Gestiona, analiza y crea hojas de cálculo directamente en tu Google Drive.',
    voicePhrase: '"Abrir Google Sheets"',
    icon: FileSpreadsheet,
    hotkey: 'S',
    badge: 'Drive',
  },
  {
    id: 'DOCS',
    title: 'Google Docs Manager',
    category: 'Productividad',
    description: 'Crea, visualiza y edita documentos profesionales con dictado por voz.',
    voicePhrase: '"Ver documentos" o "Abrir Google Docs"',
    icon: FileText,
    hotkey: 'D',
    badge: 'Drive',
  },
  {
    id: 'HISTORY',
    title: 'Historial de Comandos de Voz',
    category: 'Asistente IA',
    description: 'Revisa, busca y re-ejecuta tus órdenes de voz anteriores en documentos.',
    voicePhrase: '"Mostrar historial"',
    icon: History,
    hotkey: 'H',
    badge: 'Auditoría',
  },
  {
    id: 'IMAGES',
    title: 'Estudio de Generación de Imágenes',
    category: 'Creatividad',
    description: 'Crea renders y conceptos visuales de alta calidad con IA generativa.',
    voicePhrase: '"Ir al estudio de imágenes"',
    icon: Image,
    hotkey: 'I',
    badge: 'AI Vision',
  },
  {
    id: 'EXTRACTOR',
    title: 'Extractor Multidocumento IA',
    category: 'Documentos',
    description: 'Analiza PDFs y documentos simultáneamente y genera tablas de datos.',
    voicePhrase: '"Abrir extractor"',
    icon: Layers,
    hotkey: 'E',
  },
  {
    id: 'REAL_ESTATE',
    title: 'Ficha Técnica Inmobiliaria',
    category: 'Negocios & CRM',
    description: 'Generación de fichas profesionales listas para clientes en PDF descargable.',
    voicePhrase: '"Ficha inmobiliaria"',
    icon: Building2,
    hotkey: 'R',
    badge: 'PDF Ready',
  },
  {
    id: 'CHAT',
    title: 'Conversación y Respuestas Lexi',
    category: 'Asistente IA',
    description: 'Ver hilo completo de mensajes, respuestas y propuestas de automatización.',
    voicePhrase: '"Abrir chat"',
    icon: Bot,
    hotkey: 'C',
  },
  {
    id: 'DATABASE',
    title: 'Configurar Supabase & Base de Datos',
    category: 'Ajustes',
    description: 'Conecta Supabase, ejecuta scripts SQL y audita la persistencia en Firestore.',
    voicePhrase: '"Configurar Supabase"',
    icon: Database,
    hotkey: 'B',
  },
  {
    id: 'PROFILE',
    title: 'Perfiles de Voz & Calibración de Ruido',
    category: 'Ajustes',
    description: 'Configura perfiles de usuario, sensibilidad del micrófono y puerta anti-ruido.',
    voicePhrase: '"Configurar perfil"',
    icon: Users,
    hotkey: 'P',
  },
];

export const CommandPaletteModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSelectView,
  onVoiceCommandPrompt,
}) => {
  const [search, setSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setSearch('');
      setSelectedIndex(0);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  const filtered = COMMAND_ITEMS.filter((item) => {
    const q = search.toLowerCase().trim();
    if (!q) return true;
    return (
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.voicePhrase.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q)
    );
  });

  useEffect(() => {
    setSelectedIndex(0);
  }, [search]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % Math.max(1, filtered.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filtered.length) % Math.max(1, filtered.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const selected = filtered[selectedIndex];
        if (selected) {
          onSelectView(selected.id);
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filtered, selectedIndex, onClose, onSelectView]);

  if (!isOpen) return null;

  return (
    <div
      id="command-palette-backdrop"
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="command-palette-container"
        className="w-full max-w-2xl rounded-3xl bg-slate-950/95 border border-cyan-500/40 shadow-2xl shadow-cyan-950/80 overflow-hidden flex flex-col text-slate-100 backdrop-blur-2xl ring-1 ring-cyan-500/20"
      >
        {/* Search Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-cyan-500/20 gap-3">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            id="command-palette-input"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar comando, módulo o comando de voz (ej: 'Sheets', 'Historial')..."
            className="w-full bg-transparent text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none"
          />
          {onVoiceCommandPrompt && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onVoiceCommandPrompt();
              }}
              className="p-1.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 hover:text-white hover:bg-cyan-900 transition-colors cursor-pointer flex items-center gap-1 text-xs font-mono"
              title="Dictar comando por voz"
            >
              <Mic className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Voz</span>
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors cursor-pointer"
            title="Cerrar (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action List */}
        <div className="max-h-[60vh] overflow-y-auto p-2 space-y-1 divide-y divide-slate-900">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-sm">
              No se encontraron comandos para &ldquo;{search}&rdquo;. Prueba con &ldquo;Sheets&rdquo;, &ldquo;Docs&rdquo; o &ldquo;Historial&rdquo;.
            </div>
          ) : (
            filtered.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              const Icon = item.icon;
              return (
                <div
                  key={item.key || item.id}
                  id={`cmd-item-${item.key || item.id}`}
                  onClick={() => {
                    onSelectView(item.id);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-all duration-100 ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-950/90 via-slate-900/90 to-slate-900 border border-cyan-500/50 shadow-md shadow-cyan-950'
                      : 'hover:bg-slate-900/50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-transform ${
                        isSelected
                          ? 'bg-cyan-500 text-black scale-105'
                          : 'bg-slate-900 text-cyan-400 border border-slate-800'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-white truncate">{item.title}</span>
                        {item.badge && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 truncate mt-0.5">{item.description}</p>
                      <span className="text-[10px] text-cyan-400/80 font-mono flex items-center gap-1 mt-0.5">
                        <span>Comando de voz:</span>
                        <code className="text-cyan-300 font-semibold">{item.voicePhrase}</code>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    {item.hotkey && (
                      <kbd className="hidden sm:inline-block px-2 py-1 rounded bg-slate-900 border border-slate-700 text-[10px] font-mono text-slate-400 shadow-2xs">
                        {item.hotkey}
                      </kbd>
                    )}
                    <ArrowRight
                      className={`w-4 h-4 transition-transform ${
                        isSelected ? 'text-cyan-400 translate-x-0.5' : 'text-slate-600'
                      }`}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Hints */}
        <div className="px-4 py-2.5 bg-slate-950 border-t border-cyan-500/20 flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 gap-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px]">↑↓</kbd>
              <span>Navegar</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px]">
                <CornerDownLeft className="w-2.5 h-2.5 inline" />
              </kbd>
              <span>Seleccionar</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px]">Esc</kbd>
              <span>Cerrar</span>
            </span>
          </div>
          <span className="text-cyan-400">Ctrl + K / Cmd + K abre este panel</span>
        </div>
      </div>
    </div>
  );
};
