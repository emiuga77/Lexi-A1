import React, { useState, useEffect, useRef } from 'react';
import {
  Users,
  Plus,
  Check,
  Trash2,
  Edit2,
  Mic,
  Volume2,
  ShieldAlert,
  Sliders,
  Radio,
  CheckCircle2,
  X,
  RefreshCw,
  Zap,
  Key,
  ExternalLink,
  Server,
  AlertTriangle,
} from 'lucide-react';
import { UserProfile } from '../types';
import {
  fetchProfiles,
  getActiveProfile,
  setActiveProfile,
  createProfile,
  updateProfile,
  deleteProfile,
} from '../services/profileService';
import {
  calculateAudioRMS,
  rmsToNormalizedLevel,
  calibrateAmbientNoise,
} from '../utils/audio';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onProfileSwitched?: (profile: UserProfile) => void;
}

export const ProfileModal: React.FC<Props> = ({ isOpen, onClose, onProfileSwitched }) => {
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [activeProfile, setActiveProfileState] = useState<UserProfile>(getActiveProfile());
  const [activeTab, setActiveTab] = useState<'list' | 'create' | 'edit' | 'calibrate' | 'providers'>('list');
  const [editingProfileId, setEditingProfileId] = useState<string | null>(null);

  // Groq LPU Provider & Connection State
  const [groqCustomKey, setGroqCustomKey] = useState<string>(() => localStorage.getItem('GROQ_CUSTOM_KEY') || '');
  const [groqStatus, setGroqStatus] = useState<any>(null);
  const [isCheckingGroq, setIsCheckingGroq] = useState(false);
  const [groqTestOutput, setGroqTestOutput] = useState<string | null>(null);
  const [groqTestLoading, setGroqTestLoading] = useState(false);

  const checkGroqStatus = async (overrideKey?: string) => {
    setIsCheckingGroq(true);
    setGroqTestOutput(null);
    try {
      const keyToUse = overrideKey !== undefined ? overrideKey : groqCustomKey;
      const headers: Record<string, string> = {};
      if (keyToUse.trim()) {
        headers['x-groq-api-key'] = keyToUse.trim();
      }
      const res = await fetch('/api/groq/status', { headers });
      const data = await res.json();
      setGroqStatus(data);
    } catch (err: any) {
      setGroqStatus({
        connected: false,
        error: String(err?.message || 'Error de red consultando Groq'),
      });
    } finally {
      setIsCheckingGroq(false);
    }
  };

  const handleSaveCustomGroqKey = () => {
    const trimmed = groqCustomKey.trim();
    if (trimmed) {
      localStorage.setItem('GROQ_CUSTOM_KEY', trimmed);
      setActionSuccess('Clave personalizada de Groq guardada exitosamente.');
    } else {
      localStorage.removeItem('GROQ_CUSTOM_KEY');
      setActionSuccess('Se eliminó la clave personalizada. Usando clave de entorno del proyecto.');
    }
    checkGroqStatus(trimmed);
  };

  const handleTestGroqChat = async () => {
    setGroqTestLoading(true);
    setGroqTestOutput(null);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (groqCustomKey.trim()) {
        headers['x-groq-api-key'] = groqCustomKey.trim();
      }
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          provider: 'groq',
          model: 'llama-3.3-70b-versatile',
          messages: [{ role: 'user', content: 'Di "¡Conexión Groq LPU verificada!" en una sola frase breve.' }],
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setGroqTestOutput(`✅ ${data.reply} (Modelo: ${data.model})`);
      } else {
        setGroqTestOutput(`❌ Error: ${data.error || 'No se pudo completar la prueba'}`);
      }
    } catch (err: any) {
      setGroqTestOutput(`❌ Error: ${err?.message || 'Error de conexión'}`);
    } finally {
      setGroqTestLoading(false);
    }
  };

  // Form State
  const [formName, setFormName] = useState('');
  const [formRole, setFormRole] = useState('Investigador');
  const [formLanguage, setFormLanguage] = useState<'es-ES' | 'es-419' | 'es-MX' | 'en-US'>('es-ES');
  const [formNoiseThreshold, setFormNoiseThreshold] = useState<number>(25);
  const [formNoiseSuppression, setFormNoiseSuppression] = useState(true);
  const [formHighpass, setFormHighpass] = useState(true);
  const [formModel, setFormModel] = useState('gemini-2.5-flash');
  const [formTone, setFormTone] = useState<'analitico' | 'directo' | 'formal' | 'conversacional'>('analitico');
  const [formInstructions, setFormInstructions] = useState('');
  const [formColor, setFormColor] = useState('#2563eb');
  const [formError, setFormError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Live Microphone Monitoring & Calibration State
  const [currentMicLevel, setCurrentMicLevel] = useState(0);
  const [isVoiceDetected, setIsVoiceDetected] = useState(false);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibratedFloor, setCalibratedFloor] = useState<number | null>(null);

  // Speech Recognition Test in Modal
  const [isTestingSpeech, setIsTestingSpeech] = useState(false);
  const [speechTestTranscript, setSpeechTestTranscript] = useState('');

  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  // Load profiles
  const loadData = async () => {
    try {
      const list = await fetchProfiles();
      setProfiles(list);
      const current = getActiveProfile();
      setActiveProfileState(current);
    } catch (e) {
      console.warn('Error loading profiles:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
      setActionSuccess(null);
      setFormError(null);
    } else {
      stopMicMonitoring();
      stopSpeechTest();
    }
  }, [isOpen]);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      stopMicMonitoring();
      stopSpeechTest();
    };
  }, []);

  const handleSelectProfile = (p: UserProfile) => {
    const switched = setActiveProfile(p.id);
    setActiveProfileState(switched);
    setActionSuccess(`Perfil activado: "${switched.name}"`);
    onProfileSwitched?.(switched);
  };

  const handleStartCreate = () => {
    setFormName('');
    setFormRole('Investigador / Usuario');
    setFormLanguage('es-ES');
    setFormNoiseThreshold(25);
    setFormNoiseSuppression(true);
    setFormHighpass(true);
    setFormModel('gemini-2.5-flash');
    setFormTone('analitico');
    setFormInstructions('');
    setFormColor('#3b82f6');
    setFormError(null);
    setEditingProfileId(null);
    setActiveTab('create');
    startMicMonitoring();
  };

  const handleStartEdit = (p: UserProfile) => {
    setEditingProfileId(p.id);
    setFormName(p.name);
    setFormRole(p.role);
    setFormLanguage(p.language);
    setFormNoiseThreshold(p.noiseGateThreshold);
    setFormNoiseSuppression(p.noiseSuppressionEnabled);
    setFormHighpass(p.highpassFilterEnabled);
    setFormModel(p.preferredModel);
    setFormTone(p.tone);
    setFormInstructions(p.customInstructions || '');
    setFormColor(p.avatarColor || '#2563eb');
    setFormError(null);
    setActiveTab('edit');
    startMicMonitoring();
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setFormError('El nombre del perfil es requerido.');
      return;
    }

    try {
      if (editingProfileId) {
        const updated = await updateProfile(editingProfileId, {
          name: formName.trim(),
          role: formRole.trim(),
          language: formLanguage,
          noiseGateThreshold: formNoiseThreshold,
          noiseSuppressionEnabled: formNoiseSuppression,
          highpassFilterEnabled: formHighpass,
          preferredModel: formModel,
          tone: formTone,
          customInstructions: formInstructions.trim(),
          avatarColor: formColor,
          calibratedNoiseFloor: calibratedFloor || undefined,
        });
        setActionSuccess(`Perfil "${updated.name}" actualizado correctamente.`);
      } else {
        const created = await createProfile({
          name: formName.trim(),
          role: formRole.trim(),
          language: formLanguage,
          noiseGateThreshold: formNoiseThreshold,
          noiseSuppressionEnabled: formNoiseSuppression,
          highpassFilterEnabled: formHighpass,
          preferredModel: formModel,
          tone: formTone,
          customInstructions: formInstructions.trim(),
          avatarColor: formColor,
          isDefault: false,
          calibratedNoiseFloor: calibratedFloor || undefined,
        });
        setActionSuccess(`Perfil "${created.name}" creado y guardado en Firebase.`);
        handleSelectProfile(created);
      }
      await loadData();
      setActiveTab('list');
      stopMicMonitoring();
    } catch (err: any) {
      setFormError(err?.message || 'Error al guardar el perfil');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`¿Estás seguro de eliminar el perfil "${name}"?`)) return;
    try {
      await deleteProfile(id);
      setActionSuccess(`Perfil "${name}" eliminado.`);
      await loadData();
    } catch (err: any) {
      alert(err?.message || 'No se pudo eliminar el perfil');
    }
  };

  // Live Mic Monitoring with Real-time VU meter
  const startMicMonitoring = async () => {
    try {
      if (mediaStreamRef.current) return;
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          noiseSuppression: formNoiseSuppression,
          echoCancellation: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioContextRef.current = ctx;

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyserRef.current = analyser;

      if (formHighpass) {
        const biquad = ctx.createBiquadFilter();
        biquad.type = 'highpass';
        biquad.frequency.setValueAtTime(85, ctx.currentTime);
        source.connect(biquad);
        biquad.connect(analyser);
      } else {
        source.connect(analyser);
      }

      const buffer = new Float32Array(analyser.fftSize);

      const updateMeter = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getFloatTimeDomainData(buffer);
        const rms = calculateAudioRMS(buffer);
        const level = rmsToNormalizedLevel(rms);
        setCurrentMicLevel(level);

        // Voice detected if level meets or exceeds threshold
        setIsVoiceDetected(level >= formNoiseThreshold);

        animFrameRef.current = requestAnimationFrame(updateMeter);
      };

      updateMeter();
    } catch (err) {
      console.warn('Microphone access for preview not granted:', err);
    }
  };

  const stopMicMonitoring = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (_) {}
      audioContextRef.current = null;
    }
    setCurrentMicLevel(0);
    setIsVoiceDetected(false);
  };

  // Run Ambient Noise Calibration (Samples silence for 2.5s)
  const handleRunCalibration = async () => {
    setIsCalibrating(true);
    try {
      let stream = mediaStreamRef.current;
      let ownsStream = false;
      if (!stream) {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            noiseSuppression: true,
            echoCancellation: true,
          },
        });
        ownsStream = true;
      }

      const result = await calibrateAmbientNoise(stream, 2500);
      setCalibratedFloor(result.noiseFloor);
      setFormNoiseThreshold(result.recommendedThreshold);
      setActionSuccess(
        `Calibración completada: Ruido base medido a ${result.noiseFloor}%. Umbral óptimo anti-ruido ajustado automáticamente a ${result.recommendedThreshold}%.`
      );

      if (ownsStream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    } catch (err: any) {
      setFormError('No se pudo calibrar el micrófono: ' + (err?.message || 'permiso denegado'));
    } finally {
      setIsCalibrating(false);
    }
  };

  // Test Speech Recognition Live with Noise Gate
  const toggleSpeechTest = () => {
    if (isTestingSpeech) {
      stopSpeechTest();
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert('Tu navegador no soporta SpeechRecognition nativo.');
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.lang = formLanguage;
      rec.continuous = true;
      rec.interimResults = true;

      rec.onstart = () => {
        setIsTestingSpeech(true);
        setSpeechTestTranscript('Escuchando... habla para verificar el reconocimiento.');
      };

      rec.onresult = (e: any) => {
        let interim = '';
        let final = '';
        for (let i = e.resultIndex; i < e.results.length; ++i) {
          if (e.results[i].isFinal) {
            final += e.results[i][0].transcript + ' ';
          } else {
            interim += e.results[i][0].transcript;
          }
        }
        setSpeechTestTranscript(final || interim || 'Procesando voz...');
      };

      rec.onerror = (e: any) => {
        console.warn('Speech test error:', e.error);
        if (e.error === 'not-allowed') {
          setIsTestingSpeech(false);
          setSpeechTestTranscript('Permiso de micrófono denegado.');
        }
      };

      rec.onend = () => {
        setIsTestingSpeech(false);
      };

      rec.start();
      speechRecognitionRef.current = rec;
      startMicMonitoring();
    } catch (e: any) {
      console.warn('Speech test start notice:', e?.message || e);
    }
  };

  const stopSpeechTest = () => {
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch (_) {}
      speechRecognitionRef.current = null;
    }
    setIsTestingSpeech(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">Perfiles de Usuario & Calibración de Voz</h2>
                <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                  Anti-Ruido Activo
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Personaliza quién habla, la sensibilidad del micrófono, idioma y bóvedas para evitar confusiones con ruido de fondo.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Alerts */}
        {actionSuccess && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionSuccess}</span>
            </div>
            <button
              type="button"
              onClick={() => setActionSuccess(null)}
              className="text-emerald-700 hover:text-emerald-900 font-bold text-xs"
            >
              ✕
            </button>
          </div>
        )}

        {formError && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-900 text-xs flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
              <span>{formError}</span>
            </div>
            <button
              type="button"
              onClick={() => setFormError(null)}
              className="text-red-700 hover:text-red-900 font-bold text-xs"
            >
              ✕
            </button>
          </div>
        )}

        {/* Modal Navigation Tabs */}
        <div className="px-6 pt-4 border-b border-slate-100 flex items-center gap-2 bg-white">
          <button
            type="button"
            onClick={() => {
              setActiveTab('list');
              stopMicMonitoring();
            }}
            className={`px-3.5 py-2 border-b-2 text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'list'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Perfiles Guardados ({profiles.length})</span>
          </button>

          <button
            type="button"
            onClick={handleStartCreate}
            className={`px-3.5 py-2 border-b-2 text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'create'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Crear Perfil</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('calibrate');
              startMicMonitoring();
            }}
            className={`px-3.5 py-2 border-b-2 text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'calibrate'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>Prueba Acústica y Anti-Ruido</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('providers');
              stopMicMonitoring();
              checkGroqStatus();
            }}
            className={`px-3.5 py-2 border-b-2 text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'providers'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-500" />
            <span>Conexión Groq LPU & LLMs</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: PROFILES LIST */}
          {activeTab === 'list' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Selecciona tu perfil activo o crea uno nuevo
                </span>
                <button
                  type="button"
                  onClick={handleStartCreate}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nuevo Perfil</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {profiles.map((p) => {
                  const isActive = activeProfile?.id === p.id;
                  return (
                    <div
                      key={p.id}
                      onClick={() => handleSelectProfile(p)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between gap-3 ${
                        isActive
                          ? 'border-blue-600 bg-blue-50/40 shadow-xs ring-1 ring-blue-600'
                          : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-10 h-10 rounded-xl text-white font-bold flex items-center justify-center text-sm shadow-xs"
                            style={{ backgroundColor: p.avatarColor || '#2563eb' }}
                          >
                            {p.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-slate-900 text-sm">{p.name}</h4>
                              {isActive && (
                                <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-bold">
                                  Activo
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 font-medium">{p.role}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => handleStartEdit(p)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                            title="Editar perfil"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {profiles.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleDelete(p.id, p.name)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50"
                              title="Eliminar perfil"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Specs */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-600">
                        <div>
                          <span className="text-slate-400 block text-[10px]">Filtro Ruido:</span>
                          <span className="font-semibold text-slate-700">
                            Puerta {p.noiseGateThreshold}% {p.noiseSuppressionEnabled ? '(DSP activo)' : ''}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px]">Idioma de Voz:</span>
                          <span className="font-semibold text-slate-700 font-mono">{p.language}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px]">Modelo IA:</span>
                          <span className="font-semibold text-slate-700 truncate block">{p.preferredModel}</span>
                        </div>
                      </div>

                      <div className="pt-2 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">
                          Tono: <strong className="capitalize">{p.tone}</strong>
                        </span>
                        {!isActive ? (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSelectProfile(p);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700 text-xs font-semibold transition-colors"
                          >
                            Activar
                          </button>
                        ) : (
                          <span className="text-[11px] text-blue-600 font-bold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Perfil en Uso
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: CREATE / EDIT PROFILE FORM */}
          {(activeTab === 'create' || activeTab === 'edit') && (
            <form onSubmit={handleSaveProfile} className="space-y-6">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <h3 className="font-bold text-sm text-slate-900 mb-1">
                  {activeTab === 'create' ? 'Crear Nuevo Perfil' : `Editando: ${formName}`}
                </h3>
                <p className="text-xs text-slate-500">
                  Ajusta los parámetros de reconocimiento y el umbral de cancelación de ruido ambiental para este perfil.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nombre del Perfil *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Ej. Gabriel (Trabajo) o Perfil Oficina"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Rol / Especialidad</label>
                  <input
                    type="text"
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    placeholder="Ej. Investigador de Mercado, Gestor Workspace..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Idioma Reconocimiento de Voz</label>
                  <select
                    value={formLanguage}
                    onChange={(e: any) => setFormLanguage(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                  >
                    <option value="es-ES">Español (España / Global)</option>
                    <option value="es-419">Español (Latinoamérica)</option>
                    <option value="es-MX">Español (México)</option>
                    <option value="en-US">English (United States)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Modelo IA Preferido</label>
                  <select
                    value={formModel}
                    onChange={(e) => setFormModel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                  >
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash (Ultra Rápido)</option>
                    <option value="gemini-2.5-pro">Gemini 2.5 Pro (Razonamiento Profundo)</option>
                    <option value="groq-llama-3.3-70b">Groq LLaMA 3.3 70B (Failover)</option>
                    <option value="groq-deepseek-r1-distill-llama-70b">Groq DeepSeek R1 70B</option>
                  </select>
                </div>
              </div>

              {/* LIVE NOISE CANCELLATION & CALIBRATION SECTION */}
              <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400">
                      <Sliders className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold">Puerta de Ruido y Cancelación Acústica</h4>
                      <p className="text-[11px] text-slate-400">
                        El audio por debajo de este umbral se descarta automáticamente para evitar falsos disparos.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleRunCalibration}
                    disabled={isCalibrating}
                    className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isCalibrating ? 'animate-spin' : ''}`} />
                    <span>{isCalibrating ? 'Midiendo silencio (2.5s)...' : 'Calibrar Habitación Automático'}</span>
                  </button>
                </div>

                {/* Real-time VU Meter Bar */}
                <div className="space-y-1.5 bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 flex items-center gap-1.5">
                      <Mic className={`w-3.5 h-3.5 ${isVoiceDetected ? 'text-emerald-400' : 'text-slate-400'}`} />
                      <span>Nivel de Micrófono en Vivo:</span>
                      <strong className="font-mono text-white">{currentMicLevel}%</strong>
                    </span>

                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isVoiceDetected
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}>
                      {isVoiceDetected ? '🟢 VOZ DETECTADA' : '🟡 RUIDO DESCARTADO'}
                    </span>
                  </div>

                  {/* Level bar with threshold marker */}
                  <div className="relative h-4 bg-slate-950 rounded-lg overflow-hidden border border-slate-700">
                    <div
                      className={`h-full transition-all duration-75 ${
                        isVoiceDetected ? 'bg-emerald-500' : 'bg-amber-500/80'
                      }`}
                      style={{ width: `${Math.min(100, currentMicLevel)}%` }}
                    />
                    {/* Threshold marker pin */}
                    <div
                      className="absolute top-0 bottom-0 w-1 bg-red-400 z-10"
                      style={{ left: `${formNoiseThreshold}%` }}
                      title={`Umbral anti-ruido: ${formNoiseThreshold}%`}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                    <span>0% (Silencio)</span>
                    <span className="text-red-300 font-bold">Umbral Puerta: {formNoiseThreshold}%</span>
                    <span>100% (Voz Alta)</span>
                  </div>
                </div>

                {/* Slider */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <label className="font-medium text-slate-300">
                      Umbral de Sensibilidad Anti-Ruido (Puerta de Ruido):
                    </label>
                    <span className="font-bold text-blue-400 font-mono">{formNoiseThreshold}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="80"
                    step="1"
                    value={formNoiseThreshold}
                    onChange={(e) => setFormNoiseThreshold(Number(e.target.value))}
                    className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <p className="text-[10px] text-slate-400">
                    Un valor mayor (35-50%) es ideal para cafeterías, ruidos de ventilador o teclados mecánicos. Un valor menor (15-25%) es ideal para despachos silenciosos.
                  </p>
                </div>

                {/* Toggles */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formNoiseSuppression}
                      onChange={(e) => setFormNoiseSuppression(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                    />
                    <span className="text-xs text-slate-200 font-medium">
                      Supresión de Ruido Hardware (WebRTC)
                    </span>
                  </label>

                  <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formHighpass}
                      onChange={(e) => setFormHighpass(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                    />
                    <span className="text-xs text-slate-200 font-medium">
                      Filtro Paso-Alto 85Hz (Elimina zumbido AC/vibración)
                    </span>
                  </label>
                </div>
              </div>

              {/* Tone & Prompt Additions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tono del Asistente</label>
                  <select
                    value={formTone}
                    onChange={(e: any) => setFormTone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                  >
                    <option value="analitico">Analítico (Profundo, con tablas y fuentes)</option>
                    <option value="directo">Directo (Conciso, respuestas rápidas)</option>
                    <option value="formal">Formal (Corporativo, exhaustivo)</option>
                    <option value="conversacional">Conversacional (Cercano y fluido)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Color del Avatar</label>
                  <div className="flex items-center gap-2 pt-1">
                    {['#2563eb', '#059669', '#9333ea', '#ea580c', '#0891b2', '#e11d48'].map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setFormColor(c)}
                        className={`w-7 h-7 rounded-xl transition-transform ${
                          formColor === c ? 'scale-110 ring-2 ring-slate-800 ring-offset-2' : ''
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Instrucciones Personalizadas para la IA (System Prompt de este Perfil)
                </label>
                <textarea
                  rows={2}
                  value={formInstructions}
                  onChange={(e) => setFormInstructions(e.target.value)}
                  placeholder="Ej: 'Cuando pida resúmenes, incluye siempre una tabla con métricas clave y guarda en la bóveda tron'."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Form Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('list');
                    stopMicMonitoring();
                  }}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
                >
                  {activeTab === 'create' ? 'Guardar y Activar Perfil' : 'Actualizar Perfil'}
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: CALIBRATE & ACOUSTIC TEST */}
          {activeTab === 'calibrate' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200">
                <h3 className="font-bold text-sm text-blue-950 mb-1">
                  Prueba de Reconocimiento de Voz y Rechazo de Ruido en Vivo
                </h3>
                <p className="text-xs text-blue-900">
                  Habla de forma natural mientras reproduces sonido de fondo o tecleas. El sistema solo transcribirá cuando tu voz supere el umbral anti-ruido configurado para el perfil activo (<strong>{activeProfile.name}</strong>).
                </p>
              </div>

              {/* Live VU meter */}
              <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Mic className="w-4 h-4 text-blue-400" />
                    <span className="font-bold text-xs">Monitoreo Acústico en Tiempo Real</span>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    isVoiceDetected
                      ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/50'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}>
                    {isVoiceDetected ? '🟢 VOZ ACTIVA DETECTADA' : '🟡 RUIDO AMBIENTAL FILTRADO'}
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="h-6 bg-slate-950 rounded-xl overflow-hidden relative border border-slate-700">
                    <div
                      className={`h-full transition-all duration-75 ${
                        isVoiceDetected ? 'bg-emerald-500' : 'bg-amber-500/70'
                      }`}
                      style={{ width: `${Math.min(100, currentMicLevel)}%` }}
                    />
                    <div
                      className="absolute top-0 bottom-0 w-1.5 bg-red-400 z-10 shadow-xs"
                      style={{ left: `${activeProfile.noiseGateThreshold}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Nivel actual: <strong className="text-white font-mono">{currentMicLevel}%</strong></span>
                    <span className="text-red-300 font-bold">
                      Filtro de Ruido ({activeProfile.name}): {activeProfile.noiseGateThreshold}%
                    </span>
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={handleRunCalibration}
                    disabled={isCalibrating}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 border border-slate-600 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isCalibrating ? 'animate-spin' : ''}`} />
                    <span>Re-calibrar Silencio</span>
                  </button>

                  <button
                    type="button"
                    onClick={toggleSpeechTest}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer ${
                      isTestingSpeech
                        ? 'bg-red-600 hover:bg-red-700 text-white'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>{isTestingSpeech ? 'Detener Prueba de Reconocimiento' : 'Probar Reconocimiento de Voz'}</span>
                  </button>
                </div>

                {/* Transcript Live Box */}
                {isTestingSpeech && (
                  <div className="mt-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider font-mono">
                      Transcripción de prueba ({formLanguage}):
                    </span>
                    <p className="text-sm font-medium text-emerald-400 font-mono min-h-[1.5rem]">
                      {speechTestTranscript}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: AI PROVIDERS & GROQ LPU DIAGNOSTICS */}
          {activeTab === 'providers' && (
            <div className="space-y-6">
              {/* Header card */}
              <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200">
                <div className="flex items-center gap-2 mb-1">
                  <Zap className="w-4 h-4 text-amber-600" />
                  <h3 className="font-bold text-sm text-amber-950">
                    Diagnóstico y Estado de Conexión: Groq LPU & Google Gemini
                  </h3>
                </div>
                <p className="text-xs text-amber-900 leading-relaxed">
                  Verifica el estado en vivo de la clave <code className="px-1 py-0.5 rounded bg-amber-100 font-mono">GROQ_API_KEY</code>, prueba la comunicación directa con los servidores de Groq y configura claves personalizadas para conmutación por error instantánea (Failover).
                </p>
              </div>

              {/* Live Groq Connection Card */}
              <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-4 border border-slate-800">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs border border-amber-500/30">
                      ⚡
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        Groq LPU (Language Processing Unit)
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          ~800 tokens/seg
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Inferencia ultra rápida con latencia mínima para failover y análisis de documentos.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => checkGroqStatus()}
                    disabled={isCheckingGroq}
                    className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isCheckingGroq ? 'animate-spin' : ''}`} />
                    <span>{isCheckingGroq ? 'Verificando...' : 'Verificar Conexión'}</span>
                  </button>
                </div>

                {/* Groq Status Response Banner */}
                {groqStatus ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                      <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                        <span className="text-slate-400 text-[10px] uppercase font-mono block mb-1">Clave de API</span>
                        <div className="flex items-center gap-1.5">
                          <Key className="w-3.5 h-3.5 text-amber-400" />
                          <span className="font-mono font-bold text-white">
                            {groqStatus.maskedKey || (groqStatus.hasKey ? 'Detectada' : 'No configurada')}
                          </span>
                        </div>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                        <span className="text-slate-400 text-[10px] uppercase font-mono block mb-1">Servidor Groq</span>
                        <div className="flex items-center gap-1.5">
                          <Server className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="font-bold text-emerald-300">
                            {groqStatus.connected ? 'Comunicación 200 OK' : 'Sin conexión'}
                          </span>
                        </div>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                        <span className="text-slate-400 text-[10px] uppercase font-mono block mb-1">Modelos Detectados</span>
                        <span className="font-bold text-white">
                          {groqStatus.availableModelsCount || 0} modelos disponibles
                        </span>
                      </div>
                    </div>

                    {/* Inference status warning or success */}
                    {groqStatus.canInfer ? (
                      <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-200 text-xs flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <strong className="block text-emerald-300 mb-0.5">Conexión e Inferencia 100% Activa</strong>
                          <span>{groqStatus.message}</span>
                        </div>
                      </div>
                    ) : groqStatus.blockedReason === 'blocked_org' ? (
                      <div className="p-3.5 rounded-xl bg-amber-950/70 border border-amber-500/50 text-amber-200 text-xs space-y-2">
                        <div className="flex items-start gap-2.5">
                          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <div>
                            <strong className="block text-amber-300 mb-0.5">Clave Conectada con Éxito - Modelos Desactivados en Organización</strong>
                            <p className="leading-relaxed text-amber-200">
                              La clave de API se comunica perfectamente con los servidores de Groq. Sin embargo, tu organización en Groq tiene los modelos desactivados en los límites de cuota (o es una organización sin modelos activos).
                            </p>
                          </div>
                        </div>

                        <div className="pt-1 flex flex-wrap items-center gap-2">
                          <a
                            href={groqStatus.limitsUrl || 'https://console.groq.com/settings/limits'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Abrir Consola de Límites de Groq</span>
                          </a>
                          <a
                            href="https://console.groq.com/keys"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
                          >
                            <Key className="w-3.5 h-3.5 text-amber-400" />
                            <span>Gestionar Claves en Groq</span>
                          </a>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-slate-800 text-slate-300 text-xs flex items-center gap-2">
                        <Server className="w-4 h-4 text-slate-400" />
                        <span>{groqStatus.message || groqStatus.error}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-slate-800/60 text-slate-400 text-xs text-center">
                    Haz clic en "Verificar Conexión" para comprobar en tiempo real el estado de Groq.
                  </div>
                )}

                {/* Quick Chat Test Button */}
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs text-slate-400">
                    Prueba de inferencia directa (Ping LLM):
                  </span>
                  <button
                    type="button"
                    onClick={handleTestGroqChat}
                    disabled={groqTestLoading}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Zap className={`w-3.5 h-3.5 ${groqTestLoading ? 'animate-bounce' : ''}`} />
                    <span>{groqTestLoading ? 'Generando respuesta en Groq...' : 'Enviar Ping a Groq'}</span>
                  </button>
                </div>

                {/* Test Output Box */}
                {groqTestOutput && (
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200">
                    {groqTestOutput}
                  </div>
                )}
              </div>

              {/* Custom Groq API Key Input */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Key className="w-4 h-4 text-slate-700" />
                    <h4 className="text-xs font-bold text-slate-900">
                      Clave de API Personalizada de Groq (Opcional)
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-500">
                    Se guarda de forma segura en tu navegador
                  </span>
                </div>

                <p className="text-xs text-slate-600">
                  Si posees una cuenta o clave de Groq con modelos LLaMA activados, puedes ingresarla aquí para sobrescribir la clave del sistema.
                </p>

                <div className="flex gap-2">
                  <input
                    type="password"
                    value={groqCustomKey}
                    onChange={(e) => setGroqCustomKey(e.target.value)}
                    placeholder="gsk_..."
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleSaveCustomGroqKey}
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer transition-colors"
                  >
                    Guardar
                  </button>
                  {groqCustomKey && (
                    <button
                      type="button"
                      onClick={() => {
                        setGroqCustomKey('');
                        localStorage.removeItem('GROQ_CUSTOM_KEY');
                        setActionSuccess('Clave personalizada eliminada.');
                        checkGroqStatus('');
                      }}
                      className="px-3 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition-colors"
                    >
                      Restablecer
                    </button>
                  )}
                </div>
              </div>

              {/* Gemini Provider Information */}
              <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                    ✦
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-blue-950">Google Gemini Multi-Tier</h4>
                    <p className="text-[11px] text-blue-800">
                      Gemini 3.8 Flash, Gemini 3.5 Flash (Google Search Grounding en vivo) y Gemini 3.1 Flash Lite.
                    </p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                  Proveedor Principal
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>
              Perfil en uso: <strong className="text-slate-800">{activeProfile.name}</strong> ({activeProfile.language})
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs cursor-pointer transition-colors"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
