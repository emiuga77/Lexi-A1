import React, { useState, useEffect, useRef } from 'react';
import {
  WorkspaceFile,
  PendingActionConfirmation,
  ExtractedDocumentData,
  UploadedDocumentFile,
  GeminiModelTier,
  GroqModelTier,
  AIProvider,
  ExtractionRecord,
  AuditLog,
  DocumentMetadata,
} from '../types';
import {
  FileText,
  Table,
  Upload,
  Sparkles,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Download,
  Copy,
  Check,
  Layers,
  Eye,
  RefreshCw,
  Sliders,
  Plus,
  Trash2,
  Zap,
  Brain,
  Database,
  History,
  Radio,
  Terminal,
  Activity,
} from 'lucide-react';
import {
  listGoogleDocs,
  listGoogleSheets,
  createGoogleDoc,
  appendToGoogleDoc,
  createGoogleSheet,
  appendSpreadsheetRows,
} from '../services/workspaceApi';
import { downloadMarkdownFile } from '../utils/fileDownloader';
import {
  saveExtractionRecord,
  getExtractionHistory,
  deleteExtractionRecord,
  logAuditEvent,
  getAuditLogs,
  saveDocumentMetadata,
  getDocumentMetadataList,
} from '../services/firestoreDb';

interface Props {
  isAuthenticated: boolean;
  onPromptLogin: () => void;
  onRequestAction: (action: PendingActionConfirmation) => void;
}

export const DocumentExtractorStudio: React.FC<Props> = ({
  isAuthenticated,
  onPromptLogin,
  onRequestAction,
}) => {
  // Multi-Document File state
  const [selectedFiles, setSelectedFiles] = useState<UploadedDocumentFile[]>([]);
  const selectedFile = selectedFiles[0] || null; // Backward compatibility helper for single-file references

  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Provider and Extraction options
  const [selectedProvider, setSelectedProvider] = useState<AIProvider>('gemini');
  const [selectedGroqModel, setSelectedGroqModel] = useState<GroqModelTier>('llama-3.2-11b-vision-preview');
  const [extractionMode, setExtractionMode] = useState<'hybrid' | 'sheets' | 'docs'>('hybrid');
  const [selectedModel, setSelectedModel] = useState<GeminiModelTier>('gemini-3.8-flash');
  const [customPrompt, setCustomPrompt] = useState('');
  const [enableThinking, setEnableThinking] = useState(false);

  // Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isQuotaError, setIsQuotaError] = useState(false);
  const [countdownSeconds, setCountdownSeconds] = useState<number | null>(null);
  const [extractedData, setExtractedData] = useState<ExtractedDocumentData | null>(null);
  const [actualModelUsed, setActualModelUsed] = useState<string | null>(null);
  const [failoverNotice, setFailoverNotice] = useState<string | null>(null);
  const [activeResultTab, setActiveResultTab] = useState<'sheets' | 'docs' | 'summary' | 'firebase'>('sheets');

  // Server-Sent Events (SSE) & Progressive Streaming state
  const [useStreaming, setUseStreaming] = useState<boolean>(true);
  const [streamProgress, setStreamProgress] = useState<{
    phase: 'idle' | 'preparing' | 'connecting' | 'streaming' | 'fallback' | 'failover' | 'parsing' | 'complete';
    message: string;
    model?: string;
    provider?: string;
    chunksCount?: number;
    charCount?: number;
  }>({
    phase: 'idle',
    message: '',
    chunksCount: 0,
    charCount: 0,
  });
  const [streamingRawText, setStreamingRawText] = useState<string>('');

  // Firebase Firestore Database State
  const [extractionHistory, setExtractionHistory] = useState<ExtractionRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [documentMetadataList, setDocumentMetadataList] = useState<DocumentMetadata[]>([]);
  const [isLoadingDatabase, setIsLoadingDatabase] = useState(false);
  const [databaseSubTab, setDatabaseSubTab] = useState<'extractions' | 'metadata' | 'audit'>('extractions');
  const [firebaseStatusNotice, setFirebaseStatusNotice] = useState<string | null>(null);

  const refreshDatabaseData = async () => {
    setIsLoadingDatabase(true);
    try {
      const [extractions, logs, metadata] = await Promise.all([
        getExtractionHistory(),
        getAuditLogs(50),
        getDocumentMetadataList(),
      ]);
      setExtractionHistory(extractions);
      setAuditLogs(logs);
      setDocumentMetadataList(metadata);
    } catch (err) {
      console.warn('Error refreshing database data:', err);
    } finally {
      setIsLoadingDatabase(false);
    }
  };

  useEffect(() => {
    refreshDatabaseData();
  }, [isAuthenticated]);

  // Existing drive files for append actions
  const [userSheets, setUserSheets] = useState<WorkspaceFile[]>([]);
  const [userDocs, setUserDocs] = useState<WorkspaceFile[]>([]);
  const [selectedSheetToAppend, setSelectedSheetToAppend] = useState<string>('');
  const [selectedDocToAppend, setSelectedDocToAppend] = useState<string>('');
  const [isExporting, setIsExporting] = useState(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);

  // Copy states
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  // Fetch user's sheets and docs for append destination options
  useEffect(() => {
    if (isAuthenticated) {
      listGoogleSheets()
        .then((items) => {
          setUserSheets(items);
          if (items.length > 0) setSelectedSheetToAppend(items[0].id);
        })
        .catch(() => {});

      listGoogleDocs()
        .then((items) => {
          setUserDocs(items);
          if (items.length > 0) setSelectedDocToAppend(items[0].id);
        })
        .catch(() => {});
    }
  }, [isAuthenticated]);

  // Multi-File loading helpers
  const handleFilesProcess = (files: FileList | File[]) => {
    setError(null);
    setActionSuccessMessage(null);

    const fileList = Array.from(files);
    if (fileList.length === 0) return;

    if (selectedFiles.length + fileList.length > 8) {
      setError('Puedes subir hasta 8 documentos o imágenes simultáneamente para correlación cruzada.');
      return;
    }

    fileList.forEach((file) => {
      if (file.size > 20 * 1024 * 1024) {
        setError(`El archivo "${file.name}" supera los 20MB permitidos.`);
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const isImg = file.type.startsWith('image/');
        const newDoc: UploadedDocumentFile = {
          id: 'doc-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
          name: file.name,
          type: file.type || 'application/octet-stream',
          size: file.size,
          data: result,
          previewUrl: isImg ? result : undefined,
        };

        setSelectedFiles((prev) => [...prev, newDoc]);
      };
      reader.onerror = () => {
        setError(`No se pudo leer el archivo "${file.name}".`);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileProcess = (file: File) => {
    handleFilesProcess([file]);
  };

  const removeFile = (idToRemove: string) => {
    setSelectedFiles((prev) => prev.filter((f) => f.id !== idToRemove));
  };

  const clearAllFiles = () => {
    setSelectedFiles([]);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFilesProcess(e.dataTransfer.files);
    }
  };

  // Sample Demos for instant 1-click testing
  const loadSampleReceipt = () => {
    // A clean SVG data URI representing a commercial expense invoice with tabular data
    const svgInvoice = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="900" viewBox="0 0 800 900" fill="#ffffff">
      <rect width="800" height="900" fill="#f8fafc"/>
      <rect x="40" y="40" width="720" height="820" rx="16" fill="#ffffff" stroke="#e2e8f0" stroke-width="2"/>
      <text x="70" y="90" font-family="Arial, sans-serif" font-size="24" font-weight="bold" fill="#1e293b">INNOVA TECH SOLUTIONS S.A. DE C.V.</text>
      <text x="70" y="115" font-family="Arial, sans-serif" font-size="12" fill="#64748b">RFC: ITS180422K89 | Av. Reforma 222, CDMX | Tel: +52 55 4160 8800</text>
      <text x="70" y="150" font-family="Arial, sans-serif" font-size="14" font-weight="bold" fill="#0f172a">FACTURA FISCAL No: INV-2026-0894</text>
      <text x="70" y="170" font-family="Arial, sans-serif" font-size="12" fill="#475569">Fecha de Emisión: 14/09/2026 | Moneda: USD | Método de Pago: Transferencia PPD</text>
      <text x="70" y="195" font-family="Arial, sans-serif" font-size="13" font-weight="bold" fill="#0f172a">CLIENTE: Corporativo Global S.A. | ID Cliente: CG-9421</text>
      
      <!-- Table Header -->
      <rect x="70" y="230" width="660" height="35" rx="6" fill="#f1f5f9"/>
      <text x="85" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">CÓDIGO</text>
      <text x="170" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">DESCRIPCIÓN DEL SERVICIO</text>
      <text x="450" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">CANT.</text>
      <text x="520" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">P. UNIT ($)</text>
      <text x="640" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">TOTAL ($)</text>

      <!-- Rows -->
      <text x="85" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">SRV-01</text>
      <text x="170" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">Licencia Cloud AI Enterprise (Anual)</text>
      <text x="460" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">5</text>
      <text x="530" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">450.00</text>
      <text x="645" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">2,250.00</text>

      <line x1="70" y1="310" x2="730" y2="310" stroke="#f1f5f9"/>
      <text x="85" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">SRV-02</text>
      <text x="170" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">Consultoría Arquitectura de Integración</text>
      <text x="460" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">24</text>
      <text x="530" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">120.00</text>
      <text x="645" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">2,880.00</text>

      <line x1="70" y1="360" x2="730" y2="360" stroke="#f1f5f9"/>
      <text x="85" y="390" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">SRV-03</text>
      <text x="170" y="390" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">Mantenimiento y Soporte SLA 99.9% Q3</text>
      <text x="460" y="390" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">1</text>
      <text x="530" y="390" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">850.00</text>
      <text x="645" y="390" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">850.00</text>

      <line x1="70" y1="410" x2="730" y2="410" stroke="#f1f5f9"/>
      <text x="85" y="440" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">HW-04</text>
      <text x="170" y="440" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">Dispositivos Hardware Token FIDO2</text>
      <text x="460" y="440" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">15</text>
      <text x="530" y="440" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">45.00</text>
      <text x="645" y="440" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">675.00</text>

      <!-- Totals Box -->
      <rect x="440" y="490" width="290" height="130" rx="8" fill="#f8fafc" stroke="#e2e8f0"/>
      <text x="460" y="520" font-family="Arial, sans-serif" font-size="13" fill="#475569">Subtotal:</text>
      <text x="640" y="520" font-family="Arial, sans-serif" font-size="13" font-weight="bold" fill="#0f172a">$6,655.00</text>

      <text x="460" y="555" font-family="Arial, sans-serif" font-size="13" fill="#475569">IVA Trasladado (16%):</text>
      <text x="640" y="555" font-family="Arial, sans-serif" font-size="13" font-weight="bold" fill="#0f172a">$1,064.80</text>

      <line x1="450" y1="575" x2="720" y2="575" stroke="#cbd5e1"/>
      <text x="460" y="605" font-family="Arial, sans-serif" font-size="15" font-weight="bold" fill="#1e1b4b">TOTAL A PAGAR:</text>
      <text x="630" y="605" font-family="Arial, sans-serif" font-size="16" font-weight="bold" fill="#4338ca">$7,719.80</text>

      <text x="70" y="680" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">Condiciones y Notas:</text>
      <text x="70" y="705" font-family="Arial, sans-serif" font-size="11" fill="#64748b">1. Pago neto dentro de los 30 días posteriores a la emisión.</text>
      <text x="70" y="725" font-family="Arial, sans-serif" font-size="11" fill="#64748b">2. Depósitos a cuenta BBVA CLABE: 012180001234567890 a nombre de Innova Tech Solutions.</text>
    </svg>`;

    const base64Data = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgInvoice)));
    setSelectedFiles([{
      id: 'demo-receipt-1',
      name: 'Factura_Servicios_InnovaTech_INV-2026.svg',
      type: 'image/svg+xml',
      size: 4200,
      data: base64Data,
      previewUrl: base64Data,
    }]);
    setError(null);
  };

  const loadSampleContract = () => {
    const sampleContractText = `ACUERDO DE PRESTACIÓN DE SERVICIOS PROFESIONALES Y CONFIDENCIALIDAD (NDA)
FECHA: 12 de Septiembre de 2026
CIUDAD: Madrid, España

PARTES CONTRATANTES:
- EL PRESTADOR: Nexus Advisory Group S.L. con NIF B-89210344, representada por Dña. Elena Morales.
- EL CLIENTE: Vanguard Global Tech Ltd., representada por D. Carlos Méndez.

CLÁUSULA PRIMERA: OBJETO DEL CONTRATO
El Prestador se compromete a proveer auditoría de sistemas de inteligencia artificial y optimización de bases de datos para el cliente durante un período de 6 meses (del 01 de Octubre de 2026 al 31 de Marzo de 2027).

CLÁUSULA SEGUNDA: HONORARIOS Y FORMA DE PAGO
1. Cuota mensual fija de auditoría: 4,200.00 EUR (+ IVA 21%).
2. Pago por hito de migración: 12,500.00 EUR pagadero el 15 de Diciembre de 2026.
3. Bono de éxito por disponibilidad 99.99%: 3,000.00 EUR al cierre del contrato.
Total estimado del proyecto: 40,700.00 EUR (+ IVA).

CLÁUSULA TERCERA: CONFIDENCIALIDAD
La información técnica, financiera y datos de clientes compartidos bajo este acuerdo mantendrán carácter confidencial no transferible por un plazo mínimo de cinco (5) años posteriores a la culminación de los servicios.

CLÁUSULA CUARTA: PENALIZACIONES
Cualquier incumplimiento no justificado acarreará una penalización equivalente al 15% del valor total del contrato sin perjuicio de reclamaciones por daños y perjuicios.

FIRMADO POR DUPLICADO EN FECHA SEÑALADA:
Elena Morales (Nexus Advisory) | Carlos Méndez (Vanguard Global Tech)`;

    const base64Data = 'data:text/plain;base64,' + btoa(unescape(encodeURIComponent(sampleContractText)));
    setSelectedFiles([{
      id: 'demo-contract-1',
      name: 'Contrato_Servicios_Auditoria_Nexus_2026.txt',
      type: 'text/plain',
      size: sampleContractText.length,
      data: base64Data,
    }]);
    setError(null);
  };

  // Demo with 2 complementary documents for immediate cross-document synthesis
  const loadMultiDocDemo = () => {
    // Document 1: Commercial Invoice
    const svgInvoice = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="900" viewBox="0 0 800 900" fill="#ffffff">
      <rect width="800" height="900" fill="#f8fafc"/>
      <rect x="40" y="40" width="720" height="820" rx="16" fill="#ffffff" stroke="#e2e8f0" stroke-width="2"/>
      <text x="70" y="90" font-family="Arial, sans-serif" font-size="24" font-weight="bold" fill="#1e293b">INNOVA TECH SOLUTIONS S.A. DE C.V.</text>
      <text x="70" y="115" font-family="Arial, sans-serif" font-size="12" fill="#64748b">RFC: ITS180422K89 | Av. Reforma 222, CDMX | Tel: +52 55 4160 8800</text>
      <text x="70" y="150" font-family="Arial, sans-serif" font-size="14" font-weight="bold" fill="#0f172a">FACTURA FISCAL No: INV-2026-0894</text>
      <text x="70" y="170" font-family="Arial, sans-serif" font-size="12" fill="#475569">Fecha de Emisión: 14/09/2026 | Moneda: USD | Método de Pago: Transferencia PPD</text>
      <text x="70" y="195" font-family="Arial, sans-serif" font-size="13" font-weight="bold" fill="#0f172a">CLIENTE: Corporativo Global S.A. | ID Cliente: CG-9421</text>
      
      <rect x="70" y="230" width="660" height="35" rx="6" fill="#f1f5f9"/>
      <text x="85" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">CÓDIGO</text>
      <text x="170" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">DESCRIPCIÓN DEL SERVICIO</text>
      <text x="450" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">CANT.</text>
      <text x="520" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">P. UNIT ($)</text>
      <text x="640" y="252" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#334155">TOTAL ($)</text>

      <text x="85" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">SRV-01</text>
      <text x="170" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">Licencia Cloud AI Enterprise (Anual)</text>
      <text x="460" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">5</text>
      <text x="530" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">450.00</text>
      <text x="645" y="290" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">2,250.00</text>

      <line x1="70" y1="310" x2="730" y2="310" stroke="#f1f5f9"/>
      <text x="85" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">SRV-02</text>
      <text x="170" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">Consultoría Arquitectura de Integración</text>
      <text x="460" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">24</text>
      <text x="530" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">120.00</text>
      <text x="645" y="340" font-family="Arial, sans-serif" font-size="12" fill="#1e293b">2,880.00</text>

      <rect x="440" y="490" width="290" height="130" rx="8" fill="#f8fafc" stroke="#e2e8f0"/>
      <text x="460" y="520" font-family="Arial, sans-serif" font-size="13" fill="#475569">Subtotal:</text>
      <text x="640" y="520" font-family="Arial, sans-serif" font-size="13" font-weight="bold" fill="#0f172a">$6,655.00</text>
      <text x="460" y="555" font-family="Arial, sans-serif" font-size="13" fill="#475569">IVA Trasladado (16%):</text>
      <text x="640" y="555" font-family="Arial, sans-serif" font-size="13" font-weight="bold" fill="#0f172a">$1,064.80</text>
      <text x="460" y="605" font-family="Arial, sans-serif" font-size="15" font-weight="bold" fill="#1e1b4b">TOTAL A PAGAR:</text>
      <text x="630" y="605" font-family="Arial, sans-serif" font-size="16" font-weight="bold" fill="#4338ca">$7,719.80</text>
    </svg>`;

    // Document 2: Bank Wire Transfer Receipt complementing the invoice
    const bankTransferText = `COMPROBANTE ELECTRÓNICO DE PAGO Y TRANSFERENCIA INTERBANCARIA (SPEI / WIRE)
INSTITUCIÓN EMISORA: BBVA MÉXICO S.A.
FECHA Y HORA DE OPERACIÓN: 15 de Septiembre de 2026, 11:42:08 hrs
FOLIO / CLAVE DE RASTREO: BBVA-SPEI-2026-994120

DATOS DE LA CUENTA ORDENANTE:
- Empresa: Corporativo Global S.A. de C.V.
- Cuenta de Retiro: **** **** 4819
- Banco Emisor: BBVA México

DATOS DE LA CUENTA BENEFICIARIA:
- Beneficiario: Innova Tech Solutions S.A. de C.V.
- RFC Beneficiario: ITS180422K89
- Cuenta de Depósito (CLABE): 012180001234567890
- Banco Receptor: BBVA México

DETALLES DE LA LIQUIDACIÓN:
- Importe Transferido: $7,719.80 USD
- Concepto del Pago: Liquidacion Total Factura INV-2026-0894
- Referencia Numérica: 08942026
- Estado de la Transferencia: LIQUIDADA EXITOSAMENTE (Acreditado)
- Comisión Bancaria: $0.00 USD

FIRMA DIGITAL DE SEGURIDAD / HASH:
3a8f9c21b0e774d8129a03bc5510f4c9194e4128`;

    const doc1Base64 = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgInvoice)));
    const doc2Base64 = 'data:text/plain;base64,' + btoa(unescape(encodeURIComponent(bankTransferText)));

    setSelectedFiles([
      {
        id: 'demo-doc-1',
        name: 'Doc1_Factura_InnovaTech_INV-2026-0894.svg',
        type: 'image/svg+xml',
        size: 4200,
        data: doc1Base64,
        previewUrl: doc1Base64,
      },
      {
        id: 'demo-doc-2',
        name: 'Doc2_Comprobante_Pago_BBVA_SPEI_INV-0894.txt',
        type: 'text/plain',
        size: bankTransferText.length,
        data: doc2Base64,
      },
    ]);
    setError(null);
  };

  // Countdown timer for API quota reset
  useEffect(() => {
    if (countdownSeconds === null || countdownSeconds <= 0) return;
    const interval = setInterval(() => {
      setCountdownSeconds((prev) => {
        if (prev === null || prev <= 1) return null;
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [countdownSeconds]);

  // Helper to apply and persist extracted results across Firestore and Supabase
  const applyExtractionResult = (
    data: ExtractedDocumentData,
    modelUsed: string,
    failoverOccurred?: boolean
  ) => {
    setExtractedData(data);
    setActualModelUsed(modelUsed);
    if (failoverOccurred) {
      setFailoverNotice(
        `Failover Automático Activo: Procesado con éxito por Groq (${modelUsed}) para evitar límites de cuota.`
      );
    }
    setIsQuotaError(false);
    setCountdownSeconds(null);

    // --- PERSISTENCE LAYER: FIREBASE FIRESTORE & SUPABASE ---
    const extractionFilesName = selectedFiles.map((f) => f.name).join(', ') || 'Documento sin nombre';
    const totalBytes = selectedFiles.reduce((acc, f) => acc + (f.size || 0), 0);
    const fieldsCount = data.keyDataPoints?.length || 0;
    const tablesCount = data.sheetsData?.rows?.length ? 1 : 0;
    const summaryText = data.documentSummary?.slice(0, 500) || '';

    // 1. Save Extraction Record in Firebase Firestore (+ dual sync Supabase)
    saveExtractionRecord({
      userId: '',
      fileName: extractionFilesName,
      fileType: selectedFiles[0]?.type || 'document',
      provider: selectedProvider,
      modelUsed: modelUsed,
      summary: summaryText,
      fieldsCount,
      tablesCount,
      extractedData: JSON.stringify({
        summary: data.documentSummary,
        points: data.keyDataPoints,
        sheetsRows: data.sheetsData?.rows?.length || 0,
      }),
      status: 'completed',
    }).catch((e) => console.warn('Firebase save extraction error:', e));

    // 2. Save Document Metadata in Firebase Firestore (+ dual sync Supabase)
    saveDocumentMetadata({
      userId: '',
      fileName: extractionFilesName,
      fileSize: totalBytes,
      mimeType: selectedFiles[0]?.type || 'application/octet-stream',
      documentCategory: data.documentType || 'Análisis Documental',
      keyEntities: (data.keyDataPoints || []).slice(0, 6).map((k: any) => `${k.label}: ${k.value}`).join(' | '),
      sheetsExported: false,
      docsExported: false,
    }).catch((e) => console.warn('Firebase save metadata error:', e));

    // 3. Log Audit Event in Firebase Firestore
    logAuditEvent({
      actionType: 'doc_extraction',
      entityType: 'document',
      details: `Extracción completada para "${extractionFilesName}" usando modelo ${modelUsed} (${fieldsCount} campos, ${tablesCount} tabla)`,
      status: 'success',
    }).catch((e) => console.warn('Firebase log audit error:', e));

    setFirebaseStatusNotice('⚡ Registro guardado con éxito en base de datos Firebase Firestore.');

    // Refresh database tables
    refreshDatabaseData();

    // Automatically switch to appropriate tab
    if (extractionMode === 'docs') {
      setActiveResultTab('docs');
    } else {
      setActiveResultTab('sheets');
    }
  };

  // Perform Multi-Document Multimodal Document Analysis with optional Server-Sent Events (SSE) Streaming
  const handleAnalyzeDocument = async (overrideModel?: GeminiModelTier | React.MouseEvent | unknown) => {
    if (selectedFiles.length === 0) {
      setError('Por favor selecciona o sube al menos un documento o imagen.');
      return;
    }

    const validOverride = typeof overrideModel === 'string' ? (overrideModel as GeminiModelTier) : undefined;
    const modelToRequest = validOverride || selectedModel;
    if (validOverride) {
      setSelectedModel(validOverride);
    }

    setIsAnalyzing(true);
    setError(null);
    setIsQuotaError(false);
    setActionSuccessMessage(null);
    setFailoverNotice(null);

    const activeModel = selectedProvider === 'groq' ? selectedGroqModel : modelToRequest;
    const customGroqKey = localStorage.getItem('GROQ_CUSTOM_KEY')?.trim() || '';
    const requestPayload = {
      files: selectedFiles.map((f) => ({
        fileData: f.data,
        mimeType: f.type,
        fileName: f.name,
      })),
      fileData: selectedFiles[0]?.data,
      mimeType: selectedFiles[0]?.type,
      fileName: selectedFiles[0]?.name,
      provider: selectedProvider,
      extractionMode,
      customPrompt: customPrompt.trim() || undefined,
      enableThinking: selectedProvider === 'gemini' && enableThinking,
      model: activeModel,
      groqApiKey: customGroqKey || undefined,
    };

    const extractHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
    if (customGroqKey) {
      extractHeaders['x-groq-api-key'] = customGroqKey;
    }

    try {
      if (useStreaming) {
        setStreamProgress({
          phase: 'preparing',
          message: 'Conectando con el canal de Server-Sent Events (SSE)...',
          chunksCount: 0,
          charCount: 0,
          model: activeModel,
          provider: selectedProvider,
        });
        setStreamingRawText('');

        const response = await fetch('/api/analyze-document/stream', {
          method: 'POST',
          headers: extractHeaders,
          body: JSON.stringify(requestPayload),
        });

        if (!response.ok) {
          const errJson = await response.json().catch(() => ({}));
          if (response.status === 429 || errJson.isQuotaExceeded) {
            setIsQuotaError(true);
            if (errJson.retrySeconds) setCountdownSeconds(errJson.retrySeconds);
          }
          throw new Error(errJson.error || `Error al inicializar streaming (${response.statusText})`);
        }

        if (!response.body) {
          throw new Error('El navegador no recibió un flujo legible de eventos (ReadableStream).');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        let fullAccumulatedStreamText = '';
        let streamCompleted = false;
        let finalData: ExtractedDocumentData | null = null;
        let usedModelFromStream = activeModel;
        let failoverOccurred = false;
        let accumulatedChars = 0;
        let chunksTotal = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const parts = buffer.split('\n\n');
          buffer = parts.pop() || '';

          for (const part of parts) {
            if (!part.trim()) continue;
            const lines = part.split('\n');
            let event = 'message';
            let dataStr = '';

            for (const line of lines) {
              if (line.startsWith('event:')) {
                event = line.replace('event:', '').trim();
              } else if (line.startsWith('data:')) {
                dataStr = line.replace('data:', '').trim();
              }
            }

            if (!dataStr) continue;

            let payload: any = {};
            try {
              payload = JSON.parse(dataStr);
            } catch {
              continue;
            }

            if (event === 'status') {
              setStreamProgress((prev) => ({
                ...prev,
                phase: payload.phase || prev.phase,
                message: payload.message || prev.message,
                model: payload.model || prev.model,
                provider: payload.provider || prev.provider,
              }));
              if (payload.model) setActualModelUsed(payload.model);
              if (payload.phase === 'failover') failoverOccurred = true;
            } else if (event === 'chunk') {
              const delta = payload.delta || '';
              accumulatedChars += delta.length;
              chunksTotal = payload.chunkIndex || (chunksTotal + 1);
              fullAccumulatedStreamText += delta;

              setStreamingRawText((prev) => prev + delta);
              setStreamProgress((prev) => ({
                ...prev,
                phase: 'streaming',
                chunksCount: chunksTotal,
                charCount: accumulatedChars,
              }));
            } else if (event === 'complete') {
              streamCompleted = true;
              finalData = payload.data;
              if (payload.model) usedModelFromStream = payload.model;
              if (payload.provider === 'groq' && selectedProvider === 'gemini') {
                failoverOccurred = true;
              }
              setStreamProgress((prev) => ({
                ...prev,
                phase: 'complete',
                message: 'Extracción completada con éxito.',
                chunksCount: chunksTotal,
                charCount: accumulatedChars,
              }));
            } else if (event === 'error') {
              if (payload.isQuotaExceeded) {
                setIsQuotaError(true);
                if (payload.retrySeconds) setCountdownSeconds(payload.retrySeconds);
              }
              throw new Error(payload.error || 'Error en la transmisión de datos.');
            }
          }
        }

        if (!streamCompleted || !finalData) {
          if (fullAccumulatedStreamText) {
            try {
              finalData = JSON.parse(fullAccumulatedStreamText);
              streamCompleted = true;
            } catch {
              const match = fullAccumulatedStreamText.match(/\{[\s\S]*\}/);
              if (match) {
                try {
                  finalData = JSON.parse(match[0]);
                  streamCompleted = true;
                } catch {
                  // ignore
                }
              }
            }
          }
        }

        if (!streamCompleted || !finalData) {
          throw new Error('La transmisión concluyó sin devolver la estructura completa del documento.');
        }

        applyExtractionResult(finalData, usedModelFromStream, failoverOccurred);
      } else {
        // Standard non-streaming fallback
        const response = await fetch('/api/analyze-document', {
          method: 'POST',
          headers: extractHeaders,
          body: JSON.stringify(requestPayload),
        });

        if (!response.ok) {
          const errJson = await response.json().catch(() => ({}));
          if (response.status === 429 || errJson.isQuotaExceeded) {
            setIsQuotaError(true);
            if (errJson.retrySeconds) {
              setCountdownSeconds(errJson.retrySeconds);
            }
          }
          throw new Error(errJson.error || `Error en el análisis (${response.statusText})`);
        }

        const resData = await response.json();
        if (!resData.data) {
          throw new Error('La respuesta del modelo no contiene datos estructurados válidos.');
        }

        const usedModel = resData.model || activeModel;
        applyExtractionResult(resData.data, usedModel, resData.failoverOccurred);
      }
    } catch (err: any) {
      console.warn('Error analyzing document:', err?.message || err);
      setError(err?.message || 'Error al analizar los documentos.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // ---------------- EXPORT ACTIONS (GOOGLE DOCS & SHEETS) ----------------

  // 1. Create New Google Sheet
  const handleCreateNewSheet = () => {
    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }
    if (!extractedData?.sheetsData) return;

    const { title, headers, rows } = extractedData.sheetsData;
    const initialRows = [headers, ...(rows || [])];

    onRequestAction({
      id: 'create-sheet-extracted-' + Date.now(),
      type: 'sheets_create',
      title: 'Crear Google Sheet con Datos Extraídos',
      targetName: title || 'Datos Extraídos de Documento',
      details: [
        { label: 'Título de la Hoja', value: title || 'Extracción Documento' },
        { label: 'Columnas', value: headers },
        { label: 'Filas Extraídas', value: `${rows?.length || 0} filas de datos` },
      ],
      onConfirm: async () => {
        setIsExporting(true);
        try {
          const res = await createGoogleSheet(title || 'Datos Extraídos', initialRows);
          setActionSuccessMessage(`¡Hoja de cálculo creada exitosamente! Puedes abrirla en Google Sheets.`);
          logAuditEvent({
            actionType: 'google_sheet_created',
            entityType: 'spreadsheet',
            details: `Hoja de cálculo "${title || 'Datos Extraídos'}" creada en Google Sheets con ${rows?.length || 0} filas. ID: ${res.id}`,
            status: 'success',
          }).catch((e) => console.warn('Audit error:', e));
          // Refresh sheets list
          const updatedSheets = await listGoogleSheets();
          setUserSheets(updatedSheets);
          refreshDatabaseData();
        } catch (err: any) {
          setError(err?.message || 'Error al crear la hoja en Google Sheets');
        } finally {
          setIsExporting(false);
        }
      },
      onCancel: () => {},
    });
  };

  // 2. Append to Existing Google Sheet
  const handleAppendToExistingSheet = () => {
    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }
    if (!selectedSheetToAppend) {
      setError('Por favor selecciona una hoja de cálculo existente de destino.');
      return;
    }
    if (!extractedData?.sheetsData?.rows || extractedData.sheetsData.rows.length === 0) {
      setError('No hay filas de datos disponibles para insertar.');
      return;
    }

    const targetSheet = userSheets.find((s) => s.id === selectedSheetToAppend);
    const rowsToAppend = extractedData.sheetsData.rows;

    onRequestAction({
      id: 'append-sheet-extracted-' + Date.now(),
      type: 'sheets_append',
      title: 'Añadir Filas Extraídas a Google Sheet',
      targetName: targetSheet?.name || 'Google Sheet',
      targetId: selectedSheetToAppend,
      details: [
        { label: 'Hoja de Destino', value: targetSheet?.name || 'Hoja Seleccionada' },
        { label: 'Número de Filas', value: `${rowsToAppend.length} filas` },
        { label: 'Primer Registro', value: (rowsToAppend[0] || []).map(String) },
      ],
      onConfirm: async () => {
        setIsExporting(true);
        try {
          await appendSpreadsheetRows(selectedSheetToAppend, rowsToAppend);
          setActionSuccessMessage(`¡Se añadieron ${rowsToAppend.length} filas correctamente a "${targetSheet?.name}"!`);
          logAuditEvent({
            actionType: 'google_sheet_appended',
            entityType: 'spreadsheet',
            details: `Añadidas ${rowsToAppend.length} filas a la hoja "${targetSheet?.name}" (ID: ${selectedSheetToAppend})`,
            status: 'success',
          }).catch((e) => console.warn('Audit error:', e));
          refreshDatabaseData();
        } catch (err: any) {
          setError(err?.message || 'Error al agregar filas a la hoja de Google Sheets');
        } finally {
          setIsExporting(false);
        }
      },
      onCancel: () => {},
    });
  };

  // 3. Create New Google Doc
  const handleCreateNewDoc = () => {
    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }
    if (!extractedData?.docsContent) return;

    const { title, formattedText } = extractedData.docsContent;

    onRequestAction({
      id: 'create-doc-extracted-' + Date.now(),
      type: 'docs_create',
      title: 'Crear Google Doc con Informe Estructurado',
      targetName: title || 'Informe Extraído',
      details: [
        { label: 'Título del Documento', value: title || 'Informe Extraído' },
        { label: 'Extensión', value: `${formattedText.length} caracteres` },
      ],
      onConfirm: async () => {
        setIsExporting(true);
        try {
          const res = await createGoogleDoc(title || 'Informe Extraído', formattedText);
          setActionSuccessMessage(`¡Documento creado exitosamente! Puedes consultarlo y editarlo en Google Docs.`);
          logAuditEvent({
            actionType: 'google_doc_created',
            entityType: 'document',
            details: `Documento Google Docs "${title || 'Informe Extraído'}" creado con ${formattedText.length} caracteres. ID: ${res.id}`,
            status: 'success',
          }).catch((e) => console.warn('Audit error:', e));
          const updatedDocs = await listGoogleDocs();
          setUserDocs(updatedDocs);
          refreshDatabaseData();
        } catch (err: any) {
          setError(err?.message || 'Error al crear el documento en Google Docs');
        } finally {
          setIsExporting(false);
        }
      },
      onCancel: () => {},
    });
  };

  // 4. Append to Existing Google Doc
  const handleAppendToExistingDoc = () => {
    if (!isAuthenticated) {
      onPromptLogin();
      return;
    }
    if (!selectedDocToAppend) {
      setError('Por favor selecciona un Google Doc existente de destino.');
      return;
    }
    if (!extractedData?.docsContent?.formattedText) return;

    const targetDoc = userDocs.find((d) => d.id === selectedDocToAppend);
    const textToAppend = extractedData.docsContent.formattedText;

    onRequestAction({
      id: 'append-doc-extracted-' + Date.now(),
      type: 'docs_append',
      title: 'Añadir Contenido a Google Doc Existente',
      targetName: targetDoc?.name || 'Google Doc',
      targetId: selectedDocToAppend,
      details: [
        { label: 'Documento de Destino', value: targetDoc?.name || 'Doc Seleccionado' },
        { label: 'Sección a Insertar', value: `${textToAppend.slice(0, 120)}...` },
      ],
      onConfirm: async () => {
        setIsExporting(true);
        try {
          await appendToGoogleDoc(selectedDocToAppend, textToAppend);
          setActionSuccessMessage(`¡Contenido añadido exitosamente a "${targetDoc?.name}"!`);
          logAuditEvent({
            actionType: 'google_doc_appended',
            entityType: 'document',
            details: `Contenido añadido al documento Google Docs "${targetDoc?.name}" (ID: ${selectedDocToAppend})`,
            status: 'success',
          }).catch((e) => console.warn('Audit error:', e));
          refreshDatabaseData();
        } catch (err: any) {
          setError(err?.message || 'Error al agregar contenido al Google Doc');
        } finally {
          setIsExporting(false);
        }
      },
      onCancel: () => {},
    });
  };

  // 5. Download CSV
  const handleDownloadCsv = () => {
    if (!extractedData?.sheetsData) return;
    const { title, headers, rows } = extractedData.sheetsData;
    const allRows = [headers, ...(rows || [])];
    const csvContent = allRows
      .map((row) =>
        row
          .map((cell) => {
            const str = String(cell ?? '').replace(/"/g, '""');
            return `"${str}"`;
          })
          .join(',')
      )
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${(title || 'datos_extraidos').replace(/\s+/g, '_')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // 7. Copy TSV for Excel / Sheets
  const handleCopyTsv = async () => {
    if (!extractedData?.sheetsData) return;
    const { headers, rows } = extractedData.sheetsData;
    const allRows = [headers, ...(rows || [])];
    const tsvContent = allRows.map((r) => r.map((c) => String(c ?? '')).join('\t')).join('\n');

    try {
      await navigator.clipboard.writeText(tsvContent);
      setCopiedSection('tsv');
      setTimeout(() => setCopiedSection(null), 2000);
    } catch {
      // ignore
    }
  };

  // Restore previous extraction from Firebase Firestore
  const handleLoadPreviousExtraction = (rec: ExtractionRecord) => {
    try {
      const parsed = rec.extractedData ? JSON.parse(rec.extractedData) : null;
      setExtractedData({
        documentSummary: rec.summary || 'Sin resumen registrado',
        documentType: rec.fileType || 'Documento Histórico',
        keyDataPoints: parsed?.points || [],
        sheetsData: {
          title: rec.fileName || 'Extracción Recuperada',
          headers: ['Métrica / Campo', 'Valor Extraído'],
          rows: (parsed?.points || []).map((p: any) => [p.label, p.value]),
        },
        docsContent: {
          title: rec.fileName || 'Documento Recuperado',
          formattedText: rec.summary || '',
          markdown: `# ${rec.fileName}\n\n${rec.summary || ''}`,
        },
        suggestedActions: parsed?.suggestedActions || [],
      });
      setActiveResultTab('sheets');
      setActionSuccessMessage(`Extracción restaurada desde Firebase: "${rec.fileName}"`);
    } catch (e: any) {
      console.warn('Error loading extraction record:', e?.message || e);
    }
  };

  // Delete extraction from Firebase Firestore
  const handleDeletePreviousExtraction = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await deleteExtractionRecord(id);
      await refreshDatabaseData();
      setActionSuccessMessage('Registro eliminado de Firebase exitosamente.');
    } catch (err: any) {
      setError(err?.message || 'Error al eliminar el registro de Firebase');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Studio Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Multimodal Vision & Document Intelligence (Gemini 3.8 Flash)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              Lector de Imágenes y Documentos Complejos
            </h1>
            <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
              Sube facturas, contratos, recibos de gastos, estados de cuenta, fotos de pizarras o tablas en PDF e imágenes. La IA extraerá los datos y te permitirá acomodarlos directamente en tus hojas de <strong>Google Sheets</strong> o informes de <strong>Google Docs</strong> con un solo clic.
            </p>
          </div>
        </div>

        {/* Global Notifications */}
        {error && (
          <div className="mt-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs shadow-xs space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold block text-sm">
                    {isQuotaError
                      ? 'Límite de cuota o peticiones en el modelo actual (429)'
                      : 'Error en el procesamiento'}
                  </span>
                  <p className="text-xs text-amber-800 leading-relaxed">{error}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setError(null)}
                className="text-amber-600 hover:text-amber-800 font-bold text-xs p-1 cursor-pointer"
              >
                Cerrar
              </button>
            </div>

            {/* Quick resolution controls if 429 quota reached */}
            {isQuotaError && (
              <div className="pt-2 border-t border-amber-200/80 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleAnalyzeDocument('gemini-3.1-flash-lite')}
                  className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Extraer con Gemini 3.1 Flash Lite (Alta Disponibilidad)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAnalyzeDocument('gemini-3.8-flash')}
                  className="px-3 py-1.5 rounded-lg bg-white border border-amber-300 hover:bg-amber-100/50 text-amber-900 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span>Reintentar con 3.8 Flash</span>
                </button>

                {countdownSeconds !== null && countdownSeconds > 0 && (
                  <span className="text-[11px] text-amber-700 font-medium ml-auto">
                    Espera sugerida: <strong>{countdownSeconds}s</strong>
                  </span>
                )}
              </div>
            )}

            {/* Quick resolution controls if Groq limits blocked error */}
            {error && error.includes('console.groq.com/settings/limits') && (
              <div className="pt-2 border-t border-amber-200/80 flex flex-wrap items-center gap-2">
                <a
                  href="https://console.groq.com/settings/limits"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Habilitar Modelos en Groq</span>
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedProvider('gemini');
                    setError(null);
                    handleAnalyzeDocument('gemini-3.8-flash');
                  }}
                  className="px-3 py-1.5 rounded-lg bg-white border border-amber-300 hover:bg-amber-100/50 text-amber-900 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>Conmutar a Google Gemini 3.8 Flash</span>
                </button>
              </div>
            )}
          </div>
        )}

        {actionSuccessMessage && (
          <div className="mt-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionSuccessMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setActionSuccessMessage(null)}
              className="text-emerald-600 hover:text-emerald-800 font-bold text-xs"
            >
              Cerrar
            </button>
          </div>
        )}
      </div>

      {/* Main Grid: Upload & Controls on Left, Results on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Upload & Options (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Drag & Drop Multi-Document Upload Zone */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Upload className="w-4 h-4 text-blue-600" />
                <h2 className="text-sm font-bold text-slate-900">
                  Subir Documentos o Imágenes
                </h2>
                {selectedFiles.length > 0 && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                    {selectedFiles.length} {selectedFiles.length === 1 ? 'doc' : 'docs'}
                  </span>
                )}
              </div>
              {selectedFiles.length > 0 && (
                <button
                  type="button"
                  onClick={clearAllFiles}
                  className="text-xs text-rose-600 hover:text-rose-700 font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                  Limpiar todo
                </button>
              )}
            </div>

            {/* Drop Box & File List */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-5 text-center transition-all ${
                isDragging
                  ? 'border-blue-500 bg-blue-50/50 scale-[0.99]'
                  : 'border-slate-300 bg-slate-50/50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,application/pdf,text/plain,text/csv,text/markdown,application/json"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFilesProcess(e.target.files);
                    e.target.value = '';
                  }
                }}
                className="hidden"
              />

              {selectedFiles.length === 0 ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="space-y-3 py-4 cursor-pointer hover:opacity-90"
                >
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto border border-blue-100 shadow-2xs">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-700">
                      Arrastra uno o varios documentos aquí o haz clic para explorar
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                      Puedes subir múltiples archivos a la vez (facturas, contratos, comprobantes bancarios) para complementarlos y cruzarlos.
                    </p>
                  </div>
                  <span className="inline-block text-[11px] text-blue-600 font-semibold bg-white px-3 py-1 rounded-full border border-blue-200 shadow-2xs">
                    Formatos: PDF, JPG, PNG, WEBP, CSV, TXT (hasta 8 archivos)
                  </span>
                </div>
              ) : (
                <div className="space-y-3 text-left">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-200">
                    <span className="text-[11px] font-bold text-slate-600">
                      Documentos en cola ({selectedFiles.length}/8):
                    </span>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      Añadir más
                    </button>
                  </div>

                  <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
                    {selectedFiles.map((f, idx) => (
                      <div
                        key={f.id}
                        className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200 shadow-2xs hover:border-blue-200 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 overflow-hidden">
                          {f.previewUrl ? (
                            <img
                              src={f.previewUrl}
                              alt={f.name}
                              className="w-8 h-8 rounded-md object-cover border border-slate-200 shrink-0"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-md bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 border border-blue-100">
                              <FileText className="w-4 h-4" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-slate-800 truncate max-w-[190px]">
                              {idx + 1}. {f.name}
                            </p>
                            <p className="text-[10px] text-slate-400">
                              {(f.size / 1024).toFixed(1)} KB • {f.type.split('/')[1] || 'doc'}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeFile(f.id)}
                          title="Quitar este documento"
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="p-2 rounded-lg bg-blue-50/70 border border-blue-100 flex items-start gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <p className="text-[10px] text-blue-900 leading-tight">
                      <strong>Síntesis Complementaria:</strong> La IA correlacionará los datos de todos los documentos cargados (ej. cotejará montos de factura con comprobantes de pago o consolidará múltiples anexos).
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Demo Samples */}
            <div className="pt-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                O prueba con ejemplos precargados:
              </span>
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={loadMultiDocDemo}
                  className="w-full p-2.5 rounded-xl border border-indigo-200 hover:border-indigo-400 bg-indigo-50/60 hover:bg-indigo-50 text-left transition-colors cursor-pointer group shadow-2xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-1 rounded-md bg-indigo-600 text-white">
                        <Layers className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-xs font-bold text-indigo-950 group-hover:text-indigo-800">
                        🔗 Cargar 2 Documentos: Factura + Comprobante BBVA
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-200 text-indigo-800">
                      2 Docs
                    </span>
                  </div>
                  <p className="text-[10px] text-indigo-700 mt-1">
                    Carga simultáneamente una factura fiscal y el recibo bancario de transferencia para verificar la conciliación cruzada de datos.
                  </p>
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={loadSampleReceipt}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-blue-300 bg-slate-50 hover:bg-blue-50/50 text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-2">
                      <Table className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-xs font-semibold text-slate-800 group-hover:text-blue-700">
                        Factura Comercial
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Tabla de 4 ítems con precios e IVA.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={loadSampleContract}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-purple-300 bg-slate-50 hover:bg-purple-50/50 text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-purple-600 shrink-0" />
                      <span className="text-xs font-semibold text-slate-800 group-hover:text-purple-700">
                        Contrato Legal (NDA)
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Cláusulas y montos de honorarios.
                    </p>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Extraction Mode & Engine Configuration */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-slate-600" />
              Configuración de Extracción y Modelo
            </h2>

            {/* Destination Mode Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 block">
                Modo de Organización:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setExtractionMode('hybrid')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    extractionMode === 'hybrid'
                      ? 'border-blue-600 bg-blue-50/80 text-blue-900 font-bold shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600 text-xs'
                  }`}
                >
                  <Layers className="w-4 h-4 mx-auto mb-1 text-blue-600" />
                  <span className="text-[11px] block">Híbrido</span>
                  <span className="text-[9px] text-slate-400 block">Sheets + Docs</span>
                </button>

                <button
                  type="button"
                  onClick={() => setExtractionMode('sheets')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    extractionMode === 'sheets'
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 font-bold shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600 text-xs'
                  }`}
                >
                  <Table className="w-4 h-4 mx-auto mb-1 text-emerald-600" />
                  <span className="text-[11px] block">Google Sheets</span>
                  <span className="text-[9px] text-slate-400 block">Solo Tablas</span>
                </button>

                <button
                  type="button"
                  onClick={() => setExtractionMode('docs')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    extractionMode === 'docs'
                      ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600 text-xs'
                  }`}
                >
                  <FileText className="w-4 h-4 mx-auto mb-1 text-indigo-600" />
                  <span className="text-[11px] block">Google Docs</span>
                  <span className="text-[9px] text-slate-400 block">Informe/Texto</span>
                </button>
              </div>
            </div>

            {/* Provider Selector: Gemini vs Groq */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <label className="text-xs font-semibold text-slate-700 block">
                Motor de Inteligencia Artificial:
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedProvider('gemini');
                    setError(null);
                  }}
                  className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedProvider === 'gemini'
                      ? 'border-blue-600 bg-blue-50/70 shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span className="text-xs font-bold text-slate-900">Google Gemini</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Multimodal Nativo</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedProvider('groq');
                    setError(null);
                  }}
                  className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedProvider === 'groq'
                      ? 'border-amber-600 bg-amber-50/70 shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="text-xs font-bold text-slate-900">Groq LPU (Ultra Rápido)</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Sin límite de cuota</span>
                </button>
              </div>
            </div>

            {/* Model Selector based on provider */}
            {selectedProvider === 'gemini' ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 block">
                    Modelo Gemini:
                  </label>
                  {actualModelUsed && (
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 font-medium">
                      Activo: {actualModelUsed}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedModel('gemini-flash-latest');
                      setError(null);
                    }}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedModel === 'gemini-flash-latest'
                        ? 'border-blue-600 bg-blue-50/60 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span className="text-xs font-bold text-slate-900">Flash Latest</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Versión Actual</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedModel('gemini-3.1-flash-lite');
                      setError(null);
                    }}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedModel === 'gemini-3.1-flash-lite'
                        ? 'border-amber-600 bg-amber-50/60 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span className="text-xs font-bold text-slate-900">3.1 Lite</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Máxima Cuota</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedModel('gemini-3.8-flash');
                      setError(null);
                    }}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedModel === 'gemini-3.8-flash'
                        ? 'border-purple-600 bg-purple-50/60 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <Brain className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                      <span className="text-xs font-bold text-slate-900">3.8 Flash</span>
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Visión Max</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 block">
                    Modelo Groq LPU:
                  </label>
                  <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 font-medium">
                    Inferencia a ~800 tokens/s
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedGroqModel('llama-3.3-70b-versatile')}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedGroqModel === 'llama-3.3-70b-versatile'
                        ? 'border-amber-600 bg-amber-50/70 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-900 block truncate">70B Versatile</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Máximo poder</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedGroqModel('llama-3.1-8b-instant')}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedGroqModel === 'llama-3.1-8b-instant'
                        ? 'border-amber-600 bg-amber-50/70 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-900 block truncate">8B Instant</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Ultra rápido</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedGroqModel('llama-3.2-11b-vision-preview')}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedGroqModel === 'llama-3.2-11b-vision-preview'
                        ? 'border-amber-600 bg-amber-50/70 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-900 block truncate">11B Vision</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Multimodal</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedGroqModel('openai/gpt-oss-120b')}
                    className={`p-2 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedGroqModel === 'openai/gpt-oss-120b'
                        ? 'border-amber-600 bg-amber-50/70 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-900 block truncate">GPT-OSS 120B</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Open Source</span>
                  </button>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                  <span>Con conmutación por error automática ante cuotas o límites de modelos.</span>
                  <a
                    href="https://console.groq.com/settings/limits"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-700 hover:underline font-medium"
                  >
                    Ver límites en Groq ↗
                  </a>
                </div>
              </div>
            )}

            {/* Custom Prompt */}
            <div className="space-y-1.5">
              <label htmlFor="custom-prompt-input" className="text-xs font-semibold text-slate-700 block">
                Instrucciones específicas (Opcional):
              </label>
              <textarea
                id="custom-prompt-input"
                rows={2}
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="Ej. Concilia las fechas y montos entre los documentos, o extrae solo ítems no liquidados..."
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-hidden resize-none"
              />
            </div>

            {/* Thinking Mode Toggle (Gemini only) */}
            {selectedProvider === 'gemini' && (
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-slate-800 block">
                    Razonamiento Profundo (Thinking)
                  </span>
                  <span className="text-[11px] text-slate-400 block">
                    Para contratos complejos o cálculos matemáticos cruzados.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setEnableThinking(!enableThinking)}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                    enableThinking ? 'bg-blue-600' : 'bg-slate-200'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                      enableThinking ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            )}

            {/* Server-Sent Events (SSE) Streaming Toggle */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <Radio className={`w-3.5 h-3.5 ${useStreaming ? 'text-emerald-600 animate-pulse' : 'text-slate-400'}`} />
                  <span className="text-xs font-semibold text-slate-800">
                    Extracción Progresiva (SSE Streaming)
                  </span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full font-bold bg-emerald-100 text-emerald-800">
                    En Vivo
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 block">
                  Transmite tokens y avance en tiempo real con generateContentStream.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setUseStreaming(!useStreaming)}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  useStreaming ? 'bg-emerald-600' : 'bg-slate-200'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    useStreaming ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Failover Notice Banner */}
            {failoverNotice && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{failoverNotice}</span>
              </div>
            )}

            {/* Execute Button */}
            <button
              id="btn-analyze-document"
              type="button"
              disabled={selectedFiles.length === 0 || isAnalyzing}
              onClick={() => handleAnalyzeDocument()}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>
                    Analizando {selectedFiles.length > 1 ? `${selectedFiles.length} documentos y cruzando datos` : 'documento'}...
                  </span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {selectedFiles.length > 1
                      ? `⚡ Extraer y Complementar ${selectedFiles.length} Documentos a la vez`
                      : 'Procesar y Extraer Información'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Extracted Results, Direct Workspace Actions & Database Hub (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Top Status Notification */}
          {firebaseStatusNotice && (
            <div className="p-3.5 rounded-2xl bg-purple-50 border border-purple-200 text-purple-950 text-xs flex items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
                <span className="font-medium">{firebaseStatusNotice}</span>
              </div>
              <button
                type="button"
                onClick={() => setFirebaseStatusNotice(null)}
                className="text-purple-600 hover:text-purple-900 font-bold px-2 py-0.5 rounded-lg hover:bg-purple-100 transition-colors"
              >
                ✕
              </button>
            </div>
          )}

          {/* Top View Selector: Extracción | Firebase & Auditoría */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-2 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setActiveResultTab(extractedData ? (extractionMode === 'docs' ? 'docs' : 'sheets') : 'sheets')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeResultTab === 'sheets' || activeResultTab === 'docs' || activeResultTab === 'summary'
                    ? 'bg-blue-50 text-blue-900 border border-blue-200'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span>Extracción Actual</span>
                {extractedData && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveResultTab('firebase');
                  refreshDatabaseData();
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeResultTab === 'firebase'
                    ? 'bg-amber-50 text-amber-900 border border-amber-300 shadow-xs'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Database className="w-3.5 h-3.5 text-amber-600" />
                <span>Firebase & Auditoría</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-900 font-semibold">
                  {extractionHistory.length + auditLogs.length}
                </span>
              </button>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={refreshDatabaseData}
                title="Sincronizar base de datos"
                className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDatabase ? 'animate-spin text-blue-600' : ''}`} />
              </button>
            </div>
          </div>

          {/* VIEW 1: FIREBASE & AUDIT LOGS DATABASE VIEW */}
          {activeResultTab === 'firebase' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-6 p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                      Firebase Cloud Database
                    </span>
                    <span className="text-slate-400 text-xs">•</span>
                    <span className="text-xs text-slate-500 font-mono">firestore: extractions, audit, metadata</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">
                    Historial de Extracciones, Auditoría y Metadatos
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={refreshDatabaseData}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingDatabase ? 'animate-spin' : ''}`} />
                    <span>Actualizar</span>
                  </button>
                </div>
              </div>

              {/* Sub-Tabs: Extracciones, Metadatos, Auditoría */}
              <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
                <button
                  type="button"
                  onClick={() => setDatabaseSubTab('extractions')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                    databaseSubTab === 'extractions'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Historial de Extracciones ({extractionHistory.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDatabaseSubTab('metadata')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                    databaseSubTab === 'metadata'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Metadatos Documentales ({documentMetadataList.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDatabaseSubTab('audit')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                    databaseSubTab === 'audit'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  <span>Logs de Auditoría Inmutables ({auditLogs.length})</span>
                </button>
              </div>

              {/* Sub-Tab 1: Extractions History */}
              {databaseSubTab === 'extractions' && (
                <div className="space-y-3">
                  {extractionHistory.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-xl">
                      Aún no hay extracciones guardadas en la base de datos. Analiza un documento para registrarlo automáticamente.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {extractionHistory.map((rec) => (
                        <div
                          key={rec.id}
                          onClick={() => handleLoadPreviousExtraction(rec)}
                          className="p-3.5 rounded-xl border border-slate-200 hover:border-amber-400 bg-slate-50/50 hover:bg-amber-50/20 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-slate-900">{rec.fileName}</span>
                              <span className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 text-[10px] uppercase font-bold font-mono">
                                {rec.modelUsed}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {new Date(rec.createdAt).toLocaleString()}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 line-clamp-1">
                              {rec.summary || 'Sin resumen registrado'}
                            </p>
                            <div className="flex items-center gap-3 text-[11px] text-slate-500">
                              <span>Campos extraídos: <strong>{rec.fieldsCount}</strong></span>
                              <span>Tablas: <strong>{rec.tablesCount}</strong></span>
                              <span>Proveedor: <strong className="capitalize">{rec.provider}</strong></span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleLoadPreviousExtraction(rec);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-amber-600 text-white text-xs font-semibold hover:bg-amber-700"
                            >
                              Restaurar
                            </button>
                            <button
                              type="button"
                              onClick={(e) => handleDeletePreviousExtraction(rec.id, e)}
                              className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50"
                              title="Eliminar de Firestore"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Sub-Tab 2: Document Metadata */}
              {databaseSubTab === 'metadata' && (
                <div className="space-y-3">
                  {documentMetadataList.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-xl">
                      Aún no hay metadatos registrados. Cada documento procesado creará una entrada indexada aquí.
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100/75 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                          <tr>
                            <th className="p-3">Nombre del Archivo</th>
                            <th className="p-3">Categoría</th>
                            <th className="p-3">Tamaño</th>
                            <th className="p-3">Tipo MIME</th>
                            <th className="p-3">Entidades Clave</th>
                            <th className="p-3">Sincronización</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                          {documentMetadataList.map((m) => (
                            <tr key={m.id} className="hover:bg-slate-50/80">
                              <td className="p-3 font-semibold text-slate-900 font-sans">{m.fileName}</td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-sans">
                                  {m.documentCategory}
                                </span>
                              </td>
                              <td className="p-3 text-slate-500">{(m.fileSize / 1024).toFixed(1)} KB</td>
                              <td className="p-3 text-slate-500">{m.mimeType}</td>
                              <td className="p-3 text-slate-700 max-w-xs truncate font-sans" title={m.keyEntities}>
                                {m.keyEntities || '—'}
                              </td>
                              <td className="p-3 font-sans">
                                <div className="flex items-center gap-1.5 text-[10px]">
                                  <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-semibold">
                                    Firestore
                                  </span>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* Sub-Tab 3: Immutable Audit Logs */}
              {databaseSubTab === 'audit' && (
                <div className="space-y-3">
                  {auditLogs.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-xl">
                      No hay registros de auditoría aún. Las operaciones de lectura, creación y guardado se auditan automáticamente.
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100/75 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                          <tr>
                            <th className="p-3">Fecha y Hora</th>
                            <th className="p-3">Acción</th>
                            <th className="p-3">Estado</th>
                            <th className="p-3">Detalles de Operación</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-[11px]">
                          {auditLogs.map((log) => (
                            <tr key={log.id} className="hover:bg-slate-50/80">
                              <td className="p-3 font-mono text-slate-500 whitespace-nowrap">
                                {new Date(log.timestamp).toLocaleString()}
                              </td>
                              <td className="p-3 whitespace-nowrap">
                                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-800 font-bold text-[10px] uppercase font-mono">
                                  {log.actionType}
                                </span>
                              </td>
                              <td className="p-3 whitespace-nowrap">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  log.status === 'success'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-red-100 text-red-800'
                                }`}>
                                  {log.status === 'success' ? 'Éxito' : 'Error'}
                                </span>
                              </td>
                              <td className="p-3 text-slate-700 max-w-md break-words">
                                {log.details}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* VIEW 2: ACTIVE EXTRACTION RESULTS, LIVE SSE STREAMING OR EMPTY STATE */}
          {(activeResultTab === 'sheets' || activeResultTab === 'docs' || activeResultTab === 'summary') && (
            isAnalyzing ? (
              /* Live Real-Time Server-Sent Events (SSE) Streaming Dashboard */
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-6">
                {/* Header with Live Streaming Badge */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-5 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-2xs">
                      <Radio className="w-5 h-5 animate-pulse" />
                      <span className="absolute -top-1 -right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                      </span>
                    </div>
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-slate-900">
                          Extracción Progresiva en Tiempo Real
                        </h3>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                          SSE STREAM
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">
                        {streamProgress.message || 'Procesando documentos con IA multimodal y transmitiendo tokens en directo...'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-xl bg-slate-100 text-slate-700 text-xs font-mono font-bold flex items-center gap-1.5 border border-slate-200">
                      <Activity className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
                      <span>{actualModelUsed || streamProgress.model || selectedModel}</span>
                    </span>
                  </div>
                </div>

                {/* 4-Step Progressive Extraction Phases Tracker */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                  {/* Phase 1 */}
                  <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-bold text-emerald-950 block">1. Documentos</span>
                      <span className="text-[11px] text-emerald-800">
                        {selectedFiles.length} archivo(s) listos
                      </span>
                    </div>
                  </div>

                  {/* Phase 2 */}
                  <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                    streamProgress.phase !== 'idle'
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                      : 'bg-slate-50 border-slate-200 text-slate-500'
                  }`}>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-bold block">2. Conexión SSE</span>
                      <span className="text-[11px]">Canal establecido</span>
                    </div>
                  </div>

                  {/* Phase 3 */}
                  <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                    streamProgress.phase === 'streaming'
                      ? 'bg-blue-50 border-blue-300 text-blue-950 shadow-xs ring-2 ring-blue-100'
                      : streamProgress.phase === 'parsing' || streamProgress.phase === 'complete'
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                      : 'bg-slate-50 border-slate-200 text-slate-500'
                  }`}>
                    {streamProgress.phase === 'streaming' ? (
                      <RefreshCw className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
                    ) : streamProgress.phase === 'parsing' || streamProgress.phase === 'complete' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-slate-300 shrink-0" />
                    )}
                    <div>
                      <span className="font-bold block">3. Tokens Stream</span>
                      <span className="text-[11px]">
                        {streamProgress.chunksCount || 0} paquetes
                      </span>
                    </div>
                  </div>

                  {/* Phase 4 */}
                  <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                    streamProgress.phase === 'parsing'
                      ? 'bg-purple-50 border-purple-300 text-purple-950 ring-2 ring-purple-100'
                      : streamProgress.phase === 'complete'
                      ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                      : 'bg-slate-50 border-slate-200 text-slate-500'
                  }`}>
                    {streamProgress.phase === 'parsing' ? (
                      <RefreshCw className="w-4 h-4 text-purple-600 animate-spin shrink-0" />
                    ) : streamProgress.phase === 'complete' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-slate-300 shrink-0" />
                    )}
                    <div>
                      <span className="font-bold block">4. Tablas y Docs</span>
                      <span className="text-[11px]">Estructurando</span>
                    </div>
                  </div>
                </div>

                {/* Live Stream Terminal View */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-slate-600" />
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Flujo de Datos Recibido en Directo
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md font-medium">
                      {(streamProgress.charCount || 0).toLocaleString()} caracteres transmitidos
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950 text-slate-100 font-mono text-xs max-h-72 overflow-y-auto leading-relaxed border border-slate-800 shadow-inner">
                    <div className="flex items-center gap-1.5 pb-2 mb-2 border-b border-slate-800/80 text-[10px] text-slate-500">
                      <span className="w-2 h-2 rounded-full bg-rose-500/80"></span>
                      <span className="w-2 h-2 rounded-full bg-amber-500/80"></span>
                      <span className="w-2 h-2 rounded-full bg-emerald-500/80"></span>
                      <span className="ml-2 font-sans font-medium text-slate-400">
                        stream: event: chunk • text/event-stream
                      </span>
                    </div>
                    {streamingRawText ? (
                      <div className="space-y-1">
                        <pre className="whitespace-pre-wrap break-all text-emerald-400 font-mono text-[11px] leading-relaxed">
                          {streamingRawText}
                        </pre>
                        <span className="inline-block w-2 h-4 bg-emerald-400 animate-pulse align-middle ml-1" />
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-10 text-slate-500 text-xs">
                        <RefreshCw className="w-4 h-4 animate-spin mr-2 text-emerald-500" />
                        <span>Recibiendo primeros tokens del modelo en tiempo real...</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : extractedData ? (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              {/* Top Result Banner */}
              <div className="p-6 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-blue-500/30 text-blue-200 border border-blue-400/30 text-[10px] font-bold">
                      {extractedData.documentType || 'Documento Extraído'}
                    </span>
                    <span className="text-slate-400 text-xs">•</span>
                    <span className="text-[11px] text-slate-300">
                      {extractedData.sheetsData?.rows?.length || 0} filas tabulares identificadas
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white">
                    {extractedData.docsContent?.title || 'Extracción Completada'}
                  </h3>
                </div>
              </div>

              {/* Navigation Tabs for Results */}
              <div className="flex border-b border-slate-200 bg-slate-50/50 px-6 pt-3 gap-2">
                <button
                  type="button"
                  onClick={() => setActiveResultTab('sheets')}
                  className={`pb-3 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                    activeResultTab === 'sheets'
                      ? 'border-emerald-600 text-emerald-800'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Table className="w-4 h-4 text-emerald-600" />
                  <span>Para Google Sheets</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-normal">
                    {extractedData.sheetsData?.rows?.length || 0} filas
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveResultTab('docs')}
                  className={`pb-3 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                    activeResultTab === 'docs'
                      ? 'border-blue-600 text-blue-800'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span>Para Google Docs</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveResultTab('summary')}
                  className={`pb-3 px-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
                    activeResultTab === 'summary'
                      ? 'border-indigo-600 text-indigo-800'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Eye className="w-4 h-4 text-indigo-600" />
                  <span>Resumen y Claves</span>
                </button>
              </div>

              {/* TAB 1: GOOGLE SHEETS */}
              {activeResultTab === 'sheets' && (
                <div className="p-6 space-y-6">
                  {/* Action Bar for Sheets */}
                  <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <span className="font-bold text-xs text-emerald-950 block">
                          Acomodar en Google Sheets
                        </span>
                        <span className="text-[11px] text-emerald-700">
                          {isAuthenticated
                            ? 'Selecciona crear una hoja nueva o añadir los registros a una existente.'
                            : 'Inicia sesión en Google Workspace para insertar directamente.'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleCopyTsv}
                          className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                        >
                          {copiedSection === 'tsv' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                          {copiedSection === 'tsv' ? '¡Copiado!' : 'Copiar TSV'}
                        </button>

                        <button
                          type="button"
                          onClick={handleDownloadCsv}
                          className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                        >
                          <Download className="w-3 h-3 text-slate-500" />
                          <span>Descargar .CSV</span>
                        </button>
                      </div>
                    </div>

                    {/* Direct Insertion Buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      {/* Option A: Create New Sheet */}
                      <button
                        type="button"
                        disabled={isExporting}
                        onClick={handleCreateNewSheet}
                        className="py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Crear en Nueva Google Sheet</span>
                      </button>

                      {/* Option B: Append to Existing Sheet */}
                      <div className="flex items-center gap-1.5">
                        <select
                          value={selectedSheetToAppend}
                          onChange={(e) => setSelectedSheetToAppend(e.target.value)}
                          className="flex-1 text-xs p-2 rounded-xl border border-emerald-300 bg-white text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 truncate"
                        >
                          {userSheets.length === 0 ? (
                            <option value="">(Sin hojas cargadas)</option>
                          ) : (
                            userSheets.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))
                          )}
                        </select>
                        <button
                          type="button"
                          disabled={isExporting || userSheets.length === 0}
                          onClick={handleAppendToExistingSheet}
                          className="py-2 px-3 rounded-xl bg-white hover:bg-emerald-100 border border-emerald-300 text-emerald-900 font-semibold text-xs transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                        >
                          Añadir Filas
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Extracted Table Preview */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="font-semibold text-slate-700">
                        Tabla Generada: "{extractedData.sheetsData?.title || 'Extracción'}"
                      </span>
                      <span>{extractedData.sheetsData?.rows?.length || 0} registros</span>
                    </div>

                    <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-96 shadow-2xs">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-slate-100 text-slate-700 sticky top-0 font-bold border-b border-slate-200">
                          <tr>
                            <th className="p-2.5 w-10 text-center border-r border-slate-200">#</th>
                            {extractedData.sheetsData?.headers?.map((header, idx) => (
                              <th key={idx} className="p-2.5 whitespace-nowrap border-r border-slate-200">
                                {header}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-800">
                          {extractedData.sheetsData?.rows?.map((row, rIdx) => (
                            <tr key={rIdx} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-2.5 text-center text-slate-400 font-mono text-[11px] border-r border-slate-100">
                                {rIdx + 1}
                              </td>
                              {row.map((cell, cIdx) => (
                                <td key={cIdx} className="p-2.5 whitespace-nowrap border-r border-slate-100">
                                  {String(cell ?? '')}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: GOOGLE DOCS */}
              {activeResultTab === 'docs' && (
                <div className="p-6 space-y-6">
                  {/* Action Bar for Docs */}
                  <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <span className="font-bold text-xs text-blue-950 block">
                          Acomodar en Google Docs
                        </span>
                        <span className="text-[11px] text-blue-700">
                          {isAuthenticated
                            ? 'Crea un documento ejecutivo nuevo o anexa el texto a uno existente.'
                            : 'Inicia sesión en Google Workspace para insertar directamente.'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            downloadMarkdownFile(
                              extractedData.docsContent?.title || 'informe',
                              extractedData.docsContent?.markdown || extractedData.docsContent?.formattedText || ''
                            );
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                        >
                          <Download className="w-3 h-3 text-slate-500" />
                          <span>Descargar .md</span>
                        </button>

                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              await navigator.clipboard.writeText(extractedData.docsContent?.formattedText || '');
                              setCopiedSection('doc');
                              setTimeout(() => setCopiedSection(null), 2000);
                            } catch {
                              // ignore
                            }
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                        >
                          {copiedSection === 'doc' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                          {copiedSection === 'doc' ? '¡Copiado!' : 'Copiar Texto'}
                        </button>
                      </div>
                    </div>

                    {/* Direct Insertion Buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <button
                        type="button"
                        disabled={isExporting}
                        onClick={handleCreateNewDoc}
                        className="py-2.5 px-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs disabled:opacity-50"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Crear en Nuevo Google Doc</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <select
                          value={selectedDocToAppend}
                          onChange={(e) => setSelectedDocToAppend(e.target.value)}
                          className="flex-1 text-xs p-2 rounded-xl border border-blue-300 bg-white text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 truncate"
                        >
                          {userDocs.length === 0 ? (
                            <option value="">(Sin documentos cargados)</option>
                          ) : (
                            userDocs.map((d) => (
                              <option key={d.id} value={d.id}>
                                {d.name}
                              </option>
                            ))
                          )}
                        </select>
                        <button
                          type="button"
                          disabled={isExporting || userDocs.length === 0}
                          onClick={handleAppendToExistingDoc}
                          className="py-2 px-3 rounded-xl bg-white hover:bg-blue-100 border border-blue-300 text-blue-900 font-semibold text-xs transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                        >
                          Añadir a Doc
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Formatted Text Preview */}
                  <div className="space-y-2">
                    <span className="text-xs font-semibold text-slate-700 block">
                      Texto Estructurado para el Documento:
                    </span>
                    <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 font-mono text-xs text-slate-800 whitespace-pre-wrap max-h-96 overflow-y-auto leading-relaxed">
                      {extractedData.docsContent?.formattedText || 'No se generó texto de documento.'}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: RESUMEN Y DATOS CLAVE */}
              {activeResultTab === 'summary' && (
                <div className="p-6 space-y-6">
                  {/* Multi-Document Cross-Synthesis Section */}
                  {((extractedData.crossDocumentInsights && extractedData.crossDocumentInsights.length > 0) || (extractedData.sourceFilesCount && extractedData.sourceFilesCount > 1) || selectedFiles.length > 1) && (
                    <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200/80 space-y-2.5">
                      <div className="flex items-center gap-2">
                        <Layers className="w-4 h-4 text-indigo-700" />
                        <span className="text-xs font-bold text-indigo-950 uppercase tracking-wider">
                          Síntesis Cruzada y Conciliación ({extractedData.sourceFilesCount || selectedFiles.length} documentos):
                        </span>
                      </div>
                      
                      {extractedData.sourceFileNames && extractedData.sourceFileNames.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-0.5">
                          {extractedData.sourceFileNames.map((fn, idx) => (
                            <span key={idx} className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-white border border-indigo-200 text-indigo-900">
                              📄 {fn}
                            </span>
                          ))}
                        </div>
                      )}

                      {extractedData.crossDocumentInsights && extractedData.crossDocumentInsights.length > 0 ? (
                        <ul className="space-y-1.5 pt-1 text-xs text-indigo-950">
                          {extractedData.crossDocumentInsights.map((insight, idx) => (
                            <li key={idx} className="flex items-start gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                              <span>{insight}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-indigo-900 pt-0.5">
                          Los datos de los {selectedFiles.length} documentos fueron correlacionados y consolidados en la hoja de cálculo y documento de informe.
                        </p>
                      )}
                    </div>
                  )}

                  {/* Key Fact Chips */}
                  {extractedData.keyDataPoints && extractedData.keyDataPoints.length > 0 && (
                    <div>
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-3">
                        Datos Clave Extraídos:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {extractedData.keyDataPoints.map((dp, idx) => (
                          <div
                            key={idx}
                            className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1"
                          >
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                              {dp.label}
                            </span>
                            <span className="text-xs font-bold text-slate-900 block truncate" title={dp.value}>
                              {dp.value}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Executive Summary */}
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      Síntesis Ejecutiva del Archivo:
                    </span>
                    <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100 text-xs text-slate-800 leading-relaxed">
                      {extractedData.documentSummary}
                    </div>
                  </div>

                  {/* Suggested Next Actions */}
                  {extractedData.suggestedActions && extractedData.suggestedActions.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                        Recomendaciones y Próximos Pasos:
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                        {extractedData.suggestedActions.map((action, idx) => (
                          <li key={idx} className="leading-normal">
                            {action}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            /* Empty State / Welcome Guidance */
            <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 text-center shadow-xs space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto border border-blue-100">
                <FileSpreadsheet className="w-8 h-8" />
              </div>
              <div className="space-y-1.5 max-w-md mx-auto">
                <h3 className="text-base font-bold text-slate-800">
                  Esperando archivo para procesar
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Sube cualquier imagen o PDF a la izquierda (o pulsa un ejemplo de prueba) y haz clic en <strong>Procesar y Extraer Información</strong>.
                </p>
              </div>

              <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-lg mx-auto text-left text-[11px] text-slate-600">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="font-bold text-slate-800 block mb-1">1. Lectura Visual</span>
                  <span>Extrae texto, totales, fechas e ítems de tablas de fotos y PDFs.</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200">
                  <span className="font-bold text-emerald-900 block mb-1">2. Google Sheets</span>
                  <span>Crea o añade filas a hojas de cálculo automáticamente.</span>
                </div>
                <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-200">
                  <span className="font-bold text-blue-900 block mb-1">3. Google Docs</span>
                  <span>Estructura memorandos y resúmenes ejecutivos listos para enviar.</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
