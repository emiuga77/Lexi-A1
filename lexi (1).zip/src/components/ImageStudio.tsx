import React, { useState } from 'react';
import {
  Image as ImageIcon,
  Sparkles,
  Download,
  Upload,
  RefreshCw,
  Wand2,
  AlertCircle,
  Film,
  Video,
  Search,
} from 'lucide-react';
import { VeoVideoStudio } from './VeoVideoStudio';
import { saveMediaCreation } from '../services/firestoreDb';

export const ImageStudio: React.FC = () => {
  const [subTab, setSubTab] = useState<'create_edit' | 'veo_video' | 'generate_hq'>('create_edit');

  // HQ Generation State (gemini-3.1-flash-image & gemini-3-pro-image)
  const [hqPrompt, setHqPrompt] = useState('');
  const [imageSize, setImageSize] = useState<'512px' | '1K' | '2K' | '4K'>('1K');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '4:1' | '1:4'>('1:1');
  const [enableSearchGrounding, setEnableSearchGrounding] = useState(false);
  const [isGeneratingHq, setIsGeneratingHq] = useState(false);
  const [hqResult, setHqResult] = useState<{
    imageUrl: string;
    description?: string;
    imageSize: string;
    model: string;
  } | null>(null);

  // Edit / Create State (gemini-3.1-flash-image)
  const [editPrompt, setEditPrompt] = useState('');
  const [selectedFileBase64, setSelectedFileBase64] = useState<string | null>(null);
  const [isProcessingEdit, setIsProcessingEdit] = useState(false);
  const [editResult, setEditResult] = useState<{
    imageUrl: string;
    notes?: string;
    mode: string;
    model: string;
  } | null>(null);

  // AI Prompt Enhancer State
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false);
  const [activeStylePreset, setActiveStylePreset] = useState<string>('');

  // Cross-Studio Transfer to Veo Video
  const [videoTransferImage, setVideoTransferImage] = useState<string | null>(null);
  const [videoTransferPrompt, setVideoTransferPrompt] = useState<string>('');

  const [error, setError] = useState<string | null>(null);

  // Style Presets for Images
  const stylePresets = [
    { label: 'Cinemático 35mm', style: 'Cinematic 35mm film photography, shallow depth of field, anamorphic lens flare, moody volumetric lighting, 8k raw photo' },
    { label: 'Render 3D Octane', style: 'Hyperrealistic 3D Octane render, raytraced reflections, subsurface scattering, studio softbox illumination, ultra detailed textures' },
    { label: 'Anime Makoto Shinkai', style: 'Breathtaking anime visual style inspired by Makoto Shinkai, luminous celestial sky, radiant golden hour lighting, vibrant painterly details' },
    { label: 'Vector Minimalista', style: 'Clean minimalist vector graphic illustration, crisp modern geometric lines, sophisticated corporate flat color palette' },
    { label: 'Cyberpunk Neón', style: 'Cyberpunk aesthetic, glowing neon cyan and magenta reflections, rain-slicked asphalt streets, futuristic dark atmospheric fog' },
    { label: 'Render Arquitectónico', style: 'Modern architectural concept render, natural sunlight casting soft geometric shadows, exposed concrete and warm walnut wood finishes' },
  ];

  // Quick edit suggestions
  const editQuickSuggestions = [
    'Eliminar fondo y reemplazar con un estudio blanco minimalista con sombras suaves.',
    'Añadir iluminación de atardecer dorado con reflejos cálidos y atmósfera mágica.',
    'Convertir a una elegante ilustración de acuarela y boceto arquitectónico en tinta.',
    'Incorporar interfaces holográficas flotantes con gráficos y estadísticas futuristas.',
    'Mejorar la nitidez, eliminar imperfecciones y añadir textura cinematográfica 8k.',
  ];

  // File Upload Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedFileBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Receive snapshot from Veo Video Studio
  const handleReceiveFromVideoStudio = (imageBase64: string, promptText?: string) => {
    setSelectedFileBase64(imageBase64);
    if (promptText) {
      setEditPrompt(promptText);
    }
    setSubTab('create_edit');
  };

  // Transfer image to Veo Video Studio
  const handleAnimateWithVeo = (imageUrl: string, basePrompt: string) => {
    setVideoTransferImage(imageUrl);
    setVideoTransferPrompt(`Cinematic animation of: ${basePrompt || 'scene'}. Smooth fluid motion with physical realism and camera tracking.`);
    setSubTab('veo_video');
  };

  // Helper to extract user-friendly error messages
  const parseErrorMessage = (errData: any, fallback: string) => {
    let msg = errData?.error || fallback;
    if (typeof msg === 'string' && (msg.startsWith('{') || msg.includes('"error":'))) {
      try {
        const parsed = JSON.parse(msg);
        if (parsed?.error?.message) {
          msg = parsed.error.message;
        }
      } catch (_) {}
    }
    if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('quota') || msg.includes('limit: 0')) {
      return 'Límite de cuota alcanzado para modelos de imagen (429). En la capa gratuita de Google AI Studio los modelos de imagen pueden tener cuota restringida o requerir facturación. Puedes reintentar más tarde o habilitar facturación en Google AI Studio.';
    }
    return msg;
  };

  // AI Prompt Enhancer
  const handleEnhancePrompt = async (target: 'hq' | 'edit') => {
    const currentPrompt = target === 'hq' ? hqPrompt : editPrompt;
    if (!currentPrompt.trim()) {
      setError('Escribe una descripción básica antes de optimizar el prompt con IA.');
      return;
    }

    setIsEnhancingPrompt(true);
    setError(null);

    try {
      const response = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: currentPrompt,
          type: 'image',
          stylePreset: activeStylePreset || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Error al conectar con el optimizador de prompts.');
      }

      const data = await response.json();
      if (data.enhancedPrompt) {
        if (target === 'hq') {
          setHqPrompt(data.enhancedPrompt);
        } else {
          setEditPrompt(data.enhancedPrompt);
        }
      }
    } catch (err: any) {
      console.warn('Enhance prompt error:', err);
      setError(err?.message || 'No se pudo optimizar el prompt.');
    } finally {
      setIsEnhancingPrompt(false);
    }
  };

  // High Quality Generation
  const handleGenerateHQ = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!hqPrompt.trim()) return;

    setIsGeneratingHq(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: hqPrompt,
          imageSize,
          aspectRatio,
          enableSearchGrounding,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(parseErrorMessage(errData, 'Failed to generate high quality image.'));
      }

      const data = await response.json();
      setHqResult(data);

      if (data?.imageUrl) {
        saveMediaCreation({
          type: 'image',
          prompt: hqPrompt,
          model: data.model || 'gemini-3.1-flash-image',
          aspectRatio,
          mediaUrl: data.imageUrl,
          status: 'completed',
        }).catch(() => {});
      }
    } catch (err: any) {
      console.warn('HQ Image Generation notice:', err?.message || err);
      setError(parseErrorMessage({ error: err?.message }, 'Image generation failed.'));
    } finally {
      setIsGeneratingHq(false);
    }
  };

  // Create & Edit Images
  const handleProcessEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editPrompt.trim()) return;

    setIsProcessingEdit(true);
    setError(null);

    try {
      const response = await fetch('/api/edit-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: editPrompt,
          imageBase64: selectedFileBase64 || undefined,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(parseErrorMessage(errData, 'Failed to create/edit image.'));
      }

      const data = await response.json();
      setEditResult(data);

      if (data?.imageUrl) {
        saveMediaCreation({
          type: 'image',
          prompt: editPrompt,
          model: data.model || 'gemini-3.1-flash-image',
          aspectRatio: '1:1',
          mediaUrl: data.imageUrl,
          status: 'completed',
          hasStartingImage: Boolean(selectedFileBase64),
        }).catch(() => {});
      }
    } catch (err: any) {
      console.warn('Edit Image notice:', err?.message || err);
      setError(parseErrorMessage({ error: err?.message }, 'Image processing failed.'));
    } finally {
      setIsProcessingEdit(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <ImageIcon className="w-6 h-6 text-purple-600" />
            AI Image Studio & Workflow Assets
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Genera imágenes profesionales con Gemini 3.1 Flash Image, Google Search Grounding y anima gráficos en movimiento con Veo 3.
          </p>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setSubTab('create_edit')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              subTab === 'create_edit'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5 text-indigo-600" />
            <span>Crear y Editar Imágenes</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('generate_hq')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              subTab === 'generate_hq'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span>Alta Fidelidad (1K/2K/4K)</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('veo_video')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              subTab === 'veo_video'
                ? 'bg-white text-rose-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Film className="w-3.5 h-3.5 text-rose-500" />
            <span>Generar Video Veo 3</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-rose-900 leading-snug">{error}</p>
              {error.includes('cuota') && (
                <p className="text-[11px] text-rose-600 leading-normal">
                  Consejo: Las capacidades multimodales de análisis y chat de documentos continúan 100% operativas con failover a Groq LPU y Gemini Flash Lite.
                </p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-rose-400 hover:text-rose-700 p-1 rounded-md transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Tab 1: Veo 3 Video Studio */}
      {subTab === 'veo_video' && (
        <VeoVideoStudio
          initialImageBase64={videoTransferImage}
          initialPrompt={videoTransferPrompt}
          initialMode={videoTransferImage ? 'image_to_video' : 'text_to_video'}
          onSendToImageStudio={handleReceiveFromVideoStudio}
        />
      )}

      {/* Tab 2: High Quality Generation (1K / 2K / 4K + Search Grounding) */}
      {subTab === 'generate_hq' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls Column */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Modelo: gemini-3.1-flash-image
                </span>
                <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 text-[10px] font-bold">
                  Resolución 512px — 4K
                </span>
              </div>

              {/* Style Presets */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                  Estilos Artísticos & Fotográficos
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {stylePresets.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setActiveStylePreset(preset.style);
                        if (hqPrompt && !hqPrompt.includes(preset.label)) {
                          setHqPrompt((prev) => `${prev.trim()}, ${preset.style}`);
                        }
                      }}
                      className={`px-2.5 py-1 text-[11px] rounded-lg border transition-all cursor-pointer ${
                        activeStylePreset === preset.style
                          ? 'bg-purple-600 text-white border-purple-600 font-semibold'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <form onSubmit={handleGenerateHQ} className="space-y-4">
                {/* Prompt with AI Enhancer */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      Prompt de la Imagen
                    </label>
                    <button
                      type="button"
                      onClick={() => handleEnhancePrompt('hq')}
                      disabled={isEnhancingPrompt || !hqPrompt.trim()}
                      className="text-xs font-semibold text-purple-600 hover:text-purple-800 flex items-center gap-1 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <Wand2 className={`w-3.5 h-3.5 ${isEnhancingPrompt ? 'animate-spin' : ''}`} />
                      <span>{isEnhancingPrompt ? 'Optimizando...' : 'Optimizar con IA'}</span>
                    </button>
                  </div>
                  <textarea
                    rows={4}
                    required
                    placeholder="ej: Visualización isométrica minimalista moderna de un motor de flujo de trabajo conectando documentos, hojas de cálculo y redes neuronales, iluminación de estudio suave, render 8k."
                    value={hqPrompt}
                    onChange={(e) => setHqPrompt(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 outline-hidden leading-relaxed"
                  />
                </div>

                {/* Google Search Grounding Checkbox */}
                <div className="p-3 rounded-xl bg-purple-50/50 border border-purple-200/60 flex items-start gap-2.5">
                  <input
                    id="search-grounding"
                    type="checkbox"
                    checked={enableSearchGrounding}
                    onChange={(e) => setEnableSearchGrounding(e.target.checked)}
                    className="mt-0.5 rounded text-purple-600 focus:ring-purple-500 cursor-pointer"
                  />
                  <label htmlFor="search-grounding" className="text-xs text-slate-700 cursor-pointer select-none">
                    <span className="font-semibold text-purple-900 block flex items-center gap-1">
                      <Search className="w-3 h-3 text-purple-600" />
                      Google Search & Image Grounding
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Permite al modelo buscar información y referencias visuales en tiempo real para entidades del mundo real.
                    </span>
                  </label>
                </div>

                {/* Image Resolution (512px, 1K, 2K, 4K) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Resolución de Salida
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {(['512px', '1K', '2K', '4K'] as const).map((size) => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setImageSize(size)}
                        className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          imageSize === size
                            ? 'bg-purple-600 text-white border-purple-600 shadow-xs shadow-purple-500/20'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {imageSize === '4K'
                      ? 'Ultra alta fidelidad 4K (3840x3840).'
                      : imageSize === '2K'
                      ? 'Gran nitidez 2K (2048x2048).'
                      : imageSize === '512px'
                      ? 'Boceto rápido 512px para pruebas instantáneas.'
                      : 'Estándar 1K de alta definición (1024x1024).'}
                  </p>
                </div>

                {/* Aspect Ratio */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Relación de Aspecto
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['1:1', '16:9', '9:16', '4:3', '3:4', '4:1', '1:4'] as const).map((ratio) => (
                      <button
                        key={ratio}
                        type="button"
                        onClick={() => setAspectRatio(ratio)}
                        className={`py-1.5 px-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                          aspectRatio === ratio
                            ? 'bg-purple-100 text-purple-900 border-purple-300 font-bold'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={!hqPrompt.trim() || isGeneratingHq}
                  className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  {isGeneratingHq ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Generando con Gemini 3.1 Flash Image...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Generar Imagen {imageSize}</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Result Column */}
          <div className="lg:col-span-7">
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs min-h-[440px] flex flex-col justify-center items-center">
              {isGeneratingHq ? (
                <div className="text-center space-y-3 p-8">
                  <div className="w-12 h-12 rounded-full border-3 border-purple-600 border-t-transparent animate-spin mx-auto" />
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">
                      Sintetizando Imagen {imageSize} de Alta Fidelidad
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      Gemini 3.1 Flash Image está procesando la iluminación y el renderizado...
                    </p>
                  </div>
                </div>
              ) : hqResult ? (
                <div className="w-full space-y-3">
                  <div className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-950 flex items-center justify-center">
                    <img
                      src={hqResult.imageUrl}
                      alt="Generated Graphic"
                      className="max-h-[500px] w-auto object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-100">
                    <div className="flex items-center gap-2 text-xs text-slate-600">
                      <span className="font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                        {hqResult.imageSize} • {aspectRatio}
                      </span>
                      <span className="font-mono text-[11px] text-slate-400">
                        {hqResult.model}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleAnimateWithVeo(hqResult.imageUrl, hqPrompt)}
                        className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-500 to-indigo-600 hover:from-rose-600 hover:to-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                        title="Transferir esta imagen como fotograma de inicio a Veo 3"
                      >
                        <Film className="w-3.5 h-3.5" />
                        <span>Animar en Veo 3</span>
                      </button>

                      <a
                        href={hqResult.imageUrl}
                        download={`gemini-${hqResult.imageSize.toLowerCase()}-image.png`}
                        className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-black text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Descargar PNG</span>
                      </a>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-2 text-slate-400 p-8">
                  <ImageIcon className="w-12 h-12 mx-auto stroke-1 text-slate-400" />
                  <p className="text-xs font-medium text-slate-500">
                    La imagen generada en alta resolución aparecerá aquí.
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                    Selecciona una resolución (512px, 1K, 2K, 4K) y estilo para renderizar gráficos profesionales listos para animar en video.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Create & Edit Images */}
      {subTab === 'create_edit' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Modelo: gemini-3.1-flash-image
                </span>
                <span className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-[10px] font-bold">
                  Edición Multimodal
                </span>
              </div>

              {/* Upload Dropzone */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Foto de Entrada para Modificar (Opcional)
                </label>
                <div className="relative border-2 border-dashed border-slate-200 rounded-xl p-4 text-center hover:border-indigo-400 transition-colors bg-slate-50/50">
                  {selectedFileBase64 ? (
                    <div className="space-y-2">
                      <img
                        src={selectedFileBase64}
                        alt="Uploaded preview"
                        className="max-h-36 mx-auto rounded-lg object-contain shadow-xs border border-indigo-200"
                      />
                      <button
                        type="button"
                        onClick={() => setSelectedFileBase64(null)}
                        className="text-[11px] font-semibold text-rose-600 hover:underline cursor-pointer"
                      >
                        Quitar Imagen (Crear Desde Cero)
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                      <label className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer">
                        <span>Subir una imagen para editar</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="sr-only"
                        />
                      </label>
                      <p className="text-[11px] text-slate-400 mt-1">
                        O déjalo vacío para crear una nueva imagen a partir del prompt.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Quick Editing Suggestions */}
              {selectedFileBase64 && (
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-bold text-slate-700">
                    Instrucciones Rápidas de Edición:
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {editQuickSuggestions.map((suggestion, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setEditPrompt(suggestion)}
                        className="px-2 py-1 text-[11px] bg-slate-50 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 rounded-lg border border-slate-200 transition-colors text-left cursor-pointer truncate max-w-full"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Prompt with AI Enhancer */}
              <form onSubmit={handleProcessEdit} className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      {selectedFileBase64 ? 'Instrucciones de Edición' : 'Prompt de Creación'}
                    </label>
                    <button
                      type="button"
                      onClick={() => handleEnhancePrompt('edit')}
                      disabled={isEnhancingPrompt || !editPrompt.trim()}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <Wand2 className={`w-3.5 h-3.5 ${isEnhancingPrompt ? 'animate-spin' : ''}`} />
                      <span>{isEnhancingPrompt ? 'Optimizando...' : 'Optimizar con IA'}</span>
                    </button>
                  </div>
                  <textarea
                    rows={4}
                    required
                    placeholder={
                      selectedFileBase64
                        ? 'ej: Añadir gráficos holográficos flotando sobre el escritorio, suavizar sombras y aumentar colores neón vibrantes.'
                        : 'ej: Un escritorio minimalista de cristal con una esfera inteligente flotante sobre madera de nogal.'
                    }
                    value={editPrompt}
                    onChange={(e) => setEditPrompt(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!editPrompt.trim() || isProcessingEdit}
                  className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
                >
                  {isProcessingEdit ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Procesando con Gemini 3.1 Flash Image...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-4 h-4" />
                      <span>
                        {selectedFileBase64 ? 'Aplicar Edición a la Imagen' : 'Crear Imagen'}
                      </span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Results Display */}
          <div className="lg:col-span-7">
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs min-h-[440px] flex flex-col justify-center items-center">
              {isProcessingEdit ? (
                <div className="text-center space-y-3 p-8">
                  <div className="w-12 h-12 rounded-full border-3 border-indigo-600 border-t-transparent animate-spin mx-auto" />
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">
                      Ejecutando Edición Multimodal
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      Gemini 3.1 Flash Image está sintetizando los cambios con coherencia visual...
                    </p>
                  </div>
                </div>
              ) : editResult ? (
                <div className="w-full space-y-3">
                  {/* Before / After Comparison */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {selectedFileBase64 && (
                      <div>
                        <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                          Original de Entrada
                        </span>
                        <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center p-1">
                          <img
                            src={selectedFileBase64}
                            alt="Original"
                            className="max-h-72 w-auto object-contain rounded-lg"
                          />
                        </div>
                      </div>
                    )}
                    <div className={selectedFileBase64 ? '' : 'sm:col-span-2'}>
                      <span className="text-[11px] font-semibold text-indigo-600 block mb-1">
                        {editResult.mode === 'edited' ? 'Resultado Editado' : 'Resultado Generado'}
                      </span>
                      <div className="rounded-xl overflow-hidden border border-indigo-200 bg-slate-950 flex items-center justify-center">
                        <img
                          src={editResult.imageUrl}
                          alt="Result"
                          className="max-h-72 w-auto object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                    <span className="text-xs font-mono text-slate-500">
                      {editResult.model} ({editResult.mode})
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleAnimateWithVeo(editResult.imageUrl, editPrompt)}
                        className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-500 to-indigo-600 hover:from-rose-600 hover:to-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                        title="Transferir este resultado a Veo 3 para animarlo en video"
                      >
                        <Film className="w-3.5 h-3.5" />
                        <span>Animar en Veo 3</span>
                      </button>

                      <a
                        href={editResult.imageUrl}
                        download={`gemini-edit-${Date.now()}.png`}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Descargar PNG</span>
                      </a>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-2 text-slate-400 p-8">
                  <Wand2 className="w-12 h-12 mx-auto stroke-1" />
                  <p className="text-xs font-medium text-slate-500">
                    La imagen editada o creada aparecerá en este visor.
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                    Sube una foto existente para transformarla con lenguaje natural o escribe un prompt para crear un concepto nuevo.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
