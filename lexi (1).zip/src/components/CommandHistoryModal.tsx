import React, { useState, useEffect, useMemo } from 'react';
import {
  History,
  Search,
  Play,
  Copy,
  Check,
  Trash2,
  X,
  FileText,
  FileSpreadsheet,
  Sparkles,
  Bot,
  ExternalLink,
  CheckCircle2,
  Clock,
  RefreshCw,
} from 'lucide-react';
import { VoiceCommandRecord, VoiceCommandActionType } from '../types';
import {
  getCommandHistory,
  deleteCommandRecord,
  clearCommandHistory,
} from '../services/firestoreDb';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onReExecute: (commandText: string, actionType?: VoiceCommandActionType) => void;
}

export const CommandHistoryModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onReExecute,
}) => {
  const [commands, setCommands] = useState<VoiceCommandRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'docs' | 'sheets' | 'extract'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen]);

  const loadHistory = async () => {
    setIsLoading(true);
    try {
      const list = await getCommandHistory();
      setCommands(list);
    } catch (err: any) {
      console.warn('Notice loading command history:', err?.message || err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = async (id: string) => {
    setCommands((prev) => prev.filter((c) => c.id !== id));
    await deleteCommandRecord(id);
  };

  const handleClearAll = async () => {
    if (!window.confirm('¿Seguro que deseas vaciar el historial de comandos de Lexi?')) return;
    setIsClearing(true);
    try {
      await clearCommandHistory();
      setCommands([]);
    } finally {
      setIsClearing(false);
    }
  };

  const filteredCommands = useMemo(() => {
    return commands.filter((cmd) => {
      // Filter by category
      if (selectedFilter === 'docs' && !cmd.actionType.startsWith('docs')) return false;
      if (selectedFilter === 'sheets' && !cmd.actionType.startsWith('sheets')) return false;
      if (selectedFilter === 'extract' && cmd.actionType !== 'document_extract') return false;

      // Filter by search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const textMatch = cmd.commandText.toLowerCase().includes(q);
        const titleMatch = (cmd.targetDocumentTitle || '').toLowerCase().includes(q);
        const summaryMatch = (cmd.resultSummary || '').toLowerCase().includes(q);
        const modelMatch = (cmd.modelUsed || '').toLowerCase().includes(q);
        return textMatch || titleMatch || summaryMatch || modelMatch;
      }

      return true;
    });
  }, [commands, selectedFilter, searchQuery]);

  // Action type badge helpers
  const getActionBadge = (actionType: VoiceCommandActionType) => {
    switch (actionType) {
      case 'docs_create':
      case 'docs_append':
        return {
          icon: FileText,
          label: 'Google Docs',
          color: 'bg-blue-50 text-blue-700 border-blue-200',
          iconColor: 'text-blue-600',
        };
      case 'sheets_create':
      case 'sheets_append':
        return {
          icon: FileSpreadsheet,
          label: 'Google Sheets',
          color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          iconColor: 'text-emerald-600',
        };
      case 'document_extract':
        return {
          icon: Sparkles,
          label: 'Extracción Documento',
          color: 'bg-purple-50 text-purple-700 border-purple-200',
          iconColor: 'text-purple-600',
        };
      default:
        return {
          icon: Bot,
          label: 'Comando de Voz',
          color: 'bg-slate-50 text-slate-700 border-slate-200',
          iconColor: 'text-slate-600',
        };
    }
  };

  const formatTimestamp = (ts: number) => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / (1000 * 60));
    if (mins < 1) return 'Hace un momento';
    if (mins < 60) return `Hace ${mins} min`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `Hace ${hours} h`;
    return new Date(ts).toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-4xl max-h-[90vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="command-history-title"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-400 shadow-inner">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="command-history-title" className="text-base font-bold text-white tracking-tight">
                  Historial de Comandos de Voz
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-blue-500/25 border border-blue-400/40 text-blue-300 font-semibold text-[11px] flex items-center gap-1">
                  <Bot className="w-3 h-3 text-blue-300" />
                  Lexi AI
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Revisa, busca y re-ejecuta instrucciones de voz realizadas en tus documentos
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={loadHistory}
              disabled={isLoading}
              title="Actualizar historial"
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Cerrar ventana"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toolbar: Search & Category Filters */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por instrucción, título de documento, modelo..."
              className="w-full pl-9 pr-8 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Chips */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSelectedFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedFilter === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Todos ({commands.length})
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('docs')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedFilter === 'docs'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-blue-500" />
              Docs
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('sheets')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedFilter === 'sheets'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
              Sheets
            </button>
            <button
              type="button"
              onClick={() => setSelectedFilter('extract')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedFilter === 'extract'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-500" />
              Extracciones
            </button>
          </div>
        </div>

        {/* Command List Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
          {isLoading ? (
            <div className="p-12 text-center text-slate-400 space-y-2">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-600" />
              <p className="text-xs font-medium text-slate-500">Cargando historial de comandos...</p>
            </div>
          ) : filteredCommands.length === 0 ? (
            <div className="p-12 text-center text-slate-400 space-y-3 bg-white rounded-xl border border-dashed border-slate-200">
              <History className="w-10 h-10 mx-auto text-slate-300" />
              <h3 className="text-sm font-semibold text-slate-700">No se encontraron instrucciones</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {searchQuery
                  ? `No hay comandos que coincidan con "${searchQuery}". Intenta con otros términos.`
                  : 'Aún no se han registrado comandos para esta categoría. Habla con Lexi para automatizar tus documentos.'}
              </p>
            </div>
          ) : (
            filteredCommands.map((cmd) => {
              const badge = getActionBadge(cmd.actionType);
              const BadgeIcon = badge.icon;
              return (
                <div
                  key={cmd.id}
                  className="bg-white rounded-xl p-4 border border-slate-200 hover:border-blue-300 hover:shadow-sm transition-all group"
                >
                  {/* Top metadata line */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${badge.color}`}
                      >
                        <BadgeIcon className={`w-3 h-3 ${badge.iconColor}`} />
                        <span>{badge.label}</span>
                      </span>

                      {cmd.targetDocumentTitle && (
                        <span className="text-xs font-bold text-slate-800 truncate max-w-[240px] sm:max-w-md">
                          {cmd.targetDocumentTitle}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      {cmd.modelUsed && (
                        <span className="font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px]">
                          {cmd.modelUsed}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTimestamp(cmd.timestamp)}
                      </span>
                    </div>
                  </div>

                  {/* Instruction text */}
                  <div className="mb-3">
                    <p className="text-xs sm:text-sm font-medium text-slate-800 leading-relaxed bg-slate-50/80 p-3 rounded-lg border border-slate-100">
                      “{cmd.commandText}”
                    </p>
                  </div>

                  {/* Result summary if available */}
                  {cmd.resultSummary && (
                    <div className="mb-3 flex items-center justify-between text-[11px] text-slate-600 bg-emerald-50/70 border border-emerald-200/80 px-2.5 py-1.5 rounded-lg">
                      <div className="flex items-center gap-1.5 font-medium text-emerald-900">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{cmd.resultSummary}</span>
                      </div>
                      {cmd.resultUrl && (
                        <a
                          href={cmd.resultUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-900 font-semibold underline text-[10px]"
                        >
                          Abrir <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      )}
                    </div>
                  )}

                  {/* Action Buttons Row */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onReExecute(cmd.commandText, cmd.actionType);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                        title="Ejecutar esta instrucción de nuevo con Lexi"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Re-ejecutar con Lexi</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCopy(cmd.id, cmd.commandText)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
                        title="Copiar texto de la instrucción"
                      >
                        {copiedId === cmd.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-700 font-bold">Copiado</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-slate-500" />
                            <span>Copiar</span>
                          </>
                        )}
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDelete(cmd.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                      title="Eliminar registro del historial"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-white border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span>Mostrando {filteredCommands.length} de {commands.length} instrucciones</span>
          </div>

          <div className="flex items-center gap-3">
            {commands.length > 0 && (
              <button
                type="button"
                onClick={handleClearAll}
                disabled={isClearing}
                className="text-slate-400 hover:text-rose-600 font-medium transition-colors cursor-pointer flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" />
                <span>Vaciar historial</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-colors cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
