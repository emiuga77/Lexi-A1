import React, { useState, useEffect, useRef } from 'react';
import {
  ChatMessage,
  AssistantRole,
  GeminiModelTier,
  GroqModelTier,
  AIProvider,
  PendingActionConfirmation,
  FileAttachment,
} from '../types';
import {
  Mic,
  Send,
  Sparkles,
  Volume2,
  VolumeX,
  Brain,
  Zap,
  Bot,
  User as UserIcon,
  FileText,
  Table,
  CheckCircle2,
  ExternalLink,
  Square,
  RefreshCw,
  Download,
  Copy,
  Check,
  Paperclip,
  X,
  FileSpreadsheet,
  Globe,
  Trash2,
} from 'lucide-react';
import {
  floatTo16BitPCMBase64,
  LiveAudioPlayer,
  VoiceNoiseFilter,
  calculateAudioRMS,
  rmsToNormalizedLevel,
} from '../utils/audio';
import { logAuditEvent, saveChatSession, saveCommandRecord, saveDocumentMetadata } from '../services/firestoreDb';
import { getActiveProfile } from '../services/profileService';
import { CyberParticleOrb } from './CyberParticleOrb';
import { UserProfile } from '../types';
import { parseVoiceNavigationCommand, isTurnOffMicCommand, OverlayView } from '../utils/commandParser';
import {
  findBestNaturalVoice,
  prepareTextForHumanSpeech,
  recordSpokenSpeech,
  isAssistantEcho,
  protectUtterance,
  hasLexiKeyword,
  isBargeInInterrupt,
} from '../utils/speechSynthesisHelper';
import { buildContinuousMemoryPayload } from '../utils/conversationMemory';

interface Props {
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  onRequestAction: (action: PendingActionConfirmation) => void;
  isAuthenticated: boolean;
  onPromptLogin: () => void;
  isLiveConnected: boolean;
  setIsLiveConnected: React.Dispatch<React.SetStateAction<boolean>>;
  onNavigateOverlay?: (view: OverlayView, feedback?: string) => void;
}

export const VoiceAssistantHub: React.FC<Props> = ({
  messages,
  setMessages,
  onRequestAction,
  isAuthenticated,
  onPromptLogin,
  isLiveConnected,
  setIsLiveConnected,
  onNavigateOverlay,
}) => {
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [selectedRole, setSelectedRole] = useState<AssistantRole>('executive');
  const [selectedProvider, setSelectedProvider] = useState<AIProvider>('gemini');
  const [selectedModel, setSelectedModel] = useState<GeminiModelTier>('gemini-3.8-flash');
  const selectedGroqModel: GroqModelTier = 'llama-3.3-70b-versatile';
  const [enableHighThinking, setEnableHighThinking] = useState(false);
  const [useGoogleSearch, setUseGoogleSearch] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [currentAttachment, setCurrentAttachment] = useState<FileAttachment | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const chatFileInputRef = useRef<HTMLInputElement | null>(null);

  // User Profile & Noise Gate State
  const [activeProfile, setActiveProfileState] = useState<UserProfile>(() => getActiveProfile());
  const [liveMicLevel, setLiveMicLevel] = useState<number>(0);
  const [isVoiceDetected, setIsVoiceDetected] = useState<boolean>(false);
  const [isContinuousListening, setIsContinuousListening] = useState<boolean>(false);

  // Handle clicking the glowing cyber particle orb
  const handleOrbClick = () => {
    setAudioError(null);

    // 1. If AI is currently speaking, interrupt it
    if (isAiSpeaking || voiceStatus === 'speaking') {
      interruptSpeaking();
      return;
    }

    // 2. If Gemini Live Streaming is active, toggle / disconnect it
    if (isLiveConnected) {
      toggleLiveConnection();
      return;
    }

    // 3. If any legacy listening was active, stop it
    if (isContinuousListening || isRecording || voiceStatus === 'listening') {
      stopContinuousSpeech();
      stopRecording();
      return;
    }

    // 4. Start Gemini Live Streaming directly for fluid, constant 24kHz conversation with Zephyr voice
    toggleLiveConnection();
  };

  const continuousRecognitionRef = useRef<any>(null);
  const micMonitorStreamRef = useRef<MediaStream | null>(null);
  const micMonitorCtxRef = useRef<AudioContext | null>(null);
  const micMonitorAnimFrameRef = useRef<number | null>(null);
  const noiseFilterRef = useRef<VoiceNoiseFilter | null>(null);

  // Listen for profile changes from modal or navbar
  useEffect(() => {
    const handleProfileChanged = () => {
      const updated = getActiveProfile();
      setActiveProfileState(updated);
      if (noiseFilterRef.current) {
        noiseFilterRef.current.updateThreshold(updated.noiseGateThreshold);
      }
    };
    window.addEventListener('voiceflow:profile_changed', handleProfileChanged);
    return () => window.removeEventListener('voiceflow:profile_changed', handleProfileChanged);
  }, []);

  // Audio refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const playerRef = useRef<LiveAudioPlayer | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const executedProposalsRef = useRef<Set<string>>(new Set());
  const accumulatedLiveTranscriptRef = useRef<string>('');
  const dictateRecognitionRef = useRef<any>(null);
  const isMicActiveRef = useRef<boolean>(false);

  // Role system instructions
  const roleInstructions: Record<AssistantRole, { name: string; desc: string; instruction: string }> = {
    executive: {
      name: 'Executive Workflow Architect',
      desc: 'Orchestrates high-level tasks, daily summaries, and cross-tool workflows',
      instruction:
        'Eres Lexi, una asistente de voz ejecutiva de IA de alto nivel. Conversa con total fluidez, calidez, elocuencia y naturalidad en español. Responde directamente y con agilidad sin monólogos pesados ni introducciones mecánicas. NUNCA crees documentos automáticamente; únicamente crea un documento cuando el usuario use explícitamente el comando "crean un documento" o "crea un documento".',
    },
    docs_specialist: {
      name: 'Docs & Report Specialist',
      desc: 'Excels in formatting comprehensive memos, meeting minutes, and briefs',
      instruction:
        'Eres especialista en redacción y estructura documental. En el diálogo mantén una conversación ágil y fluida. Solo redacta un documento cuando el usuario indique explícitamente "crean un documento" o "crea un documento".',
    },
    sheets_analyst: {
      name: 'Sheets & Data Analyst',
      desc: 'Analyzes metrics, designs spreadsheet schemas, and logs tabular records',
      instruction:
        'Eres una analista de datos y modelos financieros con un tono directo, claro y conversacional. Solo crea una hoja de cálculo si el usuario pide explícitamente crear una hoja en Sheets.',
    },
    creative_designer: {
      name: 'Creative Content Director',
      desc: 'Guides media creation, visual prompts, and presentation graphics',
      instruction:
        'Eres directora creativa y estratega de contenido. Conversas de forma inspiradora, ágil y propositiva.',
    },
    realestate_researcher: {
      name: 'Investigador Inmobiliario en Vivo',
      desc: 'Investigación de mercado inmobiliario, precios $/m², comparables, demanda y rentabilidad con Google Search',
      instruction:
        'Eres una analista de inversión e inteligencia de mercado inmobiliario con acceso a datos web en tiempo real. Conversas en español con fluidez y claridad ejecutiva, sintetizando métricas clave sin crear documentos a menos que te pidan "crean un documento".',
    },
  };

  // Scroll to bottom when messages update
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, voiceStatus]);

  // Initialize LiveAudioPlayer
  useEffect(() => {
    playerRef.current = new LiveAudioPlayer((speaking) => {
      setIsAiSpeaking(speaking);
      if (speaking) {
        setVoiceStatus('speaking');
        window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'speaking' } }));
      } else if (!isRecording) {
        setVoiceStatus('idle');
        window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
      }
    });

    return () => {
      playerRef.current?.close();
      stopRecording();
      closeLiveWebSocket();
    };
  }, []);

  // Synchronize mic status and speech cessation across components
  useEffect(() => {
    const handleMicStatusEvent = (e: Event) => {
      const custom = e as CustomEvent<{ active: boolean }>;
      if (custom.detail !== undefined) {
        isMicActiveRef.current = !!custom.detail.active;
        if (!custom.detail.active) {
          interruptSpeaking();
        }
      }
    };

    const handleStopSpeakingEvent = () => {
      interruptSpeaking();
    };

    window.addEventListener('voiceflow:mic_status', handleMicStatusEvent);
    window.addEventListener('voiceflow:stop_speaking', handleStopSpeakingEvent);
    return () => {
      window.removeEventListener('voiceflow:mic_status', handleMicStatusEvent);
      window.removeEventListener('voiceflow:stop_speaking', handleStopSpeakingEvent);
    };
  }, []);

  // Handle Model Tier toggle
  const handleModelChange = (model: GeminiModelTier) => {
    setSelectedModel(model);
    if (model === 'gemini-3.1-pro-preview') {
      setEnableHighThinking(true);
    } else {
      setEnableHighThinking(false);
    }
  };

  // Connect / Disconnect Live WebSocket for Live API (gemini-3.8-live)
  const toggleLiveConnection = async () => {
    if (isLiveConnected) {
      closeLiveWebSocket();
      stopRecording();
      setIsLiveConnected(false);
      setVoiceStatus('idle');
    } else {
      setAudioError(null);
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/live`;
        const ws = new WebSocket(wsUrl);

        ws.onopen = () => {
          console.log('Connected to Gemini Live WebSocket');
          setIsLiveConnected(true);
          startRecording(ws);
        };

        ws.onmessage = async (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'connected') {
              console.log('Gemini Live session active with voice Zephyr at constant 24kHz');
            } else if (data.type === 'audio' && data.audio) {
              playerRef.current?.playChunk(data.audio);
            } else if (data.type === 'transcript' && data.text) {
              accumulatedLiveTranscriptRef.current += ' ' + data.text;
              const liveModelName = data.model || 'gemini-live';

              setMessages((prev) => {
                const last = prev[prev.length - 1];
                if (last && last.role === 'assistant' && (last.modelUsed === 'gemini-live' || last.modelUsed?.includes('live'))) {
                  return [
                    ...prev.slice(0, -1),
                    { ...last, content: last.content + ' ' + data.text },
                  ];
                } else {
                  return [
                    ...prev,
                    {
                      id: 'live-' + Date.now(),
                      role: 'assistant',
                      content: data.text,
                      timestamp: Date.now(),
                      modelUsed: liveModelName,
                    },
                  ];
                }
              });
            } else if (data.type === 'turnComplete') {
              const fullTurnText = accumulatedLiveTranscriptRef.current;
              if (fullTurnText) {
                const proposal = parseActionProposal(fullTurnText);
                if (proposal) {
                  const proposalKey = `${proposal.type}_${proposal.payload?.title || proposal.title}`;
                  if (!executedProposalsRef.current.has(proposalKey)) {
                    executedProposalsRef.current.add(proposalKey);
                    await executeProposalDirectly(proposal);
                  }
                }
              }
              accumulatedLiveTranscriptRef.current = '';
            } else if (data.type === 'interrupted') {
              accumulatedLiveTranscriptRef.current = '';
              playerRef.current?.stopAndClear();
            } else if (data.type === 'error') {
              setAudioError(data.error);
            }
          } catch (e: any) {
            console.warn('Error parsing live WS message:', e?.message || e);
          }
        };

        ws.onerror = (err) => {
          console.warn('Live WS connection notice:', (err as any)?.message || 'websocket notice');
          setAudioError('Live API connection error. Check server logs.');
          setIsLiveConnected(false);
        };

        ws.onclose = () => {
          console.log('Live WS closed');
          setIsLiveConnected(false);
          setIsRecording(false);
          setVoiceStatus('idle');
        };

        wsRef.current = ws;
      } catch (err: any) {
        setAudioError(err?.message || 'Could not start Live API session');
      }
    }
  };

  const closeLiveWebSocket = () => {
    executedProposalsRef.current.clear();
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (_) {}
      wsRef.current = null;
    }
  };

  // Mic Noise Monitoring for visual VU Meter & noise gate feedback during Speech Recognition
  const startMicNoiseMonitoring = async () => {
    try {
      if (micMonitorStreamRef.current && micMonitorCtxRef.current && micMonitorCtxRef.current.state !== 'closed') {
        return;
      }
      stopMicNoiseMonitoring();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: activeProfile.noiseSuppressionEnabled,
          autoGainControl: true,
        },
      });
      micMonitorStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      micMonitorCtxRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      source.connect(analyser);

      const buffer = new Float32Array(analyser.fftSize);
      const updateMeter = () => {
        if (!micMonitorStreamRef.current) return;
        analyser.getFloatTimeDomainData(buffer);
        const rms = calculateAudioRMS(buffer);
        const normalized = rmsToNormalizedLevel(rms);
        setLiveMicLevel(normalized);

        const threshold = activeProfile.noiseGateThreshold;
        const speaking = normalized >= threshold;
        setIsVoiceDetected(speaking);

        micMonitorAnimFrameRef.current = requestAnimationFrame(updateMeter);
      };
      updateMeter();
    } catch (e) {
      console.warn('Microphone monitoring unavailable:', e);
    }
  };

  const stopMicNoiseMonitoring = () => {
    if (micMonitorAnimFrameRef.current) {
      cancelAnimationFrame(micMonitorAnimFrameRef.current);
      micMonitorAnimFrameRef.current = null;
    }
    if (micMonitorStreamRef.current) {
      micMonitorStreamRef.current.getTracks().forEach((t) => t.stop());
      micMonitorStreamRef.current = null;
    }
    if (micMonitorCtxRef.current && micMonitorCtxRef.current.state !== 'closed') {
      try {
        micMonitorCtxRef.current.close();
      } catch (_) {}
      micMonitorCtxRef.current = null;
    }
    setLiveMicLevel(0);
    setIsVoiceDetected(false);
  };

  // Start Mic Audio capture and stream Float32 -> 16-bit PCM base64 with active profile noise gate
  const startRecording = async (activeWs?: WebSocket) => {
    try {
      setAudioError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: activeProfile.noiseSuppressionEnabled,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass({ sampleRate: 16000 });
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);

      // Create profile-tailored noise filter
      const noiseFilter = new VoiceNoiseFilter({
        noiseGateThreshold: activeProfile.noiseGateThreshold,
        highpassFilterEnabled: activeProfile.highpassFilterEnabled,
        onVoiceActivityChange: (isSpeaking, currentLevel) => {
          setLiveMicLevel(currentLevel);
          setIsVoiceDetected(isSpeaking);
        },
      });
      noiseFilterRef.current = noiseFilter;

      // 4096 buffer size processor
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      scriptProcessorRef.current = processor;

      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);

        // Pass audio buffer through our Noise Gate
        const { isVoice, processedBuffer } = noiseFilter.processBuffer(inputData);

        // Anti-Noise Guard: If audio is below noise gate threshold (fan, keyboard, coughing, chatter),
        // we DO NOT send it to the AI WebSocket. This prevents the AI from getting confused or hallucinating!
        if (!isVoice) {
          return;
        }

        const pcmBase64 = floatTo16BitPCMBase64(processedBuffer);
        const targetWs = activeWs || wsRef.current;
        if (targetWs && targetWs.readyState === WebSocket.OPEN) {
          targetWs.send(
            JSON.stringify({
              type: 'audio',
              audio: pcmBase64,
            })
          );
        }
      };

      // Apply Highpass 85Hz filter to cut off sub-bass rumble if enabled in profile
      if (activeProfile.highpassFilterEnabled) {
        const biquad = audioCtx.createBiquadFilter();
        biquad.type = 'highpass';
        biquad.frequency.setValueAtTime(85, audioCtx.currentTime);
        source.connect(biquad);
        biquad.connect(processor);
      } else {
        source.connect(processor);
      }

      processor.connect(audioCtx.destination);

      setIsRecording(true);
      setVoiceStatus('listening');
    } catch (err: any) {
      console.warn('Failed to open microphone:', err?.message || err);
      setAudioError('Microphone permission denied or unavailable.');
    }
  };

  const interruptSpeaking = () => {
    playerRef.current?.stopAndClear();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (_) {}
    }
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text: 'Stop' }));
    }
    setSpeakingMsgId(null);
    setIsAiSpeaking(false);
    setVoiceStatus('idle');
    window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
  };

  // Botón en la esquina inferior izquierda del mensaje para leerlo a petición del usuario
  const toggleReadMessage = (msgId: string, text: string) => {
    if (speakingMsgId === msgId) {
      interruptSpeaking();
      return;
    }

    interruptSpeaking();
    setSpeakingMsgId(msgId);
    setIsAiSpeaking(true);
    setVoiceStatus('speaking');
    window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'speaking' } }));

    const cleanSnippet = prepareTextForHumanSpeech(text, 600);
    if (!cleanSnippet) {
      setSpeakingMsgId(null);
      setIsAiSpeaking(false);
      setVoiceStatus('idle');
      return;
    }

    recordSpokenSpeech(cleanSnippet);

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanSnippet);
      utterance.lang = activeProfile.language || 'es-ES';
      const bestVoice = findBestNaturalVoice(activeProfile.language || 'es-ES');
      if (bestVoice) utterance.voice = bestVoice;
      utterance.rate = 0.98;
      utterance.pitch = 1.0;
      protectUtterance(utterance);

      utterance.onend = () => {
        setSpeakingMsgId(null);
        setIsAiSpeaking(false);
        setVoiceStatus('idle');
        window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
      };
      utterance.onerror = () => {
        setSpeakingMsgId(null);
        setIsAiSpeaking(false);
        setVoiceStatus('idle');
        window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
      };
      window.speechSynthesis.speak(utterance);
    } else {
      setSpeakingMsgId(null);
      setIsAiSpeaking(false);
      setVoiceStatus('idle');
    }
  };

  const stopRecording = () => {
    isMicActiveRef.current = false;
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (scriptProcessorRef.current) {
      try {
        scriptProcessorRef.current.disconnect();
      } catch (_) {}
      scriptProcessorRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (_) {}
      audioContextRef.current = null;
    }
    noiseFilterRef.current = null;
    stopMicNoiseMonitoring();
    setIsRecording(false);
    setLiveMicLevel(0);
    setIsVoiceDetected(false);
    if (voiceStatus === 'listening') {
      setVoiceStatus('idle');
    }
    // When user turns off microphone, stop assistant speaking immediately
    interruptSpeaking();
    window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
  };

  // Toggle Continuous Speech Recognition with Background Noise Filtering
  const toggleContinuousSpeech = () => {
    if (isContinuousListening) {
      stopContinuousSpeech();
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setAudioError('El reconocimiento de voz nativo no está soportado en este navegador. Puedes escribir directamente.');
      return;
    }

    interruptSpeaking();

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = activeProfile.language || 'es-ES';
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onstart = () => {
        isMicActiveRef.current = true;
        setIsContinuousListening(true);
        setIsRecording(true);
        setVoiceStatus('listening');
        startMicNoiseMonitoring();
        window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: true } }));
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const candidate = (final || interim).trim();
        if (!candidate) return;

        // 1. Anti-Echo: discard audio if it reflects assistant's own speech
        if (isAssistantEcho(candidate)) {
          return;
        }

        // 2. Interruption Guard: when AI is actively speaking, ONLY interrupt if explicit "Lexi" keyword is detected
        if (isAiSpeaking) {
          const isExplicitLexiInterrupt = hasLexiKeyword(candidate) || isBargeInInterrupt(candidate);
          if (isExplicitLexiInterrupt) {
            interruptSpeaking();
            // User called out "Lexi", so interrupt and allow subsequent speech to be processed
          } else {
            // Protect assistant speaking: ignore room noise and ambient chatter
            return;
          }
        }

        if (candidate && isTurnOffMicCommand(candidate)) {
          stopContinuousSpeech();
          window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
          return;
        }

        if (final.trim()) {
          const spoken = final.trim();
          if (isTurnOffMicCommand(spoken)) {
            stopContinuousSpeech();
            window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
            return;
          }
          const navCmd = parseVoiceNavigationCommand(spoken);
          if (navCmd.isTurnOffMicCommand) {
            stopContinuousSpeech();
            window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
            return;
          }
          if (navCmd.isNavCommand && navCmd.targetView) {
            if (onNavigateOverlay) {
              onNavigateOverlay(navCmd.targetView, navCmd.feedbackMessage);
            }
            return;
          }
          setInputText((prev) => (prev ? prev + ' ' + spoken : spoken));
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
          console.warn('Speech recognition notice:', event.error);
        }
      };

      recognition.onend = () => {
        if (continuousRecognitionRef.current) {
          try {
            recognition.start();
          } catch (_) {}
        } else {
          stopContinuousSpeech();
        }
      };

      continuousRecognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.warn('Error starting continuous recognition:', err?.message || err);
      setAudioError('No se pudo iniciar el reconocimiento de voz.');
      stopContinuousSpeech();
    }
  };

  const stopContinuousSpeech = () => {
    isMicActiveRef.current = false;
    if (continuousRecognitionRef.current) {
      const ref = continuousRecognitionRef.current;
      continuousRecognitionRef.current = null;
      try {
        ref.stop();
      } catch (_) {}
    }
    stopMicNoiseMonitoring();
    setIsContinuousListening(false);
    setIsRecording(false);
    if (voiceStatus === 'listening') setVoiceStatus('idle');
    // Stop assistant from speaking when continuous mic is turned off
    interruptSpeaking();
    window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
  };

  const stopDictation = () => {
    isMicActiveRef.current = false;
    if (dictateRecognitionRef.current) {
      const rec = dictateRecognitionRef.current;
      dictateRecognitionRef.current = null;
      try {
        rec.stop();
      } catch (_) {}
    }
    stopMicNoiseMonitoring();
    setIsRecording(false);
    setVoiceStatus('idle');
    // Stop assistant from speaking when dictation mic is turned off
    interruptSpeaking();
    window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
  };

  // Quick speech-to-text dictation with active profile language
  const handleDictatePrompt = () => {
    // If mic is currently active, turn it OFF and halt any speaking
    if (isContinuousListening) {
      stopContinuousSpeech();
      return;
    }

    if (isRecording || dictateRecognitionRef.current) {
      stopDictation();
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setAudioError('Reconocimiento de voz no soportado en este navegador.');
      return;
    }

    interruptSpeaking();

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = activeProfile.language || 'es-ES';
      recognition.interimResults = true;
      dictateRecognitionRef.current = recognition;

      recognition.onstart = () => {
        isMicActiveRef.current = true;
        setIsRecording(true);
        setVoiceStatus('listening');
        startMicNoiseMonitoring();
        window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: true } }));
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        for (let i = 0; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        const candidate = (final || interim).trim();
        if (candidate && isAssistantEcho(candidate)) {
          return;
        }
        if (candidate && isTurnOffMicCommand(candidate)) {
          stopDictation();
          window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
          return;
        }

        if (final.trim()) {
          const spoken = final.trim();
          if (isTurnOffMicCommand(spoken)) {
            stopDictation();
            window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
            return;
          }
          const navCmd = parseVoiceNavigationCommand(spoken);
          if (navCmd.isTurnOffMicCommand) {
            stopDictation();
            window.dispatchEvent(new CustomEvent('voiceflow:mic_status', { detail: { active: false } }));
            return;
          }
          if (navCmd.isNavCommand && navCmd.targetView) {
            if (onNavigateOverlay) {
              onNavigateOverlay(navCmd.targetView, navCmd.feedbackMessage);
            }
            stopDictation();
            return;
          }
          setInputText((prev) => (prev ? prev + ' ' + spoken : spoken));
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
          console.warn('Speech recognition notice:', event.error);
        }
        dictateRecognitionRef.current = null;
        stopMicNoiseMonitoring();
        setIsRecording(false);
        setVoiceStatus('idle');
      };

      recognition.onend = () => {
        dictateRecognitionRef.current = null;
        stopMicNoiseMonitoring();
        setIsRecording(false);
        if (voiceStatus === 'listening') setVoiceStatus('idle');
      };

      recognition.start();
    } catch (err: any) {
      console.warn('Error starting dictation:', err?.message || err);
      dictateRecognitionRef.current = null;
      stopDictation();
    }
  };

  const handleChatFileSelect = (file: File) => {
    if (file.size > 20 * 1024 * 1024) {
      setAudioError('El archivo supera los 20MB permitidos.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const isImg = file.type.startsWith('image/');
      setCurrentAttachment({
        name: file.name,
        type: file.type || 'application/octet-stream',
        size: file.size,
        data: result,
        previewUrl: isImg ? result : undefined,
      });
    };
    reader.readAsDataURL(file);
  };

  // Send message via /api/chat with full multi-turn context
  const handleSendMessage = async (textToSend?: string, isVoiceInitiated = false) => {
    const text = textToSend !== undefined ? textToSend : inputText;
    if ((!text.trim() && !currentAttachment) || isLoading) return;

    if (text.trim()) {
      const navCmd = parseVoiceNavigationCommand(text.trim());
      if (navCmd.isNavCommand && navCmd.targetView) {
        if (onNavigateOverlay) {
          onNavigateOverlay(navCmd.targetView, navCmd.feedbackMessage);
        }
        if (navCmd.feedbackMessage && typeof window !== 'undefined' && 'speechSynthesis' in window) {
          try {
            window.speechSynthesis.cancel();
            const utt = new SpeechSynthesisUtterance(navCmd.feedbackMessage);
            utt.lang = 'es-ES';
            utt.rate = 1.05;
            window.speechSynthesis.speak(utt);
          } catch (_) {}
        }
        setInputText('');
        return;
      }
    }

    const attached = currentAttachment;
    const userMessage: ChatMessage = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: text || (attached ? `Por favor analiza este archivo adjunto (${attached.name}) y extrae los datos necesarios.` : ''),
      timestamp: Date.now(),
      attachment: attached || undefined,
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputText('');
    setCurrentAttachment(null);
    setIsLoading(true);
    setVoiceStatus('thinking');
    window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'thinking' } }));

    try {
      const isRealEstatePrompt = 
        selectedRole === 'realestate_researcher' ||
        useGoogleSearch ||
        /(mercado inmobiliario|bienes ra[ií]ces|real estate|precio por metro|precio m2|precio por m2|costo por m2|plusval[ií]a|rentabilidad|alquiler|propiedades en|departamentos en|casas en|terrenos en|inversi[oó]n inmobiliaria|comps inmobiliarios|comparables de venta|zonas de inversi[oó]n|investiga el mercado|investigaci[oó]n inmobiliaria)/i.test(text);

      const effectiveUseSearch = selectedProvider === 'gemini' && (useGoogleSearch || isRealEstatePrompt);
      const effectiveModel = effectiveUseSearch 
        ? 'gemini-3.8-flash' 
        : (selectedProvider === 'groq' ? selectedGroqModel : selectedModel);

      const customGroqKey = localStorage.getItem('GROQ_CUSTOM_KEY')?.trim() || '';
      const chatHeaders: Record<string, string> = { 'Content-Type': 'application/json' };
      if (customGroqKey) {
        chatHeaders['x-groq-api-key'] = customGroqKey;
      }

      // 10-turn rolling window + key summary memory for ultra-fast, contextual conversation
      const memoryResult = buildContinuousMemoryPayload(newMessages, 10);

      const payload = {
        messages: memoryResult.windowedMessages,
        model: effectiveModel,
        provider: selectedProvider,
        groqApiKey: customGroqKey || undefined,
        enableThinking: selectedProvider === 'gemini' && enableHighThinking && !effectiveUseSearch,
        useGoogleSearch: effectiveUseSearch,
        systemInstruction: `${roleInstructions[selectedRole].instruction}\n[Perfil de Usuario Activo: "${activeProfile.name}", Rol: "${activeProfile.role}", Tono Preferido: "${activeProfile.tone}"]${activeProfile.customInstructions ? `\nInstrucciones Específicas del Usuario: "${activeProfile.customInstructions}"` : ''}${memoryResult.accumulatedContextBlock}\nDIRECTRICES PARA UNA CONVERSACIÓN HUMANA Y ÁGIL:\n- Sé sumamente ágil, concisa y directa al grano, hablando con naturalidad como una brillante colega ejecutiva.\n- REGLA ESTRICTA ANTI-BUCLE: NUNCA repitas la misma respuesta, idea o resumen emitido en los turnos previos de la conversación. Si el diálogo prosigue, avanza siempre aportando datos nuevos o ángulos frescos sin reiterar lo ya dicho.\n- ESCUCHA ACTIVA: Atiende exactamente lo que el usuario acaba de plantear.`,
      };

      // Resilient fetch with automatic retry on transient network hiccups or server restarts
      let response: Response | null = null;
      let lastFetchErr: any = null;

      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          response = await fetch('/api/chat', {
            method: 'POST',
            headers: chatHeaders,
            body: JSON.stringify(payload),
          });
          break;
        } catch (fetchErr: any) {
          lastFetchErr = fetchErr;
          console.warn(`[Chat fetch attempt ${attempt + 1} failed]`, fetchErr?.message || fetchErr);
          if (attempt === 0) {
            // Wait 800ms before second attempt
            await new Promise((resolve) => setTimeout(resolve, 800));
          }
        }
      }

      if (!response) {
        throw lastFetchErr || new Error('Failed to fetch');
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with ${response.status}`);
      }

      const data = await response.json();

      // Check if response contains a structured workflow action proposal
      const proposal = parseActionProposal(data.reply, text);

      const assistantMessage: ChatMessage = {
        id: 'msg-' + Date.now() + 1,
        role: 'assistant',
        content: data.reply,
        timestamp: Date.now(),
        modelUsed: data.model,
        usedThinking: data.usedThinking,
        groundingSources: data.groundingSources,
        actionProposal: proposal || undefined,
      };

      setMessages((prev) => {
        const next = [...prev, assistantMessage];
        // Save multi-turn session to Firestore
        try {
          saveChatSession({
            title: next[0]?.content.slice(0, 50) || 'Sesión de Chat Gemini',
            model: data.model || effectiveModel,
            role: selectedRole,
            messages: next,
          });
        } catch (dbErr) {
          console.warn('Auto-save chat to Firestore notice:', dbErr);
        }
        return next;
      });

      // Automatic Workspace / Document Execution without requiring user clicks
      if (proposal) {
        executeProposalDirectly(proposal, assistantMessage.id);
      }

      // El chat no se auto leerá a menos que usuario pique un botón que estará en la esquina inferior izquierda del mensaje.
      // Si la interacción provino de voz (asistente de voz con micrófono), responde por voz directamente.
      if (isVoiceInitiated) {
        speakResponse(data.reply);
      }
    } catch (err: any) {
      console.warn('Chat request notice:', err?.message || err);
      const raw = String(err?.message || '').trim();
      let friendlyError = raw || 'Ocurrió un error al procesar tu solicitud. Por favor intenta de nuevo.';
      if (raw.includes('Failed to fetch') || raw.includes('NetworkError') || raw.includes('network') || raw.includes('fetch')) {
        friendlyError = 'Error de conexión con el servidor (error de red o reconexión en curso). Por favor verifica tu conexión y haz clic en "Reintentar envío" o envía tu mensaje nuevamente.';
      } else if (raw.includes('blocked_org') || raw.includes('settings/limits')) {
        friendlyError = 'La clave de Groq está conectada pero tu organización en Groq tiene los modelos desactivados en la consola de límites (https://console.groq.com/settings/limits). Conmutando temporalmente a Google Gemini para que puedas continuar sin interrupciones.';
        setSelectedProvider('gemini');
      } else if (raw.includes('503') || raw.includes('high demand') || raw.includes('UNAVAILABLE')) {
        friendlyError = 'El modelo seleccionado está experimentando alta demanda temporal (503). Por favor selecciona Gemini 3.1 Flash Lite en la barra superior o reintenta en unos instantes.';
      } else if (raw.includes('429') || raw.includes('quota') || raw.includes('RESOURCE_EXHAUSTED')) {
        friendlyError = 'Límite de cuota alcanzado (429). Por favor selecciona Gemini 3.1 Flash Lite para continuar sin restricciones.';
      }

      setMessages((prev) => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          role: 'assistant',
          content: `⚠️ ${friendlyError}`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsLoading(false);
      setVoiceStatus('idle');
      window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
    }
  };

  // Listen for voice-initiated prompt executions from useVoiceCommander or global events
  const handleSendMessageRef = useRef(handleSendMessage);
  useEffect(() => {
    handleSendMessageRef.current = handleSendMessage;
  });

  useEffect(() => {
    const handleVoicePrompt = (e: Event) => {
      const customEvent = e as CustomEvent<{ prompt: string }>;
      const prompt = customEvent.detail?.prompt;
      if (prompt && prompt.trim()) {
        isMicActiveRef.current = true;
        handleSendMessageRef.current(prompt.trim(), true);
      }
    };
    window.addEventListener('voiceflow:execute_prompt', handleVoicePrompt);
    return () => {
      window.removeEventListener('voiceflow:execute_prompt', handleVoicePrompt);
    };
  }, []);

  // Convert text response to speech via /api/tts with seamless native browser synthesis fallback
  // Assistant speaks ONLY while the microphone is on; when user turns it off, she stops immediately.
  const speakResponse = async (text: string) => {
    const isMicActive = isMicActiveRef.current || isRecording || isContinuousListening;
    if (!isMicActive) {
      return;
    }

    // Keep utterance natural, articulate, concise and fluent for voice delivery
    const cleanSnippet = prepareTextForHumanSpeech(text, 420);
    if (!cleanSnippet) return;

    recordSpokenSpeech(cleanSnippet);

    const speakViaBrowser = () => {
      if (!isMicActiveRef.current && !isRecording && !isContinuousListening) {
        setIsAiSpeaking(false);
        return;
      }
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setIsAiSpeaking(false);
        return;
      }
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(cleanSnippet);
        utterance.lang = activeProfile.language || 'es-ES';
        const bestVoice = findBestNaturalVoice(activeProfile.language || 'es-ES');
        if (bestVoice) utterance.voice = bestVoice;
        utterance.rate = 0.98;
        utterance.pitch = 1.0;
        protectUtterance(utterance);
        utterance.onstart = () => {
          if (!isMicActiveRef.current && !isRecording && !isContinuousListening) {
            try {
              window.speechSynthesis.cancel();
            } catch (_) {}
            setIsAiSpeaking(false);
            return;
          }
          setIsAiSpeaking(true);
          setVoiceStatus('speaking');
          window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'speaking' } }));
        };
        utterance.onend = () => {
          setIsAiSpeaking(false);
          setVoiceStatus('idle');
          window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
        };
        utterance.onerror = () => {
          setIsAiSpeaking(false);
          setVoiceStatus('idle');
          window.dispatchEvent(new CustomEvent('voiceflow:status_changed', { detail: { status: 'idle' } }));
        };
        window.speechSynthesis.speak(utterance);
      } catch (_) {
        setIsAiSpeaking(false);
      }
    };

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanSnippet, voice: 'Zephyr' }),
      });

      // If user turned off microphone during fetch, abort speaking
      if (!isMicActiveRef.current && !isRecording && !isContinuousListening) {
        return;
      }

      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          if (isMicActiveRef.current || isRecording || isContinuousListening) {
            playerRef.current?.playChunk(data.audio);
          }
          return;
        }
        if (data.fallbackToBrowser) {
          speakViaBrowser();
          return;
        }
      }
      speakViaBrowser();
    } catch (_) {
      if (isMicActiveRef.current || isRecording || isContinuousListening) {
        speakViaBrowser();
      }
    }
  };

  // Extract markdown table into structured headers & rows
  const extractMarkdownTable = (text: string): { headers: string[]; rows: (string | number)[][] } | null => {
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
    const tableLines = lines.filter((l) => l.startsWith('|') && l.endsWith('|'));
    if (tableLines.length >= 2) {
      const parseRow = (line: string) =>
        line
          .slice(1, -1)
          .split('|')
          .map((c) => c.trim());
      const rawHeaders = parseRow(tableLines[0]);
      // Skip markdown divider line like |---|---|
      const dataLines = tableLines.slice(1).filter((l) => !/^\|(\s*:?-+:?\s*\|)+$/.test(l));
      const rawRows = dataLines.map(parseRow);
      if (rawHeaders.length > 0 && rawRows.length > 0) {
        return { headers: rawHeaders, rows: rawRows };
      }
    }
    return null;
  };

  // Helper to format spoken text for ultra-fluid, natural vocal delivery
  const formatSpokenSnippet = (rawText: string, maxLength: number = 380): string => {
    return rawText
      .replace(/```workspace_action[\s\S]*?```/g, '')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/[#*`~>[\]()|]/g, '')
      .replace(/\n+/g, '. ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, maxLength);
  };

  // User command validator: ONLY allow document creation when user explicitly uses the command "crean un documento" / "crea un documento"
  const isExplicitDocCreationCommand = (userPrompt?: string): boolean => {
    if (!userPrompt || typeof userPrompt !== 'string') return false;
    const normalized = userPrompt
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[.,/#!$%^&*;:{}=\-_`~()¿?¡!"]/g, '')
      .trim();

    return /\b(crean?|crear)\s+(un\s+|el\s+)?(documento|doc)\b/i.test(normalized);
  };

  // Parse workflow actions proposed by Gemini or Groq, with support for automatic sheets & docs creation
  const parseActionProposal = (text: string, userPrompt?: string) => {
    if (!text || text.trim().length === 0) return null;

    // 1. Check for structured workspace_action JSON block
    const wsActionMatch = text.match(/```workspace_action\s*([\s\S]*?)\s*```/);
    if (wsActionMatch) {
      try {
        const parsed = JSON.parse(wsActionMatch[1]);
        if (parsed.action === 'create_doc' || parsed.type === 'docs_create') {
          // STRICT RULE: Only create document if user explicitly commanded it ("crean un documento" / "crea un documento")
          if (!isExplicitDocCreationCommand(userPrompt)) {
            console.log('[Lexi] Document creation prevented: User did not explicitly say "crean un documento".');
            return null;
          }
          return {
            type: 'docs_create' as const,
            title: parsed.title || 'Documento en Google Docs',
            description: parsed.summary || 'Generación de documento por comando expreso',
            payload: {
              title: parsed.title || 'Documento Asistente IA - ' + new Date().toLocaleDateString(),
              content: parsed.content || text.replace(/```workspace_action[\s\S]*?```/, '').trim(),
            },
            status: 'pending_confirmation' as const,
          };
        } else if (parsed.action === 'create_sheet' || parsed.type === 'sheets_create') {
          return {
            type: 'sheets_create' as const,
            title: parsed.title || 'Hoja de Cálculo en Google Sheets',
            description: parsed.summary || 'Generación y guardado automático en Google Sheets',
            payload: {
              title: parsed.title || 'Hoja de Cálculo Asistente IA',
              headers: parsed.headers || ['Columna 1', 'Columna 2'],
              rows: parsed.rows || [],
              sheetName: parsed.sheetName || 'Datos',
            },
            status: 'pending_confirmation' as const,
          };
        } else if (parsed.action === 'append_sheet' || parsed.type === 'sheets_append') {
          return {
            type: 'sheets_append' as const,
            title: parsed.title || 'Añadir Fila a Google Sheet',
            description: parsed.summary || 'Registro automático en Google Sheets',
            payload: {
              row: parsed.row || (parsed.rows && parsed.rows[0]) || [new Date().toLocaleDateString(), 'Registro IA'],
            },
            status: 'pending_confirmation' as const,
          };
        }
      } catch (e) {
        console.warn('Error parsing workspace_action JSON:', e);
      }
    }

    // 2. Check for legacy tags DOC_PROPOSAL / CREATE_DOC
    if (text.includes('DOC_PROPOSAL:') || text.includes('CREATE_DOC:')) {
      if (!isExplicitDocCreationCommand(userPrompt)) return null;
      const cleaned = text.replace(/DOC_PROPOSAL:\s*|CREATE_DOC:\s*/g, '').trim();
      const firstLine = cleaned.split('\n')[0]?.replace(/^#+\s*/, '').trim() || 'Documento Google Docs';
      return {
        type: 'docs_create' as const,
        title: firstLine,
        description: 'Guardar documento en Google Docs',
        payload: { title: firstLine, content: cleaned },
        status: 'pending_confirmation' as const,
      };
    }

    // 3. Check for legacy tags SHEET_PROPOSAL / CREATE_SHEET / APPEND_SHEET
    if (text.includes('SHEET_PROPOSAL:') || text.includes('CREATE_SHEET:') || text.includes('APPEND_SHEET:')) {
      const table = extractMarkdownTable(text);
      if (table) {
        return {
          type: 'sheets_create' as const,
          title: 'Hoja de Cálculo - ' + new Date().toLocaleDateString(),
          description: 'Hoja de cálculo generada automáticamente en Google Sheets',
          payload: {
            title: 'Hoja de Cálculo - ' + new Date().toLocaleDateString(),
            headers: table.headers,
            rows: table.rows,
          },
          status: 'pending_confirmation' as const,
        };
      }
      return {
        type: 'sheets_append' as const,
        title: 'Registrar en Google Sheet',
        description: 'Añadir fila a Google Sheets',
        payload: { row: [new Date().toLocaleDateString(), 'Acción IA', 'Completado', text.slice(0, 60)] },
        status: 'pending_confirmation' as const,
      };
    }

    // 4. Automatic Spreadsheet Detection (Markdown table present + explicit context of sheets/data/tables)
    const combinedContext = `${userPrompt || ''} ${text}`.toLowerCase();
    const tableData = extractMarkdownTable(text);
    const mentionsSheet =
      combinedContext.includes('crea una hoja') ||
      combinedContext.includes('crear hoja') ||
      combinedContext.includes('crear sheet') ||
      combinedContext.includes('crea una tabla en sheets') ||
      combinedContext.includes('en google sheets');

    if (tableData && mentionsSheet && tableData.rows.length >= 1) {
      // Derive a meaningful title from headings, first line, or prompt
      let extractedTitle = 'Hoja de Cálculo IA - ' + new Date().toLocaleDateString();
      const headingMatch = text.match(/^#+\s*(.*)$/m);
      if (headingMatch && headingMatch[1]) {
        extractedTitle = headingMatch[1].trim();
      } else if (userPrompt && userPrompt.trim().length > 3) {
        extractedTitle = userPrompt
          .replace(/^(crea|hazme|haz|genera|redacta)\s+(una?\s+)?(hoja(\s+de\s+c[aá]lculo)?|sheet|tabla|excel)\s*(de|con|para|sobre)?\s*/i, '')
          .slice(0, 45)
          .trim();
        if (!extractedTitle) extractedTitle = 'Hoja de Cálculo IA';
      }

      return {
        type: 'sheets_create' as const,
        title: extractedTitle,
        description: `Crear hoja de cálculo con ${tableData.rows.length} filas y ${tableData.headers.length} columnas`,
        payload: {
          title: extractedTitle,
          headers: tableData.headers,
          rows: tableData.rows,
        },
        status: 'pending_confirmation' as const,
      };
    }

    // 5. Explicit Document Command Detection
    // Strict requirement: ONLY creates a document if the user explicitly commanded "crean un documento" / "crea un documento"
    if (isExplicitDocCreationCommand(userPrompt) && text.trim().length > 20) {
      let docTitle = 'Documento Asistente IA - ' + new Date().toLocaleDateString();
      const headingMatch = text.match(/^#+\s*(.*)$/m);
      if (headingMatch && headingMatch[1]) {
        docTitle = headingMatch[1].trim();
      } else if (userPrompt && userPrompt.trim().length > 3) {
        docTitle = userPrompt
          .replace(/^(crean?|crear|hazme|haz)\s+(un\s+|el\s+)?(documento|doc)\s*(de|con|para|sobre)?\s*/i, '')
          .slice(0, 50)
          .trim();
        if (!docTitle) docTitle = 'Documento Asistente IA';
      }

      return {
        type: 'docs_create' as const,
        title: docTitle,
        description: 'Documento redactado a partir del comando expreso del usuario',
        payload: {
          title: docTitle,
          content: text.replace(/```workspace_action[\s\S]*?```/, '').trim(),
        },
        status: 'pending_confirmation' as const,
      };
    }

    // 6. Natural Spanish Detection for Google Sheets row addition
    if (
      /(a[ñn]ad(e|ir)|agrega(r)?|inserta(r)?|registra(r)?)\s+(una?\s+)?fila/i.test(combinedContext) ||
      combinedContext.includes('añadir a la hoja') ||
      combinedContext.includes('agregar fila')
    ) {
      return {
        type: 'sheets_append' as const,
        title: 'Añadir Fila a Google Sheet',
        description: 'Insertar nuevo registro tabular en Google Sheets',
        payload: {
          row: [new Date().toLocaleDateString(), 'Registro Automático IA', text.slice(0, 60)],
        },
        status: 'pending_confirmation' as const,
      };
    }

    return null;
  };

  // Reference to hold pending proposal if Google Workspace auth is needed
  const pendingProposalRef = useRef<any>(null);

  // Resume pending proposal as soon as workspace auth succeeds
  useEffect(() => {
    const handleWorkspaceAuth = async (e: Event) => {
      const customEvent = e as CustomEvent<{ hasToken: boolean }>;
      if (customEvent.detail?.hasToken && pendingProposalRef.current) {
        const pending = pendingProposalRef.current;
        pendingProposalRef.current = null;
        await executeProposalDirectly(pending);
      }
    };
    window.addEventListener('workspace:auth_changed', handleWorkspaceAuth);
    return () => {
      window.removeEventListener('workspace:auth_changed', handleWorkspaceAuth);
    };
  }, []);

  // Descarga directa de documento en formato Markdown
  const downloadDocAsFile = (title?: string, content?: string) => {
    const safeTitle = (title || 'documento').replace(/[^a-z0-9_-]/gi, '_');
    const blob = new Blob([content || ''], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeTitle}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Reemplaza el manejo de transcripción y propuestas por ejecución directa automática
  const executeProposalDirectly = async (proposal: any, targetMessageId?: string) => {
    if (!proposal) return;

    // Verificar si el token OAuth de Workspace está presente
    let token: string | null = null;
    try {
      const { getAccessToken } = await import('../services/firebaseAuth');
      token = await getAccessToken();
    } catch {
      token = null;
    }

    try {
      if (proposal.type === 'docs_create') {
        const title = proposal.payload?.title || proposal.title || 'Nuevo Documento Google Docs';
        const content = proposal.payload?.content || '';
        let createdDocUrl: string | undefined = undefined;
        let createdDocId: string | undefined = undefined;

        // Si hay token de Google Workspace, crearlo directamente en Google Docs
        if (token) {
          try {
            const { createGoogleDoc } = await import('../services/workspaceApi');
            const doc = await createGoogleDoc(title, content);
            createdDocUrl = doc.url;
            createdDocId = doc.id;
          } catch (apiErr: any) {
            console.warn('Google Docs API call notice (fallback to assistant storage):', apiErr?.message || apiErr);
          }
        }

        proposal.status = 'executed';
        if (createdDocUrl) {
          proposal.url = createdDocUrl;
        }

        // Persistir documento en la base de datos de metadatos (Firestore / Local)
        try {
          await saveDocumentMetadata({
            title,
            fileType: 'docs',
            content,
            summary: proposal.description || 'Documento generado automáticamente por comando de voz',
            tags: ['asistente-voz', 'autogenerado', 'documento'],
            googleDocId: createdDocId,
            googleDriveUrl: createdDocUrl,
          });
          if (typeof window !== 'undefined') {
            window.dispatchEvent(
              new CustomEvent('lexi:document_created', {
                detail: { title, url: createdDocUrl, docId: createdDocId },
              })
            );
          }
        } catch (metaErr) {
          console.warn('Document metadata save notice:', metaErr);
        }

        // Guardar comando en el historial persistente de Lexi
        saveCommandRecord({
          commandText: proposal.title || `Crear documento "${title}"`,
          actionType: 'docs_create',
          targetDocumentTitle: title,
          modelUsed: selectedModel,
          status: 'executed',
          resultUrl: createdDocUrl,
          resultSummary: createdDocUrl
            ? `Documento "${title}" creado y sincronizado en Google Drive.`
            : `Documento "${title}" redactado y guardado en tu asistente.`,
        }).catch((err) => console.warn('Command history save notice:', err));

        // Log audit event to Firebase Firestore
        logAuditEvent({
          actionType: 'google_doc_created',
          entityType: 'document',
          details: createdDocUrl
            ? `Documento Google Docs "${title}" creado automáticamente vía comando de voz. URL: ${createdDocUrl}`
            : `Documento "${title}" redactado y guardado automáticamente vía comando de voz.`,
          status: 'success',
        }).catch((err) => console.warn('Audit log error:', err));

        // Actualizar el estado de los mensajes para reflejar estado 'executed' de inmediato
        setMessages((prev) =>
          prev.map((m) =>
            m.id === targetMessageId || (m.actionProposal && m.actionProposal.title === proposal.title)
              ? {
                  ...m,
                  actionProposal: {
                    ...m.actionProposal,
                    ...proposal,
                    status: 'executed',
                    url: createdDocUrl || m.actionProposal?.url,
                  },
                }
              : m
          )
        );

        // Notificar por voz
        if (createdDocUrl) {
          speakResponse(`He creado el documento ${title} en tu Google Docs de forma automática.`);
          setMessages((prev) => [
            ...prev,
            {
              id: 'sys-' + Date.now(),
              role: 'system',
              content: `⚡ **Google Doc Creado Automáticamente:** [${title}](${createdDocUrl})\nEl documento ya está disponible en tu Google Drive sin necesidad de hacer clics.`,
              timestamp: Date.now(),
            },
          ]);
        } else {
          speakResponse(`He redactado y guardado el documento ${title} automáticamente. Ya está listo en tus documentos.`);
          setMessages((prev) => [
            ...prev,
            {
              id: 'sys-' + Date.now(),
              role: 'system',
              content: `⚡ **Documento Creado Automáticamente:** "${title}"\nEl documento fue generado y guardado con tu comando de voz. Puedes descargarlo o sincronizarlo con Google Drive.`,
              timestamp: Date.now(),
            },
          ]);
        }
      } else if (proposal.type === 'sheets_append') {
        const row = proposal.payload?.row || [new Date().toLocaleDateString(), 'Registro Automático'];
        let spreadsheetId = proposal.payload?.spreadsheetId;

        if (token) {
          try {
            const { appendSpreadsheetRows, listGoogleSheets, createGoogleSheet } = await import('../services/workspaceApi');
            if (!spreadsheetId) {
              const sheets = await listGoogleSheets().catch(() => []);
              if (sheets.length > 0) {
                spreadsheetId = sheets[0].id;
              } else {
                const newSheet = await createGoogleSheet('Registro Automático de Asistente IA', [
                  ['Fecha', 'Acción', 'Estado', 'Detalle'],
                ]);
                spreadsheetId = newSheet.id;
              }
            }
            await appendSpreadsheetRows(spreadsheetId, [row]);
          } catch (sheetErr) {
            console.warn('Sheets append notice:', sheetErr);
          }
        }

        proposal.status = 'executed';
        speakResponse(`He añadido el registro a tu hoja de cálculo automáticamente.`);

        saveCommandRecord({
          commandText: proposal.title || 'Añadir registro a Google Sheets',
          actionType: 'sheets_append',
          targetDocumentTitle: 'Hoja de Cálculo en Google Drive',
          modelUsed: selectedModel,
          status: 'executed',
          resultSummary: 'Registro insertado exitosamente en Google Sheets.',
        }).catch((err) => console.warn('Command history save notice:', err));

        logAuditEvent({
          actionType: 'google_sheet_appended',
          entityType: 'spreadsheet',
          details: `Fila añadida: ${JSON.stringify(row)}`,
          status: 'success',
        }).catch((err) => console.warn('Audit log error:', err));

        setMessages((prev) =>
          prev.map((m) =>
            m.id === targetMessageId || (m.actionProposal && m.actionProposal.title === proposal.title)
              ? { ...m, actionProposal: { ...m.actionProposal, ...proposal, status: 'executed' } }
              : m
          )
        );
      } else if (proposal.type === 'sheets_create') {
        const allRows: (string | number)[][] = [];
        if (proposal.payload?.headers && proposal.payload.headers.length > 0) {
          allRows.push(proposal.payload.headers);
        }
        if (proposal.payload?.rows && proposal.payload.rows.length > 0) {
          allRows.push(...proposal.payload.rows);
        }
        const title = proposal.payload?.title || 'Nueva Hoja de Cálculo';
        let sheetUrl: string | undefined = undefined;

        if (token) {
          try {
            const { createGoogleSheet } = await import('../services/workspaceApi');
            const sheet = await createGoogleSheet(title, allRows);
            sheetUrl = sheet.url;
            proposal.url = sheet.url;
          } catch (sheetErr) {
            console.warn('Sheets create notice:', sheetErr);
          }
        }

        proposal.status = 'executed';
        speakResponse(`He creado la hoja de cálculo ${title} automáticamente.`);

        saveCommandRecord({
          commandText: proposal.title || `Crear hoja de cálculo "${title}"`,
          actionType: 'sheets_create',
          targetDocumentTitle: title,
          modelUsed: selectedModel,
          status: 'executed',
          resultUrl: sheetUrl,
          resultSummary: `Hoja de cálculo "${title}" creada con ${allRows.length} filas.`,
        }).catch((err) => console.warn('Command history save notice:', err));

        logAuditEvent({
          actionType: 'google_sheet_created',
          entityType: 'spreadsheet',
          details: `Hoja de cálculo "${title}" creada automáticamente con ${allRows.length} filas.`,
          status: 'success',
        }).catch((err) => console.warn('Audit log error:', err));

        setMessages((prev) =>
          prev.map((m) =>
            m.id === targetMessageId || (m.actionProposal && m.actionProposal.title === proposal.title)
              ? { ...m, actionProposal: { ...m.actionProposal, ...proposal, status: 'executed', url: sheetUrl } }
              : m
          )
        );

        if (sheetUrl) {
          setMessages((prev) => [
            ...prev,
            {
              id: 'sys-' + Date.now(),
              role: 'system',
              content: `⚡ **Google Sheet Creada Automáticamente:** [${title}](${sheetUrl})\nLa hoja de cálculo fue creada en tu Google Drive sin requerir clics.`,
              timestamp: Date.now(),
            },
          ]);
        }
      }
    } catch (error: any) {
      console.warn('Aviso en ejecución automática:', error);
      proposal.status = 'executed';
      setMessages((prev) =>
        prev.map((m) =>
          m.id === targetMessageId || (m.actionProposal && m.actionProposal.title === proposal.title)
            ? { ...m, actionProposal: { ...m.actionProposal, ...proposal, status: 'executed' } }
            : m
        )
      );
    }
  };

  // Handle Action Proposal execution: ejecuta directamente sin interrupciones
  const executeProposal = (proposal: any) => {
    executeProposalDirectly(proposal);
  };

  // Quick prompt commands
  const quickActions = [
    {
      icon: Globe,
      label: '🔍 Investigación Inmobiliaria en Vivo',
      prompt: 'Investiga en vivo el mercado inmobiliario de Polanco y Roma Norte en Ciudad de México: precio promedio por m², comparables recientes de venta y renta, rentabilidad estimada y demanda con Google Search.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
      useSearch: true,
      role: 'realestate_researcher' as AssistantRole,
    },
    {
      icon: FileText,
      label: '⚡ Crear Documento Google Docs',
      prompt: 'Crea un documento de Google Docs titulado "Plan de Estrategia y Objetivos" con resumen ejecutivo, 3 metas clave y próximos pasos.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
    },
    {
      icon: FileSpreadsheet,
      label: '⚡ Crear Hoja en Google Sheets',
      prompt: 'Crea una hoja de cálculo en Google Sheets titulada "Presupuesto Operativo 2026" con columnas [Concepto, Categoría, Monto USD, Estado] y 4 filas de registros detallados.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
    },
    {
      icon: FileSpreadsheet,
      label: 'Extraer Multidocumento a Sheets & Docs',
      prompt: 'Extrae y consolida datos tabulares para Google Sheets y el informe ejecutivo para Google Docs a partir de los documentos analizados.',
      model: 'gemini-3.8-flash' as GeminiModelTier,
    },
    {
      icon: FileText,
      label: 'Create Meeting Summary Doc',
      prompt: 'Draft an executive meeting summary document with goals, key decisions, and next steps for our sprint.',
    },
    {
      icon: Table,
      label: 'Log Expense in Spreadsheet',
      prompt: 'Format a row entry for an engineering software subscription expense: $149.00 on today\'s date with category Cloud Tooling.',
    },
    {
      icon: Brain,
      label: 'High Thinking Deep Analysis',
      prompt: 'Deeply reason and compare the tradeoffs between synchronous webhooks and asynchronous event bus architectures for multi-cloud enterprise apps.',
      model: 'gemini-3.1-pro-preview' as GeminiModelTier,
      thinking: true,
    },
  ];

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-text">
      {/* 1. Header: Sleek, Minimal, No Clutter */}
      <div className="px-4 py-3 border-b border-cyan-500/20 bg-slate-950/95 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-slate-900 border border-cyan-500/30 shrink-0">
            <CyberParticleOrb
              size={24}
              status={voiceStatus}
              audioLevel={liveMicLevel}
              isVoiceDetected={isVoiceDetected}
              showControls={false}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-white">Lexi</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  voiceStatus === 'listening'
                    ? 'bg-cyan-400 animate-ping'
                    : voiceStatus === 'speaking'
                    ? 'bg-purple-400 animate-pulse'
                    : voiceStatus === 'thinking'
                    ? 'bg-amber-400 animate-pulse'
                    : 'bg-emerald-400'
                }`}
              />
              <span className="text-[11px] text-slate-400 font-medium">
                {voiceStatus === 'listening'
                  ? 'Escuchando tu voz...'
                  : voiceStatus === 'speaking'
                  ? 'Hablando...'
                  : voiceStatus === 'thinking'
                  ? 'Pensando...'
                  : 'En línea'}
              </span>
            </div>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-1.5">
          {/* Provider / Engine Switcher (Gemini vs Groq LPU) */}
          <button
            id="btn-toggle-provider"
            type="button"
            onClick={() => {
              if (selectedProvider === 'gemini') {
                setSelectedProvider('groq');
                setUseGoogleSearch(false);
              } else {
                setSelectedProvider('gemini');
              }
            }}
            className={`px-2.5 py-1 rounded-lg border text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              selectedProvider === 'groq'
                ? 'bg-amber-950/90 border-amber-500/80 text-amber-300 shadow-xs shadow-amber-500/20'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
            }`}
            title={
              selectedProvider === 'groq'
                ? 'Proveedor activo: Groq LPU (Ultra rápido). Clic para cambiar a Google Gemini.'
                : 'Proveedor activo: Google Gemini. Clic para cambiar a Groq LPU.'
            }
          >
            {selectedProvider === 'groq' ? (
              <>
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Groq LPU</span>
                <span className="sm:hidden">Groq</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                <span className="hidden sm:inline">Gemini</span>
                <span className="sm:hidden">Gemini</span>
              </>
            )}
          </button>

          {/* Live Real Estate Research Toggle Button */}
          <button
            id="btn-toggle-realestate-research"
            type="button"
            onClick={() => {
              const nextState = !useGoogleSearch;
              setUseGoogleSearch(nextState);
              if (nextState) {
                setSelectedRole('realestate_researcher');
                setSelectedModel('gemini-3.8-flash');
              } else {
                setSelectedRole('executive');
                setSelectedModel('gemini-3.8-flash');
              }
            }}
            className={`px-2.5 py-1 rounded-lg border text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              useGoogleSearch || selectedRole === 'realestate_researcher'
                ? 'bg-cyan-950/90 border-cyan-400/80 text-cyan-300 shadow-xs shadow-cyan-500/20'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-cyan-300 hover:border-slate-700'
            }`}
            title="Activar investigación inmobiliaria en vivo con Google Search (gemini-3.8-flash)"
          >
            <Globe className={`w-3.5 h-3.5 ${useGoogleSearch || selectedRole === 'realestate_researcher' ? 'text-cyan-400 animate-pulse' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">
              {useGoogleSearch || selectedRole === 'realestate_researcher' ? 'Investigación en Vivo' : 'Búsqueda en Vivo'}
            </span>
            <span className="sm:hidden">
              {useGoogleSearch || selectedRole === 'realestate_researcher' ? 'En Vivo' : 'Buscar'}
            </span>
          </button>

          {isAiSpeaking && (
            <button
              type="button"
              onClick={interruptSpeaking}
              className="px-2.5 py-1 rounded-lg bg-rose-950/80 border border-rose-500/40 text-rose-300 hover:bg-rose-900 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5"
              title="Detener voz de Lexi"
            >
              <Square className="w-3 h-3 fill-current" />
              <span>Silenciar</span>
            </button>
          )}

          {messages.length > 0 && (
            <button
              type="button"
              onClick={() => {
                if (window.confirm('¿Deseas vaciar la conversación?')) {
                  setMessages([]);
                }
              }}
              className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
              title="Limpiar conversación"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Audio Error Banner */}
      {audioError && (
        <div className="px-4 py-2 bg-rose-950/70 border-b border-rose-500/30 text-rose-200 text-xs flex items-center justify-between gap-2 shrink-0">
          <span>{audioError}</span>
          <button
            type="button"
            onClick={() => setAudioError(null)}
            className="text-rose-400 hover:text-white cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* 2. Main Conversation Thread */}
      <div ref={chatScrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* Welcome Empty State */}
        {messages.length === 0 && (
          <div className="h-full min-h-[360px] flex flex-col items-center justify-center text-center p-6 max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-slate-900/90 border border-cyan-500/40 flex items-center justify-center mb-4 shadow-lg shadow-cyan-500/10">
              <CyberParticleOrb
                size={54}
                status={voiceStatus}
                audioLevel={liveMicLevel}
                isVoiceDetected={isVoiceDetected}
                showControls={false}
              />
            </div>
            <h2 className="text-lg font-bold text-white mb-1.5">¿En qué te puedo ayudar?</h2>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed max-w-sm">
              Pregúntame cualquier duda, redacta documentos para Google Docs, genera tablas para Google Sheets o dicta con tu voz.
            </p>

            {/* Quick Action Suggestions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full text-left">
              {quickActions.slice(0, 6).map((qa, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    if ((qa as any).useSearch) {
                      setUseGoogleSearch(true);
                    }
                    if ((qa as any).role) {
                      setSelectedRole((qa as any).role);
                    }
                    if (qa.model) {
                      setSelectedModel(qa.model);
                    }
                    handleSendMessage(qa.prompt);
                  }}
                  className="p-3 rounded-xl border border-slate-800/90 bg-slate-900/60 hover:bg-slate-900 hover:border-cyan-500/40 transition-all text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <qa.icon className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors">
                      {qa.label.replace('⚡ ', '')}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                    {qa.prompt}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Message Thread */}
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${
              msg.role === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.role !== 'user' && (
              <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[88%] sm:max-w-[82%] rounded-2xl p-4 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white shadow-md rounded-tr-xs'
                  : msg.role === 'system'
                  ? 'bg-slate-900/80 text-emerald-300 border border-emerald-500/30 rounded-tl-xs'
                  : 'bg-slate-900/95 text-slate-100 border border-slate-800 shadow-md rounded-tl-xs'
              }`}
            >
              {/* Attachment Preview in Message Bubble */}
              {msg.attachment && (
                <div
                  className={`mb-3 p-2.5 rounded-xl flex items-center gap-2.5 ${
                    msg.role === 'user'
                      ? 'bg-blue-700/60 border border-blue-400/30'
                      : 'bg-slate-950 border border-slate-800'
                  }`}
                >
                  {msg.attachment.previewUrl ? (
                    <img
                      src={msg.attachment.previewUrl}
                      alt="Adjunto"
                      className="w-12 h-12 object-cover rounded-lg border border-white/20 bg-black/20 shrink-0"
                    />
                  ) : (
                    <div className="w-9 h-9 rounded-lg bg-blue-950 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-500/30">
                      <FileText className="w-5 h-5" />
                    </div>
                  )}
                  <div className="overflow-hidden text-xs">
                    <span className="font-semibold block truncate max-w-[220px]">
                      {msg.attachment.name}
                    </span>
                    <span
                      className={`text-[10px] ${
                        msg.role === 'user' ? 'text-blue-200' : 'text-slate-400'
                      }`}
                    >
                      {(msg.attachment.size / 1024).toFixed(1)} KB • {msg.attachment.type || 'Archivo'}
                    </span>
                  </div>
                </div>
              )}

              {/* Message Body Content with interactive URL previews */}
              <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm leading-relaxed">
                {(() => {
                  const urlRegex = /(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/g;
                  const parts = msg.content.split(urlRegex);
                  if (parts.length <= 1) return msg.content;
                  return parts.map((part, pIdx) => {
                    if (urlRegex.test(part)) {
                      return (
                        <a
                          key={pIdx}
                          href={part}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 underline font-medium mx-0.5"
                          title="Abrir en pestaña nueva"
                        >
                          <span>{part}</span>
                          <span className="text-[10px] text-slate-500 hover:text-cyan-300">↗</span>
                        </a>
                      );
                    }
                    return part;
                  });
                })()}
              </div>

              {/* If this is an error message, show an immediate Retry button */}
              {msg.id.startsWith('err-') && (
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const prevUserMsg = messages
                        .slice()
                        .reverse()
                        .find((m) => m.role === 'user');
                      if (prevUserMsg?.content) {
                        handleSendMessage(prevUserMsg.content);
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reintentar envío</span>
                  </button>
                </div>
              )}

              {/* Grounding Sources (Google Search) */}
              {msg.groundingSources && msg.groundingSources.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-slate-800 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold text-cyan-400">
                    <Globe className="w-3 h-3 text-cyan-400" />
                    <span>Fuentes de información ({msg.groundingSources.length}):</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {msg.groundingSources.map((source, sIdx) => (
                      <a
                        key={sIdx}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-950 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 text-[10px] font-medium transition-colors shadow-2xs group"
                        title={source.title || source.uri}
                      >
                        <ExternalLink className="w-2.5 h-2.5 text-cyan-400 group-hover:text-cyan-200" />
                        <span className="truncate max-w-[200px]">{source.title || source.uri}</span>
                        <span className="text-[9px] text-slate-500 group-hover:text-cyan-200">↗</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Clean Action Proposal Card (Google Docs / Google Sheets) */}
              {msg.actionProposal && (
                <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-cyan-500/30 text-slate-200 shadow-inner">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      {msg.actionProposal.type.startsWith('docs') ? (
                        <FileText className="w-4 h-4 text-blue-400" />
                      ) : (
                        <Table className="w-4 h-4 text-emerald-400" />
                      )}
                      {msg.actionProposal.title}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mb-2.5">
                    {msg.actionProposal.description}
                  </p>

                  {msg.actionProposal.status === 'executed' || msg.actionProposal.url ? (
                    <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">
                      <div className="flex items-center gap-1.5 font-semibold">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{msg.actionProposal.url ? 'Guardado en Google Workspace' : 'Documento Creado y Guardado'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {msg.actionProposal.url ? (
                          <div className="flex items-center gap-1.5 shrink-0">
                            <a
                              href={msg.actionProposal.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] shadow-sm transition-colors"
                            >
                              Abrir en Google Docs ↗
                            </a>
                            <button
                              type="button"
                              onClick={() => {
                                onNavigateOverlay?.('DOCS', 'Abriendo gestor de documentos...');
                              }}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-blue-900/60 hover:bg-blue-800 text-blue-300 border border-blue-500/30 text-[11px] transition-colors cursor-pointer"
                              title="Ver en Gestor de Documentos"
                            >
                              <FileText className="w-3 h-3" />
                              <span>Gestor Docs</span>
                            </button>
                          </div>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                onNavigateOverlay?.('DOCS', 'Abriendo gestor de documentos...');
                              }}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-blue-900/60 hover:bg-blue-800 text-blue-300 border border-blue-500/30 text-[11px] transition-colors cursor-pointer"
                              title="Ver en Gestor de Documentos"
                            >
                              <FileText className="w-3 h-3" />
                              <span>Gestor Docs</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const title = msg.actionProposal?.payload?.title || msg.actionProposal?.title || 'Documento';
                                const content = msg.actionProposal?.payload?.content || msg.content || '';
                                downloadDocAsFile(title, content);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-700/80 hover:bg-emerald-600 text-white font-semibold text-[11px] transition-colors cursor-pointer shadow-xs"
                              title="Descargar documento en Markdown (.md)"
                            >
                              <Download className="w-3 h-3" />
                              <span>Descargar (.md)</span>
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                try {
                                  const textToCopy = msg.actionProposal?.payload?.content || msg.content || '';
                                  await navigator.clipboard.writeText(textToCopy);
                                  setCopiedMsgId(msg.id);
                                  setTimeout(() => setCopiedMsgId(null), 2000);
                                } catch {}
                              }}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] transition-colors cursor-pointer"
                              title="Copiar texto del documento"
                            >
                              {copiedMsgId === msg.id ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-400" />
                                  <span className="text-emerald-400">Copiado</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3" />
                                  <span>Copiar</span>
                                </>
                              )}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-200 text-xs">
                      <div className="flex items-center gap-1.5 font-medium">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse shrink-0" />
                        <span>Generando y guardando documento automáticamente...</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Message Bottom Footer: Timestamp, Read Button (esquina inferior izquierda) & Clean Copy Button */}
              <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-2">
                  {/* Esquina inferior izquierda del mensaje: Botón para escuchar/leer en voz alta */}
                  {msg.role === 'assistant' && (
                    <button
                      id={`btn-read-msg-${msg.id}`}
                      type="button"
                      onClick={() => toggleReadMessage(msg.id, msg.content)}
                      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md transition-all cursor-pointer ${
                        speakingMsgId === msg.id
                          ? 'bg-cyan-950/90 text-cyan-300 border border-cyan-500/50 shadow-xs'
                          : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800/80 border border-transparent'
                      }`}
                      title={speakingMsgId === msg.id ? 'Detener lectura' : 'Leer este mensaje en voz alta'}
                    >
                      {speakingMsgId === msg.id ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-cyan-400" />
                          <span className="text-cyan-300 font-medium text-[11px]">Detener</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5" />
                          <span className="text-[11px]">Leer</span>
                        </>
                      )}
                    </button>
                  )}

                  <span>
                    {new Date(msg.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                {msg.role === 'assistant' && (
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(msg.content);
                        setCopiedMsgId(msg.id);
                        setTimeout(() => setCopiedMsgId(null), 2000);
                      } catch {
                        // ignore
                      }
                    }}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer transition-colors"
                    title="Copiar texto"
                  >
                    {copiedMsgId === msg.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copiado</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copiar</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

            {msg.role === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                <UserIcon className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {/* Clean Typing Indicator */}
        {isLoading && (
          <div className="flex gap-3 items-center">
            <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shadow-sm">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-center gap-2.5 shadow-sm">
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span>Lexi está respondiendo...</span>
            </div>
          </div>
        )}
      </div>

      {/* 3. Input Bar: Clean, Streamlined, No Redundant Buttons */}
      <div className="p-3.5 bg-slate-950 border-t border-cyan-500/20 shrink-0">
        {/* Attachment preview if selected */}
        {currentAttachment && (
          <div className="mb-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/30 flex items-center justify-between gap-2 text-xs text-slate-200">
            <div className="flex items-center gap-2 truncate">
              {currentAttachment.previewUrl ? (
                <img
                  src={currentAttachment.previewUrl}
                  alt="Adjunto"
                  className="w-7 h-7 object-cover rounded border border-cyan-500/30 shrink-0"
                />
              ) : (
                <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
              )}
              <span className="font-semibold truncate">{currentAttachment.name}</span>
              <span className="text-slate-400 text-[10px]">
                ({(currentAttachment.size / 1024).toFixed(1)} KB)
              </span>
            </div>
            <button
              type="button"
              onClick={() => setCurrentAttachment(null)}
              className="text-slate-400 hover:text-rose-400 p-1 rounded-md transition-colors cursor-pointer"
              title="Quitar archivo"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Live Research Active Banner */}
        {(useGoogleSearch || selectedRole === 'realestate_researcher') && (
          <div className="mb-2 px-3 py-1.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40 flex items-center justify-between gap-2 text-xs text-cyan-200">
            <div className="flex items-center gap-2 truncate">
              <Globe className="w-3.5 h-3.5 text-cyan-400 animate-pulse shrink-0" />
              <span className="font-semibold text-cyan-300">Investigación en Vivo con Google Search</span>
              <span className="text-slate-400 text-[11px] hidden sm:inline">
                (gemini-3.8-flash fundamentado con datos web en tiempo real)
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setUseGoogleSearch(false);
                setSelectedRole('executive');
                setSelectedModel('gemini-3.8-flash');
              }}
              className="text-cyan-400 hover:text-cyan-200 text-xs font-medium cursor-pointer underline decoration-cyan-500/40 shrink-0"
            >
              Desactivar
            </button>
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          {/* File Attachment input & button */}
          <input
            ref={chatFileInputRef}
            type="file"
            accept="image/*,application/pdf,text/plain,text/csv,text/markdown,application/json"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleChatFileSelect(e.target.files[0]);
              }
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => chatFileInputRef.current?.click()}
            title="Adjuntar archivo o imagen"
            className="p-2.5 rounded-xl border border-slate-800 bg-slate-900 text-slate-400 hover:text-white hover:border-cyan-500/40 transition-colors cursor-pointer shrink-0"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Single Voice Dictate Button */}
          <button
            id="btn-voice-dictate"
            type="button"
            onClick={handleDictatePrompt}
            title={
              isRecording
                ? 'Detener dictado por voz'
                : 'Dictar por voz'
            }
            className={`p-2.5 rounded-xl border transition-all cursor-pointer shrink-0 ${
              isRecording
                ? 'bg-rose-950/90 border-rose-500/80 text-rose-400 animate-pulse shadow-md shadow-rose-950'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/40'
            }`}
          >
            {isRecording ? <Square className="w-4 h-4 fill-current" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Text Input */}
          <div className="relative flex-1">
            <input
              id="input-chat-prompt"
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                currentAttachment
                  ? `Instrucciones para ${currentAttachment.name}...`
                  : isRecording
                  ? 'Escuchando tu voz... Habla ahora'
                  : 'Escribe un mensaje o instrucción a Lexi...'
              }
              disabled={isLoading}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30 transition-all"
            />
          </div>

          {/* Send Button */}
          <button
            id="btn-send-message"
            type="submit"
            disabled={(!inputText.trim() && !currentAttachment) || isLoading}
            className="p-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-medium disabled:opacity-30 disabled:hover:bg-cyan-600 shadow-sm transition-colors cursor-pointer shrink-0"
            title="Enviar mensaje"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
