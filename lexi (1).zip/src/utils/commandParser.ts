export type OverlayView =
  | 'ORB_ONLY'
  | 'CHAT_SIDEBAR'
  | 'SHEETS'
  | 'DOCS'
  | 'EXTRACTOR'
  | 'IMAGES'
  | 'REAL_ESTATE'
  | 'HISTORY'
  | 'CHAT'
  | 'PROFILE'
  | 'DATABASE'
  | 'COMMAND_PALETTE';

export interface CommandParseResult {
  isNavCommand: boolean;
  targetView?: OverlayView;
  feedbackMessage?: string;
  isCloseCommand?: boolean;
  isTurnOffMicCommand?: boolean;
}

/**
 * Normalizes speech text for robust intent recognition across accents and phrasing.
 */
function normalizeCommand(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove diacritics
    .replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, '')
    .trim();
}

/**
 * Detects voice commands intended to turn off the microphone and put the assistant/orb to sleep.
 * Matches: "adios", "adiós", "descansa", "descansar", "a descansar", "apagar micrófono", "apágate", etc.
 */
export function isTurnOffMicCommand(rawText: string): boolean {
  const text = normalizeCommand(rawText);
  if (!text) return false;

  const triggers = [
    'adios',
    'chao',
    'bye',
    'goodbye',
    'descansa',
    'descansar',
    'a descansar',
    've a descansar',
    'puedes descansar',
    'apagar microfono',
    'apaga el microfono',
    'apaga microfono',
    'apagar el microfono',
    'apagar micro',
    'apaga el micro',
    'apaga micro',
    'apagate',
    'apagar asistente',
    'apaga la asistente',
    'desactivar microfono',
    'desactiva el microfono',
    'desactiva microfono',
    'desactivar el microfono',
    'hasta luego',
    'hasta pronto',
    'buenas noches',
    'silencio',
    'mute',
    'mutear',
    'dormir',
    'a dormir',
    'ponte a dormir',
  ];

  return triggers.some(
    (t) =>
      text === t ||
      text.startsWith(t + ' ') ||
      text.endsWith(' ' + t) ||
      text === `lexi ${t}` ||
      text === `${t} lexi` ||
      text === `ok lexi ${t}` ||
      text === `oye lexi ${t}`
  );
}

/**
 * Detects if user utterance is a command to create/draft/generate a document, spreadsheet, or table.
 * If true, this must be sent to the AI executive engine, NOT treated as a view navigation command.
 */
export function isCreationRequest(rawText: string): boolean {
  const text = normalizeCommand(rawText);
  if (!text) return false;

  const createVerbs = [
    'crea',
    'crean',
    'crear',
    'haz',
    'hazme',
    'hacer',
    'redacta',
    'redactar',
    'redactame',
    'escribe',
    'escribir',
    'genera',
    'generar',
    'elabora',
    'elaborar',
    'arma',
    'armar',
    'prepara',
    'preparar',
    'produce',
    'producir',
    'disena',
    'nuevo',
    'nueva',
  ];

  const targetEntities = [
    'documento',
    'documentos',
    'doc',
    'docs',
    'google doc',
    'google docs',
    'informe',
    'reporte',
    'minuta',
    'resumen',
    'articulo',
    'guia',
    'memo',
    'carta',
    'analisis',
    'hoja',
    'hojas',
    'sheet',
    'sheets',
    'tabla',
    'tablas',
    'excel',
    'balance',
    'presupuesto',
    'plan',
    'estrategia',
  ];

  const pattern = new RegExp(
    `(^|\\b)(${createVerbs.join('|')})\\b.{0,30}\\b(${targetEntities.join('|')})\\b`,
    'i'
  );
  if (pattern.test(text)) return true;

  for (const v of createVerbs) {
    if (text.startsWith(v + ' ')) {
      for (const ent of targetEntities) {
        if (text.includes(ent)) return true;
      }
    }
  }

  return false;
}

/**
 * Parses user voice transcript or text query to detect navigation, overlay opening, or closing.
 */
export function parseVoiceNavigationCommand(rawText: string): CommandParseResult {
  const text = normalizeCommand(rawText);

  if (!text) {
    return { isNavCommand: false };
  }

  // 0. Voice command to turn off microphone & rest
  if (isTurnOffMicCommand(rawText)) {
    return {
      isNavCommand: true,
      isTurnOffMicCommand: true,
      feedbackMessage: 'Descansando. Micrófono apagado.',
    };
  }

  // 0.5 CRITICAL: Creation commands (documents, spreadsheets, reports) must NEVER be treated as navigation
  if (isCreationRequest(rawText)) {
    return { isNavCommand: false };
  }

  // 1. Close / Return to Orb Commands
  const closeTriggers = [
    'cerrar',
    'ocultar',
    'cerrar sidebar',
    'ocultar sidebar',
    'cerrar chat',
    'ocultar chat',
    'volver al orbe',
    'volver al orb',
    'volver',
    'regresar al orbe',
    'regresar',
    'salir',
    'minimizar',
    'quitar',
    'ir al orbe',
    'orbe central',
    'solo orbe',
    'pantalla completa',
    'modo minimalista',
    'limpiar pantalla',
    'close',
    'hide',
    'exit',
    'back',
    'return to orb',
    'home',
  ];

  if (closeTriggers.some((trigger) => text === trigger || text.startsWith(trigger + ' ') || text.endsWith(' ' + trigger))) {
    return {
      isNavCommand: true,
      isCloseCommand: true,
      targetView: 'ORB_ONLY',
      feedbackMessage: 'Volviendo al orbe central...',
    };
  }

  // 1.5. Sidebar con Chat (ej: "abre sidebar con chat", "abre el chat", "open chat")
  const sidebarChatTriggers = [
    'abre sidebar con chat',
    'abrir sidebar con chat',
    'abre el sidebar con chat',
    'abrir el sidebar con chat',
    'abre sidebar chat',
    'abrir sidebar chat',
    'abre sidebar',
    'abrir sidebar',
    'sidebar con chat',
    'sidebar chat',
    'sidebar',
    'barra lateral con chat',
    'barra lateral',
    'panel lateral con chat',
    'panel lateral',
    'chat lateral',
    'abrir chat en sidebar',
    'abre chat en sidebar',
    'abre el chat',
    'abrir el chat',
    'abre chat',
    'abrir chat',
    'mostrar chat',
    'ver chat',
    'chat con lexi',
    'open chat',
    'open sidebar',
    'open chat sidebar',
    'show chat',
  ];
  if (sidebarChatTriggers.some((t) => text === t || text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'CHAT_SIDEBAR',
      feedbackMessage: 'Abriendo sidebar con chat...',
    };
  }

  // 2. Google Sheets View Navigation
  const sheetsTriggers = [
    'abrir google sheets',
    'abrir sheets',
    'mostrar google sheets',
    'mostrar sheets',
    'ir a google sheets',
    'ir a sheets',
    'ver sheets',
    'ver google sheets',
    'gestor de sheets',
  ];
  if (
    sheetsTriggers.some(
      (t) => text === t || text.startsWith(t + ' ') || text.endsWith(' ' + t) || text.includes(t)
    ) ||
    text === 'google sheets' ||
    text === 'sheets' ||
    text === 'hojas de calculo' ||
    text === 'hoja de calculo'
  ) {
    return {
      isNavCommand: true,
      targetView: 'SHEETS',
      feedbackMessage: 'Abriendo Google Sheets...',
    };
  }

  // 3. Google Docs View Navigation
  const docsTriggers = [
    'abrir google docs',
    'abrir docs',
    'ver documentos',
    'ver google docs',
    'mostrar documentos',
    'mostrar google docs',
    'ir a google docs',
    'ir a docs',
    'gestor de docs',
    'mis documentos',
  ];
  if (
    docsTriggers.some(
      (t) => text === t || text.startsWith(t + ' ') || text.endsWith(' ' + t) || text.includes(t)
    ) ||
    text === 'google docs' ||
    text === 'docs' ||
    text === 'documentos' ||
    text === 'documentos de google'
  ) {
    return {
      isNavCommand: true,
      targetView: 'DOCS',
      feedbackMessage: 'Abriendo Google Docs...',
    };
  }

  // 4. Command History
  const historyTriggers = [
    'mostrar historial',
    'abrir historial',
    'ver historial',
    'ir al historial',
    'historial de comandos',
    'registro de comandos',
    'mis comandos',
    'comandos anteriores',
    'historial',
  ];
  if (historyTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'HISTORY',
      feedbackMessage: 'Desplegando historial de comandos...',
    };
  }

  // 5. Image Studio
  const imagesTriggers = [
    'ir al estudio de imagenes',
    'abrir estudio de imagenes',
    'estudio de imagenes',
    'abrir imagenes',
    'ver imagenes',
    'generador de imagenes',
    'generar imagen',
    'estudio de fotos',
    'crear imagen',
    'imagenes ia',
  ];
  if (imagesTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'IMAGES',
      feedbackMessage: 'Abriendo Estudio de Imágenes...',
    };
  }

  // 6. Extractor Studio
  const extractorTriggers = [
    'abrir extractor',
    'extractor ia',
    'extractor de documentos',
    'extraer documentos',
    'analizar pdf',
    'escanear documentos',
    'subir archivos',
    'extractor multidocumento',
    'ir al extractor',
  ];
  if (extractorTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'EXTRACTOR',
      feedbackMessage: 'Abriendo Extractor Multidocumento...',
    };
  }

  // 7. Real Estate CRM
  const realEstateTriggers = [
    'ficha inmobiliaria',
    'fichas inmobiliarias',
    'real estate',
    'crm inmobiliario',
    'inmobiliaria',
    'propiedades',
    'ficha tecnica inmobiliaria',
    'ficha tecnica',
    'bienes raices',
  ];
  if (realEstateTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'REAL_ESTATE',
      feedbackMessage: 'Abriendo Fichas Inmobiliarias...',
    };
  }

  // 8. Database / Supabase / Firestore
  const databaseTriggers = [
    'configurar supabase',
    'abrir supabase',
    'conectar supabase',
    'supabase',
    'base de datos',
    'permanencia de datos',
    'configurar base de datos',
    'firestore',
    'estado de la base de datos',
  ];
  if (databaseTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'DATABASE',
      feedbackMessage: 'Abriendo configuración de Supabase y Base de Datos...',
    };
  }

  // 9. Profile & Noise Gate
  const profileTriggers = [
    'configurar perfil',
    'perfil de voz',
    'calibrar microfono',
    'filtro de ruido',
    'mis perfiles',
    'ajustes de voz',
    'perfil',
  ];
  if (profileTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'PROFILE',
      feedbackMessage: 'Abriendo Perfil de Voz y Calibración...',
    };
  }

  // 10. Chat / Conversation Thread
  const chatTriggers = [
    'abrir chat',
    'mostrar chat',
    'ver conversacion',
    'ver respuestas',
    'hilo de mensajes',
    'conversacion',
    'chat con lexi',
  ];
  if (chatTriggers.some((t) => text.includes(t))) {
    return {
      isNavCommand: true,
      targetView: 'CHAT',
      feedbackMessage: 'Abriendo conversación con Lexi...',
    };
  }

  // 12. Command Palette / Help
  const paletteTriggers = [
    'comandos',
    'abrir comandos',
    'menu de comandos',
    'panel de comandos',
    'mostrar comandos',
    'buscar panel',
    'atajos',
    'ayuda',
  ];
  if (paletteTriggers.some((t) => text === t || text === 'abrir ' + t)) {
    return {
      isNavCommand: true,
      targetView: 'COMMAND_PALETTE',
      feedbackMessage: 'Desplegando panel de comandos...',
    };
  }

  return { isNavCommand: false };
}
