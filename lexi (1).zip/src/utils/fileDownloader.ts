/**
 * Utility to download markdown or text files directly in the browser
 */
export function downloadMarkdownFile(title: string, content: string): void {
  const safeName = (title || 'nota').replace(/[/\\?%*:|"<>]/g, '-').trim();
  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${safeName}.md`;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    document.body.removeChild(link);
  }, 100);
}
