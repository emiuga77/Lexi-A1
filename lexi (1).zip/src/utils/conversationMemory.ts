/**
 * Continuous Conversation Memory Engine for Lexi Assistant
 * Implements a rolling window of the last 10 messages for high-speed, direct dialogue,
 * combined with an automatic executive summary of older key requests, decisions, and agreements.
 */

export interface MessagePayloadItem {
  role: 'user' | 'assistant' | 'system';
  content: string;
  attachment?: {
    name: string;
    type: string;
    data: string;
  };
}

export interface CompactMemoryResult {
  windowedMessages: MessagePayloadItem[];
  accumulatedContextBlock: string;
  totalTurns: number;
}

/**
 * Builds a lean, high-speed message payload preserving full context without latency spikes
 */
export function buildContinuousMemoryPayload(
  allMessages: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    attachment?: { name: string; type: string; data: string };
  }>,
  maxRecentTurns: number = 10
): CompactMemoryResult {
  if (!allMessages || allMessages.length === 0) {
    return {
      windowedMessages: [],
      accumulatedContextBlock: '',
      totalTurns: 0,
    };
  }

  // Filter out system transient notices
  const conversational = allMessages.filter((m) => m.role === 'user' || m.role === 'assistant');

  // If conversation is within the 10-message window, send everything directly
  if (conversational.length <= maxRecentTurns) {
    return {
      windowedMessages: conversational.map((m, idx) => ({
        role: m.role,
        content: m.content,
        // Only keep attachments on the very last turn to keep payload light
        attachment: idx === conversational.length - 1 ? m.attachment : undefined,
      })),
      accumulatedContextBlock: '',
      totalTurns: conversational.length,
    };
  }

  // Split into older history and the rolling 10-turn window
  const olderMessages = conversational.slice(0, conversational.length - maxRecentTurns);
  const recentMessages = conversational.slice(conversational.length - maxRecentTurns);

  // Extract core requests and key points from older dialogue
  const keyMemoryBullets: string[] = [];
  for (const m of olderMessages) {
    const raw = (m.content || '')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/[\n\r]+/g, ' ')
      .trim();
    if (!raw) continue;

    if (m.role === 'user') {
      const snippet = raw.length > 130 ? raw.slice(0, 130) + '...' : raw;
      keyMemoryBullets.push(`- Usuario solicitó: "${snippet}"`);
    } else if (m.role === 'assistant') {
      const snippet = raw.length > 130 ? raw.slice(0, 130) + '...' : raw;
      keyMemoryBullets.push(`- Acordado con Lexi: "${snippet}"`);
    }
  }

  // Keep the most salient items (up to 8 points)
  const consolidated = keyMemoryBullets.slice(-8);

  const accumulatedContextBlock =
    consolidated.length > 0
      ? `\n[MEMORIA CLAVE CONTINUA DE TURNOS PREVIOS]\n` +
        `Los siguientes temas y acuerdos se trataron con anterioridad en esta sesión:\n` +
        consolidated.join('\n') +
        `\n(Ten en cuenta este contexto sin repetir lo que ya se dijo y mantén la coherencia total)\n`
      : '';

  const windowedMessages: MessagePayloadItem[] = recentMessages.map((m, idx) => ({
    role: m.role,
    content: m.content,
    attachment: idx === recentMessages.length - 1 ? m.attachment : undefined,
  }));

  return {
    windowedMessages,
    accumulatedContextBlock,
    totalTurns: conversational.length,
  };
}
