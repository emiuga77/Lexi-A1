/**
 * Human Voice Synthesis & Anti-Echo Utilities for Lexi Assistant
 */

let cachedBestVoice: SpeechSynthesisVoice | null = null;
let lastSpokenText: string = '';
let lastSpokenTimestamp: number = 0;

/**
 * Normalizes text for comparison (lowercase, unaccented, stripped punctuation)
 */
export function normalizeVoiceText(text: string): string {
  return (text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[.,/#!$%^&*;:{}=\-_`~()¿?¡!"[\]|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const PINNED_VOICE_KEY_PREFIX = 'lexi_pinned_voice_uri_';
if (typeof window !== 'undefined') {
  (window as any).__activeUtterances = (window as any).__activeUtterances || [];
}

/**
 * Prevents Chromium V8 garbage collector from prematurely killing ongoing utterances
 */
export function protectUtterance(utterance: SpeechSynthesisUtterance) {
  if (typeof window !== 'undefined') {
    (window as any).__activeUtterances.push(utterance);
    const cleanup = () => {
      const list = (window as any).__activeUtterances;
      if (Array.isArray(list)) {
        const idx = list.indexOf(utterance);
        if (idx !== -1) list.splice(idx, 1);
      }
    };
    utterance.onend = cleanup;
    utterance.onerror = cleanup;
  }
}

/**
 * Finds and pins the most natural, human-sounding Spanish voice available on the device.
 * Once chosen, the voice is locked and will NEVER switch randomly during conversation.
 */
export function findBestNaturalVoice(preferredLang: string = 'es-ES'): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return null;
  }

  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) {
    return cachedBestVoice;
  }

  const langCode = preferredLang.toLowerCase().slice(0, 2); // 'es'
  const storageKey = PINNED_VOICE_KEY_PREFIX + langCode;

  // 1. Check if we already pinned a specific voice for this language
  try {
    const pinnedUri = localStorage.getItem(storageKey);
    if (pinnedUri) {
      const match = voices.find((v) => v.voiceURI === pinnedUri);
      if (match) {
        cachedBestVoice = match;
        return match;
      }
    }
  } catch (_) {}

  // 2. If already cached in memory during this session, keep using it
  if (cachedBestVoice && voices.some((v) => v.voiceURI === cachedBestVoice?.voiceURI)) {
    return cachedBestVoice;
  }

  const spanishVoices = voices.filter((v) => v.lang.toLowerCase().startsWith(langCode));

  if (spanishVoices.length === 0) {
    return voices[0] || null;
  }

  // Priority scoring system for highest fidelity human/neural voices (favoring warm female tones for Lexi)
  const scored = spanishVoices.map((v) => {
    let score = 0;
    const name = v.name.toLowerCase();
    const lang = v.lang.toLowerCase();

    // 1. Natural / Neural / Online engine priority (+120)
    if (name.includes('natural') || name.includes('neural') || name.includes('online')) {
      score += 120;
    }

    // 2. Google High-Quality Spanish voices (+100)
    if (name.includes('google') || name.includes('español')) {
      score += 100;
    }

    // 3. Apple Enhanced / Siri neural voices (+95)
    if (name.includes('siri') || name.includes('enhanced') || name.includes('premium')) {
      score += 95;
    }

    // 4. Renowned high-quality female voice profiles (Lexi persona)
    const femaleVoiceNames = [
      'sabina',
      'dalia',
      'helena',
      'paulina',
      'monica',
      'paloma',
      'mia',
      'sofi',
      'sofia',
      'lupe',
      'rosa',
      'camila',
      'lucia',
      'alva',
      'elena',
    ];
    if (femaleVoiceNames.some((n) => name.includes(n))) {
      score += 85;
    }

    // 5. Dialect alignment (es-MX, es-ES, es-US, es-419)
    if (lang === preferredLang.toLowerCase()) {
      score += 30;
    } else if (lang.includes('es-mx') || lang.includes('es-419') || lang.includes('es-es')) {
      score += 15;
    }

    // 6. Prefer default or remote natural voices over generic local synthetic ones
    if (!v.localService) {
      score += 25;
    }

    return { voice: v, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const selectedVoice = scored[0]?.voice || spanishVoices[0];
  cachedBestVoice = selectedVoice;

  // Pin this voice permanently so it never changes mid-session or on re-renders
  try {
    if (selectedVoice?.voiceURI) {
      localStorage.setItem(storageKey, selectedVoice.voiceURI);
    }
  } catch (_) {}

  return selectedVoice;
}

// Pre-warm voices on initialization
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    findBestNaturalVoice();
  };
}

/**
 * Prepares raw text to sound articulate, warm, and natural when spoken aloud
 */
export function prepareTextForHumanSpeech(rawText: string, maxLength: number = 420): string {
  if (!rawText) return '';

  let text = rawText
    // Remove code blocks and workspace actions
    .replace(/```workspace_action[\s\S]*?```/gi, '')
    .replace(/```[\s\S]*?```/g, '')
    // Remove links and markdown syntax
    .replace(/https?:\/\/\S+/gi, '')
    .replace(/[#*`~>[\]()|]/g, '')
    // Expand conversational abbreviations to natural spoken words
    .replace(/\bm²\b/gi, ' metros cuadrados')
    .replace(/\bkm\/h\b/gi, ' kilómetros por hora')
    .replace(/\bkm\b/gi, ' kilómetros')
    .replace(/\bUSD\b/gi, ' dólares')
    .replace(/\bMXN\b/gi, ' pesos')
    .replace(/\bEUR\b/gi, ' euros')
    .replace(/\bej\.\b/gi, ' por ejemplo, ')
    .replace(/\betc\.\b/gi, ' etcétera')
    .replace(/\bvs\.?\b/gi, ' frente a ')
    .replace(/\bKPIs?\b/gi, ' indicadores clave ')
    .replace(/\bROI\b/gi, ' retorno de inversión ')
    .replace(/%/g, ' por ciento ')
    // Normalize punctuation for smooth breathing pauses
    .replace(/\.{2,}/g, '.')
    .replace(/[\n\r]+/g, '. ')
    .replace(/\s+/g, ' ')
    .trim();

  // If text exceeds maxLength, gracefully cut at the end of the last complete sentence
  if (text.length > maxLength) {
    const truncated = text.slice(0, maxLength);
    const lastPeriod = Math.max(truncated.lastIndexOf('.'), truncated.lastIndexOf('!'), truncated.lastIndexOf('?'));
    if (lastPeriod > 100) {
      text = truncated.slice(0, lastPeriod + 1);
    } else {
      text = truncated.trim() + '...';
    }
  }

  return text;
}

/**
 * Records assistant's spoken output for anti-echo detection
 */
export function recordSpokenSpeech(text: string) {
  lastSpokenText = normalizeVoiceText(text);
  lastSpokenTimestamp = Date.now();
}

/**
 * Checks if a candidate voice input is an echo/reflection of what the assistant just spoke
 */
export function isAssistantEcho(candidate: string): boolean {
  if (!candidate || !lastSpokenText) return false;

  // Echo window: within 3.5 seconds after speaking finished
  const elapsed = Date.now() - lastSpokenTimestamp;
  if (elapsed > 4000) return false;

  const normCandidate = normalizeVoiceText(candidate);
  if (normCandidate.length < 3) return true; // Discard tiny trailing audio blurps right after speaking

  // Direct substring match in last spoken text
  if (lastSpokenText.includes(normCandidate)) {
    return true;
  }

  // Check word overlap: if candidate words are all contained in the assistant's previous phrase
  const candidateWords = normCandidate.split(' ').filter((w) => w.length > 2);
  if (candidateWords.length === 0) return true;

  let matchedWords = 0;
  for (const word of candidateWords) {
    if (lastSpokenText.includes(word)) {
      matchedWords++;
    }
  }

  // If more than 65% of words are directly from assistant's own speech, it's an echo!
  if (candidateWords.length > 0 && matchedWords / candidateWords.length >= 0.65) {
    return true;
  }

  return false;
}

/**
 * Checks if a candidate voice input is an explicit interruption command.
 * Strictly enforces that ONLY phrases addressing "Lexi" (e.g., "Lexi", "Oye Lexi", "Para Lexi", "Alto Lexi", "Espera Lexi")
 * are permitted to interrupt the assistant, preventing accidental room noise cutoffs.
 */
export function isBargeInInterrupt(candidate: string): boolean {
  if (!candidate) return false;
  const norm = normalizeVoiceText(candidate);
  
  // Must explicitly mention 'lexi'
  if (!norm.includes('lexi')) {
    return false;
  }

  // Interruption triggers with Lexi
  const lexiTriggers = [
    'lexi',
    'oye lexi',
    'para lexi',
    'lexi para',
    'alto lexi',
    'lexi alto',
    'espera lexi',
    'lexi espera',
    'detente lexi',
    'lexi detente',
    'silencio lexi',
    'lexi silencio',
    'stop lexi',
    'lexi stop',
    'pausa lexi',
    'lexi pausa',
  ];

  return lexiTriggers.some((phrase) => norm === phrase || norm.startsWith(phrase + ' ') || norm.endsWith(' ' + phrase));
}

/**
 * Checks if the user explicitly called out "Lexi" while assistant is speaking
 */
export function hasLexiKeyword(candidate: string): boolean {
  if (!candidate) return false;
  const norm = normalizeVoiceText(candidate);
  return norm.includes('lexi');
}
